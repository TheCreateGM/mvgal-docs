#!/bin/bash
# MVGAL PolicyKit Execution Helper
# 
# This script provides a unified interface for all privileged MVGAL operations.
# It is called via pkexec to ensure secure privilege escalation.
#
# Usage: pkexec /usr/lib/mvgal/mvgal-pkexec-helper.sh <action> [args...]
#
# Actions:
#   load-module       - Load all MVGAL kernel modules (combined mvgal.ko)
#   unload-module     - Unload all MVGAL kernel modules
#   enable-gpu N      - Enable GPU at index N
#   disable-gpu N     - Disable GPU at index N
#   set-power GPU STATE - Set GPU power state (auto, on, off)
#   rescan-gpus       - Rescan for GPU changes
#   reload-config     - Reload MVGAL configuration
#   install-vulkan-layer - Install Vulkan implicit layer
#   remove-vulkan-layer  - Remove Vulkan implicit layer
#   install-mtt-driver   - Run the Moore Threads DKMS installer
#
# Copyright (C) 2026 MVGAL Project
# SPDX-License-Identifier: MIT

set -e

LOG_FILE="/var/log/mvgal-pkexec.log"
MVGAL_CONFIG="/etc/mvgal/mvgal.conf"

# Parse global options before the action so callers can route config writes
# to a non-default file:
#   pkexec mvgal-pkexec-helper.sh --config /etc/mvgal/other.conf set-strategy hybrid
#
# SECURITY: this helper runs as root, so an unconstrained --config is a
# privilege-escalation primitive — a local user could ask polkit for one
# authorised action and have root sed-edit any path, e.g.
# /etc/sudoers.d/x or /etc/pam.d/sshd.  The path is therefore pinned to a
# regular file inside MVGAL's own config directory: no symlinks, no
# traversal, no foreign directories, and no root-owned path that is not a
# *.conf there.
MVGAL_CONFIG_DIR="/etc/mvgal"
while [ $# -gt 0 ]; do
    case "$1" in
        -c|--config)
            if [ $# -lt 2 ]; then
                echo "Error: --config requires a path" >&2
                exit 1
            fi
            case "$2" in
                *[!A-Za-z0-9_./-]*|"")
                    echo "Error: invalid config path: $2" >&2
                    exit 1
                    ;;
            esac
            case "$2" in
                "$MVGAL_CONFIG_DIR"/*.conf) ;;
                *)
                    echo "Error: --config must name a *.conf file inside $MVGAL_CONFIG_DIR: $2" >&2
                    exit 1
                    ;;
            esac
            # Resolve symlinks first: $2 may still be a link pointing outside.
            # realpath -e fails for a non-existent file, which is then reported
            # by the set_config_value "Config file not found" path below.
            if command -v realpath >/dev/null 2>&1; then
                resolved="$(realpath -e -- "$2" 2>/dev/null || true)"
                [ -n "$resolved" ] || resolved="$2"
            else
                resolved="$2"
            fi
            case "$resolved" in
                "$MVGAL_CONFIG_DIR"/*.conf)
                    if [ ! -e "$resolved" ]; then
                        echo "Error: --config file does not exist: $2" >&2
                        exit 1
                    fi
                    if [ -L "$2" ] || [ ! -f "$resolved" ]; then
                        echo "Error: --config must be an existing regular file, not a symlink or device: $2" >&2
                        exit 1
                    fi
                    ;;
                *)
                    echo "Error: --config resolves outside $MVGAL_CONFIG_DIR: $2" >&2
                    exit 1
                    ;;
            esac
            MVGAL_CONFIG="$resolved"
            shift 2
            ;;
        *)
            break
            ;;
    esac
done

ACTION="${1:-}"

# Logging function
log() {
    # M8 FIX: the log was created 0644 (world-readable) and records the
    # command lines it is asked to run plus the configuration values it
    # writes.  That is more than a local user needs to see.  Create it
    # 0640 root:mvgal so the group can read it (it is the diagnostic users
    # are pointed at) and nobody else can.
    touch "$LOG_FILE" 2>/dev/null || :
    chmod 640 "$LOG_FILE" 2>/dev/null || :
    chgrp mvgal "$LOG_FILE" 2>/dev/null || :
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $*" >> "$LOG_FILE"
}

# Error handler
error_exit() {
    log "ERROR: $1"
    echo "Error: $1" >&2
    exit 1
}

# Print a hint when a module load failure is likely caused by Secure Boot
# rejecting the unsigned/un-enrolled module signature (test report C1).
secure_boot_hint() {
    if command -v mokutil >/dev/null 2>&1 && mokutil --sb-state 2>/dev/null | grep -qi "enabled"; then
        echo "Secure Boot is enabled. If the module signature was rejected, enroll the" >&2
        echo "MVGAL signing key in the MOK database and reboot:" >&2
        echo "    pkexec mvgal-enroll-mok" >&2
        echo "    pkexec reboot" >&2
        echo "(The certificate is /var/lib/mvgal/keys/mvgal-signing.der)" >&2
    fi
}

# Check if running with elevated privileges
check_privileges() {
    if [ "$(id -u)" -ne 0 ]; then
        error_exit "This operation requires root privileges"
    fi
}

# Reject anything that is not a plain non-negative GPU index, and publish the
# validated value in GPU_INDEX (a global, not stdout: error_exit must terminate
# the whole helper, which it cannot do from inside a command substitution).
#
# The index is used unquoted in a sed *address* ("/^\[gpu_$idx\]/,/^\[/{...}")
# and to build a sysfs path, so a value like "0]/,/^\[core" or "../../etc" would
# let an unprivileged polkit caller redirect a root-privileged rewrite at
# arbitrary config sections or paths (test report [M2]).  Digits only, no
# leading zeros, no sign, no whitespace, bounded by the number of GPUs the
# kernel actually exposes.
GPU_INDEX=""
validate_gpu_index() {
    local idx="${1:-}"
    local d suffix max=-1

    if [ -z "$idx" ]; then
        error_exit "GPU index required"
    fi
    case "$idx" in
        *[!0-9]*)
            error_exit "Invalid GPU index: '$idx' (must be a non-negative integer)"
            ;;
    esac
    # Reject "0", "00", "007" — canonical decimal only, so the same GPU cannot
    # be addressed by two different config section names.  The length bound
    # also keeps the $((10#...)) below away from integer overflow, which would
    # otherwise turn a 21-digit index into a bogus "leading zeros" message.
    if [ "${#idx}" -gt 3 ]; then
        error_exit "GPU index $idx out of range (must be 0-999)"
    fi
    if [ "$idx" != "$((10#$idx))" ]; then
        error_exit "Invalid GPU index: '$idx' (must be written without leading zeros)"
    fi

    # Bound the index to the GPUs the kernel module has actually published, so
    # a typo cannot silently create a phantom [gpu_99] section.  An absent
    # sysfs tree means the module is not loaded; leave the range check to the
    # caller's own "not found" handling rather than guessing.
    for d in /sys/class/mvgal/mvgal0/gpu*; do
        [ -d "$d" ] || continue
        suffix="${d##*gpu}"
        case "$suffix" in
            ''|*[!0-9]*) continue ;;
        esac
        max="$suffix"
    done
    if [ "$max" -ge 0 ] && [ "$idx" -gt "$max" ]; then
        error_exit "GPU index $idx out of range: the kernel module exposes gpu0..gpu$max"
    fi

    GPU_INDEX="$idx"
}

# Resolve the shared MVGAL module inventory.  This helper used to carry its own
# hard-coded lists, and they disagreed both with mvgal-load and with each other:
# loading listed mvgal BEFORE its dependency mvgal_ntsync, and neither the load
# nor the unload list mentioned mvgal_mtt or mvgal_adreno (test report [N2][N3]).
# config/mvgal-modules.sh is the single source of truth and is installed next to
# this helper as /usr/lib/mvgal/modules.sh.
MVGAL_MODULE_LIST="${MVGAL_MODULE_LIST:-}"
if [ -z "$MVGAL_MODULE_LIST" ]; then
    for _mvgal_cand in \
        /usr/lib/mvgal/modules.sh \
        "$(dirname "$0")/modules.sh" \
        "$(dirname "$0")/../../config/mvgal-modules.sh"
    do
        if [ -r "$_mvgal_cand" ]; then
            MVGAL_MODULE_LIST="$_mvgal_cand"
            break
        fi
    done
fi
if [ -r "$MVGAL_MODULE_LIST" ]; then
    . "$MVGAL_MODULE_LIST"
fi
if [ -z "${MVGAL_MODULES:-}" ]; then
    log "Warning: $MVGAL_MODULE_LIST not readable; using built-in module list."
    MVGAL_MODULES="mvgal_ntsync mvgal mvgal_nvidia mvgal_amd mvgal_intel mvgal_mtt mvgal_adreno"
fi
# Load order comes straight from the shared list (dependencies first).
MVGAL_LOAD_ORDER=($MVGAL_MODULES)
# Unload order is that list reversed.
MVGAL_UNLOAD_ORDER=()
for _mvgal_mod in $MVGAL_MODULES; do
    MVGAL_UNLOAD_ORDER=("$_mvgal_mod" ${MVGAL_UNLOAD_ORDER[@]+"${MVGAL_UNLOAD_ORDER[@]}"})
done
unset _mvgal_cand _mvgal_mod

# Load kernel module
load_module() {
    log "Loading MVGAL kernel modules"

    local MODULE_DIR="/usr/lib/modules/$(uname -r)/kernel/drivers/gpu/drm/mvgal"

    for MODULE in "${MVGAL_LOAD_ORDER[@]}"; do
        if lsmod | grep -q "^${MODULE} "; then
            log "Module $MODULE already loaded"
            continue
        fi

        # Try modprobe first (preferred).  modprobe honours modules.dep and
        # the kernel's own decompressor, so it is the only one of the three
        # paths that can load a .ko.xz.  Keep its stderr: it is the only
        # evidence of WHY the load failed, and the whole point of the
        # classification below is to stop guessing.
        local MODPROBE_OUT=""
        if MODPROBE_OUT="$(modprobe "${MODULE}" 2>&1)"; then
            log "Module $MODULE loaded via modprobe"
            continue
        fi
        log "modprobe $MODULE failed: $MODPROBE_OUT"

        # Fallback to insmod.  Ask modinfo where the module actually lives
        # (handles DKMS and the kernel tree) before guessing a path, and check
        # both /lib/modules and /usr/lib/modules because the two spellings
        # differ across distros and rpm usrmerge.
        local MODULE_PATH
        MODULE_PATH="$(modinfo -n "${MODULE}" 2>/dev/null)"
        if [ -z "$MODULE_PATH" ] || [ "$MODULE_PATH" = "(builtin)" ]; then
            MODULE_PATH=""
            for _d in "$MODULE_DIR" "/lib/modules/$(uname -r)/kernel/drivers/gpu/drm/mvgal"; do
                if [ -f "${_d}/${MODULE}.ko" ]; then
                    MODULE_PATH="${_d}/${MODULE}.ko"
                    break
                fi
            done
        fi

        # modinfo can legitimately return a COMPRESSED module
        # (mvgal_ntsync.ko.xz on a compression-enabled distro).  insmod
        # cannot load that: it hands the file straight to the kernel, which
        # rejects it with EINVAL / "Invalid parameters" because insmod does
        # not decompress.  Decompress to a temporary plain .ko and load that.
        local INSMOD_TARGET="$MODULE_PATH" TMPDIR_M=""
        if [ -n "$MODULE_PATH" ]; then
            case "$MODULE_PATH" in
                *.ko.xz|*.ko.zst)
                    if command -v xz >/dev/null 2>&1 && command -v zstd >/dev/null 2>&1; then
                        TMPDIR_M="$(mktemp -d /tmp/mvgal-load.XXXXXX)"
                        local PLAIN="${TMPDIR_M}/${MODULE}.ko"
                        if xz -dc "$MODULE_PATH" > "$PLAIN" 2>/dev/null \
                           || zstd -q -dc "$MODULE_PATH" > "$PLAIN" 2>/dev/null; then
                            INSMOD_TARGET="$PLAIN"
                            log "Module $MODULE is compressed; decompressed to $PLAIN for insmod"
                        else
                            rm -rf "$TMPDIR_M"; TMPDIR_M=""
                            INSMOD_TARGET=""
                        fi
                    fi
                    ;;
            esac
        fi

        if [ -n "$INSMOD_TARGET" ]; then
            local INSMOD_OUT=""
            if INSMOD_OUT="$(insmod "$INSMOD_TARGET" 2>&1)"; then
                log "Module $MODULE loaded via insmod from $INSMOD_TARGET"
                [ -n "$TMPDIR_M" ] && rm -rf "$TMPDIR_M"
                continue
            fi
            MODPROBE_OUT="$MODPROBE_OUT $INSMOD_OUT"
        fi
        [ -n "$TMPDIR_M" ] && rm -rf "$TMPDIR_M"

        # Classify the failure.  Telling the user to enroll the MOK when the
        # real problem is the module's compression sends them down a dead
        # end: enrollment cannot fix a module the kernel cannot decompress,
        # because that check happens first.
        if printf '%s' "$MODPROBE_OUT" | grep -qiE 'key was rejected|unavailable key|signature|invalid signature|not signed'; then
            secure_boot_hint
            error_exit "Failed to load $MODULE: the kernel rejected the module signature. Enroll the MVGAL key (above) and reboot."
        fi
        if printf '%s' "$MODPROBE_OUT" | grep -qiE 'invalid parameters|decompression|compressed'; then
            error_exit "Failed to load $MODULE: the kernel could not decompress it (\"Invalid parameters\"). This is a module-format problem, NOT a Secure Boot problem -- enrolling the MOK will NOT fix it. Re-sign the modules with: sudo /usr/lib/mvgal/mvgal-sign-modules.sh"
        fi
        if printf '%s' "$MODPROBE_OUT" | grep -qiE 'no such file|not found|cannot find'; then
            error_exit "Failed to load $MODULE: the module was not found for kernel $(uname -r). It may not be built or installed for this kernel."
        fi

        secure_boot_hint
        error_exit "Failed to load $MODULE. Check dmesg for details. (modprobe said: ${MODPROBE_OUT:-no output})"
    done

    # C3 FIX: Set device node permissions — group-writable only (not world-writable).
    # Was 'root:video' but the daemon and CLI tools use the 'mvgal' group.
    # Users in 'video' but not 'mvgal' were locked out of /dev/mvgal0 despite
    # being members of the video group (test report C3).
    for dev in /dev/mvgal*; do
        if [ -e "$dev" ]; then
            chown root:mvgal "$dev" 2>/dev/null || true
            chmod 660 "$dev" 2>/dev/null || true
        fi
    done

    log "All MVGAL modules loaded successfully"
    echo "MVGAL kernel modules loaded successfully"
}

# Print every MVGAL module that is stuck in the kernel's GOING state
# (state "Unloading" or a negative refcount).  A module in that state
# cannot be removed or reloaded at all: delete_module() already ran and
# the only recovery is a reboot.  Checking only the core `mvgal` module
# missed a wedged vendor shim or mvgal_ntsync, which fails the unload just
# the same (test report issue A).
mvgal_wedged_modules() {
    awk -v mods="$MVGAL_MODULES" '
        BEGIN { n = split(mods, a, " "); for (i = 1; i <= n; i++) want[a[i]] = 1 }
        ($1 in want) && ($5 == "Unloading" || $3 + 0 < 0) {
            print $1 " " $5 " refcount " $3
        }' /proc/modules
}

# Unload kernel module
unload_module() {
    log "Unloading MVGAL kernel modules"

    # C1: a module already stuck in the kernel's GOING state cannot be
    # removed or reloaded at all.  delete_module() has already run, the
    # refcount is negative and the device node returns ENXIO.  Detect it up
    # front and tell the user the truth (reboot required) instead of
    # producing another confusing "still in use" failure.
    local wedge
    wedge=$(mvgal_wedged_modules)
    if [ -n "$wedge" ]; then
        echo "MVGAL module(s) stuck in the kernel:" >&2
        echo "$wedge" >&2
        echo "Reboot required: the kernel cannot remove or reload a module" >&2
        echo "in the Unloading state." >&2
        error_exit "A previous unload was interrupted while the kernel was waiting for a module's reference count to drop."
    fi

    # Stop the packaged unit, not the `mvgald` alias: journalctl and
    # `systemctl is-active` do not resolve aliases on every systemd version,
    # and the alias may not exist at all on newer installs.
    if systemctl is-active --quiet mvgal-daemon.service 2>/dev/null; then
        log "Stopping mvgal-daemon.service"
        systemctl stop mvgal-daemon.service || true
        # Wait for the unit to actually go inactive: the socket and device
        # fds must be closed before the module refcount can reach zero.
        local waited=0
        while systemctl is-active --quiet mvgal-daemon.service 2>/dev/null; do
            sleep 0.1
            waited=$((waited + 1))
            [ "$waited" -ge 50 ] && break
        done
    fi
    # Also stop a daemon started manually (not through systemd).
    pkill -TERM -x mvgald 2>/dev/null || true

    # Gracefully close open file descriptors to device nodes.
    # Send SIGTERM first so processes can clean up; escalate to SIGKILL
    # only for stragglers after a short grace period.
    for dev in /dev/mvgal*; do
        if [ -e "$dev" ]; then
            local pids
            pids=$(lsof -t "$dev" 2>/dev/null | sort -u)
            if [ -n "$pids" ]; then
                echo "$pids" | xargs -r kill -TERM 2>/dev/null || true
                sleep 1
                pids=$(lsof -t "$dev" 2>/dev/null | sort -u)
                if [ -n "$pids" ]; then
                    echo "$pids" | xargs -r kill -9 2>/dev/null || true
                fi
            fi
        fi
    done

    # Unload in reverse dependency order (derived from the shared module list).
    # The core `mvgal` module cannot be removed while the vendor shims or
    # mvgal_ntsync hold a reference on it -- that is the "Module mvgal is in
    # use" failure this whole path exists to avoid.
    #
    # C1: never use `modprobe -r` here.  It blocks inside delete_module()
    # until the refcount reaches zero; if the caller is killed (timeout(1),
    # Ctrl-C, pkexec teardown) the module is left permanently in the GOING
    # ("Unloading") state.  `rmmod` fails fast with EBUSY instead, so the
    # loop can report the real blocker and the module stays usable.
    for MODULE in "${MVGAL_UNLOAD_ORDER[@]}"; do
        if ! lsmod | grep -q "^${MODULE} "; then
            continue
        fi

        # Who is still holding this module?  Record it before trying, so the
        # failure message names the blocker instead of "check dmesg".
        holders="$(lsmod | awk -v m="$MODULE" '$1==m {print $4}')"

        # Redirect the subshell, not just the command: bash prints its own
        # "Killed"/"Terminated" job notice on the subshell's stderr, which
        # leaked to users as "/usr/lib/mvgal/mvgal-pkexec-helper.sh: line N:
        # PID Killed  modprobe -r ...".
        if ( rmmod "${MODULE}" ) 2>/dev/null; then
            log "Module $MODULE unloaded"
            continue
        fi

        if [ -n "$holders" ] && [ "$holders" != "-" ]; then
            log "Warning: Failed to unload $MODULE -- held by: $holders"
            echo "Failed to unload $MODULE: still in use by $holders." >&2
        else
            log "Warning: Failed to unload $MODULE (may be in use by a process)"
            echo "Failed to unload $MODULE: still in use (a process may hold /dev/mvgal*)." >&2
        fi
    done

    # A failed rmmod can still leave a module in the GOING state if a
    # reference dropped at the wrong moment.  Report it as what it is --
    # any wedged MVGAL module, not only the core one.
    wedge=$(mvgal_wedged_modules)
    if [ -n "$wedge" ]; then
        echo "MVGAL module(s) stuck in the kernel:" >&2
        echo "$wedge" >&2
        echo "Reboot required: the kernel cannot remove or reload a module" >&2
        echo "in the Unloading state." >&2
        error_exit "A previous unload was interrupted while the kernel was waiting for a module's reference count to drop."
    fi

    if lsmod | grep -q "^mvgal"; then
        echo "Remaining MVGAL modules:" >&2
        lsmod | grep '^mvgal' >&2
        error_exit "Some MVGAL modules could not be unloaded. See the list above."
    fi

    log "All MVGAL modules unloaded successfully"
    echo "MVGAL kernel modules unloaded successfully"
}

# Enable GPU
enable_gpu() {
    validate_gpu_index "${1:-}"
    local gpu_index="$GPU_INDEX"

    log "Enabling GPU $gpu_index"
    
    # Write to sysfs or use ioctl
    if [ -e "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled" ]; then
        echo 1 > "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled"
        log "GPU $gpu_index enabled via sysfs"
    fi
    
    # Update config — only edit the specific [gpu_N] section, not all sections.
    # If the section does not exist yet, create it at the end of the file.
    if [ -f "$MVGAL_CONFIG" ]; then
        if grep -q "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG"; then
            sed -i "/^\[gpu_${gpu_index}\]/,/^\[/{s/^enabled = false/enabled = true/}" "$MVGAL_CONFIG" 2>/dev/null || true
            if ! grep -A65535 "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG" | grep -q "^enabled[[:space:]]*="; then
                sed -i "/^\[gpu_${gpu_index}\]/a enabled = true" "$MVGAL_CONFIG" 2>/dev/null || true
            fi
        else
            printf '\n[gpu_%s]\nenabled = true\n' "$gpu_index" >> "$MVGAL_CONFIG"
        fi
        SIGHUP_DAEMON=1
    fi
    
    echo "GPU $gpu_index enabled in MVGAL"
}

# Disable GPU
disable_gpu() {
    validate_gpu_index "${1:-}"
    local gpu_index="$GPU_INDEX"

    log "Disabling GPU $gpu_index"
    
    # Write to sysfs
    if [ -e "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled" ]; then
        echo 0 > "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled"
        log "GPU $gpu_index disabled via sysfs"
    fi

    # Update config — mirror enable_gpu so the state survives restarts.
    # Only edit the specific [gpu_N] section, not all sections.
    # If the section does not exist yet, create it at the end of the file.
    if [ -f "$MVGAL_CONFIG" ]; then
        if grep -q "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG"; then
            sed -i "/^\[gpu_${gpu_index}\]/,/^\[/{s/^enabled = true/enabled = false/}" "$MVGAL_CONFIG" 2>/dev/null || true
            if ! grep -A65535 "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG" | grep -q "^enabled[[:space:]]*="; then
                sed -i "/^\[gpu_${gpu_index}\]/a enabled = false" "$MVGAL_CONFIG" 2>/dev/null || true
            fi
        else
            printf '\n[gpu_%s]\nenabled = false\n' "$gpu_index" >> "$MVGAL_CONFIG"
        fi
        SIGHUP_DAEMON=1
    fi

    echo "GPU $gpu_index disabled in MVGAL"
}

# Set GPU power state
set_power_state() {
    if [ -z "${1:-}" ] || [ -z "${2:-}" ]; then
        error_exit "Usage: set-power <gpu_index> <state (auto|on|off)>"
    fi
    validate_gpu_index "$1"
    local gpu_index="$GPU_INDEX"
    local state="$2"

    log "Setting GPU $gpu_index power state to $state"
    
    # Validate state
    case "$state" in
        auto|on|off)
            ;;
        *)
            error_exit "Invalid power state: $state (must be auto, on, or off)"
            ;;
    esac
    
    # Find the GPU PCI device
    local pci_path="/sys/class/mvgal/mvgal0/gpu${gpu_index}/pci_path"
    if [ -f "$pci_path" ]; then
        local pci_addr
        pci_addr=$(cat "$pci_path")
        local power_control="/sys/bus/pci/devices/${pci_addr}/power/control"
        
        if [ -f "$power_control" ]; then
            echo "$state" > "$power_control"
            log "Power state set via PCI power control"
        fi
    fi
    
    # Also set via sysfs
    if [ -e "/sys/class/mvgal/mvgal0/gpu${gpu_index}/power_state" ]; then
        echo "$state" > "/sys/class/mvgal/mvgal0/gpu${gpu_index}/power_state"
    fi
    
    echo "GPU $gpu_index power state set to $state"
}

# Rescan GPUs
rescan_gpus() {
    log "Rescanning for GPU changes"
    
    if [ -e "/sys/class/mvgal/mvgal0/rescan" ]; then
        echo 1 > "/sys/class/mvgal/mvgal0/rescan"
        log "Rescan triggered via sysfs"
        echo "GPU rescan initiated"
    else
        error_exit "Rescan interface not available — is the mvgal kernel module loaded? (Try: mvgal load-module)"
    fi
}

# Reload configuration
reload_config() {
    log "Reloading MVGAL configuration"
    
    # Signal daemon if running
    if systemctl is-active --quiet mvgald 2>/dev/null; then
        systemctl kill -s HUP mvgald || true
        log "Sent SIGHUP to mvgald"
    fi
    
    echo "Configuration reload triggered"
}

# Install Vulkan layer
install_vulkan_layer() {
    log "Installing MVGAL Vulkan implicit layer"
    
    local layer_src="/usr/share/vulkan/implicit_layer.d/VK_LAYER_MVGAL.json"
    local layer_dst="/etc/vulkan/implicit_layer.d/VK_LAYER_MVGAL.json"
    
    if [ -f "$layer_src" ]; then
        mkdir -p "$(dirname "$layer_dst")"
        cp "$layer_src" "$layer_dst"
        chmod 644 "$layer_dst"
        log "Vulkan layer installed to $layer_dst"
        echo "Vulkan implicit layer installed"
    else
        error_exit "Vulkan layer source not found: $layer_src"
    fi
}

# Remove Vulkan layer
remove_vulkan_layer() {
    log "Removing MVGAL Vulkan implicit layer"
    
    local layer_file="/etc/vulkan/implicit_layer.d/VK_LAYER_MVGAL.json"
    
    if [ -f "$layer_file" ]; then
        rm -f "$layer_file"
        log "Vulkan layer removed"
        echo "Vulkan implicit layer removed"
    else
        log "Vulkan layer not installed"
        echo "Vulkan implicit layer was not installed"
    fi
}

# Install Moore Threads DKMS driver
install_mtt_driver() {
    log "Starting Moore Threads DKMS installer"

    local installer="/usr/share/mvgal/scripts/mtt-dkms-installer.sh"
    if [ ! -x "$installer" ]; then
        error_exit "MTT installer not found or not executable: $installer"
    fi

    "$installer" install
}

# Persist a single key under an INI section of the MVGAL config file.
# Usage: set_config_value <section> <key> <value>
set_config_value() {
    local section="$1" key="$2" value="$3"
    local conf="${MVGAL_CONFIG:-/etc/mvgal/mvgal.conf}"
    [ -f "$conf" ] || error_exit "Config file not found: $conf"

    # Validate inputs: section/key are identifiers, value has no metacharacters
    case "$section" in *[!A-Za-z0-9_]*|"") error_exit "Invalid section" ;; esac
    case "$key" in *[!A-Za-z0-9_]*|"") error_exit "Invalid key" ;; esac
    # Each alternative quoted separately — a combined bracket expression like
    # *[\'"`;&<>|]* breaks out of quoting and corrupts the rest of the script.
    case "$value" in *\\*|*"'"*|*\`*|*";"*|*"&"*|*"<"*|*">"*|*"|"*|"") error_exit "Invalid value" ;; esac

    # Replace (or append) 'key = value' inside '[section]' only.
    if sed -i "/^\[${section}\]/,/^\[/ { s|^[[:space:]]*${key}[[:space:]]*=.*|${key} = ${value}|; }" "$conf"; then
        # Section-scoped existence check: only look inside '[section]' so a key
        # that also appears in a LATER section does not suppress the append.
        if ! awk -v sec="[${section}]" -v key="${key}" '
            $0 == sec { in_sec = 1; next }
            /^\[/ && in_sec { in_sec = 0 }
            in_sec && $0 ~ "^[[:space:]]*" key "[[:space:]]*=" { found = 1 }
            END { exit !found }
        ' "$conf"; then
            # Key not present in the section — append it right after the header
            sed -i "/^\[${section}\]/a ${key} = ${value}" "$conf"
        fi
        log "Set ${section}.${key} = ${value}"
        SIGHUP_DAEMON=1
    else
        error_exit "Failed to update $conf"
    fi
}

# Main entry point
main() {
    check_privileges

    log "Action requested: $ACTION"

    case "$ACTION" in
        load-module)
            load_module
            ;;
        unload-module)
            unload_module
            ;;
        enable-gpu)
            enable_gpu "$2"
            ;;
        disable-gpu)
            disable_gpu "$2"
            ;;
        set-power)
            set_power_state "$2" "$3"
            ;;
        rescan-gpus)
            rescan_gpus
            ;;
        reload-config)
            reload_config
            ;;
        install-vulkan-layer)
            install_vulkan_layer
            ;;
        remove-vulkan-layer)
            remove_vulkan_layer
            ;;
        install-mtt-driver)
            install_mtt_driver
            ;;
        set-strategy)
            # Validated against the union of names accepted by the daemon
            # config parser and the CLI, so a persisted value always
            # round-trips (status and config file stay in sync).
            case "${2-}" in
                single|single_gpu|hybrid|task|afr|sfr|compute|compute_offload|round_robin|auto|custom)
                    set_config_value "core" "default_strategy" "$2"
                    ;;
                *) error_exit "Unknown strategy: ${2-}" ;;
            esac
            ;;
        set-priority)
            case "${2-}" in ''|*[!0-9]*) error_exit "Usage: set-priority <gpu_index> <priority 0-100>" ;; esac
            case "${3-}" in ''|*[!0-9]*) error_exit "Usage: set-priority <gpu_index> <priority 0-100>" ;; esac
            [ "$2" -le 63 ] || error_exit "GPU index out of range"
            [ "$3" -le 100 ] || error_exit "Priority out of range"
            set_config_value "gpu_$2" "priority" "$3"
            ;;
        psu-config)
            # psu-config <capacity_watts> <safety_margin_percent>
            case "${2-}" in ''|*[!0-9]*) error_exit "Usage: psu-config <capacity_watts> <margin_percent>" ;; esac
            case "${3-}" in ''|*[!0-9]*) error_exit "Usage: psu-config <capacity_watts> <margin_percent>" ;; esac
            set_config_value "power" "psu_capacity_watts" "$2"
            set_config_value "power" "psu_safety_margin_percent" "$3"
            ;;
        psu-headroom)
            # psu-headroom <on|off> — enable/disable PSU headroom tracking
            case "${2-}" in
                on|true|1|yes) set_config_value "power" "enable_psu_headroom" "true" ;;
                off|false|0|no) set_config_value "power" "enable_psu_headroom" "false" ;;
                *) error_exit "Usage: psu-headroom <on|off>" ;;
            esac
            ;;
        set-power-curve)
            # set-power-curve <profile> — persist the active curve profile.
            # Global by design: the profile is stored once under [power], and
            # nothing currently reads it (audit ISSUE 5).
            case "${2-}" in
                silent|balanced|performance|custom)
                    set_config_value "power" "power_curve_profile" "$2"
                    ;;
                *) error_exit "Unknown power-curve profile: ${2-} (expected silent|balanced|performance|custom)" ;;
            esac
            ;;
        *)
            echo "Usage: $0 <action> [args...]"
            echo ""
            echo "Actions:"
            echo "  load-module              Load the MVGAL kernel module"
            echo "  unload-module            Unload the MVGAL kernel module"
            echo "  enable-gpu N             Enable GPU at index N"
            echo "  disable-gpu N            Disable GPU at index N"
            echo "  set-power GPU STATE      Set GPU power state (auto|on|off)"
            echo "  rescan-gpus              Rescan for GPU changes"
            echo "  reload-config            Reload MVGAL configuration"
            echo "  install-vulkan-layer     Install Vulkan implicit layer"
            echo "  remove-vulkan-layer      Remove Vulkan implicit layer"
            echo "  install-mtt-driver       Install Moore Threads DKMS driver"
            echo "  set-strategy NAME        Persist default_strategy to config"
            echo "  set-priority N P         Persist priority P for GPU N"
            echo "  psu-config WATTS MARGIN  Persist PSU capacity and margin"
            echo "  psu-headroom ON|OFF     Enable/disable PSU headroom tracking"
            echo "  set-power-curve PROFILE  Persist power-curve profile (global, all GPUs)"
            exit 1
            ;;
    esac

    # Ask the daemon to pick up persisted changes (best effort)
    if [ "${SIGHUP_DAEMON:-0}" = "1" ]; then
        pkill -HUP -x mvgald 2>/dev/null || true
    fi
}

main "$@"
