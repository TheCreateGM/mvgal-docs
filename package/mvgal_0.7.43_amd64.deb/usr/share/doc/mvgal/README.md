# MVGAL — Multi-Vendor GPU Aggregation Layer for Linux

<div align="center">

<img src="assets/icons/mvgal_icon.svg" alt="MVGAL Logo" width="128" height="128" />

![Version](https://img.shields.io/badge/version-0.7.41-76B900?style=for-the-badge)
![License](https://img.shields.io/badge/kernel-GPL--2.0-blue?style=for-the-badge)
![License](https://img.shields.io/badge/userspace-GPL--3.0-blue?style=for-the-badge)
![Language](https://img.shields.io/badge/C17-A8B9CC?style=for-the-badge&logo=c&logoColor=white)
![Language](https://img.shields.io/badge/C%2B%2B20-00599C?style=for-the-badge&logo=cplusplus&logoColor=white)
![Language](https://img.shields.io/badge/Rust-DEA584?style=for-the-badge&logo=rust&logoColor=white)

[![Copr build status](https://copr.fedorainfracloud.org/coprs/axogm/mvgal/package/mvgal/status_image/last_build.png)](https://copr.fedorainfracloud.org/coprs/axogm/mvgal/package/mvgal/)

**Coordinate heterogeneous GPUs through capability-probed, API-specific userspace integrations.**

[Quick Start](#quick-start) · [Install from COPR](#install-from-copr-fedora--rhel--centos-stream) · [Architecture](#architecture) · [CLI](#cli) · [Configuration](#configuration) · [Building](#building) · [COPR](https://copr.fedorainfracloud.org/coprs/axogm/mvgal/)

</div>

---

## What is MVGAL?

Linux applications use GPUs through vendor kernel drivers and userspace APIs. MVGAL is a prototype coordinator for explicit, workload-specific multi-GPU use; it does not make arbitrary applications see one physical GPU. See [feasibility and implementation status](docs/SPEC_COMPLIANCE.md) before enabling experimental components.

```
┌─────────────────────────────────────────────────────────────┐
│          Your Application / Game / AI Workload              │
└──────────────┬──────────────┬──────────────┬────────────────┘
               │ Vulkan        │ OpenCL        │ CUDA
               ▼              ▼              ▼
┌─────────────────────────────────────────────────────────────┐
│              MVGAL API Interception Layer                    │
│   VK_LAYER_MVGAL  │  libmvgal_opencl.so  │  libmvgal_cuda  │
└──────────────────────────┬──────────────────────────────────┘
                           │ Unix socket (/run/mvgal/mvgal.sock)
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    mvgald  (daemon)                          │
│  Scheduler │ MemoryMgr │ PowerMgr │ MetricsCollector │ IPC  │
└──────┬──────────────┬──────────────┬──────────────┬─────────┘
       │              │              │              │
       ▼              ▼              ▼              ▼
  amdgpu.ko     nvidia.ko       i915/xe.ko    mtgpu-drv.ko
  (AMD GPU)    (NVIDIA GPU)    (Intel GPU)   (MTT GPU)
```

---

## License

- **Kernel module** (`kernel/`): GPL-2.0-only (Linux kernel requirement)
- **Userspace components** (`src/`, `runtime/`, `tools/`, etc.): GPL-3.0-only
- **Rust crates** (`safe/`): MIT OR Apache-2.0

---

## Status

**Version 0.7.43 — experimental prototype**

MVGAL is an above-driver coordination prototype. The daemon can enumerate devices, apply scheduling policy, and — for a narrow explicit contract — execute real work: `mvgald` accepts structured workload requests over IPC and dispatches them through pluggable execution backends. The first backend is OpenCL (`tools/mvgal-exec` submits a host-staged reference kernel that runs and validates on a PCI-BDF-matched physical device; validated on NVIDIA RTX 3050 and Intel Arc A380 on this host). AMD's OpenCL stack does not expose PCI-BDF information, so AMD dispatch is correctly refused rather than guessed. Each workload still runs on exactly one device — there is no multi-GPU partitioning, no shared VRAM, and no claim that heterogeneous GPUs act as one. Cross-vendor graphics/compute scaling is not a production feature.

MVGAL does not fabricate hardware. It does not bind GPU PCI functions, it does not report work as submitted when nothing dispatched it, and it does not publish a synthetic Vulkan device. Where a capability does not exist on the running system, the path fails loudly and its caller takes a documented fallback. What a given GPU can actually do is probed at run time and readable in sysfs at `capabilities`; a clear bit means "use the fallback", never "assume it works". See [docs/SPEC_COMPLIANCE.md](docs/SPEC_COMPLIANCE.md) for the full rationale.

| Component | Status |
|-----------|--------|
| Kernel modules | Above-driver discovery only; does not bind GPU PCI functions. Kernel-side GPU submission and VRAM allocation are unsupported because native drivers own those interfaces |
| Runtime daemon (`mvgald`) | Device registry, policy scheduler, IPC, power and metrics code exist. Workload dispatch goes through execution backends; the OpenCL backend is validated on NVIDIA and Intel, AMD is unsupported (no PCI-BDF from its OpenCL stack), and all other APIs return failure |
| Vulkan layer / ICD | The layer forwards real ICD devices. The MVGAL ICD publishes no synthetic physical device; Vulkan device groups are supplied by native ICDs only |
| OpenCL / CUDA | Daemon OpenCL backend executes one host-staged kernel per workload on a matched device (NVIDIA + Intel validated); a standalone OpenCL workload tool also runs on AMD. CUDA remains NVIDIA-only and has no daemon backend |
| Memory manager | Per-device storage and explicit copies are the safe model. DMA-BUF and peer paths require pair-, format- and synchronization-specific validation; host staging is the fallback |
| Scheduler | Policy selection, scoring, and backend dispatch exist. It assigns each workload to one device; it does not split work across GPUs |
| Rust libraries | Fence, memory and capability helper crates; they do not create cross-vendor GPU synchronization or memory sharing by themselves |
| Steam / Windows compatibility | Integration scaffolding; not a Wine/Proton fork and does not implement universal AFR |
| Packaging | RPM/DEB/Arch/Nix definitions exist; supported distributions and installation flows require independent validation |

### Limitations

- **Hardware validation:** The 2026-11-08 host has AMD RX 6400, NVIDIA RTX 3050 6 GB, and Intel Arc A380. The standalone OpenCL sample executed and validated independently on each; daemon dispatch completed real workloads on NVIDIA and Intel only. This does not validate cross-vendor transfer, AMD daemon dispatch, multi-GPU partitioning, or multi-GPU speedup.
- **Transparent scaling:** Not provided for arbitrary applications. Compute/media offload must be explicit and capability-probed.
- **Moore Threads (MTT):** Experimental. Runtime code degrades cleanly when `mtgpu`/MUSA/MTML components are absent.

---

## Available functionality

- Physical GPU discovery through Linux DRM/sysfs and PCI metadata.
- Device capability and topology reporting where the native driver exposes data.
- Scheduler policy evaluation and workload state tracking in the daemon.
- Standalone OpenCL sample execution on each compatible native device, with CPU-reference validation.
- Vulkan/OpenCL/CUDA interception and IPC components for explicit integration experiments.
- Diagnostics, packaging definitions, Rust helper libraries and systemd/Polkit integration files.

These components do not currently provide transparent multi-vendor execution for arbitrary applications. In particular, the scheduler's policy result is not an executable cross-vendor command, and DMA-BUF support does not itself promise GPU memory sharing or zero-copy.

---

## Supported Hardware

| Vendor | Current evidence | Scope |
|--------|------------------|-------|
| **AMD** | `amdgpu`; OpenCL execution validated on RX 6400; Vulkan RADV enumerated | Other GPUs and APIs depend on installed driver/runtime; no general daemon dispatch |
| **NVIDIA** | `nvidia`; OpenCL and CUDA device present; Vulkan NVIDIA ICD enumerated | CUDA is available only through NVIDIA's native stack; no cross-vendor CUDA translation |
| **Intel** | `i915`; OpenCL execution validated on Arc A380; Vulkan Mesa ICD enumerated | Results vary by generation, kernel driver and installed userspace runtime |
| **Moore Threads** | No physical MTT device validated on this host | Experimental; unavailable APIs/drivers must be treated as unsupported |

---

## Install from COPR (Fedora / RHEL / CentOS Stream)

Pre-built RPMs are available on Fedora COPR at [copr.fedorainfracloud.org/coprs/axogm/mvgal](https://copr.fedorainfracloud.org/coprs/axogm/mvgal/).

```bash
# Enable the COPR repository
pkexec dnf copr enable axogm/mvgal

# Install MVGAL
pkexec dnf install mvgal
```

Supported targets: Fedora 43, 44, 45, Rawhide, ELN · RHEL 8, 9, 10 · AlmaLinux 9, 10 · CentOS Stream 9, 10 · Amazon Linux 2023

### Secure Boot

If Secure Boot is enabled, the kernel modules are signed but the key must be enrolled in the firmware MOK database before they can load:

```bash
pkexec mvgal-enroll-mok    # shows the key + prompts for password
pkexec reboot              # confirm enrollment at the MOK Manager screen
pkexec mvgal load-module   # load after reboot
```

### Post-install: mvgal group

The installer adds the user who ran `dnf install` to the `mvgal` group so
they can talk to the daemon socket. Group membership only takes effect in
**new login sessions** — log out and back in (or run `newgrp mvgal`) before
using `mvgal status`, `mvgal-config`, or the Vulkan/OpenCL ICDs. If you
installed via a different user, add yourself manually:

```bash
pkexec usermod -aG mvgal $USER
newgrp mvgal    # or log out and back in
```

---

## Quick Start

### 1. Install dependencies

```bash
# Ubuntu / Debian
pkexec apt install cmake ninja-build libdrm-dev libpci-dev libudev-dev \
                 libvulkan-dev pkg-config gcc g++

# Fedora / RHEL
pkexec dnf install cmake ninja-build libdrm-devel pciutils-devel systemd-devel \
                 vulkan-devel gcc-c++ openssl-devel kernel-devel

# Arch Linux
pkexec pacman -S cmake ninja libdrm pciutils systemd vulkan-devel gcc
```

### 2. Build

```bash
mkdir -p build_output && cd build_output
cmake .. -DCMAKE_BUILD_TYPE=Release -DMVGAL_BUILD_RUNTIME=ON -DMVGAL_BUILD_TOOLS=ON
make -j$(nproc)
```

### 3. Install

```bash
# From RPM — recommended on Fedora/RHEL
pkexec dnf copr enable axogm/mvgal && pkexec dnf install mvgal

# From the build tree
pkexec cmake --install build_output
```

### 4. Start the daemon

```bash
pkexec systemctl start mvgal-daemon.service
pkexec systemctl enable mvgal-daemon.service   # start on boot

# or via the CLI
pkexec mvgal start
```

### 5. Verify

```bash
mvgal status              # GPU utilization and strategy
mvgal list-gpus           # detected hardware
mvgal show-config         # active configuration
```

---

## Architecture

The repository contains these layers and experiments; this is not a claim that every layer forms a complete execution path:

| Layer | Component | Language |
|-------|-----------|----------|
| 6 — Tooling | CLI, diagnostics, optional dashboard and monitoring | C and optional UI languages |
| 5 — API integration | Vulkan/OpenCL/CUDA interception and explicit workload tools | C/C++ |
| 4 — Execution experiments | Planning, profiles and workload-specific adapters | C |
| 3 — Runtime daemon | Registry, policy scheduler, memory/power/metrics code, IPC | C++20 |
| 2 — Safety helpers | Fence, memory and capability utility crates | Rust |
| 1 — Linux interfaces | Read-only discovery and metadata UAPI; vendor drivers still own execution | C |

---

## CLI

The `mvgal` command manages the daemon, configuration, GPU policy, and diagnostics.

```bash
mvgal COMMAND [OPTIONS]
```

### Daemon lifecycle

| Command | Description |
|---------|-------------|
| `mvgal start` | Start the daemon (wraps `systemctl` when available) |
| `mvgal stop` | Stop the daemon (waits for clean exit) |
| `mvgal restart` | Restart the daemon |
| `mvgal status` | Show daemon status and strategy |

### Configuration

| Command | Description |
|---------|-------------|
| `mvgal set-strategy <strategy>` | Set scheduling strategy (persisted to config) |
| `mvgal set-priority <gpu> <priority>` | Set GPU priority (0–100, persisted to config) |
| `mvgal show-config` | Display config in INI format |
| `mvgal reload` | Reload configuration from disk |

### GPU management

| Command | Description |
|---------|-------------|
| `mvgal list-gpus` | List detected GPUs with vendor, VRAM, temperature |
| `mvgal enable-gpu <index>` | Enable a GPU |
| `mvgal disable-gpu <index>` | Disable a GPU |

### Module management

| Command | Description |
|---------|-------------|
| `mvgal load-module` | Load the mvgal kernel module (requires root) |
| `mvgal unload-module` | Unload the mvgal kernel module |

### Diagnostics

| Command | Description |
|---------|-------------|
| `mvgal show-stats` | Show GPU utilization, VRAM, temperature stats |
| `mvgal reset-stats` | Reset statistics counters |
| `mvgal benchmark` | Report collected workload statistics |

### Global options

| Option | Description |
|--------|-------------|
| `-c, --config <file>` | Use alternative config file |
| `-h, --help` | Show help |
| `--version` | Show version |

---

## Scheduling Strategies

| Strategy or mode | Status |
|------------------|--------|
| Dynamic load scoring, static weights, application profile, AI mode | Policy code exists in the daemon; execution still requires an API backend |
| Round robin, AFR, SFR, compute offload, hybrid, custom | Names/configuration appear in integration code and docs; they are not general-purpose working multi-GPU rendering modes |
| Single native GPU | Practical fallback for applications using their own driver/runtime |

Priority: higher value = higher priority (range 0–100, default 50).

---

## Steam / Proton Integration

Steam/Proton environment variables and profile files are experimental integration hooks. They do not make an arbitrary DirectX game multi-GPU capable. Use the vendor's normal GPU-selection mechanism unless an application-specific MVGAL adapter has been validated.

| Variable | Values | Description |
|----------|--------|-------------|
| `MVGAL_VULKAN_ENABLE` | `0` / `1` | Enable MVGAL for this launch |
| `MVGAL_STRATEGY` | `afr`, `sfr`, `hybrid`, `single` | Scheduling strategy |
| `MVGAL_FRAME_PACING` | `0` / `1` | Enable vsync-aligned frame pacing |
| `MVGAL_GPU_MASK` | hex bitmask | Which GPUs to use (e.g. `0x3` = GPU 0+1) |
| `MVGAL_VULKAN_DEBUG` | `0` / `1` | Enable Vulkan layer debug logging |

See [steam/README.md](steam/README.md) and [docs/STEAM.md](docs/STEAM.md) for details.

---

## Configuration

Default config: `/etc/mvgal/mvgal.conf`

```ini
[core]
enabled = true
debug_level = info
default_strategy = single
gpu_count = 0           # 0 = auto-detect
enable_dmabuf = true
enable_stats = true

[gpu_0]
type = auto
priority = 50           # 0–100, higher = higher priority
enabled = true

[afr]
enable_sync = true
sync_timeout_ms = 16

[sfr]
tile_mode = horizontal
tile_ratio = 50

[hybrid]
auto_switch_threshold = 80

[power]
idle_timeout_s = 30
park_gpus = false

[debug]
ring_buffer_size = 1048576
```

Full reference: [docs/API.md](docs/API.md)

---

## Building

### CMake (primary)

```bash
cmake -B build_output \
  -DCMAKE_BUILD_TYPE=Release \
  -DMVGAL_BUILD_RUNTIME=ON \
  -DMVGAL_BUILD_TOOLS=ON \
  -DMVGAL_BUILD_API=ON \
  -DMVGAL_ENABLE_RUST=ON
cmake --build build_output --parallel $(nproc)
```

### Kernel module only

```bash
cd kernel
make -C /lib/modules/$(uname -r)/build M=$(pwd) MVGAL_BUILD_FULL_STACK=1 modules
pkexec insmod mvgal_ntsync.ko
pkexec insmod mvgal.ko
# Optional vendor modules:
pkexec insmod mvgal_nvidia.ko
pkexec insmod mvgal_amd.ko
pkexec insmod mvgal_intel.ko
```

---

## Packaging

```bash
# RPM (Fedora / RHEL / CentOS Stream)
rpmbuild -bb packaging/rpm/mvgal.spec

# Or use COPR (recommended)
pkexec dnf copr enable axogm/mvgal && pkexec dnf install mvgal
```

### Building an SRPM

```bash
./scripts/mksrpm.sh
```

The SRPM is written to the repository root and can be submitted to COPR:

```bash
copr build axogm/mvgal mvgal-0.7.16-1.fc44.src.rpm
```

---

## Memory Management

MVGAL does not expose a physically unified VRAM pool. The intended transfer model is:

```
1. DMA-BUF import/export only when both native drivers support the exact buffer and synchronization use.
2. Peer transfer only when native APIs and topology report that it is usable.
3. Explicit host staging as the portable fallback.

These are candidate paths, not a universal guarantee; pairwise transfer validation is still outstanding.
```

---

## Rust Safety Components

| Crate | Purpose |
|-------|---------|
| `fence_manager` | Cross-device fence lifecycle |
| `memory_safety` | Allocation tracking + reference counting |
| `capability_model` | GPU capability normalization + JSON export |

```bash
cargo build --release
cargo test
```

---

## Man Pages

Installed with the package:

| Page | Description |
|------|-------------|
| `mvgal(1)` | Main CLI reference |
| `mvgal-config(1)` | Configuration file reference |
| `mvgal-info(1)` | GPU information display |
| `mvgal-status(1)` | Real-time GPU stats |
| `mvgal-bench(1)` | Benchmark output |
| `mvgal-compat(1)` | Compatibility checker |
| `mvgal-hw-validate(1)` | Hardware validation |
| `mvgal-enum(1)` | GPU enumeration |
| `mvgal-dmabuf-matrix(1)` | DMA-BUF transfer matrix |
| `mvgal-steam-setup(1)` | Steam/Proton integration |

---

## Project Structure

```
mvgal/
├── kernel/          # Linux kernel modules (GPL-2.0)
│   └── vendors/     # Per-vendor integration (AMD, NVIDIA, Intel, MTT)
├── runtime/         # C++20 daemon (mvgald)
│   └── daemon/      # Scheduler, device registry, IPC, power, metrics
├── safe/            # Rust safety-critical crates
├── src/userspace/   # C userspace library
│   ├── api/         # Public API implementation
│   ├── daemon/      # Config parser, IPC, GPU manager
│   ├── scheduler/   # 9 distribution strategies
│   └── intercept/   # Vulkan, OpenCL, CUDA, D3D, Metal, WebGPU
├── tools/           # CLI (mvgal) + utilities
├── steam/           # Steam/Proton compatibility layer
├── include/mvgal/   # Public C headers
├── man/             # Man page sources
├── packaging/       # RPM spec, systemd service, polkit policies
├── config/          # Default config, pkexec helper, systemd unit
├── data/            # D-Bus service, polkit policy
├── docs/            # Documentation
└── scripts/         # Build helpers, DKMS installer
```

---

## Documentation

| Document | Description |
|----------|-------------|
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Full system architecture |
| [docs/API.md](docs/API.md) | Public API reference |
| [docs/BUILD.md](docs/BUILD.md) | Detailed build instructions |
| [docs/STATUS.md](docs/STATUS.md) | Current implementation status |
| [docs/SPEC_COMPLIANCE.md](docs/SPEC_COMPLIANCE.md) | Feasibility, architecture boundaries, and gaps against the MVGAL specification |
| [docs/GAMING.md](docs/GAMING.md) | Gaming and Steam/Proton guide |
| [docs/STEAM.md](docs/STEAM.md) | Steam compatibility tool setup |
| [docs/MEMORY.md](docs/MEMORY.md) | Memory management deep-dive |
| [docs/DRIVER_INTEGRATION.md](docs/DRIVER_INTEGRATION.md) | Per-vendor driver integration |
| [docs/RUST_DEVELOPMENT.md](docs/RUST_DEVELOPMENT.md) | Rust crate development guide |

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Route all privileged operations through `pkexec`.

## Security

See [SECURITY.md](SECURITY.md) for the vulnerability disclosure policy.

### Security notes

- The daemon socket (`/run/mvgal/mvgal.sock`) is mode `0660`, group-owned by `mvgal` (falling back to `video`), with a per-connection `SO_PEERCRED` check.
- Kernel module signing keys are per-install and shipped in the RPM. For production, generate per-machine keys.
- The pkexec helper uses `chown root:video` + `chmod 0660` for `/dev/mvgal*` nodes (not world-writable).
