
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was ConfigTemplate.cmake                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib64/cmake/mvgal" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Minimal package config for libmvgal generated during configure time.
# This template is configured to set the include directory variable
# MVGAL_INCLUDE_DIR and create an imported target `mvgal` that provides
# the INTERFACE include path for consumers.
#
# Variables substituted by configure_file:
#   /var/lib/jenkins/workspace/mvgal-packages/tools/libmvgal/../../include - the path to the mvgal include directory.

if(NOT DEFINED MVGAL_INCLUDE_DIR)
    set(MVGAL_INCLUDE_DIR "/var/lib/jenkins/workspace/mvgal-packages/tools/libmvgal/../../include" CACHE PATH "Path to mvgal UAPI headers")
endif()

# Provide an imported target for consumers of the package.
# If the real library is available in the installation tree, package
# installation should add an actual library target and override this.
if(NOT TARGET mvgal)
    add_library(mvgal UNKNOWN IMPORTED)
    set_target_properties(mvgal PROPERTIES
        IMPORTED_LOCATION "${CMAKE_INSTALL_PREFIX}/lib/libmvgal.so"
        INTERFACE_INCLUDE_DIRECTORIES "${MVGAL_INCLUDE_DIR}"
    )
endif()

# Optional: provide a convenient alias for imported targets in older CMake versions
if(NOT TARGET mvgal::mvgal)
    add_library(mvgal::mvgal ALIAS mvgal)
endif()

# Export package variables for consumers
set(MVGAL_PACKAGE_VERSION "" CACHE STRING "MVGAL package version")
set(MVGAL_INSTALL_INCLUDEDIR "${MVGAL_INCLUDE_DIR}" CACHE PATH "MVGAL include directory")

# End of config template
