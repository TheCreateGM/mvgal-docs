/**
 * @file mvgal_shader_compiler.h
 * @brief NTSYNC-aware internal shader compiler API
 *
 * Provides a job-based compilation model where each compile is tracked
 * with an NTSYNC event. Multiple jobs can be waited on simultaneously
 * via ntsync_wait_multi, enabling coordinated multi-vendor compilation.
 *
 * Each vendor backend (AMD/Intel/MTT/NVIDIA) has an internal compile
 * path managed through this API. The system() calls are contained here
 * with proper NTSYNC lifecycle synchronization.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */

#ifndef MVGAL_SHADER_COMPILER_H
#define MVGAL_SHADER_COMPILER_H

#include <stddef.h>
#include <stdint.h>
#include <mvgal/mvgal_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ────────────────────────────────────────────────────────── */
/*  Compiler Job — NTSYNC-tracked compilation unit            */
/* ────────────────────────────────────────────────────────── */

typedef struct mvgal_compile_job mvgal_compile_job_t;

/**
 * @brief Create an NTSYNC-tracked shader compilation job
 * @param vendor  Target GPU vendor
 * @param spirv   SPIR-V bytecode input
 * @param word_count  Number of uint32_t words in spirv
 * @return Job handle (must be destroyed via mvgal_compile_job_destroy),
 *         or NULL on allocation failure.
 *
 * The job is created in PENDING state.  Call mvgal_compile_job_run()
 * to start compilation, then mvgal_compile_job_wait() for completion.
 */
mvgal_compile_job_t *mvgal_compile_job_create(mvgal_vendor_t vendor,
                                               const uint32_t *spirv,
                                               size_t word_count);

/**
 * @brief Get the NTSYNC event handle for a compile job
 * @param job  Job handle
 * @return  NTSYNC event handle (valid for ntsync_wait / ntsync_wait_multi),
 *          or -1 if no event has been created yet (job not run).
 *
 * The event is created on first call to mvgal_compile_job_run() and
 * remains valid until mvgal_compile_job_destroy().
 */
int mvgal_compile_job_event(mvgal_compile_job_t *job);

/**
 * @brief Run (or start) a compile job
 * @param job  Job handle
 * @return  0 on success, -1 on compilation failure.
 *
 * This runs the vendor-specific native compiler pipeline:
 *   - AMD:   LLVM toolchain (llvm-spirv + llc) or LLVM C API
 *   - Intel: IGC/ocloc toolchain
 *   - MTT:   mttc/mcc toolchain
 *   - NVIDIA: NVRTC in-process compilation
 *
 * The job signals its NTSYNC event when done, allowing
 * ntsync_wait / ntsync_wait_multi to detect completion.
 */
int mvgal_compile_job_run(mvgal_compile_job_t *job);

/**
 * @brief Wait for job completion via NTSYNC
 * @param job        Job handle
 * @param timeout_ns Timeout in nanoseconds (0 = infinite)
 * @return  0 on completion, -1 on timeout (errno = ETIMEDOUT) or error.
 *
 * Internally calls ntsync_wait() on the job's event handle.
 */
int mvgal_compile_job_wait(mvgal_compile_job_t *job, uint64_t timeout_ns);

/**
 * @brief Retrieve job result
 * @param job        Job handle (must have been run and completed)
 * @param out_source Output pointer (caller must free with free())
 * @param out_size   Output size in bytes
 * @return  0 on success, -1 if job not yet run / failed.
 */
int mvgal_compile_job_result(mvgal_compile_job_t *job,
                              char **out_source,
                              size_t *out_size);

/**
 * @brief Destroy a compile job and release all resources
 * @param job  Job handle (NULL-safe)
 *
 * Closes the NTSYNC event handle and frees all memory.
 */
void mvgal_compile_job_destroy(mvgal_compile_job_t *job);

/* ────────────────────────────────────────────────────────── */
/*  Synchronous convenience wrapper                           */
/* ────────────────────────────────────────────────────────── */

/**
 * @brief Synchronous vendor compile — NTSYNC-managed
 * @param vendor     Target GPU vendor
 * @param spirv      SPIR-V bytecode
 * @param word_count Number of uint32_t words
 * @param out_source Output source (caller must free)
 * @param out_size   Output size in bytes
 * @return 0 on success, -1 on failure
 *
 * Creates a compile job, runs it, waits for completion (infinite
 * timeout), retrieves the result, and destroys the job.
 *
 * This is the primary API that vendor backends call instead of
 * directly invoking system() subprocesses.
 */
int mvgal_compile_sync(mvgal_vendor_t vendor,
                       const uint32_t *spirv,
                       size_t word_count,
                       char **out_source,
                       size_t *out_size);

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_SHADER_COMPILER_H */
