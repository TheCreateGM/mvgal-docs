// SPDX-License-Identifier: GPL-3.0-only
/**
 * @file mvgal_binary.h
 * @brief CUDA binary format types and detection API
 *
 * Multi-Vendor GPU Aggregation Layer for Linux
 *
 * Defines unified types for PTX, cubin, fatbinary, and HSACO
 * binary formats. Provides format detection and metadata extraction.
 */

#ifndef MVGAL_BINARY_H
#define MVGAL_BINARY_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ── Binary format identifiers ────────────────────────────── */

enum mvgal_binary_format {
    MVGAL_BINARY_UNKNOWN     = 0,
    MVGAL_BINARY_PTX         = 1,  /* NVIDIA PTX text */
    MVGAL_BINARY_CUBIN       = 2,  /* NVIDIA cubin ELF */
    MVGAL_BINARY_FATBINARY   = 3,  /* NVIDIA fatbinary container */
    MVGAL_BINARY_HSACO       = 4,  /* AMD HSACO ELF */
};

/* ── Error codes ──────────────────────────────────────────── */

enum mvgal_binary_error {
    MVGAL_BINARY_SUCCESS            = 0,
    MVGAL_BINARY_ERR_INVALID_MAGIC  = -1,
    MVGAL_BINARY_ERR_TRUNCATED      = -2,
    MVGAL_BINARY_ERR_UNSUPPORTED    = -3,
    MVGAL_BINARY_ERR_PARSE          = -4,
    MVGAL_BINARY_ERR_ALLOC          = -5,
};

/* ── PTX metadata ─────────────────────────────────────────── */

struct mvgal_binary_ptx_info {
    uint32_t version_major;
    uint32_t version_minor;
    uint64_t target_sm;            /* e.g. 75 for sm_75 */
    const char *source_file;       /* .file directive, may be NULL */
    size_t      source_file_len;
    size_t      kernel_count;      /* number of .entry kernels found */
    const char *text_start;        /* pointer into source */
    size_t      text_size;
};

/* ── cubin (NVIDIA ELF) metadata ──────────────────────────── */

struct mvgal_binary_cubin_info {
    uint32_t elf_class;            /* 1=32-bit, 2=64-bit */
    uint32_t encoding;             /* 2=little-endian */
    uint32_t abi_version;
    uint32_t compute_capability_major;
    uint32_t compute_capability_minor;
    size_t   text_offset;
    size_t   text_size;
    size_t   nv_info_offset;
    size_t   nv_info_size;
    size_t   num_sections;
    size_t   total_size;
};

/* ── Fatbinary (NVIDIA container) metadata ────────────────── */

struct mvgal_binary_fatbin_entry {
    uint64_t offset;
    uint64_t size;
    uint64_t kind;                 /* 1=cubin, 2=PTX */
    uint32_t arch_major;
    uint32_t arch_minor;
};

struct mvgal_binary_fatbin_info {
    uint32_t version;
    uint64_t total_size;
    size_t   entry_count;
    struct mvgal_binary_fatbin_entry *entries;  /* caller must free */
};

/* ── HSACO (AMD ELF) metadata ─────────────────────────────── */

struct mvgal_binary_hsaco_info {
    uint32_t elf_class;
    uint32_t encoding;
    uint32_t code_object_version;  /* from note section */
    const char *target;            /* e.g. "gfx908" or "gfx90a" */
    size_t      target_len;
    size_t   text_offset;
    size_t   text_size;
    size_t   rodata_offset;
    size_t   rodata_size;
    size_t   total_size;
};

/* ── Unified binary descriptor ────────────────────────────── */

struct mvgal_binary_descriptor {
    enum mvgal_binary_format format;

    union {
        struct mvgal_binary_ptx_info      ptx;
        struct mvgal_binary_cubin_info    cubin;
        struct mvgal_binary_fatbin_info   fatbin;
        struct mvgal_binary_hsaco_info    hsaco;
    };

    /* Raw data – owned by descriptor, freed via mvgal_binary_destroy() */
    void  *data;
    size_t data_size;
};

/* ── Public API ────────────────────────────────────────────── */

/**
 * @brief Detect binary format from magic bytes.
 * @param data   Pointer to binary data
 * @param size   Size of data in bytes
 * @return enum mvgal_binary_format (MVGAL_BINARY_UNKNOWN if unrecognised)
 */
enum mvgal_binary_format
mvgal_binary_detect_format(const void *data, size_t size);

/**
 * @brief Parse binary data into a unified descriptor.
 * @param data   Pointer to binary data
 * @param size   Size of data in bytes
 * @param out    [out] Descriptor – caller must call mvgal_binary_destroy()
 * @return mvgal_binary_error
 */
int
mvgal_binary_parse(const void *data, size_t size,
                   struct mvgal_binary_descriptor *out);

/**
 * @brief Free resources held by a descriptor.
 */
void
mvgal_binary_destroy(struct mvgal_binary_descriptor *desc);

/**
 * @brief Return string name for a format enum.
 */
const char *
mvgal_binary_format_name(enum mvgal_binary_format fmt);

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_BINARY_H */
