/**
 * @file mvgal_dispatch.h
 * @brief Cross-vendor command stream dispatch
 *
 * Multi-Vendor GPU Aggregation Layer for Linux
  * SPDX-License-Identifier: GPL-3.0-only
  */

#ifndef MVGAL_DISPATCH_H
#define MVGAL_DISPATCH_H

#include <stdint.h>
#include <stdbool.h>

#include <vulkan/vulkan.h>
#include "mvgal/mvgal_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @addtogroup Dispatch
 * @{
 */

/**
 * @brief Initialize the dispatch layer
 * @return 0 on success, negative on error
 */
int mvgal_dispatch_init(void);

/**
 * @brief Shutdown the dispatch layer
 */
void mvgal_dispatch_shutdown(void);

/**
 * @brief Get the number of GPUs with loaded vendor drivers
 * @return Number of GPUs available for dispatch
 */
int mvgal_dispatch_get_gpu_count(void);

/**
 * @brief Get the vendor for a specific GPU
 * @param gpu_index GPU index (0-based)
 * @return Vendor type or MVGAL_VENDOR_UNKNOWN
 */
mvgal_vendor_t mvgal_dispatch_get_gpu_vendor(uint32_t gpu_index);

/**
 * @brief Submit command buffers to vendor drivers
 * 
 * Dispatches VkSubmitInfo to multiple vendor drivers based on gpu_mask.
 * Internally adds VkDeviceGroupSubmitInfo for GPU routing.
 *
 * @param queue Queue handle (passed through to vendor drivers)
 * @param submitCount Number of submits
 * @param pSubmits Submit info array
 * @param fence Fence to signal
 * @param gpu_mask Bitmask of target GPUs
 * @return VK_SUCCESS on success, error code on failure
 */
VkResult mvgal_dispatch_submit(VkQueue queue,
                               uint32_t submitCount,
                               const VkSubmitInfo *pSubmits,
                               VkFence fence,
                               uint32_t gpu_mask);

/**
 * @brief Route shader to vendor-specific compiler
 *
 * Translates SPIR-V to vendor intermediate representation and/or
 * compiled code for direct execution.
 *
 * @param vendor Target vendor
 * @param spirv SPIR-V code
 * @param word_count Number of 32-bit words
 * @param vendor_code Output vendor code (caller must free)
 * @param vendor_code_size Output vendor code size in words
 * @return 0 on success, negative on error
 */
int mvgal_dispatch_shader_route(mvgal_vendor_t vendor,
                                const uint32_t *spirv,
                                size_t word_count,
                                uint32_t **vendor_code,
                                size_t *vendor_code_size);

/**
 * @brief AFR (Alternate Frame Rendering) distribution
 *
 * Selects GPU for current frame based on frame count.
 *
 * @param gpu_indices Output GPU index (single value for AFR)
 * @param gpu_count Total number of GPUs
 * @param frame_count Optional frame count pointer (uses internal counter if NULL)
 * @return MVGAL_SUCCESS on success
 */
mvgal_error_t mvgal_dispatch_afr(uint32_t *gpu_indices, uint32_t gpu_count,
                                  uint64_t *frame_count);

/**
 * @brief SFR (Split Frame Rendering) distribution
 *
 * Splits render target across GPUs.
 *
 * @param gpu_indices Output GPU indices (all GPUs for SFR)
 * @param gpu_count Total number of GPUs
 * @param regions Output regions for each GPU
 * @param extent Full render target extent
 * @return MVGAL_SUCCESS on success
 */
mvgal_error_t mvgal_dispatch_sfr(uint32_t *gpu_indices, uint32_t gpu_count,
                                  mvgal_rect_t *regions, mvgal_rect_t extent);

/** @} */

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_DISPATCH_H */