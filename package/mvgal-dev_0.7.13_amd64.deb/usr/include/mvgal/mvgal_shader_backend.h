/**
 * @file mvgal_shader_backend.h
 * @brief Vendor-specific shader compiler backend interface
 * SPDX-License-Identifier: GPL-3.0-only
 */

#ifndef MVGAL_SHADER_BACKEND_H
#define MVGAL_SHADER_BACKEND_H

#include <stddef.h>
#include <stdint.h>
#include <mvgal/mvgal_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declarations for internal types */
struct mvgal_spirv_cache;
typedef struct mvgal_spirv_cache mvgal_spirv_cache_t;

/**
 * @brief Compile SPIR-V to vendor-specific shader code
 * @param spirv SPIR-V bytecode
 * @param word_count Number of uint32_t words
 * @param out_source Output source code (caller must free)
 * @param out_size Output size in bytes
 * @return 0 on success, -1 on failure
 */
int mvgal_compile_shader_amd(const uint32_t *spirv, size_t word_count,
                             char **out_source, size_t *out_size);
int mvgal_compile_shader_nvidia(const uint32_t *spirv, size_t word_count,
                              char **out_source, size_t *out_size);
int mvgal_compile_shader_intel(const uint32_t *spirv, size_t word_count,
                               char **out_source, size_t *out_size);
int mvgal_compile_shader_moore_threads(const uint32_t *spirv, size_t word_count,
                                       char **out_source, size_t *out_size);

/**
 * @brief Compile shader for a specific vendor
 */
static inline int mvgal_compile_shader(mvgal_vendor_t vendor,
                                       const uint32_t *spirv, size_t word_count,
                                       char **out_source, size_t *out_size)
{
    switch (vendor) {
    case MVGAL_VENDOR_AMD:
        return mvgal_compile_shader_amd(spirv, word_count, out_source, out_size);
    case MVGAL_VENDOR_NVIDIA:
        return mvgal_compile_shader_nvidia(spirv, word_count, out_source, out_size);
    case MVGAL_VENDOR_INTEL:
        return mvgal_compile_shader_intel(spirv, word_count, out_source, out_size);
    case MVGAL_VENDOR_MOORE_THREADS:
        return mvgal_compile_shader_moore_threads(spirv, word_count, out_source, out_size);
    default:
        return -1;
    }
}

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_SHADER_BACKEND_H */