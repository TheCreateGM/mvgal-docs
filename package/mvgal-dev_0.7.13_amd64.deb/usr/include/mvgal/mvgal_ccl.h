// SPDX-License-Identifier: GPL-3.0-only
/**
 * @file mvgal_ccl.h
 * @brief MVGAL Collective Communication Library public API
 *
 * Multi-Vendor GPU Aggregation Layer for Linux
 *
 * Vendor-neutral collective communication primitives for
 * multi-GPU data exchange across AMD, NVIDIA, Intel, and
 * Moore Threads devices.
 *
 * All functions return mvgal_ccl_error.
 * All operations are blocking unless *_async variants are used.
 */

#ifndef MVGAL_CCL_H
#define MVGAL_CCL_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ── Opaque handle types ──────────────────────────────────── */

typedef struct mvgal_ccl_comm   *mvgal_ccl_comm_t;
typedef struct mvgal_ccl_req    *mvgal_ccl_req_t;

/* ── Error codes ──────────────────────────────────────────── */

enum mvgal_ccl_error {
    MVGAL_CCL_SUCCESS           = 0,
    MVGAL_CCL_ERR_UNINITIALIZED = -1,
    MVGAL_CCL_ERR_INVALID_ARG   = -2,
    MVGAL_CCL_ERR_OUT_OF_MEMORY = -3,
    MVGAL_CCL_ERR_INTERNAL      = -4,
    MVGAL_CCL_ERR_NOT_SUPPORTED = -5,
    MVGAL_CCL_ERR_ALLOC_FAILED  = -6,
    MVGAL_CCL_ERR_TRANSPORT     = -7,
    MVGAL_CCL_ERR_TIMEOUT       = -8,
};

/* ── Datatype enums ───────────────────────────────────────── */

enum mvgal_ccl_datatype {
    MVGAL_CCL_DATATYPE_INT8    = 0,
    MVGAL_CCL_DATATYPE_INT32   = 1,
    MVGAL_CCL_DATATYPE_INT64   = 2,
    MVGAL_CCL_DATATYPE_UINT8   = 3,
    MVGAL_CCL_DATATYPE_UINT32  = 4,
    MVGAL_CCL_DATATYPE_UINT64  = 5,
    MVGAL_CCL_DATATYPE_FLOAT16 = 6,
    MVGAL_CCL_DATATYPE_FLOAT32 = 7,
    MVGAL_CCL_DATATYPE_FLOAT64 = 8,
    MVGAL_CCL_DATATYPE_BFLOAT16 = 9,
};

/* ── Reduction operation enums ────────────────────────────── */

enum mvgal_ccl_reduction_op {
    MVGAL_CCL_OP_SUM   = 0,
    MVGAL_CCL_OP_PROD  = 1,
    MVGAL_CCL_OP_MAX   = 2,
    MVGAL_CCL_OP_MIN   = 3,
    MVGAL_CCL_OP_AVG   = 4,
};

/* ── Algorithm selection hints ────────────────────────────── */

enum mvgal_ccl_algorithm {
    MVGAL_CCL_ALGO_AUTO     = 0,  /* let library choose */
    MVGAL_CCL_ALGO_RING     = 1,  /* ring all-reduce */
    MVGAL_CCL_ALGO_TREE     = 2,  /* tree all-reduce (binary butterfly) */
    MVGAL_CCL_ALGO_DIRECT   = 3,  /* direct GPU↔GPU (small messages) */
};

/* ── Topology hints ───────────────────────────────────────── */

enum mvgal_ccl_topology {
    MVGAL_CCL_TOPOLOGY_AUTO     = 0,
    MVGAL_CCL_TOPOLOGY_RING     = 1,
    MVGAL_CCL_TOPOLOGY_TREE     = 2,
    MVGAL_CCL_TOPOLOGY_MESH     = 3,
};

/* ── Communicator configuration ───────────────────────────── */

struct mvgal_ccl_config {
    int             nranks;        /* number of ranks in communicator */
    int             rank;          /* calling rank */
    enum mvgal_ccl_algorithm  algo;
    enum mvgal_ccl_topology   topo;
    bool            enable_profiling;   /* collect timing stats */
    uint32_t        timeout_ms;         /* 0 = no timeout */
    size_t          buffer_size;        /* internal buffer per rank */
};

/* ── Collective communication API ─────────────────────────── */

/**
 * @brief Initialise the CCL subsystem.
 * Must be called once per process before any other CCL function.
 */
int
mvgal_ccl_init(void);

/**
 * @brief Finalise the CCL subsystem and free all resources.
 */
int
mvgal_ccl_finalize(void);

/**
 * @brief Create a communicator from a config.
 * @param config   Desired communicator parameters
 * @param out      [out] New communicator handle
 */
int
mvgal_ccl_comm_create(const struct mvgal_ccl_config *config,
                      mvgal_ccl_comm_t *out);

/**
 * @brief Destroy a communicator and free its resources.
 */
int
mvgal_ccl_comm_destroy(mvgal_ccl_comm_t comm);

/**
 * @brief Return the number of ranks in the communicator.
 */
int
mvgal_ccl_comm_size(mvgal_ccl_comm_t comm, int *size);

/**
 * @brief Return the calling rank inside the communicator.
 */
int
mvgal_ccl_comm_rank(mvgal_ccl_comm_t comm, int *rank);

/* ── Collective operations (blocking) ────────────────────── */

/**
 * @brief All-reduce: each rank contributes sendbuf, result in recvbuf.
 * @param comm         Communicator
 * @param sendbuf      Per-rank input buffer
 * @param recvbuf      Output buffer (on each rank)
 * @param count        Number of elements
 * @param datatype     Element datatype
 * @param op           Reduction operation
 */
int
mvgal_ccl_allreduce(mvgal_ccl_comm_t comm,
                    const void *sendbuf, void *recvbuf,
                    size_t count,
                    enum mvgal_ccl_datatype datatype,
                    enum mvgal_ccl_reduction_op op);

/**
 * @brief All-gather: gather data from all ranks onto every rank.
 */
int
mvgal_ccl_allgather(mvgal_ccl_comm_t comm,
                    const void *sendbuf, void *recvbuf,
                    size_t sendcount,
                    enum mvgal_ccl_datatype datatype);

/**
 * @brief Broadcast: sendbuf on root is copied to recvbuf on all ranks.
 * @param root   Rank that owns the data to broadcast
 */
int
mvgal_ccl_broadcast(mvgal_ccl_comm_t comm,
                    void *buf, size_t count,
                    enum mvgal_ccl_datatype datatype,
                    int root);

/**
 * @brief Reduce-scatter: reduction over all ranks, result scattered.
 */
int
mvgal_ccl_reduce_scatter(mvgal_ccl_comm_t comm,
                         const void *sendbuf, void *recvbuf,
                         const size_t *recvcounts,
                         enum mvgal_ccl_datatype datatype,
                         enum mvgal_ccl_reduction_op op);

/**
 * @brief Barrier: synchronise all ranks in the communicator.
 */
int
mvgal_ccl_barrier(mvgal_ccl_comm_t comm);

/* ── Non-blocking variants (async) ───────────────────────── */

/**
 * @brief Non-blocking all-reduce.
 * @param req  [out] Request handle – must be passed to mvgal_ccl_wait()
 */
int
mvgal_ccl_allreduce_async(mvgal_ccl_comm_t comm,
                          const void *sendbuf, void *recvbuf,
                          size_t count,
                          enum mvgal_ccl_datatype datatype,
                          enum mvgal_ccl_reduction_op op,
                          mvgal_ccl_req_t *req);

int
mvgal_ccl_allgather_async(mvgal_ccl_comm_t comm,
                          const void *sendbuf, void *recvbuf,
                          size_t sendcount,
                          enum mvgal_ccl_datatype datatype,
                          mvgal_ccl_req_t *req);

int
mvgal_ccl_broadcast_async(mvgal_ccl_comm_t comm,
                          void *buf, size_t count,
                          enum mvgal_ccl_datatype datatype,
                          int root,
                          mvgal_ccl_req_t *req);

int
mvgal_ccl_barrier_async(mvgal_ccl_comm_t comm,
                        mvgal_ccl_req_t *req);

/**
 * @brief Wait for an asynchronous operation to complete.
 * Blocks until the operation identified by req finishes.
 */
int
mvgal_ccl_wait(mvgal_ccl_req_t req);

/**
 * @brief Test if an asynchronous operation has completed (non-blocking).
 * @param done  [out] Set to true if operation complete
 */
int
mvgal_ccl_test(mvgal_ccl_req_t req, bool *done);

/* ── Utility ──────────────────────────────────────────────── */

/** Return string description of an error code. */
const char *
mvgal_ccl_error_string(int err);

/** Return byte size of a datatype. */
size_t
mvgal_ccl_datatype_size(enum mvgal_ccl_datatype dt);

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_CCL_H */
