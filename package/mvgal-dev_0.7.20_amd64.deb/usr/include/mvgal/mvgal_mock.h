/**
 * @file mvgal_mock.h
 * @brief Synthetic GPU topology backend for deterministic testing
 *
 * Multi-Vendor GPU Aggregation Layer for Linux
 *
 * MVGAL is developed on machines whose GPU population differs from the
 * topologies its scheduler is supposed to handle. A developer box may have one
 * integrated GPU; a validation rig may have four discrete GPUs; almost nobody
 * has "AMD + NVIDIA + Intel + MTT" on demand, and CI has no GPU at all.
 *
 * This backend makes that reachable without faking results. It does not stub
 * out the scheduler or the P2P cost model: it registers *real* device
 * descriptors into the same discovery path that scans sysfs, with the same
 * descriptor shape, the same scoring inputs and the same copy-method decision
 * logic. A test that runs against a synthetic topology exercises the same code
 * that runs against silicon; only the source of the numbers differs.
 *
 * What a synthetic topology can simulate (see spec section 36):
 *   - 1, 2, 3 or 4 devices
 *   - heterogeneous vendors (AMD / NVIDIA / Intel / Moore Threads)
 *   - different VRAM sizes, memory bandwidths and compute performance
 *   - a GPU failure that removes exactly one device from the pool
 *   - memory pressure (allocations against a bounded VRAM budget)
 *   - thermal throttling (load heats the device, heat caps delivered power)
 *   - transfer bottlenecks (per-link bandwidth, disconnected peers)
 *
 * Everything is deterministic: no wall-clock reads, no RNG. Advancing the
 * simulation requires an explicit mvgal_mock_advance() call, so a test gets
 * identical results on every run and on every machine.
 *
 * Typical use:
 * @code
 *   mvgal_mock_config_t cfg;
 *   mvgal_mock_config_defaults(&cfg);
 *   cfg.preset = MVGAL_MOCK_TOPOLOGY_HETERO_QUAD;
 *   mvgal_mock_init(&cfg);
 *   mvgal_init(0);                    // discovers the synthetic topology
 *   assert(mvgal_gpu_get_count() == 4);
 *   ...
 *   mvgal_mock_kill_device(2);         // that GPU now fails
 *   mvgal_mock_advance(1000);          // 1 s of simulated time
 *   mvgal_shutdown();
 *   mvgal_mock_shutdown();
 * @endcode
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef MVGAL_MOCK_H
#define MVGAL_MOCK_H

#include "mvgal_gpu.h"
#include "mvgal_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/** Maximum number of synthetic devices a single topology may declare. */
#define MVGAL_MOCK_MAX_DEVICES 8

/** Initial temperature of a synthetic device, in degrees Celsius. */
#define MVGAL_MOCK_AMBIENT_C 35.0f

/** Temperature at which a synthetic device reaches its thermal design point. */
#define MVGAL_MOCK_TDP_C 85.0f

/**
 * @brief System memory of the simulated machine, in bytes.
 *
 * An integrated GPU has no private VRAM, so its memory budget is the machine's
 * RAM. The simulation states that RAM itself rather than letting the host be
 * probed: a topology that answered differently depending on how much memory
 * the machine running the test happened to have would not be reproducible.
 */
#define MVGAL_MOCK_SYSTEM_RAM_BYTES (UINT64_C(32) * 1024 * 1024 * 1024)

/**
 * @brief Predefined synthetic topologies
 *
 * Each preset is a realistic, internally consistent machine description. The
 * device ids are the real PCI ids of the part being modelled, so the resulting
 * descriptors read like hardware rather than like placeholders.
 */
typedef enum {
    /** No synthetic devices. Hardware discovery behaves unchanged. */
    MVGAL_MOCK_TOPOLOGY_NONE = 0,
    /** One discrete NVIDIA card: the "optimise the single GPU" case. */
    MVGAL_MOCK_TOPOLOGY_SINGLE = 1,
    /** AMD + NVIDIA, same PCIe root complex: the dual-vendor P2P case. */
    MVGAL_MOCK_TOPOLOGY_HETERO_DUAL = 2,
    /** AMD + NVIDIA + Intel iGPU, two root complexes: P2P and host staging. */
    MVGAL_MOCK_TOPOLOGY_HETERO_TRI = 3,
    /** AMD + NVIDIA + Intel iGPU + Moore Threads, three root complexes. */
    MVGAL_MOCK_TOPOLOGY_HETERO_QUAD = 4,
    /** Two identical AMD cards on one root complex: AMD CrossFire-style. */
    MVGAL_MOCK_TOPOLOGY_AMD_DUAL = 5,
    /** One integrated Intel GPU only: no VRAM, shared memory, host staged. */
    MVGAL_MOCK_TOPOLOGY_INTEGRATED_ONLY = 6,
} mvgal_mock_topology_t;

/**
 * @brief Synthetic topology configuration
 */
typedef struct {
    /** Topology preset to instantiate. */
    mvgal_mock_topology_t preset;

    /** Append synthetic devices after the real hardware instead of replacing
     *  them. Off by default: a test asking for a synthetic topology wants a
     *  deterministic device population regardless of the machine. */
    bool append_to_hardware;

    /** Starting per-device load, in percent. Defaults to 0 (all idle). */
    uint32_t initial_load_percent;

    /** Inject thermal throttling on all devices at start-up, i.e. start them
     *  hot instead of at the ambient temperature. */
    bool start_hot;
} mvgal_mock_config_t;

/**
 * @brief Fill @p config with the documented defaults (preset SINGLE, no
 *        hardware append, idle devices, ambient temperature).
 */
void mvgal_mock_config_defaults(mvgal_mock_config_t *config);

/**
 * @brief Activate a synthetic topology.
 *
 * Safe to call when a topology is already active: the new configuration
 * replaces the old one. Does not trigger discovery by itself; the next
 * mvgal_gpu_manager_init() or mvgal_gpu_rescan() picks it up.
 *
 * @return MVGAL_SUCCESS, MVGAL_ERROR_INVALID_ARGUMENT for a NULL config or an
 *         unknown preset, MVGAL_ERROR_NO_GPUS if the preset declares no devices.
 */
mvgal_error_t mvgal_mock_init(const mvgal_mock_config_t *config);

/**
 * @brief Deactivate the synthetic topology and release its devices.
 *
 * @return MVGAL_SUCCESS, MVGAL_ERROR_NOT_INITIALIZED when none was active.
 */
mvgal_error_t mvgal_mock_shutdown(void);

/** @return true while a synthetic topology is active. */
bool mvgal_mock_is_active(void);

/**
 * @return true when synthetic devices are appended to, rather than substituted
 *         for, the real hardware scan.
 */
bool mvgal_mock_appends_to_hardware(void);

/** @return the number of synthetic devices in the active topology, else 0. */
uint32_t mvgal_mock_device_count(void);

/**
 * @brief Translate an MVGAL GPU index into a synthetic device slot.
 *
 * Synthetic devices may be appended after real ones, so a device slot is not
 * the same number as the GPU index the rest of MVGAL uses. Pass NULL for
 * @p slot_out to ask only whether the index is synthetic.
 *
 * @return true and writes @p slot_out when @p gpu_index is synthetic.
 */
bool mvgal_mock_slot_for_index(uint32_t gpu_index, uint32_t *slot_out);

/**
 * @brief Map an MVGAL GPU index back to its synthetic slot.
 *
 * @return true when @p gpu_index is backed by a synthetic device.
 */
bool mvgal_mock_index_for_slot(uint32_t slot, uint32_t *gpu_index_out);

/**
 * @brief Set the delivered load on one synthetic device.
 *
 * The device warms up while loaded and cools down while idle, so a load change
 * becomes visible in temperature and power only after mvgal_mock_advance().
 *
 * @param slot Synthetic device slot.
 * @param percent Load in [0, 100].
 * @return MVGAL_SUCCESS, MVGAL_ERROR_INVALID_ARGUMENT for an out-of-range slot
 *         or load, MVGAL_ERROR_NOT_INITIALIZED when no topology is active.
 */
mvgal_error_t mvgal_mock_set_load(uint32_t slot, uint32_t percent);

/**
 * @brief Occupy part of a synthetic device's VRAM budget.
 *
 * Passing 0 releases everything previously allocated through this call.
 *
 * @return MVGAL_SUCCESS, MVGAL_ERROR_OUT_OF_MEMORY when @p bytes exceeds the
 *         device's VRAM, MVGAL_ERROR_INVALID_ARGUMENT, MVGAL_ERROR_NOT_INITIALIZED.
 */
mvgal_error_t mvgal_mock_allocate_vram(uint32_t slot, uint64_t bytes);

/** @return the simulated VRAM occupancy of a device in bytes, else 0. */
uint64_t mvgal_mock_vram_used(uint32_t slot);

/**
 * @brief Fail one synthetic device, as if the GPU had fallen off the bus.
 *
 * The device stays enumerated but reports itself unavailable and unhealthy, so
 * selection must skip it while the rest of the pool keeps working.
 *
 * @return MVGAL_SUCCESS, MVGAL_ERROR_INVALID_ARGUMENT, MVGAL_ERROR_NOT_INITIALIZED.
 */
mvgal_error_t mvgal_mock_kill_device(uint32_t slot);

/**
 * @brief Recover a previously failed synthetic device.
 *
 * @return MVGAL_SUCCESS, MVGAL_ERROR_INVALID_ARGUMENT, MVGAL_ERROR_NOT_INITIALIZED.
 */
mvgal_error_t mvgal_mock_resurrect_device(uint32_t slot);

/** @return true when the synthetic device has been killed. */
bool mvgal_mock_device_failed(uint32_t slot);

/**
 * @brief Force the bandwidth of one synthetic peer link.
 *
 * Used to simulate a slow link or, with @p mbps 0, to simulate two devices that
 * share a root complex but have no peer path between them.
 *
 * @return MVGAL_SUCCESS, MVGAL_ERROR_INVALID_ARGUMENT, MVGAL_ERROR_NOT_INITIALIZED.
 */
mvgal_error_t mvgal_mock_set_link_bandwidth(uint32_t slot_a, uint32_t slot_b, uint32_t mbps);

/**
 * @brief Advance the simulation by @p milliseconds.
 *
 * Integrates power draw and temperature for every synthetic device, applies
 * thermal throttling, and republishes the results into the GPU manager so the
 * regular telemetry getters report the new values. The simulation is frozen
 * between calls: nothing changes on its own.
 *
 * @return MVGAL_SUCCESS, MVGAL_ERROR_INVALID_ARGUMENT for a negative duration,
 *         MVGAL_ERROR_NOT_INITIALIZED when no topology is active.
 */
mvgal_error_t mvgal_mock_advance(uint32_t milliseconds);

/**
 * @brief Read the simulated temperature of a synthetic device, in Celsius.
 *
 * @return the temperature, or 0.0f for an unknown slot.
 */
float mvgal_mock_temperature(uint32_t slot);

/**
 * @brief Read the simulated power draw of a synthetic device, in watts.
 *
 * @return the power draw, or 0.0f for an unknown slot.
 */
float mvgal_mock_power_watts(uint32_t slot);

/**
 * @brief Peer-link query used by the P2P cost model.
 *
 * Takes MVGAL GPU indices rather than device slots so the P2P layer does not
 * need to know how slots map onto the GPU pool. Both return false / 0 when
 * either index is real hardware, which tells the caller to fall back to sysfs
 * probing.
 *
 * Topology and reachability are deliberately separate answers: two devices can
 * share a root complex and still have no peer path once
 * mvgal_mock_set_link_bandwidth() has zeroed the link.
 *
 * @return true when both devices share a PCIe root complex in the synthetic
 *         topology. Consult mvgal_mock_link_bandwidth_mbps() for the path.
 */
bool mvgal_mock_same_root_complex(uint32_t gpu_index_a, uint32_t gpu_index_b);

/**
 * @brief Synthetic peer-link bandwidth in MB/s, or 0 when unconnected.
 */
uint32_t mvgal_mock_link_bandwidth_mbps(uint32_t gpu_index_a, uint32_t gpu_index_b);

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_MOCK_H */