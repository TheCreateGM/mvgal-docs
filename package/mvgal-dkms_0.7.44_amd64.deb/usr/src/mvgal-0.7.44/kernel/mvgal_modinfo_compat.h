/* SPDX-License-Identifier: GPL-2.0 */
/**
 * @file mvgal_modinfo_compat.h
 * @brief Version-independent dma-buf namespace import
 *
 * Multi-Vendor GPU Aggregation Layer for Linux
 *
 * MODULE_IMPORT_NS() has changed shape twice and distributions backport the
 * changes at different kernel versions, so a LINUX_VERSION_CODE test cannot
 * pick the right spelling:
 *
 *   kernel <= 6.12 (e.g. openSUSE Leap 16, 6.12.0)
 *       #define MODULE_IMPORT_NS(ns) MODULE_INFO(import_ns, #ns)
 *       -> MODULE_IMPORT_NS("DMA_BUF") records the value "DMA_BUF" WITH
 *          literal quotes, and modpost aborts the build with
 *          "MODULE_IMPORT_NS used with a quoted namespace '\"DMA_BUF\"'".
 *
 *   kernel >= 6.13 (e.g. Fedora 7.2.x)
 *       #define MODULE_IMPORT_NS(ns) MODULE_INFO(import_ns, ns)
 *       -> the bare identifier form no longer compiles at all.
 *
 * Both variants ultimately emit a ".modinfo" entry of the form
 * "import_ns=<value>", and MODULE_INFO() has always taken its value as a
 * plain string literal.  Writing that entry directly therefore produces the
 * same, correct record on every kernel without depending on how the macro is
 * spelled in the headers we happen to be built against.
 */
#ifndef MVGAL_MODINFO_COMPAT_H
#define MVGAL_MODINFO_COMPAT_H

#include <linux/module.h>
#include <linux/version.h>

/*
 * Declares the DMA_BUF namespace import.  Must be used at file scope, like
 * MODULE_IMPORT_NS() itself.
 *
 * Kernels older than 5.14 do not have namespace support at all (RHEL 8 ships
 * 4.18); there modpost does not enforce imports, so nothing is emitted.
 */
#if defined(MODULE_IMPORT_NS) || \
    (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 14, 0))
#define MVGAL_IMPORT_DMA_BUF_NS() MODULE_INFO(import_ns, "DMA_BUF")
#else
#define MVGAL_IMPORT_DMA_BUF_NS() /* namespace imports unsupported */
#endif

#endif /* MVGAL_MODINFO_COMPAT_H */
