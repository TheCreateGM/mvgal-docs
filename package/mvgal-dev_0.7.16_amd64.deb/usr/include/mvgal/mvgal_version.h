/**
 * @file mvgal_version.h
 * @brief Version information
 *
 * Multi-Vendor GPU Aggregation Layer for Linux
  * SPDX-License-Identifier: GPL-3.0-only
  */

#ifndef MVGAL_VERSION_H
#define MVGAL_VERSION_H

/*
 * The three numbers below are the single source of truth for this header.
 * MVGAL_VERSION_STRING is built from them by the stringify macros rather
 * than written out by hand, so the dotted string can never drift out of
 * sync with the numbers. A previous revision carried both forms
 * independently, and a version bump that updated only the string left
 * MVGAL_VERSION_PATCH a release behind -- the CLI kept reporting the old
 * patch number while the daemon and the generated header reported the new
 * one. To bump the version, edit only these three lines.
 *
 * When CMake configures the build it generates an authoritative copy of
 * this header from include/mvgal/mvgal_version.h.in, using the version
 * from project(). This in-tree copy remains the fallback for consumers
 * that compile against the source tree without configuring, so the two
 * must be bumped together -- see scripts/mksrpm.sh, which verifies them.
 */
#define MVGAL_VERSION_MAJOR 0
#define MVGAL_VERSION_MINOR 7
#define MVGAL_VERSION_PATCH 16

/* Two-level stringify: the outer macro expands its argument before the
 * inner one turns the result into a string literal. */
#define MVGAL_VERSION_STRINGIFY_(x) #x
#define MVGAL_VERSION_STRINGIFY(x) MVGAL_VERSION_STRINGIFY_(x)

#define MVGAL_VERSION_STRING                    \
    MVGAL_VERSION_STRINGIFY(MVGAL_VERSION_MAJOR) \
    "." MVGAL_VERSION_STRINGIFY(MVGAL_VERSION_MINOR) \
    "." MVGAL_VERSION_STRINGIFY(MVGAL_VERSION_PATCH)

#define MVGAL_VERSION_NAME "Cross-Vendor Aggregation"

#endif // MVGAL_VERSION_H
