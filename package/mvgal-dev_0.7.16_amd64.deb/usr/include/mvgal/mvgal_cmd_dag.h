/**
 * @file mvgal_cmd_dag.h
 * @brief Command Buffer DAG - Phase 3 Cross-Vendor Translation
 *
 * Represents Vulkan command buffers as a directed acyclic graph (DAG)
 * that can be translated and emitted for different GPU vendors.
 * SPDX-License-Identifier: GPL-3.0-only
 */

#ifndef MVGAL_CMD_DAG_H
#define MVGAL_CMD_DAG_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <vulkan/vulkan.h>
#include <mvgal/mvgal_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------ */
/*  Command Types                                                       */
/* ------------------------------------------------------------------ */

typedef enum {
    MVGAL_CMD_DRAW = 0,
    MVGAL_CMD_DRAW_INDIRECT = 1,
    MVGAL_CMD_DISPATCH = 2,
    MVGAL_CMD_DISPATCH_INDIRECT = 3,
    MVGAL_CMD_BLIT = 4,
    MVGAL_CMD_CLEAR = 5,
    MVGAL_CMD_COPY = 6,
    MVGAL_CMD_BARRIER = 7,
    MVGAL_CMD_BIND_DESCRIPTOR_SET = 8,
    MVGAL_CMD_BIND_PIPELINE = 9,
    MVGAL_CMD_NEXT_SUBPASS = 10,
} mvgal_cmd_type_t;

/* ------------------------------------------------------------------ */
/*  DAG Node                                                            */
/* ------------------------------------------------------------------ */

typedef struct mvgal_cmd_node {
    mvgal_cmd_type_t type;
    
    /* Union of all possible arguments */
    union {
        struct {
            uint32_t vertex_count;
            uint32_t instance_count;
            uint32_t first_vertex;
            int32_t first_instance;
        } draw;
        
        struct {
            VkBuffer buffer;
            VkDeviceSize offset;
            uint32_t count;
        } draw_indirect;
        
        struct {
            uint32_t group_x;
            uint32_t group_y;
            uint32_t group_z;
        } dispatch;
        
        struct {
            VkImage src_image;
            VkImage dst_image;
            VkOffset3D src_offset;
            VkOffset3D dst_offset;
            VkExtent3D extent;
        } blit;
        
        struct {
            VkImage image;
            VkRect2D render_area;
            VkClearValue clear_value;
        } clear;
        
        struct {
            VkBuffer src_buffer;
            VkBuffer dst_buffer;
            VkDeviceSize src_offset;
            VkDeviceSize dst_offset;
            VkDeviceSize size;
        } copy;
        
        struct {
            uint32_t dependency_count;
            const VkDependencyInfo* info;
        } barrier;
        
        struct {
            VkDescriptorSet set;
            uint32_t pipeline_layout;
        } bind_desc_set;
        
        struct {
            VkPipeline pipeline;
            VkPipelineLayout layout;
        } bind_pipeline;
    } args;
    
    /* Dependencies */
    struct mvgal_cmd_node** deps;
    size_t dep_count;
    size_t dep_capacity;
    
    /* Next node in list */
    struct mvgal_cmd_node* next;
    
    /* Vendor-specific emissions */
    void* vendor_data[MVGAL_MAX_GPUS];
} mvgal_cmd_node_t;

/* ------------------------------------------------------------------ */
/*  DAG Structure                                                       */
/* ------------------------------------------------------------------ */

typedef struct {
    mvgal_cmd_node_t* head;
    size_t node_count;
    uint32_t queue_family;
    uint32_t cmd_buffer_idx;
    bool primary; /* True if this is a primary command buffer */

    /* Vendor the DAG was translated for, set by mvgal_translate_dag().
     * MVGAL_VENDOR_UNKNOWN means "not translated for any specific vendor".
     * Emission uses this to refuse replaying a DAG at a device whose vendor
     * the DAG was not built for. */
    mvgal_vendor_t target_vendor;
} mvgal_cmd_dag_t;

/* ------------------------------------------------------------------ */
/*  DAG Construction                                                    */
/* ------------------------------------------------------------------ */

/**
 * @brief Create a new empty DAG
 * @return New DAG or NULL on failure
 */
mvgal_cmd_dag_t* mvgal_dag_create(void);

/**
 * @brief Destroy a DAG
 * @param dag DAG to destroy
 */
void mvgal_dag_destroy(mvgal_cmd_dag_t* dag);

/**
 * @brief Add a node to the DAG
 * @param dag DAG
 * @param type Command type
 * @return New node or NULL on failure
 */
mvgal_cmd_node_t* mvgal_dag_add_node(mvgal_cmd_dag_t* dag, mvgal_cmd_type_t type);

/**
 * @brief Add dependency between nodes
 * @param from Source node
 * @param to Target node (must execute after source)
 */
void mvgal_dag_add_dependency(mvgal_cmd_node_t* from, mvgal_cmd_node_t* to);

/* ------------------------------------------------------------------ */
/*  Command Recording Interceptions                                   */
/* ------------------------------------------------------------------ */

/**
 * @brief Record a draw command into the DAG
 * @param dag DAG to record into
 * @param vertex_count Number of vertices
 * @param instance_count Number of instances
 */
void mvgal_record_cmd_draw(mvgal_cmd_dag_t* dag, uint32_t vertex_count, uint32_t instance_count);

/**
 * @brief Record a dispatch command into the DAG
 * @param dag DAG to record into
 * @param group_x X workgroup size
 * @param group_y Y workgroup size
 * @param group_z Z workgroup size
 */
void mvgal_record_cmd_dispatch(mvgal_cmd_dag_t* dag, uint32_t group_x, uint32_t group_y, uint32_t group_z);

/**
 * @brief Record a barrier command into the DAG
 * @param dag DAG to record into
 * @param dependency_count Number of dependencies
 * @param info Dependency info
 */
void mvgal_record_cmd_barrier(mvgal_cmd_dag_t* dag, uint32_t dependency_count, const VkDependencyInfo* info);

/**
 * @brief Begin recording a command buffer to DAG
 * @param cmd_buf Original command buffer
 * @return New DAG or NULL on failure
 */
mvgal_cmd_dag_t* mvgal_cmd_dag_begin(VkCommandBuffer cmd_buf);

/**
 * @brief Begin recording a command buffer to DAG, recording its device too
 *
 * Identical to mvgal_cmd_dag_begin(), but additionally associates the owning
 * VkDevice with the command buffer so that mvgal_emit_dag() can reach the
 * next-hop dispatch table and replay real vkCmd* calls. Recording through
 * mvgal_cmd_dag_begin() still works, but DAGs recorded that way cannot be
 * emitted, because the device is then unknown and emit must fail rather than
 * guess.
 *
 * @param cmd_buf Original command buffer
 * @param device Device the command buffer was allocated from
 * @return New DAG or NULL on failure
 */
mvgal_cmd_dag_t* mvgal_cmd_dag_begin_for_device(VkCommandBuffer cmd_buf, VkDevice device);


/**
 * @brief End recording a command buffer
 * @param cmd_buf Command buffer to end
 */
void mvgal_cmd_dag_end(VkCommandBuffer cmd_buf);

/* ------------------------------------------------------------------ */
/*  DAG Capture from Vulkan Command Buffer                              */
/* ------------------------------------------------------------------ */

/**
 * @brief Capture a Vulkan command buffer as a DAG
 * @param cmd Original command buffer
 * @param dag Output DAG
 * @return VK_SUCCESS on success
 */
VkResult mvgal_capture_command_buffer(VkCommandBuffer cmd, mvgal_cmd_dag_t** dag);

/* ------------------------------------------------------------------ */
/*  DAG Translation and Emission                                        */
/* ------------------------------------------------------------------ */

/**
 * @brief Translate DAG for a target vendor
 *
 * Produces an independent deep copy of @p dag bound to @p vendor. Every node
 * and every dependency edge is duplicated, and dependency pointers are
 * remapped to the copies, so the result shares no mutable state with the
 * input and either DAG may be destroyed in any order. Mutating the returned
 * DAG cannot corrupt the source, which an aliasing "translate" would.
 *
 * The two things deliberately NOT copied are documented rather than faked:
 *  - mvgal_cmd_node_t::vendor_data[] is reset to NULL. Those slots hold opaque
 *    per-emission state owned by whoever produced them; carrying the pointers
 *    into a second DAG would alias ownership and risk a double free. A
 *    translated DAG re-derives whatever it needs at emit time.
 *  - args.barrier.info stays a borrowed const pointer, exactly as
 *    mvgal_record_cmd_barrier() left it. Ownership of the caller's
 *    VkDependencyInfo (and its barrier arrays) stays with the caller, who must
 *    keep it alive until emission completes.
 *
 * @param dag Input DAG
 * @param vendor Target vendor; must not be MVGAL_VENDOR_UNKNOWN
 * @return Translated DAG copy, or NULL on invalid input, unknown vendor,
 *         allocation failure, or a malformed DAG with an out-of-tree
 *         dependency edge.
 */
mvgal_cmd_dag_t* mvgal_translate_dag(mvgal_cmd_dag_t* dag, mvgal_vendor_t vendor);

/**
 * @brief Emit DAG to a Vulkan command buffer
 *
 * Replays the DAG's nodes into @p cmd in recording order, dispatching through
 * the next-hop device dispatch obtained from the layer. Note that
 * mvgal_dag_add_node() prepends, so walking head->next yields nodes in reverse
 * recording order; emit reverses into an ordered array first, because
 * replaying backwards would produce wrong rendering.
 *
 * The owning VkDevice must be known to the recorder, i.e. the command buffer
 * must have been opened with mvgal_cmd_dag_begin_for_device(). When it is not,
 * or the device has no dispatch table in this layer, emit fails with a logged
 * error instead of reporting a success it cannot back up.
 *
 * @param dag DAG to emit
 * @param cmd Target command buffer
 * @return VK_SUCCESS if every node was replayed. If a node type carries no
 *         captured arguments (MVGAL_CMD_DISPATCH_INDIRECT,
 *         MVGAL_CMD_NEXT_SUBPASS), or its entry point is unavailable, emit
 *         stops and returns an error rather than silently dropping work.
 */
VkResult mvgal_emit_dag(mvgal_cmd_dag_t* dag, VkCommandBuffer cmd);

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_CMD_DAG_H */