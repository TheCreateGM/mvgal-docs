#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mvgal::mvgal" for configuration "RelWithDebInfo"
set_property(TARGET mvgal::mvgal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(mvgal::mvgal PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib64/libmvgal.so.0.7.16"
  IMPORTED_SONAME_RELWITHDEBINFO "libmvgal.so.0"
  )

list(APPEND _cmake_import_check_targets mvgal::mvgal )
list(APPEND _cmake_import_check_files_for_mvgal::mvgal "${_IMPORT_PREFIX}/lib64/libmvgal.so.0.7.16" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
