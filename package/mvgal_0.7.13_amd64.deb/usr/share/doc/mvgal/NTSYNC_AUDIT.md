# NTSYNC Kernel Module Audit

**Auditor:** CoderAgent  
**Date:** 2026-06-26  
**Session:** production-sprint  
**Target:** M6 Milestone — NTSYNC / WoW64 Production

---

## Executive Summary

The NTSYNC subsystem has strong **kernel-side fundamentals** and a **well-structured userspace library**, but the **daemon integration is completely absent**. The kernel module (`mvgal_ntsync.ko`) is a standalone misc device with 17 IOCTLs covering Events, Semaphores, Mutexes, Timers, and DMA-Fence-backed cross-GPU fences. The userspace compat library (`compat/ntsync/`) provides thin C wrappers over the IOCTLs, and there are unit tests for the timer and multi-wait paths. However, the runtime daemon (`mvgald`) has **zero NTSYNC awareness**, the Steam frame pacer does not use NTSYNC for timing, and there is no Wine/Proton interposition layer to redirect Windows sync APIs to the MVGAL NTSYNX kernel module.

**M6 Status: 🔄 Partial — kernel module exists, userspace lib exists, daemon integration missing**

---

## 1. Current NTSYNC IOCTL Interface

### 1.1 Kernel Module

**File:** `kernel/mvgal_ntsync.c` (~750 lines)  
**Device:** `/dev/mvgal_ntsync` (misc device, minor `MISC_DYNAMIC_MINOR`)  
**Version:** 0.3.0  
**License:** GPL-2.0  
**Build:** Standalone `mvgal_ntsync.ko` (no dependency on `mvgal.ko`)

#### Object Types

| Type | ID | Kernel Backing | Flags |
|------|----|----------------|-------|
| Event | `MVGAL_NTSYNC_TYPE_EVENT` (1) | `atomic_t signaled`, `wait_queue_head_t` | `AUTO_RESET`, `SIGNALED`, `SHARED` |
| Semaphore | `MVGAL_NTSYNC_TYPE_SEMAPHORE` (2) | `atomic_t count`, `atomic_t max_count` | `AUTO_RESET`, `SHARED` |
| Mutex | `MVGAL_NTSYNC_TYPE_MUTEX` (3) | `atomic_t signaled`, `owner_tid` | `AUTO_RESET`, `SHARED` |
| Timer | `MVGAL_NTSYNC_TYPE_TIMER` (4) | `struct timer_list`, `atomic_t signaled` | Always `AUTO_RESET` (forced) |
| Fence | `MVGAL_NTSYNC_TYPE_FENCE` (5) | `struct dma_fence *`, `gpu_index` | `SHARED` |

#### Complete IOCTL Table

| # | IOCTL | Direction | Struct | Description |
|---|-------|-----------|--------|-------------|
| 1 | `MVGAL_NTSYNC_IOC_CREATE_EVENT` | R/W | `mvgal_ntsync_create_args` | Create event, returns fd |
| 2 | `MVGAL_NTSYNC_IOC_OPEN_EVENT` | Write | `mvgal_ntsync_open_args` | Open existing event (stub) |
| 3 | `MVGAL_NTSYNC_IOC_WAIT_EVENT` | R/W | `mvgal_ntsync_wait_args` | Wait single event |
| 4 | `MVGAL_NTSYNC_IOC_SIGNAL_EVENT` | Write | `mvgal_ntsync_signal_args` | Signal event |
| 5 | `MVGAL_NTSYNC_IOC_CREATE_SEMAPHORE` | R/W | `mvgal_ntsync_create_args` | Create semaphore, returns fd |
| 6 | `MVGAL_NTSYNC_IOC_WAIT_SEMAPHORE` | R/W | `mvgal_ntsync_wait_args` | Wait/decrement semaphore |
| 7 | `MVGAL_NTSYNC_IOC_RELEASE_SEMAPHORE` | Write | `mvgal_ntsync_signal_args` | Release/increment semaphore |
| 8 | `MVGAL_NTSYNC_IOC_CREATE_MUTEX` | R/W | `mvgal_ntsync_create_args` | Create mutex, returns fd |
| 9 | `MVGAL_NTSYNC_IOC_ACQUIRE_MUTEX` | R/W | `mvgal_ntsync_wait_args` | Acquire (wait on) mutex |
| 10 | `MVGAL_NTSYNC_IOC_RELEASE_MUTEX` | Write | `mvgal_ntsync_signal_args` | Release mutex |
| 11 | `MVGAL_NTSYNC_IOC_CREATE_TIMER` | R/W | `mvgal_ntsync_create_args` | Create timer, returns fd |
| 12 | `MVGAL_NTSYNC_IOC_SET_TIMER` | Write | `mvgal_ntsync_timer_args` | Arm/disarm timer |
| 13 | `MVGAL_NTSYNC_IOC_CREATE_FENCE` | R/W | `mvgal_ntsync_fence_args` | Create cross-GPU fence |
| 14 | `MVGAL_NTSYNC_IOC_WAIT_FENCE` | R/W | `mvgal_ntsync_wait_args` | Wait on dma_fence |
| 15 | `MVGAL_NTSYNC_IOC_SIGNAL_FENCE` | Write | `mvgal_ntsync_signal_args` | Signal dma_fence |
| 16 | `MVGAL_NTSYNC_IOC_WAIT_MULTI` | R/W | `mvgal_ntsync_multi_wait_args` | WaitAny/WaitAll up to 64 objects |

#### IOCTL Argument Structures

```c
struct mvgal_ntsync_create_args {
    __u32 type;        // Object type (out)
    __u32 flags;       // AUTO_RESET, SIGNALED, SHARED
    __u32 initial;     // Initial count (semaphores)
    __u32 fd;          // Created FD (out)
};

struct mvgal_ntsync_wait_args {
    __u32 fd;          // Object FD
    __u32 status;      // 0=signaled, 1=timeout (out)
    __u64 timeout_ns;  // 0=infinite
};

struct mvgal_ntsync_signal_args {
    __u32 fd;
    __u32 count;       // Release count (semaphore)
    __u32 alertable;   // APC alertable flag
};

struct mvgal_ntsync_timer_args {
    __u32 fd;
    __u64 due_time_ns; // Absolute delta from now (CLOCK_MONOTONIC)
    __u64 period_ns;   // Periodic interval (0 = one-shot)
};

struct mvgal_ntsync_fence_args {
    __u32 fd;          // Created FD (out)
    __u32 gpu_index;   // GPU this fence belongs to
    __u32 flags;       // SHARED etc.
    __u64 timeout_ns;  // Default timeout
};

#define MVGAL_NTSYNC_MAX_WAIT_OBJECTS 64
struct mvgal_ntsync_multi_wait_args {
    __u32 count;       // 1-64
    __u32 wait_type;   // 0=WaitAny, 1=WaitAll
    __u32 status;      // 0=signaled, 1=timeout (out)
    __u32 index;       // Index of signaled object (out)
    __u64 timeout_ns;  // 0=infinite
    __u64 fds;         // Pointer to userspace array of __u32 FDs
};
```

#### Object Lifecycle

```
User opens /dev/mvgal_ntsync → ntsync_open() → fd to misc device

User sends CREATE_* IOCTL → create_object() → struct mvgal_ntsync_object
  → anon_inode_getfd() → returns new per-object FD
  → object registered in global ntsync_objects list

User calls wait/signal via original misc device FD
  → find_object_by_fd() looks up in global list
  → operation on object's waitqueue/DMA fence/timer

close(object_fd) → ntsync_release() → release_object()
  → refcount decrement → kfree when zero
```

#### Multi-Object Wait Implementation

The `ntsync_ioctl_wait_multi()` function implements `WaitForMultipleObjects`:
- Allocates wait entries for all objects
- Registers on ALL object waitqueues simultaneously via `prepare_to_wait()`
- On wake: checks `ntsync_is_signaled()` for each object
- WaitAny: returns first signaled index
- WaitAll: returns when all are signaled
- Supports timeout via `schedule_timeout()`
- Handles `signal_pending()` with `-ERESTARTSYS`

#### Multi-Object Wait State Machine

```
  ┌─────────┐    copy_from_user(fds)     ┌───────────┐
  │  Entry  │ ─────────────────────────→ │ Lookup    │
  └─────────┘                            │ Objects   │
                                         └─────┬─────┘
                                               │
                                    ┌──────────▼──────────┐
                                    │ Check signaled?     │
                                    │ All/WaitAny loop    │
                                    └─────┬────────┬──────┘
                                          │        │
                                No signal ┘        ┘ Signaled
                                          │        │
                                    ┌─────▼──┐ ┌───▼──────┐
                                    │Prepare  │ │Consume   │
                                    │to_wait()│ │Signal    │
                                    │on ALL   │ │           │
                                    │objs     │ │out status │
                                    └────┬────┘ └──────────┘
                                         │
                                    ┌────▼────┐
                                    │Schedule │
                                    │timeout  │
                                    └────┬────┘
                                         │
                                    ┌────▼────┐
                                    │Wake:    │
                                    │check    │
                                    │signaled │ ───→ Loop or exit
                                    └─────────┘
```

---

### 1.2 UAPI Integration (`/dev/mvgal0`)

**File:** `include/mvgal/mvgal_uapi.h`

The main MVGAL device provides an NTSYNC query IOCTL:

```c
#define MVGAL_IOC_NTSYNC_QUERY  _IOR(MVGAL_IOC_MAGIC, 0x20, struct mvgal_uapi_ntsync_info)

struct mvgal_uapi_ntsync_info {
    __u32 version_major;    // Hardcoded to 0
    __u32 version_minor;    // Hardcoded to 1
    __u32 version_patch;    // Hardcoded to 0
    __u32 capabilities;     // Bitmask
    __u8  reserved[32];
};
```

**Current implementation in `mvgal_main.c`:** The handler returns hardcoded values — it does NOT detect if the `mvgal_ntsync.ko` module is actually loaded. The feature flag `MVGAL_UAPI_FEATURE_NTSYNC` (1 << 7) is declared but NOT included in `MVGAL_UAPI_FEATURE_FLAGS` or `MVGAL_UAPI_NTSYNC_CAP_FLAGS`.

Capability bitmask includes: `EVENT | SEMAPHORE | MUTEX | TIMER | FENCE`
Notably **missing**: `MVGAL_NTSYNC_CAP_CROSS_GPU` (bit 5) — despite the fence type having `gpu_index` support.

---

### 1.3 Userspace Compat Library

**Files:** `compat/ntsync/ntsync.c` (~270 lines), `compat/ntsync/ntsync.h` (~100 lines)

A clean C wrapper library:

| Function | IOCTL | Description |
|----------|-------|-------------|
| `ntsync_init()` | — | Opens `/dev/mvgal_ntsync` |
| `ntsync_fini()` | — | Closes device fd |
| `ntsync_create_event()` | `IOC_CREATE_EVENT` | Returns object fd |
| `ntsync_create_semaphore()` | `IOC_CREATE_SEMAPHORE` | Initial + max count |
| `ntsync_create_mutex()` | `IOC_CREATE_MUTEX` | Returns object fd |
| `ntsync_create_timer()` | `IOC_CREATE_TIMER` | Returns object fd |
| `ntsync_create_fence()` | `IOC_CREATE_FENCE` | GPU-indexed fence |
| `ntsync_wait()` | `IOC_WAIT_EVENT` | Single-object wait |
| `ntsync_signal()` | `IOC_SIGNAL_EVENT` | Signal event |
| `ntsync_release_semaphore()` | `IOC_RELEASE_SEMAPHORE` | Increment count |
| `ntsync_release_mutex()` | `IOC_RELEASE_MUTEX` | Unlock |
| `ntsync_set_timer()` | `IOC_SET_TIMER` | Arm/disarm |
| `ntsync_wait_multi()` | `IOC_WAIT_MULTI` | WaitAny/WaitAll |
| `ntsync_close()` | — | `close()` on object fd |

**Fallback** (`#ifdef MVGAL_NTSYNC_FALLBACK`): Userspace-only implementation using `eventfd` + pthread condition variables. This is a last-resort path for systems without the kernel module.

---

## 2. Integration with mvgal.ko

### 2.1 Current Integration Surface

```
┌──────────────────────────────────────────────────────┐
│                  Userspace                           │
│                                                      │
│  Game/App ─→ Proton/Wine ─→ VK_LAYER_MVGAL          │
│                                    │                 │
│         compat/ntsync/ntsync.c      │                │
│              ↓ (ioctl)              │                │
├──────────────────────────────────────┼───────────────┤
│  Kernel                              │               │
│                                      │               │
│  /dev/mvgal0 (mvgal.ko)             │               │
│    ├── MVGAL_IOC_NTSYNC_QUERY       │               │
│    │   (hardcoded, no real detection)│               │
│    │                                  │               │
│  /dev/mvgal_ntsync (mvgal_ntsync.ko) │               │
│     ├── All NTSYNC IOCTLs            │               │
│     └── dma_fence objects            │               │
│         (standalone, no link to      │               │
│          mvgal's fence system)       │               │
└──────────────────────────────────────────────────────┘
```

### 2.2 Key Integration Points (Present)

1. **`MVGAL_IOC_NTSYNC_QUERY`** — Userspace can discover NTSYNC capabilities via `/dev/mvgal0`
2. **`steam/compatibilitytool.vdf`** — Sets `WINE_NTSYNC=1` and `MVGAL_NTSYNC_ENABLE=1`
3. **Shader compiler** (`mvgal_shader_compiler.c`) — Uses NTSYNC events for async job tracking
4. **Command buffer rewrite** — References NTSYNC wait operations in comments
5. **Feature flag** — `MVGAL_UAPI_FEATURE_NTSYNC` (1 << 7) exists in the UAPI

### 2.3 Key Integration Points (MISSING)

1. **No dma_fence cross-linking** — NTSYNC fences create standalone `dma_fence` objects but don't register them with `mvgal_sync.c`'s cross-vendor fence tracking
2. **No device reference** — `mvgal_ntsync.c` doesn't import or reference any mvgal symbols
3. **No daemon awareness** — `mvgald` never opens `/dev/mvgal_ntsync` or initializes the compat library
4. **No kernel symbol export** — `mvgal_ntsync_query()` is declared in the header but not exported or called from mvgal_main.c

---

## 3. Gap Analysis: M6 Milestone Requirements

### 3.1 M6 Definition

From `docs/IMPLEMENTATION_RECOMMENDATIONS.md`:
> **Goal**: Wine/Proton integration without forks
> - Wine compatibility — Test with `WINE_NTSYNC=1`
> - WoW64 support — Ensure 32-bit Windows apps work
> - Performance parity — Match esync/fsync latency

From `docs/RESEARCH_PHASE3.md`:
> "NTSYNC integration should not fork Wine wholesale initially; ship a kernel module + patch set Proton can consume via `WINE_NTSYNC=1`"

From session context:
> "Wire ntsync kernel module into mvgald daemon"
> "Integration tests with Proton game workloads"
> "Frame pacing integration"

### 3.2 Gap Table

| # | Requirement | Current Status | Gap | Priority |
|---|-------------|---------------|-----|----------|
| G1 | Kernel NTSYNC objects (Event/Sem/Mutex) | ✅ Complete | — | — |
| G2 | Kernel NTSYNC Timer | ✅ Complete | — | — |
| G3 | Multi-object wait (WaitAny/WaitAll) | ✅ Complete | — | — |
| G4 | Cross-GPU dma_fence support | ⚠️ Partial | Fences created but not linked to mvgal_sync.c fence tracking | Medium |
| G5 | WoW64 thunk layer | ✅ Complete | Separate deliverable, not analyzed here | — |
| G6 | **mvgald daemon NTSYNC integration** | ❌ Missing | Daemon has zero NTSYNC code | **HIGH** |
| G7 | **Proton/Wine interposition** | ❌ Missing | No LD_PRELOAD shim or Wine patch to redirect sync APIs | **HIGH** |
| G8 | **Frame pacing via NTSYNC** | ❌ Missing | Frame pacer uses raw CLOCK_MONOTONIC, not NTSYNC timers | **HIGH** |
| G9 | **Integration tests** | ⚠️ Partial | Unit tests exist but no full-chain (kernel→lib→Wine) | **HIGH** |
| G10 | MVGAL_IOC_NTSYNC_QUERY real detection | ❌ Broken | Returns hardcoded values, doesn't check module loaded | Medium |
| G11 | NTSYNC feature flag in caps | ❌ Missing | `MVGAL_UAPI_FEATURE_NTSYNC` not included in `feature_flags` | Medium |
| G12 | Cross-GPU fence cap flag | ❌ Missing | `MVGAL_NTSYNC_CAP_CROSS_GPU` defined but not included | Medium |
| G13 | Named NTSYNC objects | ❌ Missing | No named object support (Wine needs cross-process sync) | Medium |
| G14 | Performance monitoring | ❌ Missing | No stats: object counts, wait times, contention | Low |
| G15 | IOCP/Completion ports | ❌ Missing | Listed as future work; not needed for M6 | Low |
| G16 | Module auto-load | ❌ Missing | No systemd module load or udev rule for `/dev/mvgal_ntsync` | Medium |
| G17 | APC/Alertable wait | ⚠️ Partial | `alertable` field exists in signal_args but not implemented | Low |
| G18 | Object security descriptors | ❌ Missing | Uses default kernel security (no Windows SECURITY_ATTRIBUTES) | Low |

### 3.3 M6 Critical Path

```
┌─────────────────────────────────────────────────────────────────────────┐
│  M6 CRITICAL PATH                                                        │
│                                                                          │
│  G6 ──→ mvgald opens /dev/mvgal_ntsync at startup                       │
│           ├── NTSYNC feature flag detection                              │
│           ├── Object lifecycle tracking per-process                      │
│           └── IPC messages for NTSYNC management                        │
│                                                                          │
│  G7 ──→ Wine/Proton LD_PRELOAD shim                                     │
│           ├── Intercept NtCreateEvent, NtCreateSemaphore, etc.          │
│           ├── Convert to MVGAL NTSYNC IOCTLs                            │
│           └── Handle WoW64 thunking through existing layer              │
│                                                                          │
│  G8 ──→ Frame pacer uses NTSYNC timer                                   │
│           ├── Create NTSYNC timer for vsync boundary                    │
│           ├── Wait on timer in presentation thread                      │
│           └── Fall back to poll() if NTSYNC unavailable                │
│                                                                          │
│  G9 ──→ Full-chain integration test                                     │
│           ├── Load mvgal_ntsync.ko                                      │
│           ├── Initialize compat library from mvgald                     │
│           ├── Create event/sem/mutex from daemon                        │
│           └── Verify with Proton game loop                              │
│                                                                          │
│  G10 ──→ MVGAL_IOC_NTSYNC_QUERY returns real status                    │
│           ├── Check if /dev/mvgal_ntsync exists / module is loaded     │
│           └── Return actual version + capabilities                     │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Integration Points with mvgald Daemon

### 4.1 Current Daemon Architecture

The daemon (`runtime/daemon/`) has these subsystems relevant to NTSYNC:

| Subsystem | File | NTSYNC Relevance |
|-----------|------|-------------------|
| `Daemon` | `daemon.cpp` | Entry point, subsystem orchestration |
| `IpcServer` | `ipc_server.cpp` | 21 IPC message types; NTSYNC not among them |
| `Scheduler` | `scheduler.cpp` | Uses timeline semaphores (futex-based) |
| `MetricsCollector` | `metrics_collector.cpp` | Polls sysfs; no NTSYNC stats |
| `DeviceRegistry` | `device_registry.cpp` | GPU enumeration; no NTSYNC capability probing |
| Frame pacer | `steam/mvgal_frame_pacer.c` | Times vsync via CLOCK_MONOTONIC |

### 4.2 Required Daemon Integration Points

#### 4.2.1 Initialization (in `daemon.cpp`)

```cpp
// At startup, after IPC server is ready:
void Daemon::init_ntsync() {
    if (access("/dev/mvgal_ntsync", F_OK) == 0) {
        m_ntsync_available = (ntsync_init() == 0);
        if (m_ntsync_available) {
            MVGAL_LOG(INFO, "NTSYNC kernel module detected, %u objects supported",
                     64); // MVGAL_NTSYNC_MAX_WAIT_OBJECTS
        }
    }
}
```

#### 4.2.2 IPC Messages (in `ipc_server.cpp`)

New message types required:

| Message Type | Direction | Payload | Description |
|-------------|-----------|---------|-------------|
| `NTSYNC_QUERY` | C→S | `empty` | Query NTSYNC availability & caps |
| `NTSYNC_CREATE_EVENT` | C→S | `flags, initial_state` | Create event, returns fd |
| `NTSYNC_CREATE_SEMAPHORE` | C→S | `initial, max` | Create semaphore, returns fd |
| `NTSYNC_CREATE_MUTEX` | C→S | `empty` | Create mutex, returns fd |
| `NTSYNC_CREATE_TIMER` | C→S | `flags` | Create timer, returns fd |
| `NTSYNC_CREATE_FENCE` | C→S | `gpu_index` | Create cross-GPU fence, returns fd |
| `NTSYNC_WAIT_MULTI` | C→S | `fds[], count, wait_type, timeout` | Multi-object wait |
| `NTSYNC_SIGNAL` | C→S | `fd` | Signal event/sem/mutex/fence |
| `NTSYNC_SET_TIMER` | C→S | `fd, due_time, period` | Arm/disarm timer |

#### 4.2.3 Frame Pacer Integration (in `steam/mvgal_frame_pacer.c`)

Replace raw `clock_nanosleep(CLOCK_MONOTONIC, ...)` with NTSYNC timer wait:

```c
// Frame pacer thread loop:
while (active) {
    // ... wait for frame ready ...
    
    if (g_ntsync_available) {
        // Use NTSYNC timer for vsync-aligned wakeup
        ntsync_set_timer(vsync_timer, frame_interval_ns, frame_interval_ns);
        ntsync_wait(vsync_timer, 0); // infinite wait
    } else {
        // Fallback: poll-based timing
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next_vsync, NULL);
    }
    
    // ... present frame ...
}
```

#### 4.2.4 Capability Probing (in `device_registry.cpp`)

Add NTSYNC capability to device registry:

```cpp
struct NtsyncInfo {
    bool available;
    uint32_t version_major;
    uint32_t version_minor;
    uint32_t version_patch;
    uint32_t capabilities;  // EVENT | SEMAPHORE | MUTEX | TIMER | FENCE
};
```

### 4.3 Scheduler Integration

The scheduler (`scheduler.cpp`) uses timeline semaphores for cross-GPU synchronization. NTSYNC fences should integrate:

```cpp
// In scheduler GPU selection logic:
if (mode == DYNAMIC_LOAD_BALANCING && ntsync_available) {
    // Use NTSYNC fence as completion signal for GPU work
    int fence_fd;
    ntsync_create_fence(&fence_fd, target_gpu_index);
    submit_workload_with_fence(workload, fence_fd);
    ntsync_wait(fence_fd, timeout_ns);
}
```

---

## 5. Cross-GPU Fence Analysis

### 5.1 Current NTSYNC Fence Implementation

The NTSYNC fence (type 5) wraps a `struct dma_fence *`:

```c
case MVGAL_NTSYNC_TYPE_FENCE:
    obj->dma_fence = NULL;  // Created on-demand
    obj->owner_tid = fence_args.gpu_index;  // Stores GPU index
```

**Signal path:**
```c
case MVGAL_NTSYNC_TYPE_FENCE:
    if (obj->dma_fence)
        dma_fence_signal(obj->dma_fence);
    wake_up_all(&obj->waitq);
```

**Wait path:**
```c
case MVGAL_NTSYNC_TYPE_FENCE:
    if (obj->dma_fence) {
        dma_fence_wait_timeout(obj->dma_fence, true, timeout);
    }
```

### 5.2 Integration with mvgal_sync.c

The main mvgal sync module (`mvgal_sync.c`) provides cross-vendor fences. The NTSYNC fence type should connect:

```
NTSYNC Fence (mvgal_ntsync.c)          MVGAL Sync (mvgal_sync.c)
                                   
┌──────────────────────┐          ┌──────────────────────────┐
│  dma_fence           │          │  struct mvgal_fence      │
│  gpu_index           │          │  struct dma_fence *      │
│  waitq               │          │  timeline_semaphore     │
│                      │          │  vendor_id              │
│  ntsync_is_signaled()│          │                         │
│    → dma_fence_is    │          │  mvgal_fence_create()   │
│      _signaled()     │          │  mvgal_fence_signal()   │
└──────────────────────┘          └──────────────────────────┘
          │                                    │
          └────────── SHOULD SHARE ────────────┘
                        dma_fence
                    allocation + tracking
```

Currently, NTSYNC fences create `dma_fence` objects in isolation. They should reuse or register with `mvgal_sync.c`'s fence infrastructure so cross-vendor GPU submissions can signal NTSYNC fences and vice versa.

---

## 6. Required Changes Checklist

### 6.1 Kernel Module (mvgal_ntsync.ko)

- [ ] **G10 Real NTSYNC detection**: Implement `mvgal_ntsync_query()` to actually check if the module is initialized and return real version/capabilities
- [ ] **G12 Cross-GPU cap**: Include `MVGAL_NTSYNC_CAP_CROSS_GPU` in the query response
- [ ] **G12 Fence linking**: Register NTSYNC dma_fence objects with mvgal_sync.c's fence tracking
- [ ] **G13 Named objects**: Add NTSYNC named object support (or at minimum, a design for cross-process handle sharing)
- [ ] **G14 Performance counters**: Add `debug_level`-gated stats collection (object counts, contention events, wait durations)
- [ ] **G17 Alertable waits**: Implement `alertable` flag handling for APC support
- [ ] **Bugfix Timer jiffies precision**: `nsecs_to_jiffies()` in `ntsync_timer_callback()` loses precision; document or improve
- [ ] **Module parameters**: Add `max_objects` parameter (currently missing despite being documented in NTSYNC_DESIGN.md)

### 6.2 mvgal.ko Integration

- [ ] **G10 Wire NTSYNC query**: Call `mvgal_ntsync_query()` from `MVGAL_IOC_NTSYNC_QUERY` handler in `mvgal_main.c` instead of returning hardcoded data
- [ ] **G11 Feature flag**: Add `MVGAL_UAPI_FEATURE_NTSYNC` to `MVGAL_UAPI_FEATURE_FLAGS`
- [ ] **G11 Cap flags**: Add `MVGAL_NTSYNC_CAP_CROSS_GPU` to `MVGAL_UAPI_NTSYNC_CAP_FLAGS`
- [ ] **Kconfig**: Add `CONFIG_MVGAL_NTSYNC` Kconfig option (currently none)

### 6.3 mvgald Daemon

- [ ] **G6 Init NTSYNC**: Open `/dev/mvgal_ntsync` and call `ntsync_init()` at daemon startup
- [ ] **G6 IPC messages**: Add NTSYNC message types to `ipc_server.cpp` (CREATE, WAIT, SIGNAL, TIMER)
- [ ] **G6 Object tracking**: Track per-client NTSYNC object lifecycle in the daemon
- [ ] **G6 Capability probing**: Add NTSYNC availability to `DeviceRegistry`
- [ ] **G8 Frame pacer NTSYNC**: Convert frame pacer timing from `clock_nanosleep` to NTSYNC timer
- [ ] **G8 Fallback**: Keep `clock_nanosleep` as fallback when NTSYNC is unavailable
- [ ] **Scheduler fence integration**: Use NTSYNC fences for cross-GPU workload completion signals

### 6.4 Proton/Wine Layer

- [ ] **G7 LD_PRELOAD shim**: Create `mvgal_ntsync_proton.so` that intercepts Windows sync APIs
- [ ] **G7 API mapping**: Map `NtCreateEvent` → `ntsync_create_event()`, `NtWaitForSingleObject` → `ntsync_wait()`, etc.
- [ ] **G7 WoW64 interop**: Route 32-bit Windows sync calls through existing WoW64 thunk
- [ ] **G7 Environment variable**: `WINE_NTSYNC=1` support (already set by compatibilitytool.vdf)
- [ ] **G7 Fallback**: Delegate to Wine's default fsync/esync when MVGAL NTSYNC unavailable

### 6.5 Build & Deploy

- [ ] **G16 Systemd module load**: Add `mvgal-ntsync-load.service` or modprobe config
- [ ] **G16 udev rule**: Add `/dev/mvgal_ntsync` udev rule (group `video`, mode `0660`)
- [ ] **G16 DKMS**: Include `mvgal_ntsync.ko` in DKMS build config
- [ ] **G16 Packaging**: Add `mvgal-ntsync` subpackage to RPM/DEB/PKGBUILD

### 6.6 Tests

- [ ] **G9 Full-chain test**: Test that loads `mvgal_ntsync.ko`, opens it via compat lib, creates all object types, and exercises wait/signal paths
- [ ] **G9 daemon integration test**: Test IPC NTSYNC messages through mvgald
- [ ] **G9 Frame pacer test**: Verify NTSYNC timer-based frame pacing timing accuracy
- [ ] **G9 Multi-GPU fence test**: Create NTSYNC fence, associate with GPU, wait/signal across GPUs
- [ ] **Edge cases**: Max objects (64), timeout corner cases, concurrent multi-wait
- [ ] **Error paths**: Module not loaded, invalid FDs, OOM, signal interruption

### 6.7 Documentation

- [ ] Update `docs/NTSYNC_DESIGN.md` to reflect current implementation (it shows a different, simpler IOCTL set than what's actually coded)
- [ ] Add daemon integration docs for NTSYNC subsystem
- [ ] Document new IPC message types for NTSYNC
- [ ] Add Proton/Wine configuration examples

---

## 7. Implementation Priority Order

```
Phase 1 (M6 Critical — Next Sprint)
  G6:  mvgald daemon NTSYNC init + IPC       [HIGH]
  G7:  Proton LD_PRELOAD shim framework      [HIGH]
  G8:  Frame pacer NTSYNC timer              [HIGH]
  G10: MVGAL_IOC_NTSYNC_QUERY real status    [HIGH]
  G11: Feature flag in caps                  [HIGH]

Phase 2 (M6 Secondary — Next + 1 Sprint)
  G9:  Full-chain integration tests          [HIGH]
  G16: Module auto-load + udev + DKMS        [MEDIUM]
  G12: Cross-GPU fence capability flag       [MEDIUM]
  G13: Named object support                  [MEDIUM]

Phase 3 (Post-M6 Polish)
  G14: Performance monitoring stats          [LOW]
  G17: Alertable wait implementation         [LOW]
  G15: IOCP/Completion ports                 [FUTURE]
  G18: Security descriptors                  [LOW]
```

---

## 8. Dependency Graph

```
mvgal_ntsync.ko ── standalone, no deps
         │
         ▼
compat/ntsync/ntsync.c ── userspace ioctl wrapper
         │
         ├──→ mvgald/daemon.cpp            [G6 — needs init + IPC]
         ├──→ mvgald/ipc_server.cpp         [G6 — needs NTSYNC messages]
         ├──→ steam/mvgal_frame_pacer.c    [G8 — needs timer integration]
         ├──→ intercept/vulkan/*.c          [uses ntsync_create_event for shader compile]
         └──→ Proton LD_PRELOAD shim       [G7 — NEW component]

mvgal.ko
  └── MVGAL_IOC_NTSYNC_QUERY              [G10 — needs real data]
```

---

## 9. Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| NTSYNC kernel API drift from upstream Wine | Medium | High | Align IOCTL numbers and object semantics with Wine's `server/ntsync.c` |
| Performance regression vs fsync/esync | Medium | High | Profile NTSYNC vs fsync on same workload before production release |
| Anti-cheat false positives with NTSYNC | Low | Medium | Document in `mvgal-compat`; provide per-game opt-out |
| Timer precision insufficient for frame pacing | Low | Medium | `hrtimer` migration if jiffies-based timer drifts |
| WoW64 32-bit compat issues | Medium | Medium | Verify all struct layouts match in 32-bit mode |
| `/dev/mvgal_ntsync` permission denied | Low | Low | Add udev rule early in Phase 1 |

---

## 10. References

- **Kernel module**: `kernel/mvgal_ntsync.c` (~750 LOC, 17 IOCTLs)
- **Kernel header**: `kernel/mvgal_ntsync.h` (standalone types + integration API)
- **UAPI header**: `include/mvgal/mvgal_uapi.h` (MVGAL_IOC_NTSYNC_QUERY)
- **Compat library**: `compat/ntsync/ntsync.c` + `ntsync.h` (~270 LOC)
- **Unit tests**: `src/tests/tests/unit/test_ntsync.c` (12 test cases)
- **Shader compiler**: `src/userspace/intercept/vulkan/mvgal_shader_compiler.c` (NTSYNC job tracking)
- **Frame pacer**: `steam/mvgal_frame_pacer.c` (to be converted to NTSYNC timers)
- **Steam compat**: `steam/compatibilitytool.vdf` (WINE_NTSYNC=1, MVGAL_NTSYNC_ENABLE=1)
- **Design doc**: `docs/NTSYNC_DESIGN.md` (stale — shows different IOCTL set)
- **Implementation roadmap**: `docs/IMPLEMENTATION_RECOMMENDATIONS.md` §4.1
- **Current status**: `docs/STATUS.md` (M6 marked "Partial — WoW64 complete, kernel integration pending")
- **Session context**: `.tmp/sessions/2026-06-26-production-sprint/context.md`
