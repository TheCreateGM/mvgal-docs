# MVGAL API Reference

> **Version**: 0.5.0  
> **Last Updated**: 2026-06-06

---

## Table of Contents

1. [Public C Headers](#public-c-headers)
2. [Core API (mvgal.h)](#core-api)
3. [IOCTL Interface](#ioctl-interface)
4. [D-Bus API](#d-bus-api)
5. [REST API](#rest-api)
6. [Vulkan Extensions](#vulkan-extensions)
7. [Error Codes](#error-codes)

---

## Public C Headers

MVGAL exposes 26 public C headers under `include/mvgal/`. The main header
`mvgal.h` includes all core subsystem headers.

| Header | Description |
|--------|-------------|
| `mvgal.h` | Main API — init, shutdown, device query |
| `mvgal_types.h` | Core type definitions, enums, error codes |
| `mvgal_version.h` | Version macros (generated from `.h.in`) |
| `mvgal_uapi.h` | Kernel/userspace UAPI — IOCTL structs + commands |
| `mvgal_gpu.h` | GPU enumeration, properties, topology |
| `mvgal_memory.h` | Memory allocation, flags, placement |
| `mvgal_unified_heap.h` | Unified heap abstraction (Heaps 0–3) |
| `mvgal_scheduler.h` | Scheduler strategy, policy control |
| `mvgal_execution.h` | Frame sessions, migration plans |
| `mvgal_power.h` | Power management, DVFS, thermal |
| `mvgal_config.h` | Configuration file parsing |
| `mvgal_log.h` | Logging subsystem |
| `mvgal_ipc.h` | IPC client/server — Unix domain socket protocol |
| `mvgal_intercept.h` | API intercept layer interface |
| `mvgal_p2p_dma.h` | P2P DMA transfer API |
| `mvgal_pool.h` | Memory pool management |
| `mvgal_fork.h` | GPU fork/clone support |
| `mvgal_ai.h` | AI/ML scheduling hint API |
| `mvgal_coherency.h` | Cache coherency management |
| `mvgal_barrier_translate.h` | Barrier translation (Vulkan ↔ CUDA ↔ OpenCL) |
| `mvgal_cmd_dag.h` | Command DAG analysis |
| `mvgal_shader_backend.h` | Shader backend interface (SPIR-V routing) |
| `mvgal_sycl.h` | SYCL backend support |
| `mvgal_network.h` | Network pooling / RDMA |
| `mvgal_wow64.h` | WoW64 filesystem redirection types |

### Usage

```c
#include <mvgal/mvgal.h>

// All subsystems are available via the single include:
// - mvgal_types.h — types, enums, error codes
// - mvgal_gpu.h — GPU management
// - mvgal_memory.h — memory allocation
// - mvgal_scheduler.h — scheduling
// - mvgal_log.h — logging
// - mvgal_config.h — configuration
// - mvgal_sycl.h — SYCL backend
// - mvgal_power.h — power management
// - mvgal_p2p_dma.h — P2P DMA
// - mvgal_unified_heap.h — unified memory heaps
// - mvgal_wow64.h — WoW64
```

---

## Core API

### Initialization & Shutdown

```c
mvgal_error_t mvgal_init(uint32_t flags);
mvgal_error_t mvgal_init_with_config(const char *config_path, uint32_t flags);
void mvgal_shutdown(void);
bool mvgal_is_initialized(void);
```

- `mvgal_init(0)` — Initialize with default configuration.
- `mvgal_init_with_config("/path/to/config", 0)` — Custom config path.
- `mvgal_shutdown()` — Clean up all resources.
- `mvgal_is_initialized()` — Query init state.

### GPU Management

From `mvgal_gpu.h`:

```c
mvgal_error_t mvgal_get_gpu_count(uint32_t *count);
mvgal_error_t mvgal_get_gpu_info(mvgal_gpu_index_t index, mvgal_gpu_info_t *info);
mvgal_error_t mvgal_get_gpu_topology(mvgal_gpu_index_t index, mvgal_gpu_topology_t *topology);
```

- `mvgal_get_gpu_count` — Number of available GPUs.
- `mvgal_get_gpu_info` — Query name, vendor, VRAM, utilization.

### Memory Management

From `mvgal_memory.h`:

```c
mvgal_error_t mvgal_memory_alloc(mvgal_memory_alloc_info_t *info, mvgal_memory_handle_t *handle);
mvgal_error_t mvgal_memory_free(mvgal_memory_handle_t handle);
mvgal_error_t mvgal_memory_bind(mvgal_memory_handle_t handle, mvgal_gpu_index_t gpu);
```

### Scheduler Control

From `mvgal_scheduler.h`:

```c
mvgal_error_t mvgal_scheduler_set_strategy(mvgal_distribution_strategy_t strategy);
mvgal_error_t mvgal_scheduler_get_strategy(mvgal_distribution_strategy_t *strategy);
mvgal_error_t mvgal_scheduler_set_policy(const char *app_name, mvgal_distribution_strategy_t strategy);
```

### Power Management

From `mvgal_power.h`:

```c
mvgal_error_t mvgal_power_get_state(mvgal_gpu_index_t gpu, mvgal_power_state_t *state);
mvgal_error_t mvgal_power_get_temperature(mvgal_gpu_index_t gpu, int32_t *temperature_c);
mvgal_error_t mvgal_power_get_metrics(mvgal_gpu_index_t gpu, mvgal_power_metrics_t *metrics);
```

### P2P DMA

From `mvgal_p2p_dma.h`:

```c
mvgal_error_t mvgal_p2p_transfer(mvgal_p2p_context_t ctx, const mvgal_p2p_transfer_info_t *info);
mvgal_error_t mvgal_p2p_get_caps(mvgal_gpu_index_t src, mvgal_gpu_index_t dst, mvgal_p2p_caps_t *caps);
```

---

## IOCTL Interface

MVGAL exposes a character device at `/dev/mvgal0` with the following IOCTLs.
Defined in `include/mvgal/mvgal_uapi.h`.

### IOCTL Table

| IOCTL | Code | Direction | Description |
|-------|:----:|:---------:|-------------|
| `MVGAL_IOC_QUERY_VERSION` | `0x00` | Read | Query UAPI version |
| `MVGAL_IOC_GET_GPU_COUNT` | `0x01` | Read | Get number of GPUs |
| `MVGAL_IOC_GET_GPU_INFO` | `0x02` | Write-Read | Get GPU info by index |
| `MVGAL_IOC_ENABLE` | `0x03` | None | Enable MVGAL |
| `MVGAL_IOC_DISABLE` | `0x04` | None | Disable MVGAL |
| `MVGAL_IOC_GET_STATS` | `0x05` | Read | Get driver statistics |
| `MVGAL_IOC_GET_CAPS` | `0x06` | Read | Get capabilities |
| `MVGAL_IOC_RESCAN` | `0x07` | None | Trigger GPU rescan |
| `MVGAL_IOC_EXPORT_DMABUF` | `0x10` | Write-Read | Export DMA-BUF |
| `MVGAL_IOC_IMPORT_DMABUF` | `0x11` | Write-Read | Import DMA-BUF |
| `MVGAL_IOC_ALLOC_CROSS_VENDOR` | `0x12` | Write-Read | Cross-vendor allocation |
| `MVGAL_IOC_FREE_CROSS_VENDOR` | `0x13` | Write | Free cross-vendor alloc |

Magic number: `'M'` (0x4D)

### Key Structs

#### mvgal_uapi_version (IOCTL 0x00)
```c
struct mvgal_uapi_version {
    __u32 major;
    __u32 minor;
    __u32 patch;
    __u32 feature_flags;  // Bitmask of MVGAL_UAPI_FEATURE_*
};
```

#### mvgal_gpu_info (IOCTL 0x02 output)
```c
struct mvgal_gpu_info {
    __u32 index;
    __u32 vendor_id;          // PCI vendor ID (0x1002, 0x10DE, 0x8086, 0x1ED5)
    __u32 device_id;
    __u32 subsystem_vendor_id;
    __u32 subsystem_device_id;
    __u32 pci_domain;
    __u32 pci_bus;
    __u32 pci_slot;
    __u32 pci_function;
    __u32 class_code;
    __u32 numa_node;
    __u32 pcie_link_gen;
    __u32 pcie_link_width;
    __u32 flags;              // MVGAL_UAPI_GPU_FLAG_*
    __u64 largest_prefetchable_bar_bytes;
    __u64 largest_mmio_bar_bytes;
    char name[128];           // GPU name string
    char driver[32];          // Kernel driver name
    char bdf[16];             // BDF address (DDDD:BB:SS.F)
};
```

#### mvgal_uapi_caps (IOCTL 0x06)
```c
struct mvgal_uapi_caps {
    __u32 enabled;
    __u32 gpu_count;
    __u32 vendor_mask;          // Bitmask of detected vendors
    __u32 topology_generation;
    __u32 max_pcie_link_gen;
    __u32 max_pcie_link_width;
    __u32 feature_flags;
    __u32 largest_prefetchable_bar_bytes;
    __u32 largest_mmio_bar_bytes;
    __u8  p2p_matrix[32 * 32];  // P2P capability per GPU pair
};
```

#### mvgal_uapi_stats (IOCTL 0x05)
```c
struct mvgal_uapi_stats {
    __u64 open_count;
    __u64 release_count;
    __u64 ioctl_count;
    __u64 rescans;
    __u64 hotplug_events;
    __u64 unsupported_dmabuf_exports;
    __u64 unsupported_dmabuf_imports;
    __u64 unsupported_cross_vendor_allocs;
    __u64 dma_buf_export_count;
    __u64 dma_buf_import_count;
    __u64 cross_vendor_alloc_count;
    __u64 p2p_transfer_count;
    __u64 host_staging_transfer_count;
};
```

### Feature Flags

```c
enum mvgal_uapi_feature_flags {
    MVGAL_UAPI_FEATURE_ENUMERATION       = 1 << 0,
    MVGAL_UAPI_FEATURE_PCI_TOPOLOGY      = 1 << 1,
    MVGAL_UAPI_FEATURE_HOTPLUG_MONITOR   = 1 << 2,
    MVGAL_UAPI_FEATURE_RESCAN            = 1 << 3,
    MVGAL_UAPI_FEATURE_READ_ONLY_SKELETON = 1 << 4,
    MVGAL_UAPI_FEATURE_FUTURE_DMABUF     = 1 << 5,
    MVGAL_UAPI_FEATURE_FUTURE_SUBMISSION = 1 << 6,
};
```

### GPU Flags

```c
enum mvgal_uapi_gpu_flags {
    MVGAL_UAPI_GPU_FLAG_DISPLAY_CLASS    = 1 << 0,
    MVGAL_UAPI_GPU_FLAG_PCIE             = 1 << 1,
    MVGAL_UAPI_GPU_FLAG_DRIVER_BOUND     = 1 << 2,
    MVGAL_UAPI_GPU_FLAG_MULTIFUNCTION    = 1 << 3,
    MVGAL_UAPI_GPU_FLAG_VIRTUAL_FUNCTION = 1 << 4,
    MVGAL_UAPI_GPU_FLAG_INTEGRATED_GUESS = 1 << 5,
};
```

---

## D-Bus API

MVGAL exposes a D-Bus service for daemon control and monitoring.

| Property | Value |
|----------|-------|
| Bus name | `org.mvgal.MVGAL` |
| Object path | `/org/mvgal/daemon` |
| Interface | `org.mvgal.MVGAL` |

### Methods

| Method | Args | Returns | Description |
|--------|------|---------|-------------|
| `GetGPUCount` | — | `uint32 count` | Number of GPUs |
| `GetGPUInfo` | `uint32 index` | `struct GPUInfo` | GPU properties |
| `GetStats` | — | `struct Stats` | Daemon statistics |
| `GetScheduler` | — | `string strategy` | Current strategy |
| `SetScheduler` | `string strategy` | — | Set strategy |
| `GetPowerState` | `uint32 gpu_index` | `uint32 state` | GPU power state |
| `GetTemperature` | `uint32 gpu_index` | `int32 temp_c` | GPU temperature |
| `RescanGPUs` | — | — | Trigger hotplug rescan |
| `Ping` | — | — | Health check |

### Signals

| Signal | Args | Description |
|--------|------|-------------|
| `GPUHotplug` | `uint32 gpu_index`, `bool added` | GPU added/removed |
| `TemperatureWarning` | `uint32 gpu_index`, `int32 temperature` | Thermal warning |
| `PowerLimitReached` | `uint32 gpu_index` | Power cap hit |

### IPC Protocol

The daemon also exposes a Unix domain socket at `/run/mvgald.sock` for
high-throughput IPC (defined in `mvgal_ipc.h`):

```c
enum mvgal_ipc_message_type_t {
    MVGAL_IPC_MSG_PING,           // Health check
    MVGAL_IPC_MSG_GPU_ENUMERATE,  // Request GPU list
    MVGAL_IPC_MSG_GPU_LIST,       // GPU list response
    MVGAL_IPC_MSG_WORKLOAD_SUBMIT, // Submit workload
    MVGAL_IPC_MSG_WORKLOAD_RESULT, // Workload result
    MVGAL_IPC_MSG_MEMORY_ALLOCATE, // Allocate memory
    MVGAL_IPC_MSG_MEMORY_FREE,     // Free memory
    MVGAL_IPC_MSG_CONFIG_GET,      // Get config
    MVGAL_IPC_MSG_CONFIG_SET,      // Set config
    MVGAL_IPC_MSG_ERROR,           // Error response
};
```

---

## REST API

MVGAL provides a REST API (Go server in `ui/`) on port `:7474` by default.

### Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/v1/gpus` | List all GPUs |
| `GET` | `/api/v1/gpus/{index}` | Single GPU details |
| `GET` | `/api/v1/stats` | Aggregated statistics |
| `GET` | `/api/v1/scheduler` | Current scheduler status |
| `PUT` | `/api/v1/scheduler` | Set scheduler strategy |
| `GET` | `/api/v1/power` | Power state summary |
| `GET` | `/api/v1/temperature` | GPU temperatures |
| `GET` | `/api/v1/logs` | Recent daemon logs |
| `GET` | `/api/v1/health` | Health check |

### Example

```bash
curl http://localhost:7474/api/v1/gpus | jq
```

Response:
```json
{
  "gpus": [
    {
      "index": 0,
      "vendor": "NVIDIA",
      "name": "NVIDIA RTX 4080",
      "vram_total": 17179869184,
      "vram_free": 12884901888,
      "utilization": 0.45,
      "temperature_c": 62
    }
  ],
  "count": 1
}
```

### Configuration

```bash
# Start REST server
cd ui && go build -o mvgal-rest-server ./mvgal_rest_server.go
./mvgal-rest-server --listen :7474 --dbus org.mvgal.MVGAL
```

---

## Vulkan Extensions

MVGAL exposes the following Vulkan extensions through the intercept layer
and `VkPhysicalDeviceMVGAL` properties:

### MVGAL Extension Table

| Extension Name | Version | Description |
|---------------|:-------:|-------------|
| `VK_MVGAL_aggregation_device` | 1 | Query MVGAL virtual device properties |
| `VK_MVGAL_memory_heaps` | 1 | Unified heap (Heaps 0–3) enumeration |
| `VK_MVGAL_multi_gpu_submit` | 1 | Multi-GPU command buffer submission |
| `VK_MVGAL_scheduler_hint` | 1 | Per-submission scheduling hint |
| `VK_MVGAL_frame_pacing` | 1 | Frame pacing control via Vulkan |
| `VK_MVGAL_p2p_transfer` | 1 | P2P transfer between MVGAL GPUs |

### Extension Details

#### VK_MVGAL_aggregation_device
- **Type**: `VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_EXT`
- Provides `VkPhysicalDeviceMVGALProperties`:
  ```c
  typedef struct VkPhysicalDeviceMVGALProperties {
      VkStructureType sType;
      void* pNext;
      uint32_t physicalDeviceCount;
      uint32_t enabledGPUMask;
      VkBool32 aggregationActive;
  } VkPhysicalDeviceMVGALProperties;
  ```

#### VK_MVGAL_scheduler_hint
- **Type**: `VkSubmitInfo` pNext chain
- Allows per-submission strategy override:
  ```c
  typedef struct VkMVGALSchedulerHint {
      VkStructureType sType;
      void* pNext;
      VkMVGALSchedulerStrategy strategy;  // RR, AFR, SFR, etc.
      uint32_t targetGPUMask;
  } VkMVGALSchedulerHint;
  ```

---

## Error Codes

Defined in `mvgal_types.h`:

| Code | Value | Description |
|------|:-----:|-------------|
| `MVGAL_SUCCESS` | 0 | Success |
| `MVGAL_ERROR_INVALID_ARGUMENT` | 1 | Invalid argument |
| `MVGAL_ERROR_OUT_OF_MEMORY` | 2 | Out of memory |
| `MVGAL_ERROR_NOT_FOUND` | 3 | Resource not found |
| `MVGAL_ERROR_TIMEOUT` | 4 | Operation timed out |
| `MVGAL_ERROR_UNSUPPORTED` | 5 | Unsupported operation |
| `MVGAL_ERROR_BUSY` | 6 | Resource busy |
| `MVGAL_ERROR_DEVICE_LOST` | 7 | GPU device lost |
| `MVGAL_ERROR_CONTEXT_LOST` | 8 | GPU context lost |
| `MVGAL_ERROR_NOT_INITIALIZED` | 9 | MVGAL not initialized |
| `MVGAL_ERROR_ALREADY_INITIALIZED` | 10 | Already initialized |
| `MVGAL_ERROR_PERMISSION_DENIED` | 11 | Permission denied |
| `MVGAL_ERROR_IO` | 12 | I/O error |
| `MVGAL_ERROR_AGAIN` | 13 | Retry |
| `MVGAL_ERROR_INTERRUPTED` | 14 | Interrupted |
| `MVGAL_ERROR_NO_MEMORY` | 15 | Low memory |
| `MVGAL_ERROR_INVALID_STATE` | 16 | Invalid state |

---

*See `docs/ARCHITECTURE.md` for system architecture context.  
See `include/mvgal/` for full API definitions.  
See `docs/KERNEL_MODULE.md` for IOCTL implementation details.*
