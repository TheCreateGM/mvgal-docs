# MVGAL Vendor-Specific Binary Handling Research Report

**Version:** 1.0  
**Date:** 2026-07-25  
**Status:** Complete  
**Author:** AxoGM  

---

## 1. Executive Summary

This document provides a comprehensive analysis of vendor-specific binary formats used by NVIDIA, AMD, Intel, and Moore Threads (MTT) GPUs, and details how MVGAL will intercept, translate, and route these binaries for heterogeneous multi-GPU workload distribution.

**Key Findings:**
- Each vendor uses distinct intermediate representations (IRs) and binary formats
- PTX (NVIDIA) and SPIR-V are the most interoperable formats
- Direct binary translation between vendor formats is generally not feasible
- Interception at the API level (before binary submission) is the most practical approach
- SPIR-V serves as the common interchange format for cross-vendor compatibility

**MVGAL Strategy:**
1. **Intercept** at API boundaries (OpenCL, CUDA, Vulkan, etc.)
2. **Analyze** binary format and capabilities required
3. **Route** to compatible GPUs based on capability matching
4. **Translate** when necessary (PTX -> SPIR-V, HSACO -> SPIR-V)
5. **Fallback** to single-GPU execution when translation not possible

---

## 2. Binary Format Overview

### 2.1 Format Classification

| Category | Format | Vendor | Stage | Human Readable |
|----------|--------|--------|-------|----------------|
| **Source** | GLSL | Khronos | High | Yes |
| **Source** | HLSL | Microsoft | High | Yes |
| **Source** | CUDA C/C++ | NVIDIA | High | Yes |
| **Source** | HIP C++ | AMD | High | Yes |
| **Source** | OpenCL C | Khronos | High | Yes |
| **IR** | SPIR-V | Khronos | Medium | Yes (disassembled) |
| **IR** | LLVM IR | LLVM | Medium | Yes |
| **IR** | PTX | NVIDIA | Medium | Yes |
| **IR** | HSACO | AMD | Medium | Yes (partial) |
| **IR** | HSAIL | HSA Foundation | Medium | Yes |
| **Binary** | CUBIN | NVIDIA | Low | No |
| **Binary** | FATBIN | NVIDIA | Low | No |
| **Binary** | .s (Assembly) | AMD | Low | Yes |
| **Binary** | .gen | Intel | Low | No |

### 2.2 Format Lifecycle

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Shader Compilation Pipeline                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Source Code (GLSL, HLSL, CUDA, OpenCL)                            │
│           │                                                      │
│           ▼                                                      │
│  ┌─────────────────────┐    ┌─────────────────────┐               │
│  │    NVIDIA Path      │    │     AMD Path        │               │
│  │                     │    │                     │               │
│  │  CUDA C/C++ ──────► │PTX │  HIP C++ ────────► │HSACO│         │
│  │                     │    │                     │               │
│  │  PTX ──────────────► │CUBIN│  HSACO ───────────► │ISA │         │
│  │                     │    │                     │               │
│  │  FATBIN (PTX+CUBIN) │    │  .s (Assembly)      │               │
│  └─────────────────────┘    └─────────────────────┘               │
│                                                                     │
│  ┌─────────────────────┐    ┌─────────────────────┐               │
│  │    Intel Path       │    │     MTT Path        │               │
│  │                     │    │                     │               │
│  │  OpenCL/SYCL ──────► │SPIR-V│  OpenCL/MTML ─────► │MUSA IR│      │
│  │                     │    │                     │               │
│  │  SPIR-V ───────────► │GEN │  MUSA IR ─────────► │Binary│       │
│  └─────────────────────┘    └─────────────────────┘               │
│                                                                     │
│  Common Interchange: SPIR-V (Vulkan, OpenCL 2.1+)                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. NVIDIA Binary Formats

### 3.1 PTX (Parallel Thread Execution)

#### Overview
- **Format:** NVIDIA's intermediate representation
- **Purpose:** Platform-independent GPU code representation
- **Extensions:** `.ptx`
- **Version:** PTX ISA versions correspond to CUDA compute capabilities
- **License:** Proprietary (but format is documented)

#### PTX Versions and Compute Capabilities

| PTX Version | Compute Capability | Architecture | GPU Examples |
|-------------|---------------------|-------------|--------------|
| PTX 1.0-1.3 | 1.x | Tesla | GTX 2xx |
| PTX 2.0-2.3 | 2.x | Fermi | GTX 4xx, 5xx |
| PTX 3.0-3.3 | 3.x | Kepler | GTX 6xx, 7xx |
| PTX 4.0-4.3 | 5.x | Maxwell | GTX 9xx |
| PTX 5.0-5.3 | 6.x | Pascal | GTX 10xx |
| PTX 6.0-6.5 | 7.x | Volta, Turing | RTX 20xx |
| PTX 7.0-7.3 | 8.x | Ampere | RTX 30xx, A100 |
| PTX 8.0 | 9.x | Hopper | H100 |

#### PTX File Structure

```ptx
// PTX file header
.version 8.0
.target sm_90
.address_size 64

// Function declaration
.visible .func (.reg .b32 %function_id) my_kernel
(
    .param .b32 param1,
    .param .b64 param2
)
{
    // PTX instructions
    .reg .b32 %r1;
    .reg .b64 %r2;
    
    ld.param.b32 %r1, [param1];
    ld.param.b64 %r2, [param2];
    
    // ... kernel body ...
    
    ret;
}
```

#### PTX Instruction Categories

| Category | Instructions | Purpose |
|----------|--------------|---------|
| **Control** | `bra`, `call`, `ret`, `brx` | Control flow |
| **Arithmetic** | `add`, `sub`, `mul`, `div`, `rem` | Arithmetic operations |
| **Bitwise** | `and`, `or`, `xor`, `not`, `shl`, `shr` | Bit manipulation |
| **Comparison** | `setp`, `setp.lt`, `setp.eq` | Predicate setting |
| **Memory** | `ld`, `st`, `ldu`, `stu` | Memory access |
| **Conversion** | `cvt`, `mov` | Type conversion |
| **Atomic** | `atom.add`, `atom.cas` | Atomic operations |
| **Texture** | `tex`, `tld4` | Texture sampling |
| **Special** | `bar.sync`, `vote` | Synchronization |

#### PTX to SPIR-V Translation

**Challenges:**
1. **Semantic differences:** PTX has GPU-specific semantics (warps, registers)
2. **Memory model:** PTX uses explicit memory spaces, SPIR-V uses storage classes
3. **Built-in functions:** Different sets of built-in functions
4. **Vector operations:** Different vector operation semantics

**Translation Approach:**
```
PTX → LLVM IR → SPIR-V
  │       │       │
  │       ▼       │
  │   LLVM optimizations
  │       │
  ▼       ▼       ▼
NVIDIA   AMD/Intel   Vulkan
GPU      GPU        GPU
```

**Tools for Translation:**
1. **LLVM/NVIDIA Toolchain:** `ptxas` (PTX assembler), `llc` (LLVM compiler)
2. **SPIRV-Cross:** SPIR-V toolchain with PTX support
3. **Custom Translator:** MVGAL-specific PTX to SPIR-V converter

**Example Translation:**
```c
// Using SPIRV-Cross for PTX to SPIR-V
#include <spirv-cross/spirv_glsl.hpp>

spv::SpirvTools tools(SPV_ENV_VULKAN_1_3);
std::vector<uint32_t> spirv = tools.assemble("ptx_input.ptx");
```

### 3.2 CUBIN (CUDA Binary)

#### Overview
- **Format:** Compiled CUDA binary
- **Purpose:** GPU-executable binary for specific architecture
- **Extensions:** `.cubin`
- **Target:** Specific GPU architecture (sm_XX)

#### CUBIN Characteristics

| Aspect | Details |
|--------|---------|
| **Target-specific:** | Compiled for specific compute capability |
| **Contains:** | PTX + machine code + metadata |
| **Size:** | Larger than PTX (includes binary code) |
| **Portability:** | Limited (architecture-specific) |
| **Execution:** | Direct submission to GPU |

#### CUBIN File Structure

```
CUBIN File Header (0x100 bytes)
├── Magic: "\x7fELF" (ELF-based)
├── Class: 64-bit
├── Data: Little-endian
├── Version: CUDA version
├── Target: sm_XX
└── Entry point information

ELF Sections:
├── .text (executable code)
├── .data (global data)
├── .rodata (read-only data)
├── .symtab (symbol table)
└── .strtab (string table)

PTX embedded in .debug section (optional)
```

#### CUBIN Interception Strategy

**Interception Points:**
1. **CUDA Driver API:** `cuModuleLoad`, `cuModuleLoadData`
2. **CUDA Runtime API:** `cudaModuleLoad`
3. **File system:** Monitor .cubin file access

**Interception Code:**
```c
// Intercept cuModuleLoad
CUresult CUDAAPI cuModuleLoad(CUmodule *hmod, const char *fname) {
    // MVGAL interception
    if (mvgal_cuda_intercept_enabled()) {
        // Read the CUBIN file
        std::vector<char> cubin_data = read_file(fname);
        
        // Analyze CUBIN metadata
        CubinMetadata meta = parse_cubin_metadata(cubin_data);
        
        // Route to compatible GPU
        int gpu_index = mvgal_route_to_gpu(&meta);
        
        // Load on target GPU
        return cuModuleLoadOnGPU(hmod, fname, gpu_index);
    }
    
    // Original function
    return original_cuModuleLoad(hmod, fname);
}
```

#### CUBIN Analysis

**Metadata to Extract:**
```c
struct CubinMetadata {
    uint32_t ptx_version;
    uint32_t compute_capability;  // e.g., sm_80 for Ampere
    uint32_t clock_rate_mhz;
    uint32_t shared_mem_bytes;
    uint32_t const_mem_bytes;
    uint32_t local_mem_bytes;
    uint32_t num_regs;
    std::vector<std::string> kernels;
    std::map<std::string, uint32_t> kernel_offsets;
};
```

### 3.3 FATBIN (Fat Binary)

#### Overview
- **Format:** Container for multiple CUBINs
- **Purpose:** Support multiple architectures in single file
- **Extensions:** `.fatbin`
- **Structure:** Header + multiple CUBIN images

#### FATBIN Structure

```
FATBIN Header (0x40 bytes)
├── Magic: "\xca\xfe\xba\xbe"
├── Version: 1 or 2
├── Header size
└── Number of architectures

Architecture Descriptions (per architecture)
├── Compute capability (sm_XX)
├── CUBIN offset
└── CUBIN size

CUBIN Data (for each architecture)
└── Raw CUBIN data
```

#### FATBIN Interception Strategy

```c
// Parse FATBIN
struct FatbinParser {
    std::vector<CubinInfo> cubins;
    
    void parse(const std::vector<char> &data) {
        FatbinHeader *header = (FatbinHeader *)data.data();
        
        // Verify magic
        if (memcmp(header->magic, "\xca\xfe\xba\xbe", 4) != 0) {
            throw std::runtime_error("Not a FATBIN file");
        }
        
        // Parse each CUBIN
        uint8_t *ptr = data.data() + sizeof(FatbinHeader);
        for (int i = 0; i < header->num_architectures; i++) {
            ArchInfo *arch = (ArchInfo *)ptr;
            ptr += sizeof(ArchInfo);
            
            cubins.push_back({
                .compute_cap = arch->sm_version,
                .cubin_offset = arch->cubin_offset,
                .cubin_size = arch->cubin_size,
                .cubin_data = data.data() + arch->cubin_offset
            });
        }
    }
    
    // Extract CUBIN for specific architecture
    std::vector<char> extract_cubin_for_arch(uint32_t target_sm) {
        for (auto &cubin : cubins) {
            if (cubin.compute_cap == target_sm) {
                return std::vector<char>(cubin.cubin_data,
                                        cubin.cubin_data + cubin.cubin_size);
            }
        }
        return {}; // Not found
    }
};
```

#### FATBIN Routing Strategy

1. **Parse** FATBIN to extract all CUBINs
2. **Analyze** compute capabilities of each CUBIN
3. **Match** with available GPUs' compute capabilities
4. **Route** each kernel to compatible GPU
5. **Fallback** to highest-capability GPU if no exact match

---

## 4. AMD Binary Formats

### 4.1 HSAIL (HSA Intermediate Language)

#### Overview
- **Format:** HSA Foundation's intermediate representation
- **Purpose:** Cross-vendor GPU compute representation
- **Status:** Deprecated (replaced by AMDGCN)
- **Extensions:** `.hsail`

#### HSAIL Characteristics

| Aspect | Details |
|--------|---------|
| **Target:** | HSA-compliant devices |
| **Portability:** | Cross-vendor (theoretically) |
| **Status:** | Deprecated in favor of AMDGCN |
| **Replacement:** | AMDGCN (LLVM-based)

### 4.2 HSACO (HSAIL Compiled Object)

#### Overview
- **Format:** Compiled HSAIL
- **Purpose:** GPU-executable binary for HSA devices
- **Extensions:** `.hsaco`
- **Status:** Used by ROCm

#### HSACO File Structure

```
HSACO Header
├── Magic: "HSAC"
├── Version
├── Target GPU
└── Metadata

Sections:
├── .text (ISA code)
├── .data (global data)
├── .rodata (read-only data)
├── .note (metadata)
└── .symtab (symbols)

ISA Code:
└── AMDGCN machine code
```

#### HSACO Interception Strategy

**Interception Points:**
1. **ROCr API:** `hsa_code_object_reader_create`
2. **OpenCL API:** `clCreateProgramWithBinary`
3. **HIP API:** `hipModuleLoad`

**HSACO to SPIR-V Translation:**
```
HSACO → AMDGCN ISA → LLVM IR → SPIR-V
```

**Tools:**
- **ROCm Device Libraries:** `rocDeviceLib` for AMDGCN disassembly
- **LLVM:** AMDGPU backend for LLVM IR conversion
- **SPIRV-Tools:** SPIR-V toolchain

### 4.3 AMDGCN ISA (AMD Graphics Core Next)

#### Overview
- **Format:** AMD GPU machine code
- **Purpose:** Direct GPU execution
- **Target:** AMD GCN/RDNA architectures
- **Extensions:** `.s` (assembly), embedded in HSACO

#### AMDGCN Architectures

| Architecture | Family | GPUs | ISA Version |
|-------------|--------|------|-------------|
| GCN 1.0 | Southern Islands | HD 7xxx, R9 2xx | GCN 1.0 |
| GCN 1.1 | Sea Islands | R9 290x | GCN 1.1 |
| GCN 2.0 | Volcanic Islands | R9 3xx | GCN 2.0 |
| GCN 3.0 | Arctic Islands | RX 4xx | GCN 3.0 |
| GCN 4.0 | Vega | RX Vega, VII | GCN 4.0 |
| GCN 5.0 | RDNA 1 | RX 5xxx | GCN 5.0 |
| GCN 5.1 | RDNA 2 | RX 6xxx | GCN 5.1 |
| GCN 5.2 | RDNA 3 | RX 7xxx | GCN 5.2 |

#### AMDGCN Assembly Example

```asm
; AMDGCN Assembly
; Function: vector_add
; Inputs: %sgpr0, %sgpr1 (pointers), %sgpr2 (length)

vector_add:
    s_load_dword s0, [s0], 0x0           ; Load length
    s_mov_b32 s1, 0                      ; Counter = 0

.loop:
    s_cmp_ge_u32 s0, s1                  ; Check counter < length
    s_cbranch_vccnz .end                 ; Branch if done
    
    ; Load data
    v_mov_b32 v0, s1                     ; v0 = counter
    v_mul_u32_u24 v0, v0, 4              ; v0 *= sizeof(float)
    v_add_u32 v1, v0, v0                 ; v1 = v0 * 2
    
    ; Perform addition
    buffer_load_dword v2, v0, s[2:3], 0 offen ; Load a[i]
    buffer_load_dword v3, v1, s[4:5], 0 offen ; Load b[i]
    v_add_f32 v4, v2, v3                 ; c[i] = a[i] + b[i]
    buffer_store_dword v4, v0, s[6:7], 0 offen
    
    s_add_u32 s1, s1, 1                  ; counter++
    s_branch .loop                       ; Loop

.end:
    s_endpgm
```

### 4.4 ROCm Binary Formats

#### ROCm Kernel Types

| Format | Description | Extension | Interception Point |
|--------|-------------|----------|-------------------|
| **HSAIL** | High-level IR | .hsail | Deprecated |
| **HSACO** | Compiled HSAIL | .hsaco | `clCreateProgramWithBinary` |
| **AMDGCN ISA** | Machine code | .s | ROCr internal |
| **ELF (ROCm)** | Executable | .so | `dlopen` |

#### ROCm Interception

```c
// Intercept clCreateProgramWithBinary
cl_program clCreateProgramWithBinary(cl_context context,
                                     cl_uint num_devices,
                                     const cl_device_id *device_list,
                                     const size_t *lengths,
                                     const unsigned char **binaries,
                                     cl_int *errcode_ret,
                                     cl_program *errcode_ret2) {
    
    // MVGAL interception
    if (mvgal_opencl_intercept_enabled()) {
        // Analyze binaries
        std::vector<BinaryInfo> binaries_info;
        for (cl_uint i = 0; i < num_devices; i++) {
            BinaryInfo info = analyze_binary(binaries[i], lengths[i]);
            binaries_info.push_back(info);
        }
        
        // Route to compatible devices
        std::vector<cl_device_id> target_devices;
        for (auto &info : binaries_info) {
            cl_device_id device = mvgal_route_binary(&info);
            target_devices.push_back(device);
        }
        
        // Create program on target devices
        return clCreateProgramWithBinaryOnDevices(context,
                                                  target_devices.size(),
                                                  target_devices.data(),
                                                  lengths, binaries,
                                                  errcode_ret);
    }
    
    // Original function
    return original_clCreateProgramWithBinary(context, num_devices,
                                               device_list, lengths,
                                               binaries, errcode_ret);
}
```

---

## 5. Intel Binary Formats

### 5.1 SPIR-V (Standard Portable Intermediate Representation)

#### Overview
- **Format:** Khronos-standard intermediate representation
- **Purpose:** Cross-vendor, cross-API GPU code
- **Extensions:** `.spv`
- **Standard:** Khronos SPIR-V specification
- **Supported by:** Vulkan, OpenCL 2.1+, SYCL, WebGPU

#### SPIR-V Versions

| Version | Specification | Features |
|---------|---------------|----------|
| SPIR-V 1.0 | OpenCL 2.1 | Basic compute |
| SPIR-V 1.1 | OpenCL 2.2 | Enhanced features |
| SPIR-V 1.2 | OpenCL 3.0 | C++ for OpenCL |
| SPIR-V 1.3 | Vulkan 1.0 | Graphics + compute |
| SPIR-V 1.4 | Vulkan 1.1 | New extensions |
| SPIR-V 1.5 | Vulkan 1.2 | Ray tracing |
| SPIR-V 1.6 | Vulkan 1.3 | Additional extensions |

#### SPIR-V Module Structure

```
SPIR-V Module
├── Header (5 words)
│   ├── Magic number: 0x07230203
│   ├── Version: SPIR-V version
│   ├── Generator magic: Tool identifier
│   ├── Generator version
│   └── Reserved
├── Instructions (variable length)
│   ├── OpCapability: Declares capabilities
│   ├── OpExtension: Declares extensions
│   ├── OpExtInstImport: External instruction sets
│   ├── OpMemoryModel: Memory model
│   ├── OpEntryPoint: Entry points (kernels/functions)
│   ├── OpExecutionMode: Execution modes
│   ├── OpSource: Source language
│   ├── OpName: Names for IDs
│   ├── OpDecorate: Decorations
│   └── Function bodies (OpFunction, OpFunctionEnd)
└── End marker
```

#### SPIR-V Example

```spirv
; SPIR-V module
; Version: 1.3
; Generator: Khronos SPIR-V Tools v2023.4
; Capabilities: Shader, Kernel
; Memory Model: Physical64, OpenCL

OpCapability Kernel
OpCapability Float
OpMemoryModel Physical64 OpenCL

; Entry point: vector_add
OpEntryPoint Kernel %vector_add "vector_add" %global_a %global_b %global_c %n
OpExecutionMode %vector_add LocalSize 256 1 1

; Global variables
%global_a = OpVariable _ptr_StorageBuffer Global %_ptr_StorageBuffer_float
%global_b = OpVariable _ptr_StorageBuffer Global %_ptr_StorageBuffer_float
%global_c = OpVariable _ptr_StorageBuffer Global %_ptr_StorageBuffer_float
%n = OpVariable _ptr_Workgroup Global %_ptr_Workgroup_int

; Function definitions...
```

#### SPIR-V Analysis for Routing

```c
struct SpirvAnalysis {
    std::vector<std::string> capabilities;
    std::vector<std::string> extensions;
    std::vector<SpirvEntryPoint> entry_points;
    std::vector<SpirvMemoryModel> memory_models;
    std::vector<SpirvExecutionMode> execution_modes;
    
    // Resource requirements
    uint32_t workgroup_size_x;
    uint32_t workgroup_size_y;
    uint32_t workgroup_size_z;
    uint32_t local_memory_size;
    uint32_t private_memory_size;
    
    // Feature requirements
    bool requires_atomics;
    bool requires_subgroups;
    bool requires_fp64;
    bool requires_int64;
};

SpirvAnalysis analyze_spirv(const std::vector<uint32_t> &spirv) {
    SpirvAnalysis analysis;
    
    // Parse SPIR-V
    spv::Context context;
    std::unique_ptr<spv::Module> module;
    
    context.set_upper_bound(10000);
    module = spv::parseBinary(spirv.data(), spirv.size(), &context);
    
    // Extract capabilities
    for (auto &cap : module->capability) {
        analysis.capabilities.push_back(get_capability_name(cap));
    }
    
    // Extract entry points
    for (auto &entry : module->entry_points) {
        analysis.entry_points.push_back({
            .name = entry.name,
            .execution_model = entry.execution_model,
            .interface_variables = entry.interface_variables
        });
    }
    
    // Extract execution modes
    for (auto &mode : module->execution_modes) {
        analysis.execution_modes.push_back(mode);
        if (mode == OpExecutionMode LocalSize) {
            // Extract workgroup size
        }
    }
    
    return analysis;
}
```

### 5.2 Intel-Specific SPIR-V Extensions

| Extension | Purpose | Intel GPUs |
|-----------|---------|------------|
| `SPV_INTEL_subgroups` | Subgroup operations | Gen 8+ |
| `SPV_INTEL_media_block_io` | Media block I/O | Gen 9+ |
| `SPV_INTEL_shader_integer_functions2` | Integer functions | Gen 8+ |
| `SPV_INTEL_fpga_reg` | FPGA register access | FPGA |
| `SPV_INTEL_unstructured_loop_controls` | Loop controls | Gen 9+ |

### 5.3 Intel Level Zero Binaries

#### Overview
- **Format:** Proprietary binary format for Level Zero
- **Purpose:** Direct GPU execution via Level Zero API
- **Extensions:** Internal to Level Zero runtime

#### Level Zero Interception

```c
// Intercept zeModuleCreate
ze_result_t zeModuleCreate(ze_context_handle_t hContext,
                           ze_device_handle_t hDevice,
                           const ze_module_desc_t *desc,
                           ze_module_handle_t *phModule,
                           ze_module_build_log_handle_t *phBuildLog) {
    
    // MVGAL interception
    if (mvgal_ze_intercept_enabled()) {
        // Analyze module descriptor
        ModuleAnalysis analysis = analyze_level_zero_module(desc);
        
        // Route to compatible device
        ze_device_handle_t target_device = mvgal_route_ze_module(&analysis);
        
        // Create module on target device
        return zeModuleCreateOnDevice(hContext, target_device,
                                       desc, phModule, phBuildLog);
    }
    
    // Original function
    return original_zeModuleCreate(hContext, hDevice, desc,
                                    phModule, phBuildLog);
}
```

---

## 6. Moore Threads (MTT) Binary Formats

### 6.1 MUSA IR (Moore Threads Unified Software Architecture)

#### Overview
- **Format:** MTT's intermediate representation
- **Purpose:** Cross-platform GPU code representation
- **Status:** Proprietary format (documentation limited)
- **Extensions:** Internal (typically embedded in binaries)

#### MUSA IR Characteristics

| Aspect | Details |
|--------|---------|
| **Target:** | MTT GPUs (S60, S80, S2000) |
| **Portability:** | MTT GPUs only |
| **Documentation:** | Limited public documentation |
| **Tools:** | MUSA SDK provides compiler toolchain |

### 6.2 MTML (Moore Threads Metal Language)

#### Overview
- **Format:** Low-level shading language for MTT
- **Purpose:** Graphics/compute shader representation
- **Status:** Proprietary

#### MTML Characteristics

| Aspect | Details |
|--------|---------|
| **Target:** | MTT GPUs |
| **Abstraction:** | Similar to SPIR-V but MTT-specific |
| **Documentation:** | Limited |

### 6.3 MTT Binary Interception

**Challenges:**
- Limited public documentation
- Proprietary format
- Community driver support limited

**Strategy:**
1. **Capability probing:** Detect MTT GPU and its capabilities
2. **API interception:** Intercept at MTML API level
3. **Fallback:** Use standard OpenCL/Vulkan APIs when available
4. **Graceful degradation:** Disable MTT-specific features when not available

```c
// MTT capability detection
bool mvgal_mtt_is_available() {
    // Check for MTT GPU
    for (auto &gpu : mvgal_gpus()) {
        if (gpu.vendor == MVGAL_VENDOR_MTT) {
            return true;
        }
    }
    return false;
}

// MTT binary routing
cl_device_id mvgal_route_mtt_binary(const BinaryInfo *binary) {
    // Find MTT GPU
    for (auto &gpu : mvgal_gpus()) {
        if (gpu.vendor == MVGAL_VENDOR_MTT) {
            // Check if binary is compatible
            if (is_compatible_with_mtt(binary)) {
                return gpu.device_id;
            }
        }
    }
    
    // Fallback to any GPU
    return mvgal_any_gpu();
}
```

---

## 7. Binary Interception Architecture

### 7.1 Interception Points

#### API-Level Interception

| API | Function | Interception Point | Binary Format |
|-----|----------|---------------------|---------------|
| **CUDA Driver** | `cuModuleLoad` | `compat/cuda/load.c` | CUBIN, PTX, FATBIN |
| **CUDA Driver** | `cuModuleLoadData` | `compat/cuda/load.c` | CUBIN, PTX, FATBIN |
| **CUDA Driver** | `cuModuleLoadFatBinary` | `compat/cuda/load.c` | FATBIN |
| **CUDA Runtime** | `cudaModuleLoad` | `compat/cuda/runtime.c` | CUBIN, PTX, FATBIN |
| **OpenCL** | `clCreateProgramWithBinary` | `compat/opencl/program.c` | HSACO, SPIR-V |
| **OpenCL** | `clCreateProgramWithIL` | `compat/opencl/program.c` | SPIR-V |
| **OpenCL** | `clCreateProgramWithSource` | `compat/opencl/program.c` | Source |
| **Level Zero** | `zeModuleCreate` | `compat/levelzero/module.c` | SPIR-V, Internal |
| **Vulkan** | `vkCreateShaderModule` | `compat/vulkan/shader.c` | SPIR-V |
| **HIP** | `hipModuleLoad` | `compat/hip/module.c` | HSACO |

#### File System Interception

| File Type | Interception Method | Library |
|-----------|---------------------|---------|
| **PTX** | `open()`/`read()` interception | `compat/fs/ptx.c` |
| **CUBIN** | `open()`/`read()` interception | `compat/fs/cubin.c` |
| **FATBIN** | `open()`/`read()` interception | `compat/fs/fatbin.c` |
| **HSACO** | `open()`/`read()` interception | `compat/fs/hsaco.c` |
| **SPIR-V** | `open()`/`read()` interception | `compat/fs/spirv.c` |

### 7.2 Interception Library Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     MVGAL Binary Interception Layer                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    Interception Manager                         │   │
│  │  (src/userspace/intercept/intercept_manager.c)                │   │
│  │                                                             │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │   │
│  │  │   API Hooks     │  │ File System     │  │  LD_PRELOAD     │ │   │
│  │  │                 │  │  Monitoring      │  │  Interception   │ │   │
│  │  │ - cuModuleLoad  │  │ - open()         │  │ - dlsym()       │ │   │
│  │  │ - clCreate...   │  │ - read()         │  │ - dlopen()      │ │   │
│  │  │ - zeModule...   │  │ - mmap()         │  │                 │ │   │
│  │  └─────────────────┘  └─────────────────┘  └─────────────────┘ │   │
│  │                                      │                            │   │
│  │                                      ▼                            │   │
│  │  ┌─────────────────────────────────────────────────────────┐   │   │
│  │  │                    Binary Analyzer                         │   │   │
│  │  │  (src/userspace/intercept/binary_analyzer.c)              │   │   │
│  │  │                                                             │   │   │
│  │  │  ┌──────────┐  ┌──────────┐  ┌──────────┐                │   │   │
│  │  │  │  PTX     │  │  CUBIN   │  │  HSACO   │ ...            │   │   │
│  │  │  │  Parser  │  │  Parser  │  │  Parser  │                │   │   │
│  │  │  └──────────┘  └──────────┘  └──────────┘                │   │   │
│  │  │                                      │                            │   │   │
│  │  │  ┌─────────────────────────────────────────────────┐   │   │   │
│  │  │  │                 Binary Info                        │   │   │   │
│  │  │  │  - Format type                                    │   │   │   │
│  │  │  │  - Target architecture                              │   │   │   │
│  │  │  │  - Required capabilities                            │   │   │   │
│  │  │  │  - Resource requirements (registers, memory)      │   │   │   │
│  │  │  │  - Entry points/kernels                             │   │   │   │
│  │  │  └─────────────────────────────────────────────────┘   │   │   │
│  │  └─────────────────────────────────────────────────────────┘   │   │
│  │                                      │                            │   │
│  │                                      ▼                            │   │
│  │  ┌─────────────────────────────────────────────────────────┐   │   │
│  │  │                 Binary Translator                         │   │   │
│  │  │  (src/userspace/intercept/binary_translator.c)          │   │   │
│  │  │                                                             │   │   │
│  │  │  ┌─────────────────┐      ┌─────────────────┐          │   │   │
│  │  │  │   PTX → SPIR-V   │      │   HSACO → SPIR-V │          │   │   │
│  │  │  │   Translator    │      │   Translator    │          │   │   │
│  │  │  └─────────────────┘      └─────────────────┘          │   │   │
│  │  │                                              │          │   │   │
│  │  │  ┌─────────────────────────────────────────────────┐   │   │   │
│  │  │  │           Translation Cache                         │   │   │   │
│  │  │  │  - PTX to SPIR-V cache                            │   │   │   │
│  │  │  │  - HSACO to SPIR-V cache                           │   │   │   │
│  │  │  │  - Performance metrics                             │   │   │   │
│  │  │  └─────────────────────────────────────────────────┘   │   │   │
│  │  └─────────────────────────────────────────────────────────┘   │   │
│  │                                      │                            │   │
│  │                                      ▼                            │   │
│  │  ┌─────────────────────────────────────────────────────────┐   │   │
│  │  │                 Binary Router                            │   │   │
│  │  │  (src/userspace/scheduler/binary_router.c)              │   │   │
│  │  │                                                             │   │   │
│  │  │  Input: Binary Info + Available GPUs                      │   │   │
│  │  │  Output: GPU assignment for each kernel/entry point       │   │   │
│  │  │                                                             │   │   │
│  │  │  Algorithm:                                                  │   │   │
│  │  │  1. Match capabilities                                     │   │   │
│  │  │  2. Match resource requirements                            │   │   │
│  │  │  3. Balance load across GPUs                                │   │   │
│  │  │  4. Optimize for performance                                │   │   │
│  │  └─────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 7.3 Binary Routing Algorithm

```c
// Binary routing decision tree
struct GpuAssignment {
    int gpu_index;
    std::vector<int> kernel_to_gpu;  // Per-kernel assignments
    std::string reason;
};

GpuAssignment route_binary(const BinaryInfo *binary, 
                           const std::vector<GpuDevice> &available_gpus) {
    GpuAssignment assignment;
    
    // Step 1: Check if translation is needed
    bool needs_translation = binary->format != BINARY_FORMAT_SPIRV;
    
    if (needs_translation) {
        // Step 2: Translate to SPIR-V if possible
        TranslationResult translation = translate_to_spirv(binary);
        if (translation.success) {
            // Use translated SPIR-V for analysis
            binary = translation.output;
        } else {
            // Translation failed - use original binary
            // This may limit routing options
        }
    }
    
    // Step 3: Analyze capabilities
    std::vector<CapabilityMatch> matches;
    for (size_t i = 0; i < available_gpus.size(); i++) {
        CapabilityMatch match = match_capabilities(binary, available_gpus[i]);
        matches.push_back(match);
    }
    
    // Step 4: Filter compatible GPUs
    std::vector<size_t> compatible_gpus;
    for (size_t i = 0; i < matches.size(); i++) {
        if (matches[i].is_compatible) {
            compatible_gpus.push_back(i);
        }
    }
    
    if (compatible_gpus.empty()) {
        // No compatible GPU - fallback to single-GPU
        assignment.gpu_index = 0;
        assignment.reason = "No compatible GPU found - fallback to GPU 0";
        return assignment;
    }
    
    // Step 5: For each kernel, assign to best GPU
    for (size_t kernel_idx = 0; kernel_idx < binary->kernels.size(); kernel_idx++) {
        const KernelInfo &kernel = binary->kernels[kernel_idx];
        
        // Find best GPU for this kernel
        int best_gpu = -1;
        int best_score = -1;
        
        for (size_t gpu_idx : compatible_gpus) {
            int score = calculate_gpu_score(binary, &kernel, available_gpus[gpu_idx]);
            if (score > best_score) {
                best_score = score;
                best_gpu = gpu_idx;
            }
        }
        
        assignment.kernel_to_gpu.push_back(best_gpu);
    }
    
    // Step 6: Balance load if multiple kernels
    if (binary->kernels.size() > 1) {
        balance_load(assignment.kernel_to_gpu, available_gpus);
    }
    
    assignment.reason = "Routed based on capability matching and load balancing";
    return assignment;
}

// Capability matching
int calculate_gpu_score(const BinaryInfo *binary, 
                        const KernelInfo *kernel,
                        const GpuDevice &gpu) {
    int score = 0;
    
    // Capability matching (50% weight)
    int cap_score = match_capabilities(binary, gpu);
    score += cap_score * 50;
    
    // Resource matching (30% weight)
    int res_score = match_resources(kernel, gpu);
    score += res_score * 30;
    
    // Performance estimation (20% weight)
    int perf_score = estimate_performance(binary, kernel, gpu);
    score += perf_score * 20;
    
    return score;
}
```

### 7.4 Fallback Strategies

#### Fallback Decision Tree

```
Binary Submission
    │
    ├─ Can translate to SPIR-V?
    │   ├─ Yes
    │   │   │
    │   │   ├─ SPIR-V compatible with any GPU?
    │   │   │   ├─ Yes → Route to best GPU
    │   │   │   └─ No → Fallback to single GPU (best match)
    │   │   │
    │   │   └─ Translation failed?
    │   │       └─ Use original binary, fallback to single GPU
    │   │
    │   └─ No (untranslatable format)
    │       └─ Route to vendor-specific GPU or fallback
    │
    └─ Can analyze capabilities?
        ├─ Yes → Route based on capability matching
        └─ No → Fallback to single GPU (GPU 0)
```

#### Fallback Implementations

```c
// Fallback to single-GPU execution
enum FallbackStrategy {
    FALLBACK_SINGLE_GPU,           // Use single GPU for entire workload
    FALLBACK_MULTIPLE_GPUS,        // Distribute across GPUs (best effort)
    FALLBACK_CPU,                  // Execute on CPU (if supported)
    FALLBACK_ERROR                 // Return error to application
};

// Fallback configuration
struct FallbackConfig {
    FallbackStrategy strategy;
    int default_gpu_index;
    bool allow_cpu_fallback;
    bool log_fallback_events;
};

// Apply fallback
int apply_fallback(const BinaryInfo *binary, 
                   const std::vector<GpuDevice> &gpus,
                   const FallbackConfig &config) {
    
    switch (config.strategy) {
    case FALLBACK_SINGLE_GPU:
        // Use default GPU
        return config.default_gpu_index;
        
    case FALLBACK_MULTIPLE_GPUS:
        // Distribute across all GPUs (round-robin)
        static int last_gpu = 0;
        int gpu_index = last_gpu % gpus.size();
        last_gpu = (last_gpu + 1) % gpus.size();
        return gpu_index;
        
    case FALLBACK_CPU:
        // Offload to CPU (if supported)
        if (config.allow_cpu_fallback) {
            return offload_to_cpu(binary);
        }
        // Fall through to error
        
    case FALLBACK_ERROR:
        mvgal_log_warning("Fallback: Binary not compatible with any GPU");
        return -1;
    }
    
    return -1;
}
```

---

## 8. Translation Implementations

### 8.1 PTX to SPIR-V Translator

#### Implementation Options

| Option | Pros | Cons | Feasibility |
|--------|------|------|--------------|
| **LLVM-based** | Most accurate, well-tested | Heavy dependency, slow | High |
| **SPIRV-Cross** | Lightweight, good support | May not support all PTX | Medium |
| **Custom** | Tailored to MVGAL needs | Development effort, maintenance | Medium |
| **NVIDIA NVC** | Official NVIDIA tool | Proprietary, limited availability | Low |

#### Recommended: SPIRV-Cross + Custom Enhancements

```c
// PTX to SPIR-V translation using SPIRV-Cross
class PtxToSpirvTranslator {
public:
    std::vector<uint32_t> translate(const std::vector<uint32_t> &ptx_code,
                                    uint32_t ptx_version,
                                    uint32_t target_sm);
    
private:
    // Parse PTX
    std::unique_ptr<PtxModule> parse_ptx(const std::vector<uint32_t> &ptx_code);
    
    // Convert PTX module to LLVM IR
    std::unique_ptr<llvm::Module> convert_to_llvm(PtxModule *ptx_module);
    
    // Convert LLVM IR to SPIR-V
    std::vector<uint32_t> convert_to_spirv(llvm::Module *llvm_module);
    
    // Optimize SPIR-V for target
    void optimize_spirv(std::vector<uint32_t> &spirv,
                       uint32_t target_sm);
};

// SPIRV-Cross implementation
std::vector<uint32_t> PtxToSpirvTranslator::translate(
        const std::vector<uint32_t> &ptx_code,
        uint32_t ptx_version,
        uint32_t target_sm) {
    
    // Step 1: Parse PTX
    auto ptx_module = parse_ptx(ptx_code);
    
    // Step 2: Convert to LLVM IR
    auto llvm_module = convert_to_llvm(ptx_module.get());
    
    // Step 3: Apply target-specific optimizations
    optimize_llvm_for_target(llvm_module.get(), target_sm);
    
    // Step 4: Convert to SPIR-V
    auto spirv = convert_to_spirv(llvm_module.get());
    
    // Step 5: Optimize SPIR-V
    optimize_spirv(spirv, target_sm);
    
    return spirv;
}
```

#### PTX Version Compatibility Matrix

| PTX Version | Supported | Target SM | Translation Quality |
|-------------|-----------|----------|---------------------|
| PTX 1.0-1.3 | ⚠️ Partial | sm_1x | Basic support |
| PTX 2.0-2.3 | ✅ Yes | sm_2x | Full support |
| PTX 3.0-3.3 | ✅ Yes | sm_3x | Full support |
| PTX 4.0-4.3 | ✅ Yes | sm_5x | Full support |
| PTX 5.0-5.3 | ✅ Yes | sm_6x | Full support |
| PTX 6.0-6.5 | ✅ Yes | sm_7x | Full support |
| PTX 7.0-7.3 | ✅ Yes | sm_8x | Full support |
| PTX 8.0 | ✅ Yes | sm_9x | Full support |

### 8.2 HSACO to SPIR-V Translator

#### Implementation Approach

```c
class HsacoToSpirvTranslator {
public:
    std::vector<uint32_t> translate(const std::vector<char> &hsaco_data);
    
private:
    // Extract ISA from HSACO
    std::vector<uint32_t> extract_isa(const std::vector<char> &hsaco_data);
    
    // Disassemble AMDGCN ISA to LLVM IR
    std::unique_ptr<llvm::Module> disassemble_amdgcn(
            const std::vector<uint32_t> &isa_code,
            const HsacoMetadata &metadata);
    
    // Convert LLVM IR to SPIR-V
    std::vector<uint32_t> convert_llvm_to_spirv(llvm::Module *module);
};

std::vector<uint32_t> HsacoToSpirvTranslator::translate(
        const std::vector<char> &hsaco_data) {
    
    // Step 1: Parse HSACO
    HsacoParser parser;
    auto metadata = parser.parse_metadata(hsaco_data);
    auto isa_code = parser.extract_isa(hsaco_data);
    
    // Step 2: Disassemble to LLVM IR
    auto llvm_module = disassemble_amdgcn(isa_code, metadata);
    
    // Step 3: Convert to SPIR-V
    auto spirv = convert_llvm_to_spirv(llvm_module.get());
    
    return spirv;
}
```

### 8.3 Translation Cache

#### Cache Design

```c
class TranslationCache {
public:
    TranslationCache(size_t max_entries = 1000);
    
    // Look up translation
    std::optional<std::vector<uint32_t>> lookup(
            const BinaryKey &key);
    
    // Store translation
    void store(const BinaryKey &key,
               const std::vector<uint32_t> &translated);
    
    // Invalidate cache
    void invalidate();
    
private:
    struct CacheEntry {
        BinaryKey key;
        std::vector<uint32_t> translated;
        std::chrono::system_clock::time_point timestamp;
        size_t hit_count;
    };
    
    std::unordered_map<BinaryKey, CacheEntry, BinaryKeyHash> cache;
    size_t max_entries;
    size_t total_size;
    
    // Eviction policy
    void evict_if_needed();
};

struct BinaryKey {
    BinaryFormat format;
    uint32_t version;
    std::vector<uint32_t> hash;  // SHA-256 hash of binary
    std::vector<uint32_t> capability_hash;  // Hash of required capabilities
    
    bool operator==(const BinaryKey &other) const;
};

struct BinaryKeyHash {
    size_t operator()(const BinaryKey &key) const;
};
```

#### Cache Statistics

```c
struct CacheStatistics {
    size_t total_entries;
    size_t total_hits;
    size_t total_misses;
    size_t total_evictions;
    double hit_rate() const { return (double)total_hits / (total_hits + total_misses); }
    size_t total_size_bytes;
};
```

---

## 9. Binary Analysis and Capability Matching

### 9.1 Binary Analysis

#### Analysis Framework

```c
class BinaryAnalyzer {
public:
    BinaryAnalysis analyze(const std::vector<char> &binary_data,
                           BinaryFormat format);
    
private:
    BinaryAnalysis analyze_ptx(const std::vector<char> &data);
    BinaryAnalysis analyze_cubin(const std::vector<char> &data);
    BinaryAnalysis analyze_fatbin(const std::vector<char> &data);
    BinaryAnalysis analyze_hsaco(const std::vector<char> &data);
    BinaryAnalysis analyze_spirv(const std::vector<char> &data);
};

struct BinaryAnalysis {
    BinaryFormat format;
    uint32_t version;
    std::vector<KernelInfo> kernels;
    std::vector<Capability> required_capabilities;
    std::vector<Extension> used_extensions;
    ResourceRequirements resources;
    std::vector<MemorySpace> memory_spaces_used;
    std::vector<BuiltinFunction> builtins_used;
};

struct KernelInfo {
    std::string name;
    uint32_t local_size_x;
    uint32_t local_size_y;
    uint32_t local_size_z;
    uint32_t private_memory_size;
    uint32_t local_memory_size;
    uint32_t num_regs;
    std::vector<KernelArgument> arguments;
};

struct ResourceRequirements {
    uint32_t max_local_size;
    uint32_t max_private_memory;
    uint32_t max_local_memory;
    uint32_t max_num_regs;
    uint32_t max_barriers;
    bool requires_atomics;
    bool requires_subgroups;
    bool requires_fp64;
    bool requires_int64;
};
```

### 9.2 Capability Matching

#### GPU Capability Model

```c
struct GpuCapabilities {
    // Vendor info
    Vendor vendor;
    std::string model;
    uint32_t vendor_id;
    uint32_t device_id;
    
    // Architecture
    std::string architecture;
    uint32_t compute_capability;  // For NVIDIA
    uint32_t gcn_version;         // For AMD
    uint32_t gen_version;         // For Intel
    
    // API support
    bool vulkan;
    uint32_t vulkan_version;
    uint32_t vulkan_api_version;
    
    bool opencl;
    uint32_t opencl_version;
    
    bool cuda;                    // Only for NVIDIA
    uint32_t cuda_version;
    
    bool hip;                     // Only for AMD
    uint32_t hip_version;
    
    bool level_zero;              // Only for Intel
    uint32_t level_zero_version;
    
    // Memory
    uint64_t vram_total;
    uint64_t vram_free;
    uint32_t memory_clock_mhz;
    
    // Compute
    uint32_t core_clock_mhz;
    uint32_t core_count;
    uint32_t compute_units;
    uint32_t shading_units;
    uint32_t ray_tracing_cores;
    uint32_t tensor_cores;         // NVIDIA
    uint32_t ai_accelerators;     // Intel
    
    // Features
    bool supports_fp64;
    bool supports_int64;
    bool supports_atomics;
    bool supports_subgroups;
    bool supports_ray_tracing;
    bool supports_tensor_cores;
    bool supports_mesh_shading;
    bool supports_variable_rate_shading;
    
    // DMA-BUF
    bool dmabuf_export;
    bool dmabuf_import;
    bool p2p_support;
    
    // Synchronization
    bool dma_fence;
    bool timeline_sync;
    bool external_fence;
};
```

#### Capability Matching Algorithm

```c
struct CapabilityMatch {
    bool is_compatible;
    double compatibility_score;  // 0.0 to 1.0
    std::vector<CapabilityMismatch> mismatches;
    std::vector<std::string> warnings;
};

CapabilityMatch match_capabilities(const BinaryAnalysis &binary,
                                    const GpuCapabilities &gpu) {
    CapabilityMatch match;
    match.is_compatible = true;
    match.compatibility_score = 1.0;
    
    // Check API support
    if (binary.requires_vulkan && !gpu.vulkan) {
        match.is_compatible = false;
        match.mismatches.push_back({
            .type = CAP_MISMATCH_API,
            .required = "Vulkan",
            .available = "None"
        });
        match.compatibility_score -= 0.5;
    }
    
    if (binary.requires_opencl && !gpu.opencl) {
        match.is_compatible = false;
        match.mismatches.push_back({
            .type = CAP_MISMATCH_API,
            .required = "OpenCL",
            .available = "None"
        });
        match.compatibility_score -= 0.5;
    }
    
    // Check feature support
    if (binary.resources.requires_atomics && !gpu.supports_atomics) {
        match.mismatches.push_back({
            .type = CAP_MISMATCH_FEATURE,
            .required = "Atomics",
            .available = "Not supported"
        });
        match.compatibility_score -= 0.2;
    }
    
    if (binary.resources.requires_fp64 && !gpu.supports_fp64) {
        match.mismatches.push_back({
            .type = CAP_MISMATCH_FEATURE,
            .required = "FP64",
            .available = "Not supported"
        });
        match.compatibility_score -= 0.2;
    }
    
    if (binary.resources.requires_subgroups && !gpu.supports_subgroups) {
        match.mismatches.push_back({
            .type = CAP_MISMATCH_FEATURE,
            .required = "Subgroups",
            .available = "Not supported"
        });
        match.compatibility_score -= 0.1;
    }
    
    // Check resource requirements
    if (binary.resources.max_local_size > gpu.max_local_size) {
        match.mismatches.push_back({
            .type = CAP_MISMATCH_RESOURCE,
            .required = std::to_string(binary.resources.max_local_size),
            .available = std::to_string(gpu.max_local_size)
        });
        match.compatibility_score -= 0.1;
    }
    
    // Check extensions
    for (const auto &ext : binary.used_extensions) {
        bool supported = is_extension_supported(ext, gpu);
        if (!supported) {
            match.mismatches.push_back({
                .type = CAP_MISMATCH_EXTENSION,
                .required = ext.name,
                .available = "Not supported"
            });
            match.compatibility_score -= 0.05;
        }
    }
    
    // Final decision
    if (match.compatibility_score < 0.5) {
        match.is_compatible = false;
    }
    
    return match;
}
```

---

## 10. MVGAL Implementation Plan

### 10.1 Short-Term (1-2 months)

#### Phase 1: Binary Interception Foundation

1. **Implement Binary Analyzer**
   - PTX parser
   - CUBIN parser
   - HSACO parser
   - SPIR-V analyzer
   - Binary fingerprinting (hashing)

2. **Implement Translation Cache**
   - Cache storage and retrieval
   - Eviction policy
   - Statistics tracking

3. **Implement Basic Routing**
   - Capability matching
   - Load balancing
   - Fallback strategies

4. **API-Level Interception**
   - CUDA Driver API hooks
   - OpenCL API hooks
   - Vulkan API hooks

**Deliverables:**
- `src/userspace/intercept/binary_analyzer.c`
- `src/userspace/intercept/binary_translator.c`
- `src/userspace/intercept/translation_cache.c`
- `src/userspace/scheduler/binary_router.c`
- Updated CUDA, OpenCL, Vulkan interception layers

---

#### Phase 2: PTX to SPIR-V Translation

1. **Integrate SPIRV-Cross**
   - Add SPIRV-Cross dependency
   - Implement PTX parsing
   - Implement LLVM IR conversion
   - Implement SPIR-V generation

2. **Add Custom Enhancements**
   - Target-specific optimizations
   - Capability-aware translation
   - Performance tuning

3. **Testing**
   - PTX translation tests
   - Capability matching tests
   - Routing tests

**Deliverables:**
- PTX to SPIR-V translator
- Integration with existing interception
- Test suite for PTX translation

---

### 10.2 Medium-Term (2-4 months)

#### Phase 3: HSACO to SPIR-V Translation

1. **Integrate ROCm Toolchain**
   - Add ROCm device libraries dependency
   - Implement HSACO parsing
   - Implement AMDGCN disassembly
   - Implement SPIR-V generation

2. **Enhanced Routing**
   - Multi-kernel routing
   - Dynamic load balancing
   - Performance-aware routing

**Deliverables:**
- HSACO to SPIR-V translator
- Enhanced binary router
- Performance optimization tests

---

#### Phase 4: Advanced Features

1. **Cross-Vendor Translation**
   - NVIDIA to AMD translation
   - AMD to NVIDIA translation
   - Intel to NVIDIA/AMD translation

2. **Binary Optimization**
   - Target-specific optimization passes
   - Resource usage optimization
   - Performance profiling

3. **MTT Support**
   - MTT binary analysis
   - MTT capability probing
   - MTT routing

**Deliverables:**
- Cross-vendor translation support
- Binary optimization passes
- MTT support

---

### 10.3 Long-Term (4-6 months)

#### Phase 5: Production Readiness

1. **Performance Optimization**
   - Translation performance
   - Cache efficiency
   - Runtime overhead reduction

2. **Error Handling and Recovery**
   - Translation error handling
   - Fallback mechanisms
   - Error reporting

3. **Monitoring and Telemetry**
   - Translation statistics
   - Routing decisions logging
   - Performance metrics

**Deliverables:**
- Production-ready implementation
- Comprehensive error handling
- Monitoring and telemetry

---

## 11. Performance Considerations

### 11.1 Translation Performance

| Metric | Target | Measurement |
|--------|--------|-------------|
| **PTX to SPIR-V** | < 100ms per kernel | Translation time |
| **HSACO to SPIR-V** | < 150ms per kernel | Translation time |
| **Cache hit rate** | > 80% | Hit rate percentage |
| **Translation overhead** | < 5% | Runtime overhead |

### 11.2 Optimization Strategies

1. **Caching:**
   - Cache translated binaries
   - Cache capability analysis
   - Cache routing decisions

2. **Lazy Translation:**
   - Translate only when needed
   - Translate once, reuse multiple times
   - Background translation for preloading

3. **Parallel Translation:**
   - Multi-threaded translation
   - Async translation for non-blocking execution
   - Batch translation for multiple kernels

4. **Incremental Translation:**
   - Translate only changed parts
   - Partial translation for debugging
   - On-demand translation

---

## 12. Testing Strategy

### 12.1 Unit Tests

| Test Category | Tests | Coverage |
|---------------|-------|----------|
| **Binary Analysis** | 50+ | PTX, CUBIN, HSACO, SPIR-V |
| **Translation** | 50+ | PTX->SPIR-V, HSACO->SPIR-V |
| **Routing** | 50+ | Capability matching, load balancing |
| **Cache** | 20+ | Cache operations, eviction |
| **Fallback** | 20+ | Fallback strategies, error handling |

### 12.2 Integration Tests

| Test | Description |
|------|-------------|
| **CUDA Interception** | Test CUDA module loading interception |
| **OpenCL Interception** | Test OpenCL program creation interception |
| **Vulkan Interception** | Test Vulkan shader module creation interception |
| **Cross-Vendor Routing** | Test routing across AMD, NVIDIA, Intel |
| **Fallback Testing** | Test fallback mechanisms |

### 12.3 Performance Tests

| Test | Metric | Target |
|------|--------|--------|
| **Translation Throughput** | Kernels/second | > 10 |
| **Cache Hit Rate** | % hits | > 80% |
| **Routing Time** | Milliseconds | < 1 |
| **Overhead** | % runtime | < 5% |

---

## 13. Dependencies

### 13.1 External Dependencies

| Dependency | Version | Purpose | License |
|-------------|---------|---------|---------|
| **LLVM** | 15+ | SPIR-V translation | Apache 2.0 |
| **SPIRV-Tools** | Latest | SPIR-V manipulation | Apache 2.0 |
| **SPIRV-Cross** | Latest | SPIR-V conversion | Apache 2.0 |
| **ROCm Device Libraries** | Latest | AMDGCN disassembly | MIT/BSD |
| **NVIDIA CUDA Toolkit** | Latest | PTX tools | Proprietary |
| **Intel Level Zero** | Latest | Intel binary tools | MIT |

### 13.2 Build Dependencies

| Dependency | Optional | Purpose |
|-------------|----------|---------|
| **LLVM** | No | Core translation |
| **SPIRV-Tools** | No | SPIR-V support |
| **SPIRV-Cross** | Yes | Alternative translation |
| **ROCm** | Yes | AMD HSACO support |
| **CUDA** | Yes | NVIDIA PTX support |
| **Level Zero** | Yes | Intel support |

---

## 14. Security Considerations

### 14.1 Binary Validation

- **Hash verification:** Verify binary integrity
- **Signature checking:** Verify signed binaries
- **Size limits:** Enforce maximum binary size
- **Format validation:** Validate binary format

### 14.2 Translation Safety

- **Sandboxing:** Sandbox translation process
- **Timeout:** Prevent infinite translation loops
- **Memory limits:** Limit memory usage during translation
- **Error handling:** Graceful handling of translation errors

### 14.3 Capability Verification

- **Capability bounds:** Enforce reasonable capability requests
- **Resource limits:** Prevent excessive resource requests
- **Privilege checking:** Verify permissions for operations

---

## 15. References

1. **NVIDIA Documentation:**
   - PTX ISA Documentation: https://docs.nvidia.com/cuda/parallel-thread-execution/index.html
   - CUDA Binary Utilities: https://docs.nvidia.com/cuda/cuda-binary-utilities/index.html
   - CUDA Toolkit Documentation: https://docs.nvidia.com/cuda/

2. **AMD Documentation:**
   - ROCm Documentation: https://rocm.docs.amd.com/
   - HSA Documentation: https://www.hsafoundation.com/
   - AMDGCN Documentation: https://llvm.org/docs/AMDGPUUsage.html

3. **Khronos Documentation:**
   - SPIR-V Specification: https://www.khronos.org/registry/spir-v/specs/unified1/SPIRV.html
   - Vulkan Documentation: https://www.khronos.org/registry/vulkan/specs/1.3-extensions/html/
   - OpenCL Documentation: https://www.khronos.org/registry/OpenCL/specs/3.0-unified/html/OpenCL_API.html

4. **Intel Documentation:**
   - Level Zero Specification: https://spec.oneapi.io/level-zero/latest/
   - Intel Graphics for Linux: https://dgpu-docs.intel.com/

5. **Moore Threads Documentation:**
   - MTT Developer Docs: https://developer.mthreads.com/
   - MTT GitHub: https://github.com/dixyes/mtgpu-drv

---

## 16. Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-07-25 | AxoGM | Initial comprehensive binary handling report |

---

*This document is part of the MVGAL project. For more information, see the main [README.md](../README.md).*
