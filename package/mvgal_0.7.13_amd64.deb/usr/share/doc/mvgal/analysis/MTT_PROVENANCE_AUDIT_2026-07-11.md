# MTT Source Provenance Audit

**Date:** 2026-07-11  
**Auditor:** MVGAL Development Team  
**Repository:** https://github.com/dixyes/mtgpu-drv  

## Executive Summary

The `dixyes/mtgpu-drv` repository was successfully cloned and inspected on 2026-07-11. The repository contains an out-of-tree Linux kernel driver for Moore Threads GPUs. **Critical finding: the project is marked as unmaintained and now requires login to download.**

## Repository Status

| Attribute | Value |
|-----------|-------|
| Repository URL | https://github.com/dixyes/mtgpu-drv |
| Clone Status | ✅ Successfully cloned (shallow, depth 1) |
| Last Commit | `9647512 Mark project as unmaintained in README` |
| Maintenance Status | **UNMAINTAINED** |
| Download Barrier | **Login required** (added after initial release) |
| License | Dual MIT/GPLv2 |

## License Analysis

The driver source files contain the following license header:

```
* @License     Dual MIT/GPLv2
*
* The contents of this file are subject to the MIT license as set out below.
* ...
* Alternatively, the contents of this file may be used under the terms of
* the GNU General Public License Version 2 ("GPL") in which case the provisions
* of GPL are applicable instead of those above.
```

**MVGAL Implications:**
- The kernel module (`kernel/vendors/mvgal_mtt.c`) is GPL-2.0-only
- The MTT driver code is dual MIT/GPLv2 — compatible with GPL-2.0-only when used under GPL terms
- No proprietary-only components detected in the cloned source
- **However:** The unmaintained status and login wall make this unsuitable for production claims

## Code Architecture

The repository contains:

### Kernel Driver (`src/`)
- **PVR (PowerVR) DRM driver:** `src/pvr/pvr_drm.c` — Main DRM device registration
- **Platform driver:** `src/pvr/pvr_platform_drv.c` — Platform device probe
- **Buffer management:** `src/pvr/pvr_gem.c`, `pmr_osmem_linux.c` — GEM objects and memory
- **Fence/Sync:** `src/pvr/pvr_fence.c`, `pvr_sync_file.c`, `pvr_sw_fence.c` — DMA fences and sync
- **PCI support:** `src/pvr/pci_support.c` — PCI enumeration
- **Interrupts:** `src/pvr/interrupt_support.c`
- **Debug:** `src/pvr/pvr_debug.c`, `pvr_debugfs.c`

### User-Space Components
- **MTPU (MTT Processing Unit):** `src/mtvpu/mtvpu_drv.c`, `mtvpu_gem.c`, `mtvpu_api.c`
- **Audio:** `src/mtsnd/mtsnd_pcm.c` — Not relevant for GPU aggregation

### Build System
- **DKMS support:** `dkms.conf` — Builds `mtgpu.ko` module
- **Makefile:** Standard kernel module build
- **Post-install hooks:** `dkms.post_install`, `dkms.pre_install`

## Integration Points for MVGAL

### What Works
1. **DRM registration:** The driver registers as a standard DRM device (`pvr_drm.c`)
2. **PCI enumeration:** Standard PCI device probing via `pci_support.c`
3. **GEM/DMA-BUF:** Buffer objects via GEM, exportable via DMA-BUF
4. **Fence/Sync:** Software fences and sync files for GPU synchronization
5. **Platform driver:** Can be probed via device tree or ACPI

### What's Missing or Uncertain
1. **No P2P/peer memory API exposed** — The driver does not appear to expose peer-to-peer memory access interfaces
2. **No user-space library** — Unlike NVIDIA (NVML) or AMD (ROCm), there's no documented user-space management library
3. **No compute API bindings** — No OpenCL, CUDA, or SYCL bindings in this repo
4. **Unmaintained codebase** — Last commit marks project as unmaintained
5. **Login wall** — Cannot download without authentication; breaks reproducible builds

## MVGAL Current Implementation Assessment

The current `kernel/vendors/mvgal_mtt.c` implementation:

```c
/* Mock fallback for development/testing if no driver is bound/loaded */
if (!priv->mtgpu_drv_loaded && !priv->official_driver_loaded) {
    pr_info("MVGAL: Moore Threads driver not found, using emulation fallback\n");
    priv->official_driver_loaded = true; /* Enable emulation mode */
}
```

**Assessment:** The current implementation falls back to emulation when no driver is present. This is safe but means MTT support is not production-ready.

## Recommendations

1. **Do not claim production MTT support** until:
   - A maintained, cloneable driver source is identified
   - License is confirmed compatible
   - P2P and memory mapping APIs are documented
   - Hardware validation is performed

2. **Keep MTT support optional and capability-probed** — The current implementation already does this correctly

3. **Document the limitation** in README and STATUS.md — Already partially done, should be strengthened

4. **Consider alternative MTT sources:**
   - Official Moore Threads SDK/documentation
   - Mainline kernel inclusion (if driver is upstreamed)
   - Other community drivers

## Action Items

| Action | Owner | Priority |
|--------|-------|----------|
| Document MTT as experimental/optional in README | MVGAL team | High |
| Add provenance warning to STATUS.md | MVGAL team | High |
| Remove hardcoded MTT defaults (8GB VRAM, 2048 CUs) | MVGAL team | Medium |
| Add capability probe for MTT driver presence | MVGAL team | Medium |
| Investigate official MTT SDK for user-space interfaces | MVGAL team | Low |
