# MVGAL Hardware Validation Matrix

**Date:** 2026-07-11  
**Maintainer:** MVGAL Development Team  
**Status:** Test harness complete — hardware evidence collection required

## Purpose

This document defines the hardware validation matrix for MVGAL. It specifies which GPU combinations must be tested, what metrics to collect, and how to classify results. All hardware validation must produce reproducible logs with driver/kernel versions.

## Test Harness

The hardware validation test harness is implemented in:
- `src/tests/tests/integration/test_hardware_validation.c` — Integration test with JSON output
- `tools/mvgal-hw-validate.c` — Standalone validation tool

### Running the Tests

```bash
# Integration test (requires mvgal_core built)
cd build_output/src/tests/tests
ctest -R test_hardware_validation --output-on-failure

# Standalone tool
./tools/mvgal-hw-validate --json results.json
```

### JSON Output Schema

```json
{
  "schema_version": "1.0.0",
  "timestamp": "2026-07-11T14:00:00Z",
  "hostname": "mvgal-testbox",
  "gpus": [
    {
      "index": 0,
      "vendor": "AMD",
      "vendor_id": "0x1002",
      "device_id": "0x731f",
      "driver": "amdgpu",
      "pci_bdf": "0000:03:00.0"
    }
  ],
  "tests": [
    {
      "name": "test_gpu_detection",
      "passed": true,
      "message": "At least one GPU detected"
    }
  ],
  "summary": {
    "passed": 7,
    "failed": 0,
    "total": 7
  }
}
```

## Hardware Matrix

### Single-GPU Configurations

| Configuration | Vendor | Architecture | Driver | Status | Notes |
|---------------|--------|-------------|--------|--------|-------|
| S1-AMD | AMD | RDNA 2/3 | `amdgpu` | 🔄 Required | RX 5000/6000/7000 series |
| S1-NVIDIA | NVIDIA | Turing+ | `nvidia-open`/proprietary | 🔄 Required | RTX 20xx/30xx/40xx |
| S1-Intel | Intel | Gen 9-12/Xe | `i915`/`xe` | 🔄 Required | UHD 600+, Arc |
| S1-MTT | Moore Threads | MTT S60/S80/S2000 | `mtgpu` | ⚠️ Experimental | Requires MTT driver |

### Dual-GPU Same Vendor

| Configuration | Vendor | Status | Notes |
|---------------|--------|--------|-------|
| S2-AMD | AMD | 🔄 Required | NVLink or PCIe P2P |
| S2-NVIDIA | NVIDIA | 🔄 Required | NVLink or PCIe P2P |
| S2-Intel | Intel | 🔄 Required | No P2P expected |
| S2-MTT | Moore Threads | ⚠️ Experimental | Unmaintained driver |

### Dual-GPU Mixed Vendors

| Configuration | GPU 0 | GPU 1 | Status | P2P Expected | Notes |
|---------------|-------|-------|--------|--------------|-------|
| M2-AMD+NVIDIA | AMD | NVIDIA | 🔄 Required | No | Host staging only |
| M2-NVIDIA+Intel | NVIDIA | Intel | 🔄 Required | No | Host staging only |
| M2-AMD+Intel | AMD | Intel | 🔄 Required | No | Host staging only |
| M2-AMD+MTT | AMD | MTT | ⚠️ Experimental | No | MTT experimental |
| M2-NVIDIA+MTT | NVIDIA | MTT | ⚠️ Experimental | No | MTT experimental |
| M2-Intel+MTT | Intel | MTT | ⚠️ Experimental | No | MTT experimental |

### Triple-GPU Mixed Vendors

| Configuration | GPUs | Status | Notes |
|---------------|------|--------|-------|
| M3-AMD+NVIDIA+Intel | AMD + NVIDIA + Intel | 🔄 Required | Full heterogeneous test |
| M3-AMD+NVIDIA+MTT | AMD + NVIDIA + MTT | ⚠️ Experimental | MTT experimental |
| M3-AMD+Intel+MTT | AMD + Intel + MTT | ⚠️ Experimental | MTT experimental |
| M3-NVIDIA+Intel+MTT | NVIDIA + Intel + MTT | ⚠️ Experimental | MTT experimental |

### Quad-GPU+ Configurations

| Configuration | GPUs | Status | Notes |
|---------------|------|--------|-------|
| M4-2xAMD+2xNVIDIA | 2x AMD + 2x NVIDIA | 🔄 Future | Stress test |
| M4-4xNVIDIA | 4x NVIDIA | 🔄 Future | NVLink domain test |
| M4-4xAMD | 4x AMD | 🔄 Future | Infinity Fabric test |

## Software Matrix

### Distributions

| Distro | Kernel | Status | Notes |
|--------|--------|--------|-------|
| Ubuntu 24.04 LTS | 6.8.x | 🔄 Required | Primary target |
| Fedora 44 | 6.10.x | 🔄 Required | CI reference |
| Arch Linux | 6.10.x | 🔄 Required | Rolling target |
| openSUSE Leap 15.6 | 5.14.x | 🔄 Required | LTS kernel |

### Kernel Versions

| Kernel | Status | Notes |
|--------|--------|-------|
| 6.1.x LTS | 🔄 Required | Baseline LTS |
| 6.6.x LTS | 🔄 Required | Current LTS |
| 6.8.x | 🔄 Required | Ubuntu 24.04 |
| 6.10.x | 🔄 Required | Fedora 44, Arch |

## Validation Criteria

### Device Enumeration

| Test | Pass Criteria | Method |
|------|--------------|--------|
| GPU count | All physical GPUs detected | `mvgal_gpu_get_count()` |
| Vendor ID | Correct PCI vendor ID | `mvgal_gpu_get_descriptor()` |
| Driver binding | Driver name matches expected | sysfs `/sys/class/drm/cardX/device/driver` |
| VRAM size | Within 10% of expected | `mvgal_gpu_get_descriptor().vram_size` |
| NUMA node | Correct NUMA affinity | `mvgal_gpu_get_descriptor().numa_node` |

### P2P Capabilities

| Test | Pass Criteria | Method |
|------|--------------|--------|
| Same-vendor P2P | Detected when supported | `mvgal_unified_heap_p2p_supported()` |
| Cross-vendor P2P | Correctly reports unsupported | `mvgal_unified_heap_p2p_supported()` |
| DMA-BUF export | FD returned, valid | `MVGAL_IOC_EXPORT_DMABUF` |
| DMA-BUF import | FD returned, valid | `MVGAL_IOC_IMPORT_DMABUF` |

### API Interception

| API | Test | Pass Criteria |
|-----|------|---------------|
| Vulkan | Layer discovery | `VK_LAYER_MVGAL` found by loader |
| Vulkan | Device enumeration | Logical device created |
| OpenCL | Platform interception | `clGetPlatformIDs` returns MVGAL platform |
| CUDA | Device count | `cudaGetDeviceCount` returns aggregated count |

### Scheduling

| Strategy | Test | Pass Criteria |
|----------|------|---------------|
| Round-robin | Workload distribution | Equal distribution across GPUs |
| AFR | Frame alternation | Frames alternate GPUs |
| SFR | Tile splitting | Workload split across GPUs |
| Single-GPU | Pass-through | Workload on primary GPU only |

### Power/Idle

| Test | Pass Criteria | Method |
|------|--------------|--------|
| Idle detection | GPU parked after timeout | `mvgal_power_manager` metrics |
| Power curve | Clock/frequency adjustable | sysfs power_dpm_force_performance_level |
| Thermal | No throttling under load | Temperature < 90°C |

## Result Classification

### Hardware-Validated

Results from real hardware with:
- Reproducible logs (driver versions, kernel versions, dmesg)
- Measurable performance metrics
- No kernel panics or system instability
- Stored in `docs/hardware_validation/`

### Synthetic

Results from simulated/emulated environments:
- QEMU virtual GPUs
- Mocked vendor adapters
- Unit tests without real hardware
- Clearly labeled in test output

### Design-Only

Features not yet implemented:
- Clearly marked in STATUS.md
- No performance claims

## Required Evidence for M7 Gate

To mark M7 (Hardware Validation Matrix) as complete, the following must be submitted:

1. **Single-GPU baseline** for each vendor (4 configs)
   - `mvgal-info --json` output
   - `dmesg` showing driver binding
   - `lspci -vvv` for GPU

2. **Dual-GPU same-vendor** for at least one vendor
   - P2P capability report
   - Cross-GPU workload execution log

3. **Dual-GPU mixed-vendor** for at least one combination
   - Host staging transfer bandwidth
   - Workload execution log

4. **Triple-GPU mixed-vendor** (optional but preferred)
   - Full heterogeneous workload log

5. **Distribution validation** for at least two distros
   - Package install/uninstall log
   - Service start/stop log

## Storage Format

Hardware validation results should be stored as:

```
docs/hardware_validation/
├── README.md
├── matrix.md
├── S1-AMD/
│   ├── hostname.txt
│   ├── kernel-version.txt
│   ├── driver-versions.txt
│   ├── mvgal-info.json
│   ├── dmesg.log
│   └── lspci.txt
├── M2-AMD+NVIDIA/
│   ├── ...
│   └── workload-log.txt
└── summary.json
```

## CI Integration

Hardware validation tests are registered in CTest:

```bash
# Run all hardware validation tests
ctest -R hardware_validation --output-on-failure

# Run with JSON output for CI parsing
./tools/mvgal-hw-validate --json /tmp/hw-validation.json
```

## Known Limitations

1. **MTT hardware:** No reproducible MTT hardware available for validation
2. **NVIDIA P2P:** Requires matching NVIDIA GPUs and NVLink/PCIe topology
3. **Intel P2P:** Intel GPUs do not support PCIe P2P — host staging only
4. **Cross-vendor P2P:** Not supported by hardware — host staging required
