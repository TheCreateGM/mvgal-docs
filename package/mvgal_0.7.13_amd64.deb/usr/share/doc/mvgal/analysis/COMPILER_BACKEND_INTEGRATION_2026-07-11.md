# Per-Vendor Compiler Backend Integration Plan

**Date:** 2026-07-11  
**Status:** Implementation Complete — Toolchain Integration Pending

## Executive Summary

MVGAL implements a unified SPIR-V shader backend dispatch system with per-vendor compilation paths. All four vendor backends (AMD, Intel, NVIDIA, MTT) are implemented as stubs with graceful fallback chains. The infrastructure is production-ready; actual vendor compiler toolchain integration requires optional runtime dependencies.

## Architecture

### Unified Dispatch (`mvgal_shader_backend.c`)

The central dispatcher loads vendor backends via `dlopen/dlsym` at runtime:

```c
static vendor_plugin_t g_plugins[] = {
    { .vendor_id = MVGAL_VENDOR_AMD,      .soname = "libmvgal_amd_llvm.so" },
    { .vendor_id = MVGAL_VENDOR_INTEL,    .soname = "libmvgal_intel_igc.so" },
    { .vendor_id = MVGAL_VENDOR_NVIDIA,   .soname = "libmvgal_nvidia_ptx.so" },
    { .vendor_id = MVGAL_VENDOR_MTT,      .soname = "libmvgal_mtt_musa.so" },
};
```

Each backend exports three symbols:
- `mvgal_backend_<vendor>_init()`
- `mvgal_backend_<vendor>_fini()`
- `mvgal_backend_<vendor>_compile()`

### Compilation Fallback Chain

Each vendor backend implements a three-tier fallback:

1. **Native toolchain** (preferred) — vendor-specific compiler subprocess
2. **NTSYNC-managed internal compiler** — kernel-assisted compilation job
3. **SPIRV-Cross translation** — portable fallback to GLSL/HLSL/MSL

## Vendor Backend Status

### AMD — LLVM/AMDGPU

| Component | Status | Details |
|-----------|--------|---------|
| `backend_amd.c` | ✅ Implemented | llvm-spirv + llc subprocess chain |
| Toolchain probe | ✅ Implemented | ROCM_HOME, MVGAL_AMD_LLVM_PATH, PATH |
| NTSYNC fallback | ✅ Implemented | `mvgal_compile_sync(MVGAL_VENDOR_AMD, ...)` |
| SPIRV-Cross fallback | ✅ Implemented | GLSL emission |
| Build target | ✅ Built | `mvgal_shader_backend_amd.c.o` |

**Runtime dependencies:**
- `llvm-spirv` (LLVM SPIR-V translator)
- `llc` with AMDGPU target (`-march=amdgcn`)
- Optional: ROCm installation for full toolchain

**Probe order:**
1. `MVGAL_AMD_LLVM_PATH` environment variable
2. `ROCM_HOME` / `ROCM_PATH` environment variables
3. `/opt/rocm` default path
4. `PATH` lookup

### Intel — IGC/ocloc

| Component | Status | Details |
|-----------|--------|---------|
| `backend_intel.c` | ✅ Implemented | ocloc subprocess |
| Toolchain probe | ✅ Implemented | INTEL_ONEAPI_ROOT, PATH, well-known paths |
| NTSYNC fallback | ✅ Implemented | `mvgal_compile_sync(MVGAL_VENDOR_INTEL, ...)` |
| SPIRV-Cross fallback | ✅ Implemented | GLSL emission |
| Build target | ✅ Built | `mvgal_shader_backend_intel.c.o` |

**Runtime dependencies:**
- `ocloc` (Intel oneAPI Level Zero compiler)
- Optional: Intel Graphics Compiler library (future)

**Probe order:**
1. `INTEL_ONEAPI_ROOT` environment variable
2. `PATH` lookup
3. `/usr/bin/ocloc`, `/usr/local/bin/ocloc`
4. `/opt/intel/oneapi/compiler/latest/linux/bin/ocloc`

### NVIDIA — NVRTC/PTX

| Component | Status | Details |
|-----------|--------|---------|
| `backend_nvidia.c` | ✅ Stub | NVRTC + SPIRV-Cross PTX path |
| Toolchain probe | ✅ Implemented | MVGAL_HAVE_NVRTC conditional |
| NTSYNC fallback | ✅ Implemented | `mvgal_compile_sync(MVGAL_VENDOR_NVIDIA, ...)` |
| SPIRV-Cross fallback | ✅ Implemented | PTX emission via `mvgal_shader_route` |
| Build target | ✅ Built | `mvgal_shader_backend_nvidia.c.o` |

**Runtime dependencies:**
- CUDA toolkit (for `nvrtc` and `spirv-cross --cuda`)
- Optional: NVIDIA NVRTC library

**Note:** NVIDIA Vulkan drivers accept SPIR-V natively. This backend is primarily for CUDA/OptiX workloads.

### Moore Threads — MTT/MUSA

| Component | Status | Details |
|-----------|--------|---------|
| `backend_mtt.c` | ✅ Stub | NTSYNC + SPIRV-Cross GLSL path |
| Toolchain probe | ⚠️ Limited | MTT SDK not publicly available |
| NTSYNC fallback | ✅ Implemented | `mvgal_compile_sync(MVGAL_VENDOR_MOORE_THREADS, ...)` |
| SPIRV-Cross fallback | ✅ Implemented | GLSL emission |
| Build target | ✅ Built | `mvgal_shader_backend_mtt.c.o` |

**Runtime dependencies:**
- MTT SDK / MUSA compiler (`mttc`/`mcc`) — not publicly available
- Status: **Experimental** — degrades gracefully when absent

**Provenance note:** See `docs/MTT_PROVENANCE_AUDIT_2026-07-11.md` for MTT driver audit.

## Build System Integration

### CMake Configuration

The backends are compiled into `mvgal_vulkan_layer` as part of the main build:

```cmake
set(_vk_srcs
    intercept/vulkan/vk_layer.c
    intercept/vulkan/mvgal_shader_translate.c
    intercept/vulkan/mvgal_shader_backend_amd.c
    intercept/vulkan/mvgal_shader_backend_nvidia.c
    intercept/vulkan/mvgal_shader_backend_intel.c
    intercept/vulkan/mvgal_shader_backend_mtt.c
    intercept/mvgal_shader_backend.c
    ...
)
```

### Optional Compiler Dependencies

| Dependency | CMake Option | Default |
|------------|-------------|---------|
| LLVM + llvm-spirv | `MVGAL_HAVE_LLVM`, `MVGAL_HAVE_LLVM_SPIRV` | OFF |
| SPIR-V Tools/Cross | `MVGAL_ENABLE_SPIRV_OPT` | OFF |
| NVRTC | `MVGAL_HAVE_NVRTC` | OFF |
| Intel ocloc | Detected at runtime | — |

## Integration Tasks Remaining

| Task | Priority | Effort | Notes |
|------|----------|--------|-------|
| Add CMake options for LLVM/NVRTC detection | Medium | Small | Auto-detect llvm-spirv, llc, nvrtc |
| Package LLVM toolchain in distro deps | Medium | Medium | Add to install_dependencies.sh |
| Add NVIDIA NVRTC .so packaging | Low | Small | libmvgal_nvidia_ptx.so stub |
| Add MTT compiler integration (if SDK available) | Low | Unknown | Blocked on MTT provenance |
| Benchmark compilation latency per backend | Low | Medium | Measure subprocess overhead |
| Add SPIR-V validation before compilation | Low | Small | Use spirv-tools validator |

## Testing

All backends are covered by `test_shader_backend` (unit test) and `test_barrier_translate`:

```bash
cd build_output/src/tests/tests
ctest -R shader_backend --output-on-failure
ctest -R barrier_translate --output-on-failure
```

## Security Considerations

- All compiler backends use subprocess execution (`popen`, `system`) — input SPIR-V must be validated
- Temporary files are created in `/tmp` with `mkstemp` — safe from race conditions
- No network access during compilation
- NTSYNC path uses kernel-mediated compilation — safer for untrusted shaders

## License Notes

- AMD backend: links against LLVM (Apache-2.0) — compatible with GPL-3.0
- Intel backend: links against ocloc (proprietary) — used via subprocess, not linked
- NVIDIA backend: links against NVRTC (proprietary) — used via subprocess, not linked
- MTT backend: blocked on MTT SDK license audit
