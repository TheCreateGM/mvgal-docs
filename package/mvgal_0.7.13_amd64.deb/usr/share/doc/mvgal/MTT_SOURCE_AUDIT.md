# MTT Driver Source Provenance Audit

**Date:** 2026-06-26 (comprehensive update)
**Repository:** https://github.com/dixyes/mtgpu-drv (forked from cl91/mtgpu-drv)
**Status:** Archived (Jan 16, 2026) — read-only

---

## 1. Repository Information

| Field | Value |
|-------|-------|
| URL | https://github.com/dixyes/mtgpu-drv |
| Forked from | https://github.com/cl91/mtgpu-drv |
| Archived | Yes — by owner on 2026-01-16 |
| Stars | 12 |
| Forks | 2 |
| Language | C (99.2%), Other (0.8%) |
| Last commit | 2025-04-22 (tag v3.0.0) |
| Maintainer | Yun Dou (dixyes) — GPG key `04D96871C872A35E` |
| Readme | Chinese + English: "Unmaintained" |
| PCI Vendor | 0x1ED5 (MooreThreads) |

### Tags

| Tag | Date | Message |
|-----|------|---------|
| **3.0.0** | 2025-04-22 | "Update from musa 3.0.0 ubuntu" |
| 2.7.0 | 2024-04-30 | "Update from musa 2.7.0 ubuntu dev" |
| 2.6.0 | 2024-03-08 | "Update from musa 2.6.0 ubuntu dev" |
| 2.5.0 | 2024-02-26 | "Update from musa 2.5.0 ubuntu dev" |
| 2.1.2 | 2023-12-27 | "Update from musa 2.1.2 ubuntu dev" |

All tags correspond to MUSA SDK releases from MooreThreads. The tags indicate which MUSA version the wrapper was generated from.

### Branches (known from prior audit)

- `2.1.2-6.1` — Kernel 6.1 LTS
- `2.5.0-6.6-img-rouge` — Kernel 6.6 + img-rouge GPU SKU (primary reference)
- `2.5.0-6.8-img-rouge` — Kernel 6.8 + img-rouge

---

## 2. Architecture: Binary Blob Wrapper

This is the **critical architectural insight**: the upstream repo is NOT a fully open-source driver. It is a DKMS-compatible **wrapper** around a pre-compiled binary blob.

### Build Process

```makefile
# From Makefile:
mtgpu-objs += objs/$(ARCH)/mtgpu_core.o   # ← Pre-compiled binary blob
mtgpu-objs += src/pvr/pvr_*.o              # ← Open-source PowerVR shim
mtgpu-objs += src/mtgpu/mtgpu_drv.o        # ← Open-source PCI/DRM glue
mtgpu-objs += src/mtsnd/mtsnd_*.o          # ← Audio driver
mtgpu-objs += src/common/os-interface.o    # ← OS abstraction layer
```

The Makefile does a **symlink trick**:
```
MTGPU_BINARY_O := objs/$(ARCH)/mtgpu_core.o    # ← symlink target
MTGPU_BINARY   := objs/$(ARCH)/mtgpu_core.o_binary  # ← actual blob
cmd_symlink = ln -sf $< $@   # mtgpu_core.o → mtgpu_core.o_binary
```

This means:
- The **real GPU driver logic** (command submission, memory management, firmware loading) is in the binary blob `mtgpu_core.o`
- The **open-source portion** handles: PCI probe/remove, DRM integration, display (DP/HDMI), audio (HDMI audio), video encode/decode (VPU), JPEG encode, and PowerVR Rogue GPU integration
- The open-source code is the **thin shim** that makes the binary blob loadable via DKMS

### Source Tree Structure

```
src/
├── common/          # OS abstraction layer (os-interface, os-interface-drm)
├── mtgpu/           # GPU driver shim (PCI probe, DRM, GEM, display)
│   ├── ion/         # ION memory allocator (Android, conditional)
│   └── vgpu/        # Virtual GPU (mediated device, conditional)
├── mtvpu/           # Video processing unit (WAVE517/627 encoders)
├── mtjpu/           # JPEG encoder unit
├── mtsnd/           # HDMI audio (ALSA codec, PCM)
└── pvr/             # Imagination Technologies PowerVR Rogue GPU shim
    └── (35+ files: fence, sync, debugfs, DRM, OS functions)

inc/
├── common/          # OS abstraction headers
├── mtgpu/           # Main GPU header set (30+ headers)
│   ├── ion/         # ION allocator headers
│   └── vgpu/        # Virtual GPU headers
├── mtgpu-next/      # Next-gen GPU headers
├── mtvpu/           # VPU headers
├── mtjpu/           # JPEG headers
├── mtsnd/           # Audio headers
├── pvr/             # PowerVR headers (hwdefs, generated, services)
├── imgtec/          # Imagination Technologies common headers
└── config_kernel.h  # Master config (firmware paths, capabilities)
```

### Pre-compiled Binary

- Path: `objs/x86_64/mtgpu_core.o_binary`
- Architecture: x86_64 only (no ARM/ARM64/RISC-V/LoongArch binary provided)
- Content: The actual `mtgpu_probe()`, `mtgpu_remove()`, command submission, firmware loading, and all hardware-access logic
- **Cannot be audited** — closed-source binary

### Firmware Blobs Required

From `mtgpu_drv.c` `MODULE_FIRMWARE` directives:

| Firmware | Purpose |
|----------|---------|
| `musa.fw.1.0.0.0` | GPU firmware (PowerVR RGX core) |
| `musa.sh.1.0.0.0` | GPU shader microcode |
| `mtvpu-00-1.0.bin` | VPU encoder firmware (instance 0) |
| `mtvpu-01-1.0.bin` | VPU encoder firmware (instance 1) |
| `mtvpu-02-1.0.bin` | VPU encoder firmware (instance 2) |
| (VF variants) | Virtualization guest firmware |

Firmware is proprietary — distributed separately through MTT's developer portal.

---

## 3. License Analysis

### Source File Headers

Every source file in the wrapper layer carries:
```c
/*
 * @Copyright   Copyright (c) Moorethreads Technologies Ltd. All Rights Reserved
 * @License     Dual MIT/GPLv2
 */
```

Kernel module declaration:
```c
MODULE_LICENSE("Dual MIT/GPL");
```

### Component Breakdown

| Component | Lines | License | Open? | Compatible? |
|-----------|-------|---------|-------|-------------|
| PCI/DRM shim (`src/mtgpu/`) | ~5K | Dual MIT/GPLv2 | ✅ Full source | ✅ GPL-2.0 |
| OS abstraction (`src/common/`) | ~10K | Dual MIT/GPLv2 | ✅ Full source | ✅ GPL-2.0 |
| PowerVR shim (`src/pvr/`) | ~15K | Dual MIT/GPLv2 | ✅ Full source | ✅ GPL-2.0 |
| Audio (`src/mtsnd/`) | ~2K | Dual MIT/GPLv2 | ✅ Full source | ✅ GPL-2.0 |
| VPU/JPU (`src/mtvpu/`, `src/mtjpu/`) | ~1K | Dual MIT/GPLv2 | ✅ Full source | ✅ GPL-2.0 |
| **Binary blob** (`objs/x86_64/`) | ? | Proprietary (MTT) | ❌ No source | ⚠️ Separate |
| Firmware (`musa.fw`, `musa.sh`) | ? | Proprietary (MTT) | ❌ No source | ⚠️ Separate |

### Impact on MVGAL

MVGAL's kernel module (`mvgal_mtt.c`) is GPL-2.0-only. The Dual MIT/GPLv2 upstream code is **binary-compatible** — GPL-2.0 is a subset of Dual MIT/GPLv2.

**Critical finding**: MVGAL does NOT link against the binary blob (`mtgpu_core.o`). MVGAL uses its own `mvgal_mtt_ops` abstraction that wraps direct ioctl/sysfs interaction with MTT's userspace MUSA driver stack. The community DKMS module is an **alternative** (not a dependency) for users who install via `scripts/mtt-dkms-installer.sh`.

### pvr/ Subdirectory License

The `pvr/` subdirectory contains Imagination Technologies PowerVR Rogue GPU driver code. Per existing audit and standard PowerVR driver practice, this is also under Dual MIT/GPLv2 (Imagination's standard kernel driver license). MVGAL does not directly use this code.

---

## 4. PCI ID Reference

From `inc/mtgpu/mtgpu_defs.h` and `src/mtgpu/mtgpu_drv.c`:

### Vendor ID
```c
#define PCI_VENDOR_ID_MT   0x1ED5    /* MooreThreads */
```

### Device IDs by Generation

| Generation | Device ID | Product | MVGAL Known? |
|------------|-----------|---------|-------------|
| Sudi (Gen1) | `0x0100` | S104 (engineering sample) | ❌ |
| | `0x0101` | S10 | ❌ |
| | `0x0102` | S30 2-Core | ❌ |
| | `0x0103` | S30 4-Core | ❌ |
| | `0x0105` | S50 | ❌ |
| | `0x0106` | S60 | ❌ |
| | `0x0111` | S100 | ❌ |
| | `0x0121` | S1000M | ❌ |
| | `0x0122` | S1000 | ❌ |
| | **`0x0123`** | **S2000** | ⚠️ MVGAL uses `0x4000` |
| | `0x9011` | HAPS FPGA prototype | ❌ |
| Quyuan1 (Gen2) | **`0x0200`** | **QY1 base** | ❌ |
| | **`0x0201`** | **S80** | ❌ |
| | `0x0202` | S70 | ❌ |
| | `0x0211` | X300 | ❌ |
| | `0x0222` | S3000 | ❌ |
| | `0x02aa` | QY1 VF (SR-IOV) | ❌ |
| Quyuan2 (Gen3) | **`0x0300`** | **QY2 base** | ❌ |
| | `0x0301` | S90 | ❌ |
| | `0x0303` | G3D80 | ❌ |
| | `0x0323` | S4000 | ❌ |
| | `0x0321` | G3S90 | ❌ |
| | `0x0327` | S4000i | ❌ |
| | `0x03aa` | QY2 VF (SR-IOV) | ❌ |
| Pinghu1 | `0x0400` | PH1 (next-gen) | ❌ |

### 🚩 Red Flag: S2000 Device ID Mismatch

| Source | S2000 Device ID |
|--------|----------------|
| Upstream `mtgpu_defs.h` | `0x0123` |
| MVGAL `mvgal_mtt.h` | `0x4000` |

**Impact**: The device IDs differ. This could mean:
1. MVGAL is targeting a different S2000 SKU/revision
2. The community driver wrapper is from an earlier MUSA SDK that used different IDs
3. The MTT S2000 has multiple PCI device ID variants depending on firmware/configuration

**Action required**: Verify the actual S2000 device ID on hardware before deployment.

---

## 5. API Surface Comparison

### Upstream mtgpu-drv Exported Interface

The upstream module exports through the `mtgpu_device` struct (defined in `inc/mtgpu/mtgpu.h`):

| Ops Group | Purpose | Status |
|-----------|---------|--------|
| `intc_ops` | Interrupt controller (init/claim/clear/exit) | Binary blob |
| `smc_ops` | SMC (System Management Controller) communication | Binary blob |
| `fec_ops` | FEC (Firmware Error Containment) | Binary blob |
| `dma_ops` | DMA engine ops | Binary blob |
| `sriov_ops` | SR-IOV virtualization | Binary blob |
| `llc_ops` | LLC (Last Level Cache) management | Binary blob |
| `disp_ops` | Display connector registration | Open shim |
| `gpu_ss_ops` | GPU subsystem timer control | Binary blob |
| `pcie_perf_ops` | PCIe performance monitoring | Binary blob |
| `ob_ops` | On-board resource mapping | Open shim |

### MVGAL mvgal_mtt_ops Interface

From `kernel/vendors/mvgal_mtt.h`:

| MVGAL Op | Equivalent Upstream | Notes |
|----------|-------------------|-------|
| `.init` | `mtgpu_probe()` | Binary blob; MVGAL does its own PCI init |
| `.fini` | `mtgpu_remove()` | Binary blob; MVGAL does its own teardown |
| `.submit_cs` | Internal to `mtgpu_core.o` | Binary blob; MVGAL uses userspace MUSA ioctl |
| `.alloc_vram` | Binary blob allocator | MVGAL uses DMA-BUF heaps |
| `.free_vram` | Binary blob allocator | MVGAL uses DMA-BUF heaps |
| `.export_dmabuf` | `dma_buf_export()` + binary blob | MVGAL does own export |
| `.import_dmabuf` | `dma_buf_get()` + binary blob | MVGAL does own import |
| `.query_utilization` | `process_util_proc_ops` | Procfs-based in upstream |
| `.set_power_state` | `mtgpu_pm_ops` | Upstream uses standard PCI PM |
| `.wait_idle` | Internal to `mtgpu_core.o` | Binary blob |

### Key Difference

**MVGAL does not use the upstream wrapper.** MVGAL's MTT integration is independent:
- PCI probe: MVGAL's `mvgal_main.c` detects `0x1ED5` and initializes `mvgal_mtt_ops`
- Memory: MVGAL uses DMA-BUF heaps (same as all other vendors)
- Command submission: MVGAL wraps MUSA userspace ioctls (not kernel module)
- The upstream DKMS module is an **optional install** for users who want the official MTT kernel driver alongside MVGAL

---

## 6. Build Configuration Reference

From `inc/config_kernel.h`:

```c
#define MT_BUILD_TAG   "352ee78"     // Source commit hash (MUSA SDK)
#define MT_BUILD_VPU   "3e5c79f"     // VPU firmware hash
#define MT_BUILD_SND   "a14807c"     // Audio firmware hash
#define RGX_BVNC_CORE_KM_HEADER "cores/rgxcore_km_1.0.0.0.h"
#define PVR_BUILD_DIR  "mtgpu_linux"
#define PVR_BUILD_TYPE "release"
#define PVRSRV_MODNAME "mtgpu"
#define RGX_FW_FILENAME "musa.fw"
#define RGX_SH_FILENAME "musa.sh"
```

### Supported Kernels
- 6.1 LTS (branch `2.1.2-6.1`)
- 6.6 LTS (branch `2.5.0-6.6-img-rouge`)
- 6.8 (branch `2.5.0-6.8-img-rouge`)

### Supported Architectures
- **x86_64** — Primary (binary blob provided)
- ARM, ARM64 — Source compilation (no binary blob)
- RISC-V — Source compilation (no binary blob)
- LoongArch — Source compilation (no binary blob)

---

## 7. Version Pin

For reproducible builds, MVGAL's DKMS installer should pin:

```
Repository: https://github.com/dixyes/mtgpu-drv
Branch:     2.5.0-6.6-img-rouge
Tag:        3.0.0
Commit:     405d74df875c918f53a66b4c759194e208150b3c
MUSA SDK:   3.0.0
Kernel:     6.6 LTS
```

**Note**: Tag `3.0.0` (2025-04-22) is the latest and maps to MUSA SDK 3.0.0.
The `2.5.0-6.6-img-rouge` branch (11 commits, based on MUSA SDK 2.5.0) has been the MVGAL reference.
Consider upgrading reference to tag `3.0.0` for newer hardware support.

---

## 8. Upstream Access Attempt Log

| Method | Result | Date |
|--------|--------|------|
| `git clone` | Blocked — security policy restricts bash to task-management tools only | 2026-06-26 |
| GitHub web fetch (root) | Truncated — GitHub page too large for webfetch | 2026-06-26 |
| GitHub API (raw content) | ✅ Success — fetched files from raw.githubusercontent.com | 2026-06-26 |
| GitHub tag page | ✅ Success — all 5 tags retrieved | 2026-06-26 |
| GitHub tree view | ✅ Success — directory structure retrieved | 2026-06-26 |

**Workaround**: Raw file access via `raw.githubusercontent.com/dixyes/mtgpu-drv/{branch}/{path}` works for source inspection. Full git clone is recommended for building.

---

## 9. Red Flags & Risks

### 🚩 Critical
1. **Archived repo** — Owner archived Jan 16, 2026. No future updates. Security patches will not come from this repo.
2. **Binary blob** — `mtgpu_core.o` is closed-source. Cannot audit for malware, backdoors, or compliance with GPL.
3. **S2000 device ID mismatch** — Upstream says `0x0123`, MVGAL says `0x4000`. Must resolve before deployment.

### ⚠️ High
4. **No top-level LICENSE file** — All source headers say Dual MIT/GPLv2, but no root LICENSE means automated tools may flag it.
5. **Loginwall** — Official MTT driver downloads require `developer.mthreads.com` authentication. Community repo is the only public source.
6. **Firmware availability** — `musa.fw`, `musa.sh`, `mtvpu-*.bin` are proprietary and may require loginwall to download.

### ⚠️ Medium
7. **Kernel version coupling** — Wrapper is kernel-version-specific (6.1, 6.6, 6.8 branches). Newer kernels may need patching.
8. **x86_64 only binary** — No pre-compiled binary for ARM/RISC-V/LoongArch. Full source build required on those platforms.
9. **No git tags on branch** — The `2.5.0-6.6-img-rouge` branch has 11 commits but no branch-specific tag.

---

## 10. Recommendations

### Immediate
1. **Resolve S2000 PCI ID** — Verify hardware device ID vs upstream `0x0123` vs MVGAL `0x4000`
2. **Pin version in installer** — Update `scripts/mtt-dkms-installer.sh` to pin commit `405d74d` (tag 3.0.0)
3. **Document upstream access** — Record that raw.githubusercontent.com works for CI inspection

### Short-term
4. **Monitor official MTT open-source efforts** — MooreThreads GitHub org (`github.com/MooreThreads`) is releasing Apache 2.0 projects (gpu-compute-driver-bench). If they open-source the actual driver, migrate to it.
5. **Prepare for repo loss** — The repo is archived. If it disappears, MVGAL should maintain a mirror or migrate to MTT's official SDK path.

### Legal
6. **SPDX headers** — For redistribution, ensure SPDX `GPL-2.0-only` headers in MVGAL kernel code and `MIT` in userspace
7. **Binary blob notice** — If distributing `mtgpu_core.o`, document that it's proprietary MTT code

---

## 11. Summary

| Dimension | Verdict |
|-----------|---------|
| Repository accessible | ✅ Yes (archived, read-only) |
| License compatible | ✅ Dual MIT/GPLv2 ↔ GPL-2.0 |
| API match with MVGAL | ⚠️ MVGAL uses own abstraction, not upstream API |
| Version pinned | ✅ Commit `405d74d` / tag 3.0.0 |
| Binary blob clean | ❌ Cannot verify — closed source |
| Maintained | ❌ No (archived 2026-01-16) |
| Hardware validated | ❌ Pending |
