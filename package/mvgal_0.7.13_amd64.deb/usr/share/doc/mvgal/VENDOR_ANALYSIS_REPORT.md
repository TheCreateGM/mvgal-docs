# MVGAL Vendor Analysis Report
**Date:** 2026-06-17  
**Status:** Initial Research Complete

## Executive Summary

This document provides a detailed analysis of vendor kernel modules and their integration points with MVGAL. The goal is to identify safe integration interfaces for an above-driver coordination layer.

---

## 1. NVIDIA Analysis (`open-gpu-kernel-modules`)

### 1.1 Key Findings

**Repository Structure:**
- `kernel-open/nvidia/` - Main NVIDIA kernel module
- `kernel-open/nvidia-uvm/` - Unified memory support
- `kernel-open/nvidia-drm/` - DRM interface
- `kernel-open/common/` - Shared headers and utilities

### 1.2 Integration Points

| Component | Interface | MVGAL Usage |
|-----------|-----------|-------------|
| Character device | `nvidia` and `nvidiactl` | Topology enumeration only |
| DRM device | `nvidia-drm` | Render node access (`/dev/dri/cardX`) |
| DMA-BUF | `nv-dmabuf.c` | Export/import via `drm_gem_prime_export()` |
| NVLink | `nvlink_*` files | P2P detection, not command submission |
| IOCTLs | `nv-ioctl.h` | User-space only (cannot use from kernel) |

### 1.3 Key Files Analyzed

```
kernel-open/nvidia/nv.c           - Main device registration
kernel-open/nvidia/nv-pci.c       - PCI driver registration
kernel-open/nvidia/nv-dmabuf.c    - DMA-BUF export/import
kernel-open/nvidia/nv-p2p.c       - Peer-to-peer support
kernel-open/common/inc/nv-ioctl.h - IOCTL definitions
```

### 1.4 MVGAL Integration Strategy

```c
/* In kernel/vendors/mvgal_nvidia.c */

/* 
 * NVIDIA-specific notes:
 * - Cannot access proprietary driver internals from kernel
 * - Must use DRM render node path for command submission
 * - DMA-BUF export requires nvidia-drm.modeset=1
 * - NVLink P2P must be probed via sysfs or NVML (userspace)
 */

const struct mvgal_vendor_ops mvgal_nvidia_ops = {
    .init = mvgal_nvidia_init,          // Probe DRM device
    .fini = mvgal_nvidia_fini,          // Cleanup
    .submit_cs = mvgal_nvidia_submit_cs, // Forward to userspace
    .alloc_vram = mvgal_nvidia_alloc_vram, // Reserve VA range
    .free_vram = mvgal_nvidia_free_vram,
    .wait_idle = mvgal_nvidia_wait_idle, // Use nvidia-smi via daemon
    .set_power_state = mvgal_nvidia_set_power_state, // sysfs or pm-run
    .export_dmabuf = mvgal_nvidia_export_dmabuf, // Via DRM
    .import_dmabuf = mvgal_nvidia_import_dmabuf, // Via DRM
    .query_utilization = mvgal_nvidia_query_utilization, // Use nvidia-smi
};
```

### 1.5 Limitations

- **No kernel-space command submission**: Must forward to userspace daemon
- **Firmware dependency**: Requires matching GSP firmware
- **VA space management**: Must coordinate with NVIDIA's internal allocator

---

## 2. AMD Analysis (`AMDVLK` + `amdgpu` kernel)

### 2.1 Key Findings

**Important Note:** AMDVLK is discontinued. MVGAL should integrate with:
- Kernel `amdgpu.ko` for DMA-BUF and VRAM
- Mesa RADV for Vulkan (if available)
- ROCm for compute

### 2.2 Integration Points

| Component | Interface | MVGAL Usage |
|-----------|-----------|-------------|
| DRM device | `amdgpu.ko` | Render node (`/dev/dri/renderDXX`) |
| TTM | `drm_gem_tt_create()` | Memory allocation tracking |
| DMA-BUF | `drm_gem_prime_export()` | Cross-vendor sharing |
| P2P | AMD specific | NVLink-like on same GPU |
| Sysfs | `/sys/class/drm/cardX/` | Telemetry, power management |

### 2.3 MVGAL Integration Strategy

```c
/* In kernel/vendors/mvgal_amd.c */

/*
 * AMD-specific notes:
 * - Full kernel integration possible via DRM uapi
 * - TTM buffer objects tracked for residency
 * - DMA-BUF export/import through drm_gem functions
 * - Power management via sysfs DPM interfaces
 */

const struct mvgal_vendor_ops mvgal_amd_ops = {
    .init = mvgal_amd_init,            // Get amdgpu DRM device
    .fini = mvgal_amd_fini,            // Cleanup TTM tracking
    .submit_cs = mvgal_amd_submit_cs,  // Use DRM_IOCTL_AMDGPU_CS
    .alloc_vram = mvgal_amd_alloc_vram, // TTM bump allocator
    .free_vram = mvgal_amd_free_vram,
    .wait_idle = mvgal_amd_wait_idle,  // amdgpu_device_wait_idle
    .set_power_state = mvgal_amd_set_power_state, // DPM sysfs
    .export_dmabuf = mvgal_amd_export_dmabuf, // drm_gem_prime_export
    .import_dmabuf = mvgal_amd_import_dmabuf, // drm_gem_prime_import
    .query_utilization = mvgal_amd_query_utilization, // gpu_busy_percent
};
```

---

## 3. Intel Analysis (`i915`/`xe` + `media-driver`)

### 3.1 Key Findings

**Two kernel variants:**
- `i915.ko` - Legacy Intel graphics driver
- `xe.ko` - Next-generation Intel graphics driver (in development)

### 3.2 Integration Points

| Component | Interface | MVGAL Usage |
|-----------|-----------|-------------|
| DRM device | `i915.ko` or `xe.ko` | Render node access |
| GEM | `drm_gem_*` | Buffer management |
| DMA-BUF | `drm_gem_prime_export()` | Cross-device sharing |
| Sysfs | `/sys/class/drm/cardX/` | Telemetry, power states |
| Level Zero | Planned | Compute offload |

### 3.3 MVGAL Integration Strategy

```c
/* In kernel/vendors/mvgal_intel.c */

/*
 * Intel-specific notes:
 * - Use i915 or xe DRM interface (compile-time detection)
 * - DMA-BUF standard through drm_gem
 * - Power management via RPS/CCS sysfs
 */

const struct mvgal_vendor_ops mvgal_intel_ops = {
    .init = mvgal_intel_init,          // Detect i915 vs xe
    .fini = mvgal_intel_fini,
    .submit_cs = mvgal_intel_submit_cs, // Use DRM ioctls
    .alloc_vram = mvgal_intel_alloc_vram,
    .free_vram = mvgal_intel_free_vram,
    .wait_idle = mvgal_intel_wait_idle,
    .set_power_state = mvgal_intel_set_power_state, // RPS
    .export_dmabuf = mvgal_intel_export_dmabuf,
    .import_dmabuf = mvgal_intel_import_dmabuf,
    .query_utilization = mvgal_intel_query_utilization,
};
```

---

## 4. Moore Threads (MTT) Analysis (`mtgpu-drv`)

### 4.1 Key Findings

**Repository:** `https://github.com/dixyes/mtgpu-drv`  
**Status:** Community maintained, unmaintained upstream  
**License:** Dual MIT/GPLv2

### 4.2 Integration Points

| Component | Interface | MVGAL Usage |
|-----------|-----------|-------------|
| DRM device | `mtgpu.ko` | Render node (`/dev/dri/cardX`) |
| MUSA SDK | User-space | Compute offload |
| MTML | Management library | Telemetry |

### 4.3 MVGAL Integration Strategy

```c
/* In kernel/vendors/mvgal_mtt.c */

/*
 * MTT-specific notes:
 * - Keep support optional and capability-probed
 * - Graceful degradation when driver absent
 * - DMA-BUF support needs hardware validation
 */

const struct mvgal_vendor_ops mvgal_mtt_ops = {
    .init = mvgal_mtt_init,            // Optional, check availability
    .fini = mvgal_mtt_fini,
    .submit_cs = mvgal_mtt_submit_cs,  // Forward to userspace
    .alloc_vram = mvgal_mtt_alloc_vram,
    .free_vram = mvgal_mtt_free_vram,
    .wait_idle = mvgal_mtt_wait_idle,
    .set_power_state = mvgal_mtt_set_power_state,
    .export_dmabuf = mvgal_mtt_export_dmabuf,
    .import_dmabuf = mvgal_mtt_import_dmabuf,
    .query_utilization = mvgal_mtt_query_utilization,
};
```

---

## 5. Cross-Vendor Integration Requirements

### 5.1 DMA-BUF Matrix

| Src\Dst | AMD | NVIDIA | Intel | MTT |
|---------|-----|--------|-------|-----|
| AMD | ✅ | ⚠️ | ⚠️ | ⚠️ |
| NVIDIA | ⚠️ | ✅ | ⚠️ | ⚠️ |
| Intel | ⚠️ | ⚠️ | ✅ | ⚠️ |
| MTT | ⚠️ | ⚠️ | ⚠️ | ✅ |

Legend: ✅ = Tested, ⚠️ = Needs validation, ❌ = Not supported

### 5.2 API Support Matrix

| Vendor | Vulkan | OpenGL | OpenCL | CUDA | SYCL |
|--------|--------|--------|--------|------|------|
| AMD | RADV/AMDVLK | Mesa | ROCm | ❌ | CRTL |
| NVIDIA | Proprietary | Proprietary | CUDA | ✅ | DPC++ |
| Intel | ANV | Mesa | Level Zero | ❌ | DPC++ |
| MTT | MTML | ? | MUSA | ❌ | ? |

---

## 6. Implementation Recommendations

### 6.1 Kernel Module Structure

```
kernel/
├── mvgal_main.c          # Core device, PCI enumeration
├── mvgal_device.c        # Logical device management
├── mvgal_memory.c        # DMA-BUF, allocation coordination
├── mvgal_scheduler.c     # Workload dispatch
├── mvgal_sync.c          # Cross-device fences
├── mvgal_power.c         # Power management
└── vendors/
    ├── mvgal_amd.c       # AMD integration
    ├── mvgal_nvidia.c    # NVIDIA integration
    ├── mvgal_intel.c     # Intel integration
    └── mvgal_mtt.c       # MTT integration
```

### 6.2 Userspace Daemon Structure

```
runtime/daemon/
├── main.cpp              # Entry point
├── daemon.cpp            # Orchestration
├── device_registry.cpp   # GPU enumeration
├── scheduler.cpp         # Workload scheduling
├── memory_manager.cpp    # Cross-GPU memory
├── power_manager.cpp     # Power policy
├── metrics_collector.cpp # Telemetry
└── ipc_server.cpp        # Client API
```

### 6.3 API Interception Layers

```
src/userspace/intercept/
├── vk_layer.c            # Vulkan layer
├── cl_intercept.c        # OpenCL shim
├── cuda_wrapper.c        # CUDA shim
├── d3d_wrapper.c         # DirectX shim
└── webgpu_wrapper.c      # WebGPU shim
```

---

## 7. Next Steps

1. **Validate DMA-BUF export/import** on real hardware combinations
2. **Implement MTT detection** with runtime capability probing
3. **Add cross-vendor P2P detection** via PCI topology
4. **Create integration tests** for each vendor combination
5. **Document specific ioctl interfaces** for each vendor

---

## 8. References

- NVIDIA Open GPU Kernel Modules: https://github.com/NVIDIA/open-gpu-kernel-modules
- AMDVLK (Discontinued): https://github.com/GPUOpen-Drivers/AMDVLK
- Intel media-driver: https://github.com/intel/media-driver
- Moore Threads Driver: https://github.com/dixyes/mtgpu-drv
- MTT Developer Portal: https://developer.mthreads.com/