# MVGAL Session Progress — 2026-07-24

## Host hardware (validated)

| Card | Vendor | Device | Role |
|------|--------|--------|------|
| card2 | AMD | 1002:743f RX 6400 | Display (HDMI connected), ~4080 MiB |
| card0 | NVIDIA | 10de:2584 RTX 3050 6GB | Compute/render |
| card1 | Intel | 8086:56a5 Arc A380 | Discrete Xe |

Aggregated pool ≈ **16 GiB** across 3 vendors.

## Done this session

1. Cloned vendor research trees to `/tmp/mvgal-vendor-research/`:
   - NVIDIA `open-gpu-kernel-modules`
   - AMD `AMDVLK`
   - Intel `media-driver`
   - MTT `dixyes/mtgpu-drv` (clone succeeded)

2. Fixed daemon `DeviceRegistry` detection:
   - Correct PCI vendor/device file parsing (was broken `vendor:device` scanf)
   - DRM→PCI `realpath` binding, display connector detection
   - AMD `mem_info_vram_*` + `gpu_busy_percent`, NVML, Intel Arc fallbacks
   - Aggregation VRAM/util/PCIe/NUMA populated at init

3. Kernel aggregation fixes:
   - PCI class filter (VGA/3D only) — stopped claiming HD-audio funcs as GPUs
   - Vendor late-bind: `mvgal_core_register_vendor()` now inits existing GPUs
   - Host-backed `mvgal_dmabuf_export_host()` for cross-vendor staging
   - AMD VRAM from sysfs; Intel Arc device-ID VRAM table (A380=6GB)

4. Tools: `scripts/probe-gpu-detection.sh`

## Load order

```bash
insmod mvgal_ntsync.ko   # first — exports mvgal_ntsync_query
insmod mvgal.ko
insmod mvgal_amd.ko
insmod mvgal_nvidia.ko
insmod mvgal_intel.ko
```

## Known follow-ups

- Stuck `mvgal` module after oops on unload (refcnt=-1) may need reboot before reload
- NVIDIA VRAM still BAR-estimated (~8GB) vs real 6GB — prefer NVML in userspace (done) / refine kernel estimate
- Power-budget register returns `-EINVAL` (non-fatal)
- Real CS submit still daemon-forwarded by design (see FEASIBILITY doc)
