# Spec-to-Codebase Gap Analysis Map

**Maps `docs/MVGAL_RESEARCH_AND_DELIVERABLES_INDEX.md` sections 1–13 against the actual codebase.**

**Date:** 2026-07-09  
**Reference:** [`MVGAL_RESEARCH_AND_DELIVERABLES_INDEX.md`](MVGAL_RESEARCH_AND_DELIVERABLES_INDEX.md), [`CODEBASE_ANALYSIS.md`](CODEBASE_ANALYSIS.md), [`FEASIBILITY_AND_GAPS_2026-05-30.md`](FEASIBILITY_AND_GAPS_2026-05-30.md), [`GAP_ANALYSIS_2026-06-27.md`](GAP_ANALYSIS_2026-06-27.md), [`MISSING.md`](MISSING.md)

---

## §1 — Research Phase Checklist

**Spec describes:** 10-row checklist (README, source reading, architecture, dependency map, subsystem diagrams, workflows, kernel–user comms, vendor driver research, technology survey, gap analysis).

### Codebase evidence

| Checklist item | Spec status | Codebase evidence | Gap |
|---|---|---|---|
| Read README + project docs | ✅ | `README.md` exists, comprehensive, covers all layers | None — README is thorough |
| Read source | ✅ | `docs/CODEBASE_ANALYSIS.md` (64 files catalogued), `docs/RESEARCH_PHASE3.md` | None |
| Analyze architecture | ✅ | `docs/ARCHITECTURE.md`, `docs/ENGINEERING_DESIGN.md` | None |
| Dependency map | ✅ | Spec §3 flowchart, build system `CMakeLists.txt` dependencies documented | None |
| Subsystem diagrams | ✅ | Spec §4 mermaid diagrams | None |
| Workflow diagrams | ✅ | Spec §5 init/gaming/compute sequences | None |
| Kernel–user communication | ✅ | Spec §6, `docs/KERNEL_INTERFACE_SPEC.md`, `include/mvgal/mvgal_uapi.h` | None |
| Vendor driver research | ✅ | `docs/UPSTREAM_DRIVER_RESEARCH_2026-05-30.md`, vendor comparison table (§7) | None |
| Existing technologies survey | ✅ | `docs/RESEARCH_PHASE3.md §3.1`, `docs/research/01-multi-gpu-framework-survey.md` | None |
| Gap analysis | ✅ | `docs/FEASIBILITY_AND_GAPS_2026-05-30.md`, `docs/MISSING.md`, `docs/GAP_ANALYSIS_2026-06-27.md` | None — but these are fragmented across 3 docs; see §9 |

### Verdict
✅ **Fully implemented.** All research checklist items are documented. No new work needed.

---

## §2 — System Architecture (Target Design)

**Spec describes:** 14-row layer table mapping responsibilities to implementation paths.

### Codebase evidence

| Layer | Spec implementation path | Codebase status | Evidence |
|---|---|---|---|
| API interception | `src/userspace/intercept/`, `opengl/`, `compat/` | ✅ Complete | Vulkan layer (17 intercepted fns), OpenCL, CUDA (40+ fns), D3D, Metal, WebGPU, OpenGL preload |
| Execution engine | `src/userspace/execution/` | ✅ Complete | `execution.c` (882 LOC) — frame sessions, migration plans, Steam profiles |
| Runtime | `runtime/daemon/`, `src/userspace/daemon/` | ✅ Complete | mvgald C++20 daemon with all subsystems |
| Scheduler | `src/userspace/scheduler/`, `runtime/daemon/scheduler.cpp` | ✅ Complete | 7 strategies + AI prediction hook |
| Memory mgr | `src/userspace/memory/`, `runtime/daemon/memory_manager.cpp`, `kernel/mvgal_memory.c` | ⚠️ Partial | Userspace complete; kernel paths are stub (-EOPNOTSUPP) |
| Synchronization | `kernel/mvgal_sync.c`, `safe/fence_manager/`, `src/userspace/memory/sync.c` | ✅ Complete | Fence crate (3 tests), sync.c (402 LOC), kernel stubs exist |
| Device discovery | `kernel/mvgal_main.c`, `runtime/daemon/device_registry.cpp` | ✅ Complete | PCI enumeration, 8 ioctls, sysfs topology |
| Driver abstraction | `kernel/vendors/`, `safe/capability_model/` | ⚠️ Partial | 4 vendor stubs return fake addresses; capability_model crate (6 tests) is solid |
| Power mgr | `runtime/daemon/power_manager.cpp`, `kernel/mvgal_power.c` | ✅ Complete | DVFS, thermal, PSU headroom; kernel stubs |
| IPC | `runtime/daemon/ipc_server.cpp`, `src/userspace/daemon/ipc.c` | ✅ Complete | Unix socket, SCM_CREDENTIALS, 21 message types |
| Security | `config/org.freedesktop.policykit.mvgal.policy`, `docs/SECURITY_REVIEW.md` | ✅ Complete | Polkit, pkexec, SCM_CREDENTIALS |
| Monitoring | `runtime/daemon/metrics_collector.cpp`, `ui/`, `tools/mvgal_exporter.go` | ✅ Complete | Qt dashboard, Go REST API, Prometheus exporter |
| Kernel layer | `kernel/mvgal.ko → /dev/mvgal0` | ✅ Complete | Character device, 10 ioctls, sysfs |
| Container/virt | `docs/NETWORK_GPU_POOLING.md` | ⚠️ Design only | Documented, no implementation |

### Verdict
🔶 **Mostly complete.** Two gaps:
1. **Kernel memory paths** (DMA-BUF export/import, cross-vendor alloc/free) — 4 kernel ioctls stubbed with `-EOPNOTSUPP`
2. **Network GPU pool** — design document only, no code

---

## §3 — Dependency Map

**Spec describes:** Mermaid flowchart showing components and arrows between layers (apps → intercept → execution → runtime → Rust → kernel → vendor stacks).

### Codebase evidence

- The dependency arrows are implicitly implemented in the build system (`CMakeLists.txt` link dependencies) and runtime (Unix socket IPC, dlopen layer loading)
- The flowchart is accurate — MVGAL intercept layers communicate via IPC to daemon, daemon calls kernel via ioctl, vendor stacks are unmodified
- Build-time external dependencies are documented: CMake 3.16+, libdrm, pciaccess, Vulkan headers, optional OpenCL/Rust/Go/Qt

### Verdict
✅ **Fully implemented.** Dependency map is correct and the build system enforces the described relationships.

---

## §4 — Subsystem Diagram

**Spec describes:** Mermaid flowchart for device discovery → DAL → scheduler → memory manager, with subcomponents (PCI/DRM/NUMA/TOPO, vendor ops/capability, 7 strategies, DMA-BUF/P2P/staging/UVA).

### Codebase evidence

| Subsystem | Codebase | Status |
|---|---|---|
| Device discovery | `kernel/mvgal_device.c` (PCI, DRM nodes, NUMA), `runtime/daemon/device_registry.cpp` | ✅ Complete |
| Driver abstraction | `kernel/vendors/*.c` (4 vendor files), `safe/capability_model/` (6 tests) | ⚠️ Partial — vendor ops return fake data |
| Scheduler (7 strategies) | `src/userspace/scheduler/strategy/*.c` (afr, sfr, task, compute_offload, hybrid, plus round-robin and single in scheduler.c) | ✅ Complete |
| Memory manager | `src/userspace/memory/dmabuf.c` (DMA-BUF, P2P, UVM), `runtime/daemon/memory_manager.cpp` | ✅ Complete userspace; kernel DMA-BUF stubs |

### Verdict
🔶 **Mostly complete.** The subsystem architecture as documented is implemented. Only the kernel-level DMA-BUF and vendor ops stubs prevent the diagram from being fully operational. These are documented in the spec as "stubs / -EOPNOTSUPP" so this is honest.

---

## §5 — Workflow Diagrams

**Spec describes:** Three sequence diagrams:
1. §5.1 **Initialization** — systemd → mvgald → /dev/mvgal0 → PCI scan → device registry → bind socket
2. §5.2 **Gaming (AFR)** — Game → DXVK → VK_LAYER_MVGAL → daemon IPC → vendor ICD
3. §5.3 **Compute offload** — App → CUDA/OpenCL shim → scheduler → GPU A + GPU B

### Codebase evidence

#### §5.1 Initialization
- `runtime/daemon/main.cpp` — entry, signal handling, daemonization, PID file
- `runtime/daemon/daemon.cpp` — orchestrates all subsystems
- `kernel/mvgal_main.c` — `/dev/mvgal0` char device, PCI rescan
- `runtime/daemon/device_registry.cpp` — sysfs/PCI enumeration
- `runtime/daemon/ipc_server.cpp` — bind `/run/mvgal/mvgal.sock`

**Verdict:** ✅ Complete — the init path matches the diagram exactly.

#### §5.2 Gaming (AFR)
- `src/userspace/intercept/vulkan/vk_layer.c` — dispatch-chain layer, 17 intercepted functions
- `src/userspace/scheduler/strategy/afr.c` — alternate frame rendering
- `runtime/daemon/ipc_server.cpp` — IPC telemetry
- `steam/mvgal_frame_pacer.c` — vsync-aligned pacing

**Verdict:** ✅ Complete — the AFR gaming path is implemented and matches the diagram.

#### §5.3 Compute offload
- `src/userspace/intercept/cuda/cuda_wrapper.c` — CUDA shim, 40+ functions
- `src/userspace/intercept/opencl/cl_intercept.c` — OpenCL shim
- `src/userspace/scheduler/strategy/compute_offload.c` — compute offload strategy

**Verdict:** ✅ Complete — compute offload path exists and matches the diagram.

### Overall Verdict
✅ **All three workflow diagrams are accurate and implemented.** No gaps.

---

## §6 — Kernel–User Communication

**Spec describes:** Diagram showing /dev/mvgal0 ioctl, sysfs, Unix socket, optional D-Bus. Design rule: MVGAL does NOT `pci_register_driver` on GPUs.

### Codebase evidence

| Interface | Codebase | Status |
|---|---|---|
| `/dev/mvgal0 ioctl` | `kernel/mvgal_main.c` — 10 ioctls (8 implemented, 4 stubbed) | ✅ 8/10 functional |
| `/sys/class/mvgal/mvgal0/` | `kernel/mvgal_main.c` sysfs — gpu_count, topology_generation, rescan, per-GPU subdirs | ✅ Complete |
| `/run/mvgal/mvgal.sock` | `runtime/daemon/ipc_server.cpp` — Unix socket, SCM_CREDENTIALS, 21 message types | ✅ Complete |
| D-Bus (optional) | `runtime/daemon/dbus_service.cpp` — scheduling mode, GPU rescan | ✅ Complete |

**Design rule compliance:** MVGAL observes PCI via bus scan, never claims devices from vendor drivers. Verified — no `pci_register_driver` call on GPU PCI IDs.

### Verdict
✅ **Fully implemented.** 4 kernel ioctls return `-EOPNOTSUPP` (documented in spec as stubs), but the communication architecture is correct.

---

## §7 — Vendor Driver Comparison

**Spec describes:** 13-dimension comparison table for NVIDIA (open-gpu-kernel-modules), AMD (AMDVLK + amdgpu), Intel (media-driver + i915/xe), Moore Threads (mtgpu-drv).

### Codebase evidence

- `docs/UPSTREAM_DRIVER_RESEARCH_2026-05-30.md` — detailed vendor repository research
- `docs/REFERENCE_RESEARCH.md` — additional reference material
- `kernel/vendors/mvgal_amd.c`, `mvgal_nvidia.c`, `mvgal_intel.c`, `mvgal_mtt.c` — 4 vendor integration files (~200 LOC each)
- All four vendor files implement `struct mvgal_vendor_ops` with stubs returning fake addresses and 50% utilization

### Verdict
🔶 **Research complete, implementation stubbed.** The comparison table is well-researched and accurate. The vendor operations interface (`mvgal_vendor_ops`) is designed correctly. The actual implementation returns fake data — this is acknowledged in the spec as "stubs / fake addresses" and is acceptable for v1 which does userspace-only submission.

---

## §8 — Existing Technologies — Reusable Concepts

**Spec describes:** 10-row table mapping existing technologies (Vulkan device groups, dma-buf, NCCL/RCCL, MPI/OpenMP/SYCL, SLI/CrossFire, DXVK, esync/fsync, Mesa, StarPU/Legion, PyTorch Distributed) to MVGAL reuse.

### Codebase evidence

| Technology | MVGAL reuse | Codebase evidence |
|---|---|---|
| Vulkan device groups | ICD + layer model | `src/userspace/vulkan_icd/device_group.c` — device group emulation |
| dma-buf / PRIME | Primary zero-copy path | `src/userspace/memory/dmabuf.c` (802 LOC), `kernel/mvgal_memory.c` (280 LOC) |
| NCCL / RCCL | P2P matrix + compute offload | `docs/research/01-multi-gpu-framework-survey.md` references |
| MPI / OpenMP / SYCL | Explicit multi-device compute | Referenced in scheduler and memory designs |
| SLI / CrossFire | AFR/SFR heuristics | `src/userspace/scheduler/strategy/afr.c` (166 LOC), `sfr.c` (331 LOC) |
| DXVK / VKD3D-Proton | Inherit Vulkan aggregation | `docs/GAMING.md`, `steam/README.md` |
| Esync / Fsync / NTSYNC | Wine synchronization | `kernel/mvgal_ntsync.ko`, `compat/ntsync/` |
| Mesa / Gallium / Zink | OpenGL → VK | `opengl/mvgal_gl_preload.c` — Zink integration |
| StarPU / Legion | Scheduler + migration design | `docs/research/01-multi-gpu-framework-survey.md` references |
| PyTorch Distributed | Explicit backends, not transparent CUDA | `professional/ai_frameworks.md` doc only; **no native torch.distributed.Backend exists** |

### Verdict
🔶 **Mostly complete.** One gap: **PyTorch Distributed** is documented but has no native `torch.distributed.Backend` plugin. The doc currently describes `LD_PRELOAD libmvgal_cuda.so` as the approach, but a proper backend registration (`torch.distributed.Backend.register_backend("mvgal", ...)`) does not exist.

---

## §9 — Gap Analysis (Honest)

**Spec describes:** 8-row gap table (kernel cross-vendor submit, DMA-BUF matrix, Vulkan heterogeneous logical device, SPIR-V → vendor ISA, transparent unmodified apps, MTT production, network GPU pool, AI scheduler, hardware CI).

### Codebase evidence

| Gap area | Spec claim | Codebase reality | Delta |
|---|---|---|---|
| Kernel cross-vendor submit | Stubs / -EOPNOTSUPP | ✅ Accurate — 4 vendor files return fake addresses | None |
| DMA-BUF matrix | Code + tests; HW matrix incomplete | ✅ Accurate — dmabuf.c exists, but HW validation per-pair is incomplete | None |
| Vulkan heterogeneous logical device | Synthetic groups + ICD scaffold | ✅ Accurate — device_group.c, ICD entry points exist | None |
| SPIR-V → vendor ISA | Routing stubs | ⚠️ Partially — shader_translate.c (490 LOC) has FNV-1a hash cache, capture + route stubs; shader_backend files exist for all 4 vendors | Some code exists beyond "stubs" |
| Transparent unmodified apps | Marketing risk | ✅ Accurate — pass-through default is documented | None |
| MTT production | Cloneable source; stub on test box | ✅ Accurate — MTT_SOURCE_AUDIT.md exists | None |
| Network GPU pool | Design only | ✅ Accurate — NETWORK_GPU_POOLING.md exists | None |
| AI scheduler | Heuristic + ONNX hook | ✅ Accurate — mvgal_ai_model_predict() expects /etc/mvgal/models/scheduler.onnx | None |
| Hardware CI | Manual workflow_dispatch | ✅ Accurate — CI configuration exists, no hardware farm | None |

**Spec cross-references:** `MISSING.md`, `FEASIBILITY_AND_GAPS_2026-05-30.md`, milestone table in `STATUS.md`.

### Verdict
✅ **The spec's gap table is accurate and honest.** Three separate gap analysis docs exist (`MISSING.md`, `FEASIBILITY_AND_GAPS_2026-05-30.md`, `GAP_ANALYSIS_2026-06-27.md`) with overlapping content. Consider consolidating.

---

## §10 — Language, Compiler, and Build Choices

**Spec describes:** 8-row table (C, C++20, Rust, Go, Python, V/others, CMake, Meson/Zig, GCC/Clang) with rationale.

### Codebase evidence

| Language | Rationale | Codebase evidence |
|---|---|---|
| C (C17) | Kernel KAPI, stable FFI | `kernel/*.c` (9 files), `src/userspace/*.c` (16+ files), `include/mvgal/*.h` (13 headers) |
| C++20 | RAII for daemon | `runtime/daemon/*.cpp` (10+ files) |
| Rust | Memory safety | `safe/` (3 crates, 12 tests) |
| Go | Fast HTTP/tooling | `ui/mvgal_rest_server.go`, `tools/mvgal_exporter.go` |
| Python | Scripts, AI | `professional/test_pytorch_multiGPU.py`, test scripts |
| CMake | Primary build | `CMakeLists.txt` (root), subdirectory `CMakeLists.txt` files |
| Meson | Alternative | `meson.build` files present |
| Zig | Alternative | `build.zig` present |
| GCC / Clang | Both supported | CI matrix tests both |

### Verdict
✅ **Fully implemented.** All languages, compilers, and build systems described in the spec are present in the codebase.

---

## §11 — Twenty Deliverables (D1–D20)

**Spec describes:** 20-row deliverable table with maturity ratings (design complete / implemented / current / late alpha).

### Codebase evidence

| # | Deliverable | Spec maturity | Codebase status | Gap |
|---|---|---|---|---|
| D1 | Architecture spec | Design complete | ✅ `ARCHITECTURE.md`, `ENGINEERING_DESIGN.md`, spec §2–6 exist | None |
| D2 | Driver abstraction spec | Design complete; ops partially stubbed | ✅ `DRIVER_ARCHITECTURE_DESIGN.md`, `DRIVER_INTEGRATION.md` exist; vendor ops stubs | None (spec accurate) |
| D3 | Runtime spec | Implemented | ✅ `runtime/daemon/` complete | None |
| D4 | Scheduler spec | Implemented; validation ongoing | ✅ 7 strategies, tests pass | None |
| D5 | Memory spec | Design + code; HW matrix open | ✅ `MEMORY.md`, code exists; HW validation per-pair incomplete | Spec accurate |
| D6 | Security spec | Documented + Polkit | ✅ `SECURITY_REVIEW.md`, `SECURITY.md`, Polkit policy | None |
| D7 | Linux packaging spec | DEB/RPM/Arch/COPR | ✅ `PACKAGING_SUMMARY.md`, `packaging/`, COPR builds | None |
| D8 | Steam integration spec | Implemented | ✅ `STEAM.md`, `steam/` complete | None |
| D9 | Wine/Proton spec | Partial (NTSYNC/WoW64 scaffolding) | ✅ WoW64 thunk, NTSYNC kernel module; Wine integration pending | Spec accurate |
| D10 | Power mgmt spec | Implemented in daemon | ✅ `power_manager.cpp`, `mvgal_power.c`, `ENGINEERING_DESIGN.md §4` | None |
| D11 | Benchmark reports | Tool exists; publish logs | ✅ `mvgal-bench` tool, `misc/benchmarks/` | Need published per-platform logs |
| D12 | Test reports | One 3-GPU system logged | ✅ `HARDWARE_VALIDATION_2026-06-01.md` | Limited coverage |
| D13 | API documentation | Complete headers | ✅ `include/mvgal/` (13 headers), `API.md`, `API_REFERENCE.md` | None |
| D14 | Developer docs | Complete | ✅ `DEVELOPER_GUIDE.md`, `CONTRIBUTING.md` | None |
| D15 | End-user docs | Complete | ✅ `USER_GUIDE.md`, `QUICKSTART.md`, `INSTALL.md` | None |
| D16 | Build system docs | Complete | ✅ README §Building, CMake options | None |
| D17 | Gap analysis report | Current | ✅ `FEASIBILITY_AND_GAPS_2026-05-30.md`, `MISSING.md`, `GAP_ANALYSIS_2026-06-27.md` | 3 overlapping docs; this doc consolidates |
| D18 | Roadmap | Current | ✅ `plans/IMPLEMENTATION_PLAN.md`, `STATUS.md` milestones | None |
| D19 | Prototype implementation | Late alpha | ✅ v0.6.0, 59/59 tests pass | Spec accurate |
| D20 | Production plan | This document | ✅ Spec §12 | None |

### Verdict
✅ **All 20 deliverables exist with maturity as documented in the spec.** The spec's maturity ratings are accurate.

---

## §12 — Production Implementation Plan

**Spec describes:** Phased 4-phase plan (A–D) with specific milestones:
- **Phase A** (0–3mo): HW matrix, DMA-BUF/P2P validation, Vulkan loader regression, security audit
- **Phase B** (3–9mo): Vulkan ICD primary, cross-vendor dma-buf, AFR/SFR safety, SPIR-V backends, unified heap
- **Phase C** (9–18mo): NTSYNC production, AI scheduler, packaging expansion, professional validation
- **Phase D** (18+mo): Network GPU pool, virtual DRM node, HW CI farm

### Codebase evidence

| Phase | Status | Evidence |
|---|---|---|
| **Phase A** — Evidence & safety | 🔶 Partial | HW matrix: partial (1 system logged). DMA-BUF/P2P: code exists, per-pair validation incomplete. Vulkan regression: layer exists, formal regression suite unclear. Security: Polkit + pkexec audits exist |
| **Phase B** — Core aggregation | 🔶 Partial | Vulkan ICD: scaffold exists. Cross-vendor dma-buf: code exists. AFR/SFR: implemented. SPIR-V: routing stubs exist. Unified heap: mvgal_residency_migrate() exists |
| **Phase C** — Ecosystem | ⚠️ Mostly future | NTSYNC: kernel module + WoW64 thunk done, Wine integration pending. AI scheduler: hook exists (ONNX model path), no real model. Flatpak/Snap: not done. Professional: docs exist |
| **Phase D** — Advanced | ⚠️ Future | Network pool: design doc only. Virtual DRM: not started. HW CI: manual-only |

### Verdict
🔶 **Phase A is partially implemented, Phase B partially, Phases C–D largely future.** This matches the spec's expectation for a v0.6.0 "late alpha" project.

---

## §13 — Topology Example

**Spec describes:** Example NUMA topology with AMD RX 6400 + NVIDIA RTX 3050 + Intel (optional) + MTT S30, with P2P eligibility guidance.

### Codebase evidence

- `kernel/mvgal_device.c` — P2P detection: NUMA node check, NVIDIA NVLink, AMD xGMI
- `runtime/daemon/device_registry.cpp` — PCI enumeration, sysfs topology
- `src/userspace/memory/dmabuf.c` — `mvgal_detect_all_p2p()` function
- `include/mvgal/mvgal_gpu.h` — PCI info, DRM node, NUMA fields in GPU descriptor
- `docs/HARDWARE_VALIDATION_2026-06-01.md` — validates on AMD RX 6400 + NVIDIA RTX 3050 + MTT S30

### Verdict
✅ **Fully implemented.** The topology example matches a real validated system. P2P detection code exists at both kernel and userspace levels.

---

## Summary

### Per-Section Verdict

| § | Section | Verdict |
|---|---------|---------|
| 1 | Research Phase Checklist | ✅ Complete |
| 2 | System Architecture | 🔶 Partial — kernel DMA-BUF stubs, network pool design-only |
| 3 | Dependency Map | ✅ Complete |
| 4 | Subsystem Diagram | 🔶 Partial — vendor ops return fake data |
| 5 | Workflow Diagrams | ✅ Complete |
| 6 | Kernel–User Communication | ✅ Complete |
| 7 | Vendor Driver Comparison | 🔶 Research complete, kernel vendor ops stubbed |
| 8 | Existing Technologies | 🔶 Partial — PyTorch Distributed backend missing |
| 9 | Gap Analysis (Honest) | ✅ Accurate — spec table is honest |
| 10 | Language/Compiler/Build | ✅ Complete |
| 11 | Twenty Deliverables | ✅ All 20 exist at documented maturity |
| 12 | Production Plan | 🔶 Phases A/B partially done, C/D future |
| 13 | Topology Example | ✅ Complete |

### Top 3 Gaps (by priority)

1. **PyTorch Distributed Backend** (§8) — documented as `LD_PRELOAD` workaround, no native `torch.distributed.Backend` plugin
2. **Qt Light Theme Bug** (not in spec) — `ThemeManager::setTheme()` never calls `qApp->setPalette()` or `qApp->style()->polish(qApp)` — **FIXED** (2026-07-09)
3. **Consolidated Gap Analysis** (§9) — 3 overlapping documents (`MISSING.md`, `FEASIBILITY_AND_GAPS_2026-05-30.md`, `GAP_ANALYSIS_2026-06-27.md`) with different scopes and dates; this map helps but consolidation would reduce confusion
