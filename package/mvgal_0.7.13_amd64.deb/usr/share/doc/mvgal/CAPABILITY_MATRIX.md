# MVGAL Vendor Capability Matrix

This document provides a detailed mapping of hardware and driver capabilities across supported GPU vendors (AMD, NVIDIA, Intel, and Moore Threads).

| Feature | NVIDIA | AMD | Intel | Moore Threads |
|---------|--------|-----|-------|---------------|
| **Primary Driver** | `nvidia-open` / `nvidia` | `amdgpu` | `i915` / `xe` | `mtgpu-drv` |
| **Kernel Subsystem** | DRM / proprietary | DRM | DRM | DRM |
| **DMA-BUF Export** | ✅ Yes | ✅ Yes | ✅ Yes | ⚠️ Experimental |
| **DMA-BUF Import** | ✅ Yes | ✅ Yes | ✅ Yes | ⚠️ Experimental |
| **PCIe P2P DMA** | ✅ Yes (Turing+) | ✅ Yes (RDNA+) | ⚠️ Limited | ❌ No |
| **Unified Memory** | ✅ Yes (UVA) | ✅ Yes (HMM) | ✅ Yes (SVM) | ❌ No |
| **Timeline Semaphores**| ✅ Yes | ✅ Yes | ✅ Yes | ⚠️ Partial |
| **Vulkan Support** | ✅ 1.3 | ✅ 1.3 | ✅ 1.3 | ⚠️ 1.2 |
| **Compute APIs** | CUDA, OpenCL, Vulkan | ROCm, OpenCL, Vulkan | OneAPI, OpenCL, Vulkan | MUSA, OpenCL, Vulkan |
| **Power Management** | ✅ High | ✅ High | ✅ Medium | ⚠️ Basic |
| **Thermal Monitoring** | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |

---

## Vendor Specific Details

### NVIDIA
- **Supported Architectures:** Turing (RTX 20xx), Ampere (RTX 30xx), Ada (RTX 40xx), Pascal.
- **Interconnect:** Supports NVLink for ultra-high-speed P2P transfers.
- **DMA-BUF:** Requires `nvidia-drm.modeset=1`. Full support for cross-vendor sharing via `dma-buf`.
- **P2P DMA:** Supported on Turing and newer when connected via compatible PCIe switches or NVLink.

### AMD
- **Supported Architectures:** RDNA 1/2/3, GCN, APU (Vega/RDNA).
- **Interconnect:** Infinity Fabric (internal), standard PCIe P2P.
- **DMA-BUF:** Native support in `amdgpu` driver. Very reliable for cross-vendor aggregation.
- **P2P DMA:** Supported on RDNA and newer.

### Intel
- **Supported Architectures:** Gen 9–12 (iGPU), Xe / Arc (discrete).
- **Interconnect:** Standard PCIe.
- **DMA-BUF:** Native support. Discrete Arc cards (Xe driver) have better P2P support than integrated Gen 9/11.
- **P2P DMA:** Limited by system BIOS and PCIe topology.

### Moore Threads (MTT)
- **Supported Architectures:** MTT S60, S80, S2000.
- **Driver:** `mtgpu-drv` (out-of-tree).
- **DMA-BUF:** Support is under active development. Current implementation may require host-staged fallbacks.
- **P2P DMA:** Not currently supported in the public driver.

---

## Aggregation Compatibility

| Configuration | P2P Path | Fallback Path | Performance |
|---------------|----------|---------------|-------------|
| AMD + AMD | PCIe P2P | DMA-BUF | Excellent |
| NVIDIA + NVIDIA| NVLink / PCIe P2P| DMA-BUF | Excellent |
| AMD + NVIDIA | PCIe P2P | DMA-BUF / Staging| Good |
| Intel + Any | DMA-BUF | Staging | Fair |
| MTT + Any | Staging | Staging | Experimental |

---

## Known Issues & Gaps
- **MTT:** Missing peer-to-peer memory registration.
- **Intel i915:** Limited DMA-BUF export of certain tiling formats.
- **NVIDIA:** Requires specific kernel module parameters for full P2P functionality.
