# MVGAL Implementation Plan

**Version:** 0.7.3 | **Last Updated:** August 2026

---

## Overview

This document tracks milestones, owners, timelines, and deliverables for the MVGAL project. The project follows an incremental delivery model with 6 milestones (M0–M5), of which M0–M5 core are complete.

---

## Milestones

### M0: Research & Prototyping (Complete)

**Duration:** 2 weeks | **Owner:** Core team

| Deliverable | Status | Notes |
|-------------|--------|-------|
| Kernel module proof-of-concept | ✅ | Single char device, basic ioctls |
| GPU enumeration via sysfs | ✅ | AMD, NVIDIA, Intel detection |
| IPC protocol design | ✅ | Binary protocol with MVGL magic |
| Scheduler algorithm prototype | ✅ | Round-robin and AFR working |

### M1: MVP Prototype (Complete)

**Duration:** 4 weeks | **Owner:** Core team

| Deliverable | Status | Notes |
|-------------|--------|-------|
| Kernel module with 10 DRM ioctls | ✅ | DRM_ioctl_def_drv registration |
| `mvgald` daemon with 12 subsystems | ✅ | C++20, scheduler + memory + power |
| `libmvgal` public C API | ✅ | 13 public headers |
| Vulkan implicit layer | ✅ | VK_LAYER_MVGAL |
| Basic packaging (RPM) | ✅ | COPR for Fedora/RHEL |

### M2: High-Performance Paths (Complete)

**Duration:** 4 weeks | **Owner:** Core team

| Deliverable | Status | Notes |
|-------------|--------|-------|
| DMA-BUF zero-copy transfer | ✅ | Three-tier fallback |
| PCIe P2P detection | ✅ | Same root-complex check |
| NVML dynamic loading | ✅ | 11 NVML functions wrapped |
| OpenCL ICD wrapper | ✅ | LD_PRELOAD |
| CUDA shim (40+ functions) | ✅ | Function hooking |

### M3: Rendering, Gaming & Proton (Partial)

**Duration:** 6 weeks | **Owner:** Core team

| Deliverable | Status | Notes |
|-------------|--------|-------|
| AFR strategy | ✅ | Alternate Frame Rendering |
| SFR strategy | ✅ | Split Frame Rendering |
| Frame pacer (vsync-aligned) | ✅ | Background thread, CLOCK_MONOTONIC |
| Steam profile loader | ✅ | INI-based per-game profiles |
| GameMode plugin | ✅ | Feral Interactive integration |
| NTSYNC bridge | ✅ | Wine sync primitives |
| WineSyncBridge (fsync/esync) | ✅ | Mode detection and mapping |
| **Proton module patches** | ⚠️ | `proton-module/` directory created; needs real testing |
| **Game FPS benchmarks** | ⚠️ | Scripts created; needs hardware validation |

### M4: Power, Packaging & Distro (Partial)

**Duration:** 4 weeks | **Owner:** Core team

| Deliverable | Status | Notes |
|-------------|--------|-------|
| PowerManager (idle/parking/DVFS) | ✅ | Thermal management |
| RPM packaging via COPR | ✅ | Fedora 43-45, RHEL/Alma 8-10 |
| DEB packaging scripts | ✅ | `packaging/build_deb.sh` (untested) |
| Arch PKGBUILD | ✅ | `packaging/arch/PKGBUILD` (untested) |
| systemd unit files | ✅ | `mvgal-daemon.service` |
| Man pages (10 pages) | ✅ | `mvgal(1)` through `mvgal-steam-setup(1)` |
| **CI pipeline** | ✅ | `.github/workflows/build.yml` created |
| **DEB CI build** | ⚠️ | Script exists; CI workflow created |

### M5: Hardening & Polish (Partial)

**Duration:** Ongoing | **Owner:** Core team

| Deliverable | Status | Notes |
|-------------|--------|-------|
| Rust safety crates (3 crates) | ✅ | fence_manager, memory_safety, capability_model |
| 88 tests passing | ✅ | 12 Rust + 76 C/C++ |
| Secure Boot signing | ✅ | MOK enrollment via `mvgal-enroll-mok` |
| Security review | ✅ | Documented in SECURITY.md |
| Contributor guide | ✅ | CONTRIBUTING.md |
| **Extended hardware validation** | ⚠️ | AMD RX 6400 + NVIDIA RTX 3050 tested |
| **Network GPU pooling** | ⚠️ | IPC protocol supports it; not production-ready |
| **AI scheduling** | ⚠️ | Code exists; needs training data |
| **Cloud GPU integration** | ⚠️ | Future milestone |

---

## Remaining Work

### Priority 1: Hardware Validation (Required)

- Test on multi-vendor GPU combinations: AMD+NVIDIA, AMD+Intel, NVIDIA+Intel
- Measure actual FPS improvement with AFR/SFR on real games
- Validate DMA-BUF zero-copy across vendor boundaries
- Test PCIe P2P performance with same-root-complex setups

### Priority 2: Proton Module Testing (Required)

- Build against Proton source tree
- Test with DXVK-based Windows games
- Test with VKD3D-Proton-based DirectX 12 games
- Measure frame time improvement vs single-GPU baseline

### Priority 3: Packaging (Recommended)

- Add DEB builds to CI pipeline
- Add Arch Linux builds to CI pipeline
- Test COPR builds on all supported targets
- Validate DKMS installer on fresh systems

### Priority 4: Future Features (Deferred)

- Network GPU pooling (remote GPU aggregation)
- AI-driven scheduling with trained model
- Cloud GPU integration (AWS G5, GCP A2)
- Upstream kernel submission plan
- UCX/UCC integration for collective communication
- Qt dashboard for GPU monitoring

---

## Timeline

```
2026-Q1: M0 + M1 (Research + MVP)              ✅ COMPLETE
2026-Q2: M2 + M3 (Perf paths + Gaming)          ✅ COMPLETE
2026-Q3: M4 + M5 (Packaging + Hardening)        🔄 IN PROGRESS
2026-Q4: Hardware validation + Proton testing    📋 PLANNED
2027-Q1: Network GPU + AI scheduling             📋 FUTURE
2027-Q2: Cloud GPU integration                   📋 FUTURE
```

---

## Team

| Role | Responsibility |
|------|----------------|
| Core developer | Kernel module, daemon, IPC, scheduling |
| Packaging | RPM/DEB/Arch builds, COPR, CI |
| Testing | Hardware validation, game benchmarks |
| Documentation | Architecture, API, man pages |

---

## Risk Register

| Risk | Impact | Mitigation |
|------|--------|------------|
| Kernel API changes break module | High | Track kernel releases, test on 5.10+ |
| Anti-cheat flags LD_PRELOAD | Medium | Document workaround, provide kernel-mode path |
| Vendor driver changes break DMA-BUF | Medium | Test on latest driver versions quarterly |
| Upstream kernel rejection | Low | Module works out-of-tree; upstream is aspirational |
| COPR build failures | Low | Monitor CI, pin dependency versions |
