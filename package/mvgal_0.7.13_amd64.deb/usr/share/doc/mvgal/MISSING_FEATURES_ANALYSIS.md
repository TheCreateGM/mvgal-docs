# MVGAL Missing Features Analysis

**Version:** 1.0  
**Date:** 2026-06-02  

---

## 1. Missing Features by Category

### 1.1 Kernel Module Features (Require `MVGAL_FULL_STACK`)

| Feature | Current State | Gap Description | Priority |
|---------|---------------|-----------------|----------|
| `MVGAL_IOC_EXPORT_DMABUF` | Returns `-EOPNOTSUPP` | Needs `dma_buf_ops` integration with vendor drivers | High |
| `MVGAL_IOC_IMPORT_DMABUF` | Returns `-EOPNOTSUPP` | Needs DMA-BUF import path for cross-vendor sharing | High |
| `MVGAL_IOC_ALLOC_CROSS_VENDOR` | Returns `-EOPNOTSUPP` | Needs unified virtual address space management | High |
| `MVGAL_IOC_FREE_CROSS_VENDOR` | Returns `-EOPNOTSUPP` | Needs cross-vendor free tracking | High |
| DRM driver registration | `#if 0` disabled | Current code fails on kernel 7.x; class_create API changed | Medium |
| Vendor VRAM allocation | Fake addresses (`0x10000000`) | No real TTM/GEM/BO allocation calls | High |
| Vendor utilization query | Fake (50%) | No sysfs reading / real metrics | Medium |

---

### 1.2 Runtime Daemon Features

| Feature | Current State | Gap Description | Priority |
|---------|---------------|-----------------|----------|
| Real GPU submission | Stubbed | Workload marked COMPLETE immediately without actual submission | High |
| Fence tracking | Stubbed | No proper fence signaling from vendor drivers | High |
| AI model integration | Heuristic fallback | ONNX Runtime not linked; mock prediction | Medium |
| Work stealing | Not implemented | Queue depth checks missing; migration path absent | Medium |
| Remote GPU support | Partial | Network code exists but experimental | Low |

---

### 1.3 Vulkan Layer Features

| Feature | Current State | Gap Description | Priority |
|---------|---------------|-----------------|----------|
| VkPhysicalDeviceGroups for heterogeneous devices | Intercepts enumeration | Cannot create true heterogeneous group across vendors | High |
| Queue submission routing | Basic AFR injection | No real cross-vendor submit; limited to device groups | High |
| Shader compiler integration | Capture only | No SPIR-V → vendor ISA compilation | Medium |
| VkDeviceGroupSubmitInfo production | Synthetic | No hardware validation of group submission | Medium |

---

### 1.4 Memory Management Features

| Feature | Current State | Gap Description | Priority |
|---------|---------------|-----------------|----------|
| DMA-BUF hardware matrix | Research stubs | No validated cross-vendor import/export combinations | Critical |
| PCIe P2P detection | Heuristic (NUMA) | No actual `pci_p2pdma` capability probe | High |
| Unified VRAM migration | Stub | No real migration between GPUs | High |
| Buffer replication | Code exists | Needs hardware testing for coherence | Medium |

---

### 1.5 Compute Aggregation Features

| Feature | Current State | Gap Description | Priority |
|---------|---------------|-----------------|----------|
| CUDA cross-vendor | Single vendor only | Cannot shard across AMD/NVIDIA | High |
| OpenCL heterogeneous | LD_PRELOAD exists | Needs multi-platform ICD testing | Medium |
| HIP/ROCm integration | Not started | AMD compute API missing | Medium |
| SYCL/oneAPI integration | Stub (`src/userspace/sycl/`) | Intel compute API missing | Medium |
| PyTorch/TensorFlow distributed | Documented | No real multi-GPU execution validation | High |

---

## 2. Vendor-Specific Gaps

### 2.1 NVIDIA

| Gap | Description | Impact |
|-----|-------------|--------|
| NVLink support | Not implemented | Missed opportunity for high-bandwidth GPU-GPU transfer |
| NCCL integration | Missing | Cannot leverage NVIDIA's optimized collectives |
| MIG (Multi-Instance GPU) | Not handled | Cannot partition A100/H100 instances |
| NVML integration | `nvidia-smi` fallback | Less efficient than direct NVML |

### 2.2 AMD

| Gap | Description | Impact |
|-----|-------------|--------|
| ROCm/HIP integration | Missing | Cannot leverage AMD compute stack |
| Infinity Fabric P2P | Not detected | Missed high-bandwidth path on multi-GPU AMD |
| AMDVLK discontinuation | RADV only | Less choice for Vulkan ICD |

### 2.3 Intel

| Gap | Description | Impact |
|-----|-------------|--------|
| Level Zero integration | Missing | Misses Intel's modern compute API |
| oneAPI DPC++ | Not integrated | Cannot use Intel's cross-architecture toolkit |

### 2.4 Moore Threads (MTT)

| Gap | Description | Impact |
|-----|-------------|--------|
| Source provenance audit | Pending | Cannot claim production support |
| MUSA integration | Missing | Cannot use MTT's CUDA-like API |
| MTML integration | Missing | Cannot use MTT's ML framework |

---

## 3. Gaming Integration Gaps

| Feature | Current State | Gap | Priority |
|---------|---------------|-----|----------|
| Anti-cheat compatibility | Blocked | EAC/BattlEye block Vulkan layers | High |
| DXVK/VKD3D-Proton validation | Documented | No real game testing logs | Critical |
| Ray tracing split | Not implemented | RT shaders cannot cross vendors | Medium |
| Frame pacing with AFR | Implemented | Needs more real-game validation | Medium |

---

## 4. Power Management Gaps

| Feature | Current State | Gap | Priority |
|---------|---------------|-----|----------|
| Per-vendor DVFS | Sysfs writes stubbed | No real power limit control | Medium |
| PSU-aware power curve | Documented | No hardware power monitoring | Low |
| Thermal-aware scheduling | Implemented in daemon | Kernel power module stubbed | Medium |

---

## 5. Security Gaps

| Feature | Current State | Gap | Priority |
|---------|---------------|-----|----------|
| ioctl input validation | Basic | Needs fuzz testing | Medium |
| PolicyKit dry-run support | Missing | Cannot preview power changes | Low |

---

## 6. Documentation Gaps

| Document | Status | Gap |
|----------|--------|-----|
| `docs/CROSS_VENDOR_COMMAND_STREAM.md` | Exists | Needs update with implementation status |
| `docs/POWER_MANAGEMENT.md` | Referenced but may be outdated | Needs detailed hardware-specific guidance |
| Hardware validation logs | Partial | Need reproducible logs per vendor combination |
| Performance benchmarks | Reported | Need per-platform reproducible measurements |

---

## 7. CI/CD Gaps

| Feature | Current State | Gap | Priority |
|---------|---------------|-----|----------|
| Auto-trigger on push/PR | Manual-only | `.github/workflows/` missing CI.yml | High |
| Hardware-in-loop CI | Design only | No GPU farm integration | Low |
| KUnit kernel tests | Missing | No kernel test suite | Medium |
| `.clang-format` | Missing | Code style enforcement | Low |

---

## 8. Priority Matrix

### Critical (Must Fix for v1.0)

1. **DMA-BUF hardware validation matrix** - Without validated cross-vendor transfer paths, true aggregation impossible
2. **Real GPU workload submission** - Current stubbed submission makes benchmarking meaningless
3. **Vulkan heterogeneous device groups** - Core use case for gaming/professional apps
4. **Vendor source provenance audit (MTT)** - Cannot claim support without license verification

### High Priority (Next Release)

1. **PCIe P2P detection** - Needed for performance
2. **Unified VRAM migration** - Core memory feature
3. **CI automation** - Essential for maintainability
4. **Anti-cheat workaround** - Major adoption barrier for gaming

### Medium Priority

1. **NVLink support**
2. **Work stealing**
3. **Level Zero integration**
4. **ROCm/HIP integration**

### Low Priority (Future)

1. **Network GPU pooling**
2. **Virtual DRM node**
3. **PSU-aware power curves**
4. **Hardware-in-loop CI farm**