# MVGAL Design & Performance Modeling

> **Version**: 0.5.0  
> **Layer**: 5 — WDE (Workload Distribution Engine)  
> **Status**: Comprehensive  
> **Last Updated**: 2026-06-06

---

## Table of Contents

1. [Overview](#overview)
2. [Performance Model](#performance-model)
3. [Workload Characterization](#workload-characterization)
4. [Bottleneck Analysis Framework](#bottleneck-analysis-framework)
5. [Cost Functions for Scheduling](#cost-functions-for-scheduling)
6. [Scaling Models](#scaling-models)
7. [Inter-GPU Transfer Modeling](#inter-gpu-transfer-modeling)
8. [Power & Thermal Modeling](#power--thermal-modeling)
9. [Strategy Selection Model](#strategy-selection-model)
10. [Prediction Framework](#prediction-framework)
11. [Validation Methodology](#validation-methodology)

---

## Overview

MVGAL's design modeling framework provides the mathematical and analytical
foundation for all scheduling, allocation, and optimization decisions in the
Workload Distribution Engine (WDE, Layer 5). The framework unifies:

- **Performance modeling** — throughput, latency, and scaling equations
- **Workload characterization** — classifier signatures for GPU workloads
- **Bottleneck analysis** — automated detection of GPU/Memory/PCIe/thermal
  constraints
- **Cost functions** — numerical optimization targets for the scheduler
- **Scaling models** — Amdahl's, Gustafson's, and heterogeneous scaling laws
- **Transfer modeling** — inter-GPU bandwidth and latency prediction
- **Power/thermal modeling** — DVFS impact, thermal headroom prediction
- **Strategy selection** — model-driven strategy assignment per workload
- **Prediction framework** — AI-driven workload forecasting

The framework is implemented across `src/userspace/scheduler/` (WDE),
`runtime/daemon/metrics_collector.cpp` (telemetry), and `safe/capability_model`
(normalized GPU capability data).

---

## Performance Model

### Throughput Model

For a workload distributed across N GPUs, the aggregate throughput is:

```
T(N) = min(T_max, Σᵢ T_i × E_i(N))
```

Where:
- `T_i` = theoretical peak throughput of GPU i (FLOPS, pixels/s, texels/s)
- `E_i(N)` = parallel efficiency of GPU i with N devices ∈ [0, 1]
- `T_max` = ceiling imposed by the slowest serial dependency

### Latency Model

End-to-end frame latency for a partitioned workload:

```
L_total = max(L_submit, L_gpu_max, L_composite, L_present)

L_gpu_max = max_i(L_gpu_i + L_transfer_i)
L_transfer_i = Σⱼ (sizeⱼ / bandwidth_iⱼ) + overhead_iⱼ
```

Where:
- `L_gpu_i` = GPU i execution latency for its assigned work
- `L_transfer_i` = data transfer latency for GPU i
- `L_composite` = frame compositing latency
- `L_present` = presentation/display latency

### Utilization Model

Per-GPU utilization prediction:

```
U_i(t) = (Σⱼ workloadⱼ_i(t)) / (capacity_i × Δt)
```

The scheduler queries predicted utilization via the `mvgal_sched_predict()`
function (see `include/mvgal/scheduler.h`) before assigning new work.

### Key Constants

| Constant | Symbol | Typical Range | Source |
|----------|--------|---------------|--------|
| GPU compute efficiency | `E_gpu` | 0.60–0.95 | `capability_model` tier |
| PCIe transfer efficiency | `E_pcie` | 0.85–0.98 | Gen/lane detection |
| AFR scaling efficiency | `E_afr` | 0.70–0.95 | Historical metrics |
| SFR scaling efficiency | `E_sfr` | 0.50–0.85 | Historical metrics |
| RLD compose overhead | `O_rld` | 0.02–0.05 | Measured via bench |
| PPL stage imbalance | `I_ppl` | 0.10–0.40 | DAG analysis |

---

## Workload Characterization

### Workload Signature

Every submitted workload is characterized by a 7-dimensional signature vector:

```
S = [compute, memory, bandwidth, sync, duration, locality, api_class]
```

| Dimension | Range | Description |
|-----------|-------|-------------|
| `compute` | 0.0–1.0 | Compute intensity (FLOPS / byte) |
| `memory` | 0.0–1.0 | Memory access density |
| `bandwidth` | 0.0–1.0 | Bandwidth pressure (bytes / sec) |
| `sync` | 0.0–1.0 | Synchronization frequency |
| `duration` | μs–ms | Expected execution duration |
| `locality` | 0.0–1.0 | Data locality (0 = scattered, 1 = local) |
| `api_class` | enum | Vulkan, OpenCL, CUDA, D3D, etc. |

### Workload Taxonomy

The classifier assigns workloads to one of 8 categories:

| Category | Signature Pattern | Typical Examples |
|----------|------------------|------------------|
| **Graphics (compute-bound)** | high compute, low memory | Deferred shading, tessellation |
| **Graphics (memory-bound)** | high memory, low compute | Texture-heavy scenes, MSAA |
| **Compute (arithmetic)** | high compute, low BW | ML training kernels, physics sims |
| **Compute (memory-bound)** | low compute, high BW | Data sorting, reduction ops |
| **Media encode/decode** | fixed-function, streaming | NVENC, VCE, VA-API transcode |
| **Synchronization-heavy** | high sync, short duration | Immediate-mode UI, swap chains |
| **Transfer-bound** | high bandwidth, low compute | Cross-GPU migration, uploads |
| **Mixed** | balanced across dims | General-purpose apps |

Classification is performed by `mvgal_sched_classify()` in
`src/userspace/scheduler/workload_classifier.c`.

### Migration Cost Model

The cost of migrating a workload from GPU A to GPU B is:

```
C_migrate(A, B, size) = C_dma(A, B, size) + C_sync(A, B) + C_invalidate
```

Where:
- `C_dma(A, B, size)` = `size / min(bandwidth_AB, bandwidth_BA)`
- `C_sync(A, B)` = fence round-trip latency between A and B
- `C_invalidate` = cache/TLB invalidation overhead on the source GPU

---

## Bottleneck Analysis Framework

### Bottleneck Detection

The `metrics_collector` (Layer 3) feeds real-time counters into a bottleneck
classifier that identifies the limiting resource:

```
Bottleneck = argmax over resources of (usage_i / capacity_i)
```

### Bottleneck Categories

| Category | Indicator | Threshold | Remediation |
|----------|-----------|-----------|-------------|
| GPU compute | ALU utilization > 90% | > 90% | Offload to peer GPU via RLD/PPL |
| VRAM capacity | Allocated / total > 90% | > 90% | Migrate cold data to Heap 3/4 |
| VRAM bandwidth | BW utilization > 85% | > 85% | Replicate read-only textures (Heap 1) |
| PCIe upstream | Tx+Rx > 80% of link BW | > 80% | Reduce cross-GPU traffic, enable P2P |
| Thermal | Temperature > 85 C | > 85 C | Throttle via power_manager, DVFS down |
| Power | Draw > 90% TDP | > 90% | Redistribute to cooler GPUs |
| Sync contention | Wait time > 15% submit | > 15% | BATCH workloads, reduce fence count |

### Bottleneck Score

A dimensionless score for comparing across resources:

```
B_score(r) = (usage_r / capacity_r) × weight_r(workload)
```

The scheduler queries `mvgald` at `GET_STATISTICS` interval to obtain current
bottleneck state.

---

## Cost Functions for Scheduling

### General Cost Model

Each scheduling decision minimizes a weighted cost function:

```
C_total = w_perf × C_perf + w_power × C_power + w_fair × C_fair + w_stable × C_stable
```

Where:
- `C_perf` = 1 / predicted throughput (normalized)
- `C_power` = projected power draw / TDP
- `C_fair` = fairness penalty (variance of GPU utilization)
- `C_stable` = strategy switching penalty (hysteresis)

Default weights: `w_perf = 0.5`, `w_power = 0.2`, `w_fair = 0.2`,
`w_stable = 0.1`. Weights are configurable per application via
`/etc/mvgal/app-policies/<app>.json`.

### Strategy-Specific Cost Functions

**AFR Cost:**
```
C_afr = Σ_frames |L_frame_i - target_vsync| + migration_cost
```
Minimizes frame time variance vs vsync interval. Migration_cost includes
cross-GPU buffer transfers between even/odd frames.

**RLD Cost:**
```
C_rld = Σ_layers (L_layer_i + C_composite + C_transfer_i)
```
Minimizes total composite latency across separated render layers.

**PPL Cost:**
```
C_ppl = max_stage_latency × (1 + I_ppl)
```
Minimizes the longest pipeline stage. `I_ppl` is the stage imbalance penalty.

**REP Cost:**
```
C_rep = max(T_gpu_i) + N × C_reduce
```
Where `C_reduce` is the reduction/verification overhead for replicated work.

### Fairness Metric

```
F = 1 - (σ_U / μ_U)
```

Where `σ_U` is the standard deviation and `μ_U` is the mean of per-GPU
utilization. F = 1.0 indicates perfect balance; F → 0 indicates severe skew.

---

## Scaling Models

### Amdahl's Law (Latency-Oriented)

For fixed-size problems distributed across heterogeneous GPUs:

```
S(N) = 1 / ((1 - P) + P / S_avg(N))
```

Where:
- `P` = parallelizable fraction of the workload
- `S_avg(N)` = average speedup per GPU (normalized to baseline)
- Heterogeneous GPUs with different `S_i` use a harmonic mean:

```
S_avg(N) = N / Σ_i (1 / S_i)
```

### Gustafson's Law (Throughput-Oriented)

For scaled problems where work grows with available resources:

```
S(N) = (1 - P) + P × N × E_avg
```

Where `E_avg` is the average parallel efficiency across the heterogeneous pool.

### Heterogeneous Scaling Model

MVGAL extends Amdahl's/Gustafson's for heterogeneous GPU pools by modelling
each GPU's contribution weighted by capability:

```
S_het(N) = (1 - P) + Σ_i (P_i × S_i)

where Σ_i P_i = P (total parallel fraction partitioned across N GPUs)
and S_i = capability_i / capability_baseline
```

Capability tiers (`Full`, `ComputeOnly`, `Mixed`) from the capability_model
crate influence `S_i` — a compute-only GPU may have `S_graphics = 0` but
`S_compute = 1.2`.

### Predicted Scaling Table

| Workload Type | 2 GPUs | 4 GPUs | 8 GPUs | Limiting Factor |
|--------------|--------|--------|--------|-----------------|
| Graphics (AFR) | 1.6–1.9× | 2.4–3.2× | 3.0–4.5× | Sync overhead |
| Graphics (SFR) | 1.4–1.7× | 2.0–2.8× | 2.5–3.5× | Tile boundary cost |
| Compute (RR) | 1.8–1.95× | 3.2–3.8× | 5.5–7.0× | Transfer overhead |
| ML Training (REP) | 1.6–1.9× | 2.8–3.5× | 4.5–6.0× | Gradient sync |
| Video (PPL) | 1.3–1.6× | 1.8–2.5× | 2.0–3.0× | Stage imbalance |
| Mixed (HYB) | 1.5–1.8× | 2.2–3.0× | 3.0–4.0× | Strategy switching |

Scaling predictions are reported by `mvgal-sched analyze` (see `tools/`).

---

## Inter-GPU Transfer Modeling

### Bandwidth Model

Effective bandwidth between GPU i and GPU j:

```
BW_eff(i, j) = min(BW_device_i, BW_link_ij, BW_device_j)

BW_link_ij = BW_pcie × gen_factor × lane_factor × utilization_factor
```

| Link Type | Gen Factor | Lane Factor | Peak BW |
|-----------|-----------|-------------|---------|
| PCIe 3.0 x16 | 1.0 | 1.0 | 15.75 GB/s |
| PCIe 4.0 x16 | 2.0 | 1.0 | 31.5 GB/s |
| PCIe 5.0 x16 | 3.9 | 1.0 | 63.0 GB/s |
| NVLink 2.0 (NVIDIA) | — | — | 150 GB/s (bidir) |
| XGMI (AMD) | — | — | 84 GB/s (bidir) |

### Transfer Latency Decomposition

```
L_xfer(i, j, size) = L_init + size / BW_eff(i, j) + L_fence_roundtrip
```

Where `L_init` includes DMA descriptor setup (≈ 1–5 µs) and P2P mapping.

### Transfer Path Selection

```
if DMA-BUF(i, j) supported → path = DMA-BUF (zero-copy)
elif P2P DMA supported → path = P2P (requires same RC)
else → path = host staging (CPU bounce buffer)
```

This logic is implemented in `src/userspace/memory/p2p.c`.

---

## Power & Thermal Modeling

### Power Model

Per-GPU power draw as function of utilization and frequency:

```
P_i(t) = P_idle_i + (P_max_i - P_idle_i) × U_i(t) × (f_i / f_max_i)^2 × V_i(f)^2
```

Where:
- `P_idle_i`, `P_max_i` = idle and max power draw (from vendor ops)
- `U_i(t)` = GPU utilization at time t
- `f_i` = current clock frequency, `f_max_i` = maximum frequency
- `V_i(f)` = voltage at frequency f

### Thermal Model

Temperature prediction using a lumped capacitance model:

```
T_i(t+Δt) = T_i(t) + (P_i(t) - (T_i(t) - T_ambient) / R_thermal) × Δt / C_thermal
```

Where `R_thermal` and `C_thermal` are per-GPU thermal resistance and
capacitance (calibrated per vendor/architecture).

### DVFS Impact on Performance

```
S_dvfs(f) = (f / f_max) × (V(f) / V(f_max))^0.5
```

Power-performance trade-off at frequency f:

```
Efficiency(f) = S_dvfs(f) / P_avg(f)
```

The power_manager selects the frequency that maximizes efficiency for the
current workload, subject to thermal constraints.

### Thermal Throttle Prediction

The framework predicts time to thermal throttle:

```
t_throttle(T_i, P_i) = C_thermal × (T_throttle - T_i) / (P_i - P_ambient)
```

If `t_throttle < `mvgald`'s `idleTimeoutMs`, the scheduler pre-emptively
migrates work to a cooler GPU.

---

## Strategy Selection Model

### Selection Decision Tree

```
                                          Workload Submission
                                                  │
                                          Workload Classification
                                           (7-dim signature)
                                                  │
                                    ┌─────────────┴─────────────┐
                                    │                           │
                              Compute-heavy               Graphics-heavy
                                    │                           │
                        ┌───────────┴───────────┐     ┌─────────┴─────────┐
                        │                       │     │                   │
                   Data-parallel          Pipeline             │      Complex scene
                        │                       │            │           │
                       REP                    PPL            │           │
                                                   ┌──────────┘           │
                                                   │                ┌─────┴─────┐
                                                   │                │           │
                                              Fast-paced          Separable passes
                                                   │                │           │
                                                   │               RLD        SFR
                                                   │
                                                   AFR
```

### Model Confidence

Each assignment includes a confidence score C ∈ [0, 1]:

```
C = match_quality × historical_success × model_maturity
```

- `match_quality` = cosine similarity of workload signature to training cluster
- `historical_success` = fraction of past assignments with same strategy that
  met performance targets
- `model_maturity` = number of observed samples / minimum required samples

When `C < 0.6`, the scheduler falls back to `HYB(RR+LL)` and collects more
training data.

### Strategy Switching Cost

Switching from strategy A to B incurs:

```
C_switch(A, B) = C_drain(A) + C_warmup(B)
```

- `C_drain(A)` = time to complete in-flight work under strategy A
- `C_warmup(B)` = time for strategy B to reach steady state

The scheduler will not switch if `C_switch > expected_benefit × 2`.

---

## Prediction Framework

### AI-Driven Workload Prediction

MVGAL's scheduler includes a lightweight ML predictor (implemented as a
priority queue with learned weights in `src/userspace/scheduler/`).

**Input features:**
- Historical per-GPU utilization (last 60 samples)
- Current queue depth per GPU
- In-flight frame counts per strategy
- Workload signature of pending submissions

**Output:**
- Predicted utilization in 100 ms window for each GPU
- Recommended strategy assignment with confidence

**Training:** The predictor self-trains online using observed outcomes vs
predictions. No offline training dataset is required.

### Historical Metrics Database

The metrics_collector maintains a circular buffer of performance data:

| Metric | Granularity | Retention | Storage |
|--------|-------------|-----------|---------|
| Per-frame timestamps | per frame | 1000 frames | `mvgald` memory |
| Per-GPU utilization | 1 s | 3600 samples | `mvgald` memory |
| Strategy outcomes | per strategy switch | 100 entries | `mvgald` memory |
| Bottleneck records | per detection | 500 entries | `mvgald` memory |

---

## Validation Methodology

### Model Validation Framework

Each model is validated against real hardware measurements:

1. **Synthetic benchmarks** — `mvgal-bench all` produces known workloads
2. **Application traces** — captured via `MVGAL_VULKAN_DEBUG=1` and Steam
   frame pacer logs
3. **Cross-validation** — predict metrics, execute workload, compare

### Validation Metrics

| Model | Validation Target | Tolerance | Measurement Tool |
|-------|------------------|-----------|-----------------|
| Throughput | Predicted vs actual FPS | ±15% | `mvgal-bench compute` |
| Latency | Predicted vs actual frame time | ±10% | Frame pacer logs |
| Power draw | Predicted vs actual power | ±20% | hwmon / NVML |
| Temperature | Predicted vs actual temp | ±5 C | hwmon sensors |
| Transfer BW | Predicted vs actual throughput | ±15% | `mvgal-bench memory` |
| Scaling | Predicted vs actual speedup | ±20% | Multi-GPU benchmark suite |

### Continuous Calibration

Model parameters are recalibrated at `mvgald` startup from the most recent
100 workload observations. Calibration data is persisted in
`/var/lib/mvgal/model_cache.json`.

---

## References

- **Scheduling Strategies**: `docs/STRATEGIES.md` — detailed strategy descriptions
- **Architecture**: `docs/ARCHITECTURE.md` §5 — WDE layer specification
- **Memory Heaps**: `docs/ARCHITECTURE.md` §5 — Memory Heap Hierarchy
- **Power Management**: `docs/POWER_MANAGEMENT.md` — DVFS and thermal states
- **Troubleshooting**: `docs/TROUBLESHOOTING.md` — bottleneck diagnostics
- **API Reference**: `docs/API_REFERENCE.md` — IPC and function interfaces
- **Source**: `src/userspace/scheduler/` — WDE implementation
- **Source**: `runtime/daemon/metrics_collector.cpp` — telemetry collection
- **Hardware Compatibility**: `docs/HARDWARE_COMPATIBILITY.md` — per-vendor BW tables
