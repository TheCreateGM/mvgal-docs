# MVGAL DMA-BUF / P2P Matrix

**Generated:** 2026-06-01 11:43:03 UTC  
**GPUs:** 3  
**Updated:** 2026-06-02 - Added validation procedure

## Detected devices

| Index | Vendor | Device | Name | PCI |
|-------|--------|--------|------|-----|
| 0 | NVIDIA | 0x2584 | NVIDIA GPU 2584 (8 GiB) | 0000:04:00.0 |
| 1 | MTT | 0x0102 | Moore Threads GPU 0102 (16 GiB) | 0000:05:00.0 |
| 2 | AMD | 0x743f | AMD GPU 743F (3 GiB) | 0000:03:00.0 |

## Pairwise transfer path (advisory)

| Src \ Dst | 0 | 1 | 2 |
|-----------|------|------|------|
| **0** | — | Host staging (portable) | Host staging (portable) |
| **1** | Host staging (portable) | — | PCIe P2P (same root complex) |
| **2** | Host staging (portable) | PCIe P2P (same root complex) | — |

## Transfer Path Selection Algorithm

MVGAL selects the optimal transfer path for each GPU pair:

```
mvgal_select_transfer_path(src_gpu, dst_gpu):
    1. If src_gpu == dst_gpu:
        - Return LOCAL_VRAM (no transfer needed)
    
    2. If same NUMA node AND both support DMA-BUF:
        - Try DMA-BUF export/import
        - If succeeds: Return DMA_BUF_ZERO_COPY
    
    3. If same PCIe root complex AND P2P supported:
        - Try PCIe P2P transfer
        - If succeeds: Return PCIE_P2P
    
    4. Default:
        - Return HOST_RAM_STAGING
```

## Hardware-Specific Requirements

### NVIDIA (nvidia-open / proprietary)
- Open modules (525+): Full DMA-BUF support via `NV_DRM_IOCTL_GEM_EXPORT_DMABUF_FD`
- Proprietary driver: Requires `nvidia-drm.modeset=1` kernel parameter
- VRAM metrics: Use `nvidia-smi` or NVML library

### AMD (amdgpu)
- Full DMA-BUF support via `DRM_IOCTL_PRIME_HANDLE_TO_FD`
- VRAM query: `/sys/class/drm/cardN/device/mem_info_vram_total/used`
- Utilization: `/sys/class/drm/cardN/device/gpu_busy_percent`

### Intel (i915 / xe)
- DMA-BUF via `drm_gem_prime_export()`
- Metrics: `/sys/class/drm/cardN/gt*/rps_cur_freq_mhz`
- Power: `power/level`, `power_status`

### Moore Threads (mtgpu-drv)
- Verify GEM export support in driver
- DMA-BUF export via `DRM_IOCTL_PRIME_HANDLE_TO_FD` if supported
- Requires driver audit for production claims

## Validation Procedure

### Prerequisites
- Linux kernel 5.6+ (for DMA-BUF)
- Kernel 5.10+ (for PCIe P2P)
- Appropriate vendor drivers installed

### Test Commands
```bash
# Run the validation tool
mvgal-dmabuf-matrix --test --output=hardware_matrix.txt

# Check PCIe topology
lspci -tv

# Verify Vulkan layer
MVGAL_VULKAN_ENABLE=1 vulkaninfo --summary | grep -i mvgal

# Run DMA-BUF tests
ctest -R test_dmabuf_integration
```

## Userspace DMA-BUF self-test

Run: `ctest -R test_dmabuf_integration` or `./test_dmabuf_integration` after build.

## Notes

- Labels are **capability hints**; real dma-buf import/export must be validated per driver pair.
- Regenerate after driver or topology changes: `mvgal-dmabuf-matrix -o docs/HARDWARE_DMABUF_MATRIX.md`
- Cross-vendor DMA-BUF requires both endpoints to support the operation.
- PCIe P2P requires same root complex AND vendor P2P support.