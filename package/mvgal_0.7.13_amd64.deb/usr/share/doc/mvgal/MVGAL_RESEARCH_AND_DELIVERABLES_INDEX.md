# MVGAL — Research Phase Completion & Deliverables Index

**Version:** 1.0  
**Date:** 2026-06-01  
**Status:** Mandatory research phase complete — implementation continues under milestone gates

This document is the **single entry point** for the full MVGAL specification effort. It consolidates codebase analysis, upstream driver research, technology surveys, architecture diagrams, gap analysis, and maps all **20 required deliverables** to repository artifacts.

---

## 1. Research Phase Checklist

| Step | Status | Primary reference |
|------|--------|-------------------|
| Read README and project docs | ✅ | [README.md](../README.md), [docs/](.) |
| Read source (kernel, runtime, userspace, tools) | ✅ | [docs/CODEBASE_ANALYSIS.md](CODEBASE_ANALYSIS.md), [docs/RESEARCH_PHASE3.md](RESEARCH_PHASE3.md) |
| Analyze architecture | ✅ | [docs/ARCHITECTURE.md](ARCHITECTURE.md), [docs/ENGINEERING_DESIGN.md](ENGINEERING_DESIGN.md) |
| Dependency map | ✅ | §3 below |
| Subsystem diagrams | ✅ | §4 below |
| Workflow diagrams | ✅ | §5 below |
| Kernel–user communication | ✅ | §6 below |
| Vendor driver research | ✅ | §7, [docs/UPSTREAM_DRIVER_RESEARCH_2026-05-30.md](UPSTREAM_DRIVER_RESEARCH_2026-05-30.md) |
| Existing technologies survey | ✅ | §8, [docs/RESEARCH_PHASE3.md](RESEARCH_PHASE3.md), [docs/research/](research/) |
| Gap analysis | ✅ | §9, [docs/FEASIBILITY_AND_GAPS_2026-05-30.md](FEASIBILITY_AND_GAPS_2026-05-30.md), [docs/MISSING.md](MISSING.md) |
| Document findings | ✅ | This file + linked specs |

**Executive conclusion:** MVGAL is correctly positioned as an **above-driver coordination layer**. Transparent “one GPU” semantics are achievable only per API and per workload class, with capability probes and single-GPU fallback. Kernel code must not submit native vendor command buffers cross-vendor.

---

## 2. System Architecture (Target Design)

MVGAL decomposes into the layers below. Names match the specification; implementation paths are in parentheses.

| Layer | Responsibility | Implementation |
|-------|----------------|----------------|
| **MVGAL API interception** | Vulkan layer/ICD, OpenCL ICD, CUDA shim, OpenGL preload, D3D (Wine) | `src/userspace/intercept/`, `opengl/`, `compat/` |
| **MVGAL execution engine** | Frame sessions, migration plans, Steam profiles | `src/userspace/execution/` |
| **MVGAL runtime** | Daemon, IPC, policy | `runtime/daemon/`, `src/userspace/daemon/` |
| **MVGAL scheduler** | 7 strategies, load balancing, AI hook | `src/userspace/scheduler/`, `runtime/daemon/scheduler.cpp` |
| **MVGAL memory manager** | DMA-BUF, P2P matrix, UVA, staging | `src/userspace/memory/`, `runtime/daemon/memory_manager.cpp`, `kernel/mvgal_memory.c` |
| **MVGAL synchronization** | Fences, timelines, barriers | `kernel/mvgal_sync.c`, `safe/fence_manager/`, `src/userspace/memory/sync.c` |
| **MVGAL device discovery** | PCI, DRM, NUMA, topology | `kernel/mvgal_main.c`, `runtime/daemon/device_registry.cpp`, `gpu_manager.c` |
| **MVGAL driver abstraction (DAL)** | `mvgal_vendor_ops`, capability model | `kernel/vendors/`, `safe/capability_model/` |
| **MVGAL power management** | Parking, DVFS, thermal, PSU | `runtime/daemon/power_manager.cpp`, `kernel/mvgal_power.c` |
| **MVGAL IPC** | Unix socket, D-Bus | `runtime/daemon/ipc_server.cpp`, `src/userspace/daemon/ipc.c` |
| **MVGAL security** | Polkit, pkexec, SCM_CREDENTIALS | `config/org.freedesktop.policykit.mvgal.policy`, [docs/SECURITY_REVIEW.md](SECURITY_REVIEW.md) |
| **MVGAL monitoring** | Metrics, dashboard, Prometheus | `runtime/daemon/metrics_collector.cpp`, `ui/`, `tools/mvgal_exporter.go` |
| **MVGAL kernel layer** | UAPI, topology, coordination | `kernel/mvgal.ko` → `/dev/mvgal0` |
| **Container / virtualization** | Design + future hooks | [docs/NETWORK_GPU_POOLING.md](NETWORK_GPU_POOLING.md) (distributed pool) |

---

## 3. Dependency Map

Build-time and runtime dependencies (simplified). Solid arrows = hard dependency; dashed = optional / capability-probed.

```mermaid
flowchart TB
  subgraph apps [Applications]
    Games[Games / Proton]
    Compute[PyTorch / OpenCL / CUDA apps]
    VulkanApps[Vulkan apps]
  end

  subgraph intercept [Layer 5 - API Interception]
    VKL[VK_LAYER_MVGAL]
    VKICD[mvgal_vulkan_icd]
    OCL[libmvgal_opencl]
    CUDA[libmvgal_cuda]
    GL[libmvgal_gl]
    D3D[d3d_wrapper via DXVK/VKD3D]
  end

  subgraph exec [Layer 4 - Execution Engine]
    EXE[execution.c / frame sessions]
    STEAM[steam/ frame pacer]
  end

  subgraph runtime [Layer 3 - Runtime]
    D[mvgald]
    SCH[Scheduler]
    MM[MemoryMgr]
    PWR[PowerMgr]
    IPC[IPC server]
    MET[Metrics]
  end

  subgraph safe [Layer 2 - Rust]
    FENCE[fence_manager]
    MEMSAFE[memory_safety]
    CAP[capability_model]
  end

  subgraph kernel [Layer 1 - Kernel]
    KO[mvgal.ko /dev/mvgal0]
  end

  subgraph vendor [Vendor stacks - unchanged]
    AMD[amdgpu + RADV/AMDVLK]
    NV[nvidia + proprietary UMD]
    INTL[i915/xe + ANV]
    MTT[mtgpu / stub]
  end

  Games --> D3D --> VKL
  VulkanApps --> VKL
  VulkanApps -.-> VKICD
  Compute --> OCL
  Compute --> CUDA

  VKL --> EXE
  VKICD --> EXE
  OCL --> D
  CUDA --> D
  GL --> EXE

  EXE --> IPC
  VKL --> IPC
  D --> SCH & MM & PWR & MET
  D --> FENCE & MEMSAFE & CAP
  D --> KO
  SCH --> AMD & NV & INTL & MTT
  MM --> AMD & NV & INTL & MTT
  STEAM --> EXE
```

**External build dependencies:** CMake 3.16+, libdrm, pciaccess, Vulkan headers, optional OpenCL/Rust/Go/Qt (see root `CMakeLists.txt`).

---

## 4. Subsystem Diagram

```mermaid
flowchart LR
  subgraph discovery [Device Discovery]
    PCI[PCI scan]
    DRM[DRM nodes]
    NUMA[NUMA node]
    TOPO[P2P / PCIe gen]
  end

  subgraph dal [Driver Abstraction Layer]
    VOPS[mvgal_vendor_ops]
    CAPS[capability_model]
  end

  subgraph sched [Scheduler]
    RR[round_robin]
    AFR[afr]
    SFR[sfr]
    TASK[task]
    CO[compute_offload]
    HY[hybrid]
    SG[single]
  end

  subgraph mem [Memory Manager]
    DBUF[DMA-BUF]
    P2P[PCIe P2P]
    STG[host staging]
    UVA[unified heap]
  end

  discovery --> dal
  dal --> sched
  dal --> mem
  sched --> mem
```

---

## 5. Workflow Diagrams

### 5.1 Initialization

```mermaid
sequenceDiagram
  participant User
  participant systemd
  participant mvgald
  participant KO as mvgal.ko
  participant DRM as vendor DRM

  User->>systemd: pkexec systemctl start mvgald
  systemd->>mvgald: start
  mvgald->>KO: open /dev/mvgal0, QUERY_VERSION, GET_GPU_COUNT
  KO->>KO: PCI display-class rescan
  mvgald->>DRM: sysfs /sys/class/drm/cardN
  mvgald->>mvgald: DeviceRegistry + capability tier
  mvgald->>mvgald: bind /run/mvgal/mvgal.sock
```

### 5.2 Gaming (AFR via Vulkan layer)

```mermaid
sequenceDiagram
  participant Game
  participant DXVK
  participant Layer as VK_LAYER_MVGAL
  participant ICD as vendor ICD
  participant Daemon as mvgald

  Game->>DXVK: D3D11 present path
  DXVK->>Layer: vkQueueSubmit
  Layer->>Daemon: IPC telemetry / strategy
  Daemon-->>Layer: GPU index for frame N
  Layer->>ICD: forward submit to selected GPU
  Note over Layer,ICD: Unsafe paths fall back to single GPU
```

### 5.3 Compute offload (explicit multi-device)

```mermaid
sequenceDiagram
  participant App
  participant Shim as CUDA/OpenCL shim
  participant Sched as scheduler
  participant G0 as GPU A
  participant G1 as GPU B

  App->>Shim: launch kernel / NDRange
  Shim->>Sched: partition by policy
  Sched->>G0: chunk 0
  Sched->>G1: chunk 1
  G0-->>Shim: fence
  G1-->>Shim: fence
  Shim->>App: completion
  Note over Shim: Requires compatible APIs + verified execution
```

---

## 6. Kernel–User Communication

```mermaid
flowchart TB
  subgraph userspace [Userspace]
    Tools[mvgal-info / probe]
    Lib[libmvgal / intercept layers]
    Daemon[mvgald]
  end

  subgraph interfaces [Interfaces]
    DEV["/dev/mvgal0 ioctl"]
    SYS["/sys/class/mvgal/mvgal0/"]
    SOCK["/run/mvgal/mvgal.sock"]
    DBUS[D-Bus optional]
  end

  subgraph kernel [Kernel mvgal.ko]
    UAPI[UAPI handlers]
    TOPO[topology + caps]
    MEMK[DMA-BUF coord stubs]
    SYNK[fence stubs]
  end

  Tools --> DEV
  Tools --> SYS
  Daemon --> DEV
  Daemon --> SYS
  Lib --> SOCK
  Lib --> DEV
  Daemon --> SOCK
  Daemon --> DBUS

  DEV --> UAPI
  SYS --> TOPO
  UAPI --> TOPO & MEMK & SYNK
```

**UAPI reference:** [docs/KERNEL_INTERFACE_SPEC.md](KERNEL_INTERFACE_SPEC.md), `include/mvgal/mvgal_uapi.h`.

**Design rule:** MVGAL does **not** `pci_register_driver` on GPUs; it observes PCI and coordinates via public surfaces only.

---

## 7. Vendor Driver Comparison

Repositories studied (see [docs/UPSTREAM_DRIVER_RESEARCH_2026-05-30.md](UPSTREAM_DRIVER_RESEARCH_2026-05-30.md), [docs/REFERENCE_RESEARCH.md](REFERENCE_RESEARCH.md)):

| Dimension | NVIDIA (open-gpu-kernel-modules) | AMD (AMDVLK + amdgpu) | Intel (media-driver + i915/xe) | Moore Threads (mtgpu-drv) |
|-----------|----------------------------------|------------------------|--------------------------------|---------------------------|
| **Primary artifact** | `nvidia.ko`, `nvidia-drm`, UVM | `amdgpu.ko`; AMDVLK = user ICD (discontinued OSS project) | `i915`/`xe` DRM; media-driver = VA-API only | `mtgpu.ko` (community/OSS variants) |
| **Device init** | PCI driver + DRM register + GSP firmware | amdgpu probe; AMDVLK consumes DRM | i915/xe probe; media-driver via LibVA | PCI + DRM GEM |
| **Command submission** | Proprietary UMD + ioctl path | AMDGPU CS rings; PAL in AMDVLK | Exec buffers via DRM | Vendor CS via DRM |
| **Memory / VRAM** | Proprietary MM; dma-buf in open stack | TTM/GEM, HMM, strong PRIME | GEM/TTM; Arc uses discrete path | GEM-based |
| **Scheduler** | Internal to UMD/KMD | amdgpu scheduler entities | i915/xe schedulers | Driver-internal |
| **DMA** | P2P + NVLink where supported | PCIe P2P, dma-buf export | dma-buf; P2P topology-limited | Often staging-only |
| **Sync** | Syncpoints, sync_file, Vulkan fences | dma-fences, timeline semaphores | Standard DRM fences | Partial vs Mesa stack |
| **Power** | sysfs, NVML (userspace) | sysfs, amdgpu DPM | sysfs, intel_gpu_freq | Basic sysfs |
| **Firmware** | GSP required (Turing+) | GPU firmware via amdgpu | GuC/HuC on newer parts | Vendor blobs |
| **Userspace API** | CUDA, Vulkan, OpenCL | Vulkan (RADV/AMDVLK), ROCm, OpenCL | Vulkan ANV, Level Zero, SYCL, VA-API | MUSA, Vulkan, OpenCL (varies) |
| **Kernel API for MVGAL** | DRM render node, dma-buf, PCI | Same | Same | Same (capability-probed) |
| **MVGAL must avoid** | Resubmitting NVIDIA IBs from `mvgal.ko` | PAL/LLPC private ABI | Treating media-driver as full 3D stack | Production claims without license audit |

**Common portable layers:** PCI enumeration, `/sys/class/drm`, render nodes, `dma-buf`/PRIME, `sync_file`, Vulkan external memory/fence FD extensions, Polkit-gated privileged ops.

**Hard incompatibilities:** No cross-vendor coherent VRAM; no universal command-stream format; device groups are implementation-defined and usually same-vendor; anti-cheat may block Vulkan layers.

**Abstraction design:** `struct mvgal_vendor_ops` + Rust `capability_model` + per-API intercept (not one kernel command virtualizer). See [docs/DRIVER_ARCHITECTURE_DESIGN.md](DRIVER_ARCHITECTURE_DESIGN.md).

Feature matrix for aggregation paths: [docs/CAPABILITY_MATRIX.md](CAPABILITY_MATRIX.md).

---

## 8. Existing Technologies — Reusable Concepts

| Technology | Solves | MVGAL reuse |
|------------|--------|-------------|
| **Vulkan device groups + external memory** | Explicit multi-GPU, fd-backed sharing | ICD + layer model; [research/03-vulkan-multi-gpu-explicit-api.md](research/03-vulkan-multi-gpu-explicit-api.md) |
| **dma-buf / PRIME** | Cross-driver buffer sharing | Primary zero-copy path |
| **NCCL / RCCL** | Collective ops, topology-aware P2P | P2P matrix + `compute_offload` strategy |
| **MPI / OpenMP / SYCL** | Partitioned compute | Explicit multi-device compute class |
| **SLI / CrossFire (legacy)** | AFR/SFR heuristics | Strategies only — not driver-profile model |
| **DXVK / VKD3D-Proton** | D3D → Vulkan | Inherit Vulkan aggregation path |
| **Esync / Fsync / NTSYNC** | Wine synchronization | `compat/ntsync/`, Proton env integration |
| **Mesa / Gallium / Zink** | GL → VK | OpenGL shim + Zink path |
| **StarPU / Legion** | Heterogeneous task scheduling | Scheduler + migration design references |
| **PyTorch Distributed / vLLM** | Framework-level sharding | AI layer = explicit backends, not transparent CUDA |

Survey detail: [docs/research/01-multi-gpu-framework-survey.md](research/01-multi-gpu-framework-survey.md), [docs/RESEARCH_PHASE3.md](RESEARCH_PHASE3.md) §3.1.

---

## 9. Gap Analysis (Honest)

| Area | Current state | Production gate |
|------|---------------|-----------------|
| Kernel cross-vendor submit | Stubs / `-EOPNOTSUPP` in skeleton builds | Never required for v1; userspace submit only |
| DMA-BUF matrix | Code + unit tests; hardware matrix incomplete | Per-pair validation AMD×NVIDIA×Intel×MTT |
| Vulkan heterogeneous logical device | Synthetic groups + ICD scaffold | Conformance + fallback tests on real titles |
| SPIR-V → vendor ISA | Routing stubs | NVRTC, AMDGPU LLVM, IGC, MUSA backends |
| Transparent unmodified apps | Marketing risk | Label per workload; default pass-through |
| MTT production | Cloneable source ([MTT_SOURCE_AUDIT.md](MTT_SOURCE_AUDIT.md)); stub on test box | License audit + full driver on hardware |
| Network GPU pool | Documented only | 2027+ milestone |
| AI scheduler | Heuristic + ONNX hook | ONNX Runtime integration |
| Hardware CI | Manual `workflow_dispatch` | Multi-vendor farm |

Full lists: [docs/MISSING.md](MISSING.md), [docs/FEASIBILITY_AND_GAPS_2026-05-30.md](FEASIBILITY_AND_GAPS_2026-05-30.md), milestone table in [docs/STATUS.md](STATUS.md).

---

## 10. Language, Compiler, and Build Choices

| Choice | Decision | Rationale |
|--------|----------|-----------|
| **C** | Kernel module, userspace core, interceptors | Linux KAPI, stable FFI |
| **C++20** | `mvgald` | RAII, standard library for daemon subsystems |
| **Rust** | `safe/` crates | Memory safety for fences, tracking, capabilities |
| **Go** | REST server, exporter | Fast HTTP/tooling |
| **Python** | Scripts, future AI training | Ecosystem |
| **V / others** | `bindings/`, experimental tools | Optional bindings only |
| **CMake** | Primary build | Cross-distro, CPack, optional kernel build |
| **Meson / Zig** | Alternative paths | Documented in README |
| **GCC / Clang** | Both supported | Distro defaults; kernel built with Kbuild |

Compiler micro-benchmarks are **not** run in-tree (no reproducible harness); use distro toolchain for releases. Deep compiler study remains optional research.

---

## 11. Twenty Deliverables — Index

| # | Deliverable | Document / artifact | Maturity |
|---|-------------|---------------------|----------|
| 1 | Architecture specification | [ARCHITECTURE.md](ARCHITECTURE.md), [ENGINEERING_DESIGN.md](ENGINEERING_DESIGN.md), this §2–6 | Design complete |
| 2 | Driver abstraction specification | [DRIVER_ARCHITECTURE_DESIGN.md](DRIVER_ARCHITECTURE_DESIGN.md), [DRIVER_INTEGRATION.md](DRIVER_INTEGRATION.md) | Design complete; vendor ops partially stubbed |
| 3 | Runtime specification | [ARCHITECTURE.md](ARCHITECTURE.md) §Layer 3, `runtime/daemon/` | Implemented |
| 4 | Scheduler specification | [wiki/Scheduling-Strategies.md](../wiki/Scheduling-Strategies.md), `src/userspace/scheduler/` | Implemented; validation ongoing |
| 5 | Memory management specification | [MEMORY.md](MEMORY.md), [CROSS_VENDOR_COMMAND_STREAM.md](CROSS_VENDOR_COMMAND_STREAM.md) | Design + code; HW matrix open |
| 6 | Security specification | [SECURITY_REVIEW.md](SECURITY_REVIEW.md), [SECURITY.md](../SECURITY.md) | Documented + Polkit |
| 7 | Linux packaging specification | [PACKAGING_SUMMARY.md](PACKAGING_SUMMARY.md), `packaging/` | DEB/RPM/Arch/COPR |
| 8 | Steam integration specification | [STEAM.md](STEAM.md), [steam/README.md](../steam/README.md) | Implemented |
| 9 | Wine/Proton integration specification | [GAMING.md](GAMING.md), `compat/`, [research/](research/) | Partial (NTSYNC/WoW64 scaffolding) |
| 10 | Power management specification | [ENGINEERING_DESIGN.md](ENGINEERING_DESIGN.md) §4, `power_manager.cpp` | Implemented in daemon |
| 11 | Benchmark reports | `misc/benchmarks/`, `mvgal-bench` | Tool exists; publish per-platform logs |
| 12 | Test reports | [HARDWARE_VALIDATION_2026-06-01.md](HARDWARE_VALIDATION_2026-06-01.md), `ctest` | One 3-GPU system logged |
| 13 | API documentation | [API.md](API.md), [API_REFERENCE.md](API_REFERENCE.md), `include/mvgal/` | Complete headers |
| 14 | Developer documentation | [DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md), [CONTRIBUTING.md](CONTRIBUTING.md) | Complete |
| 15 | End-user documentation | [USER_GUIDE.md](USER_GUIDE.md), [QUICKSTART.md](QUICKSTART.md), [INSTALL.md](INSTALL.md) | Complete |
| 16 | Build system documentation | README §Building, `CMakeLists.txt` options | Complete |
| 17 | Gap analysis report | §9 above, [FEASIBILITY_AND_GAPS_2026-05-30.md](FEASIBILITY_AND_GAPS_2026-05-30.md) | Current |
| 18 | Roadmap | [plans/IMPLEMENTATION_PLAN.md](plans/IMPLEMENTATION_PLAN.md), [STATUS.md](STATUS.md) milestones | Current |
| 19 | Prototype implementation | Tree v0.2.19 — kernel, daemon, layers, tools | **Prototype / late alpha** |
| 20 | Production implementation plan | §12 below | This document |

Traceability matrix: [SPECIFICATION.md](SPECIFICATION.md), [SPEC_TASK_REPORT.md](SPEC_TASK_REPORT.md).

---

## 12. Production Implementation Plan

Phased plan aligned with [docs/STATUS.md](STATUS.md) milestone gates. **Do not claim production multi-vendor graphics until each gate has published logs.**

### Phase A — Evidence and safety (0–3 months)

1. **Hardware matrix:** AMD+NVIDIA, AMD+Intel, NVIDIA+Intel, +MTT where available; separate synthetic vs hardware test labels.
2. **DMA-BUF / P2P:** Run `mvgal-dmabuf-matrix -o docs/HARDWARE_DMABUF_MATRIX.md`, `test_dmabuf_integration`, and `cross_vendor_compute` on each pair; document fallbacks.
3. **Vulkan:** Loader regression suite; single-GPU fallback default; game spot-check list in `mvgal-compat`.
4. **Security:** Audit all install paths for pkexec-only elevation; ioctl input validation review.
5. **Docs:** Align README badges with [HARDWARE_VALIDATION_2026-06-01.md](HARDWARE_VALIDATION_2026-06-01.md) claims.

### Phase B — Core aggregation (3–9 months)

1. **M1–M2:** Vulkan ICD primary path (`MVGAL_USE_ICD=1`) + cross-vendor dma-buf on supported pairs.
2. **M3:** AFR/SFR only with frame-graph safety checks; frame pacer integration tests.
3. **M4:** SPIR-V backends (vendor compilers behind capability flags).
4. **M5:** Unified heap migration tied to real P2P probes.
5. **Per-vendor compiler CI:** AMDGPU LLVM, NVRTC, IGC, MUSA (optional).

### Phase C — Ecosystem (9–18 months)

1. **M6:** NTSYNC production path with Proton (`WINE_NTSYNC=1`) without forking Wine.
2. **AI scheduler:** ONNX Runtime in `mvgal_ai_model_predict`.
3. **Packaging:** Flatpak/Snap/AppImage if demanded by distros.
4. **Professional:** Expand [professional/](../professional/) validation (Blender, UE, frameworks).

### Phase D — Advanced (18+ months)

1. Network GPU pooling ([NETWORK_GPU_POOLING.md](NETWORK_GPU_POOLING.md)).
2. Optional virtual DRM node for compositor integration (kernel Phase 2).
3. Hardware-in-the-loop CI farm.

**Success criteria for “production-grade”:**

- Reproducible multi-vendor compute demo on ≥2 physical GPUs per supported API.
- Vulkan path with measured frame-time stability vs single-GPU baseline on approved titles.
- Zero silent corruption: fail closed to single GPU.
- Distro packages signed and COPR/deb/rpm maintained with kernel ABI tracking (DKMS).

---

## 13. Topology Example

```
CPU (NUMA node 0)
├── GPU0  AMD     RX 6400   0000:03:00.0  PCIe Gen4 x16  amdgpu
├── GPU1  NVIDIA  RTX 3050  0000:04:00.0  PCIe Gen1 x8   nvidia
├── GPU2  Intel   (optional iGPU/Arc)
└── GPU3  MTT     S30       0000:05:00.0  PCIe Gen3 x2   mtgpu / stub
```

P2P eligibility: same PCI domain + bridge policy + driver support → consult `mvgal_detect_all_p2p()` / daemon P2P matrix.

---

## 14. Related Research Files

| Topic | Path |
|-------|------|
| Vulkan multi-GPU | [research/03-vulkan-multi-gpu-explicit-api.md](research/03-vulkan-multi-gpu-explicit-api.md) |
| Framework survey | [research/01-multi-gpu-framework-survey.md](research/01-multi-gpu-framework-survey.md) |
| Vulkan layer dev | [research/10-vulkan-layer-development.md](research/10-vulkan-layer-development.md) |
| Upstream drivers | [UPSTREAM_DRIVER_RESEARCH_2026-05-30.md](UPSTREAM_DRIVER_RESEARCH_2026-05-30.md) |
| Phase 3 research | [RESEARCH_PHASE3.md](RESEARCH_PHASE3.md) |
| MTT audit | [MTT_SOURCE_AUDIT.md](MTT_SOURCE_AUDIT.md) |
| Implementation strategy | [MVGAL_IMPLEMENTATION_STRATEGY.md](MVGAL_IMPLEMENTATION_STRATEGY.md) |

---

## 15. Next Actions for Contributors

1. Pick a **milestone gate** from [STATUS.md](STATUS.md) and attach hardware logs before closing it.
2. Extend **DMA-BUF validation** on your machine; file results under `docs/HARDWARE_VALIDATION_*.md`.
3. Keep **pass-through default** for unsupported Vulkan/D3D paths.
4. Use this index in PR descriptions to show which deliverable (#1–20) is affected.

---

*Research phase sign-off: architecture understood, vendor boundaries documented, gaps explicit, prototype scope separated from production gates.*
