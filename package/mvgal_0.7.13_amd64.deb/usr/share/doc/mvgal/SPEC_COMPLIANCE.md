# MVGAL feasibility, architecture, and implementation status

**Reviewed:** 2026-09-27. This document describes this checkout; filenames, API scaffolding, builds, and synthetic tests do not prove operation on physical multi-vendor hardware.

**Status of this revision:** findings 1, 2, and 3 below have been resolved. MVGAL no longer registers a PCI driver, no longer reports unsubmitted work or fabricated VRAM addresses, and no longer publishes a synthetic Vulkan physical device. The replacement is a runtime capability-probe contract, described in "Runtime capability probing" below. Findings 4 through 7 are unchanged.

## Feasibility

Linux has no general ABI that combines independent AMD, NVIDIA, Intel, and Moore Threads GPUs into one transparent physical GPU. Native kernel drivers own device memory, queues, address spaces, scheduling, and synchronization. MVGAL can coordinate separate native devices above those drivers; it cannot safely take over their PCI functions, submit private command streams from a second kernel driver, or create universal cross-vendor memory coherence.

The practical design is capability based and API specific. Keep each vendor's kernel and userspace driver responsible for its GPU. Enumerate DRM render nodes and native API devices in userspace, correlate them by PCI BDF, and update the registry on hotplug/device loss. Zero devices means zero devices; one uses native pass-through; multiple are used only for APIs and workloads with real implementations and validated compatibility. The daemon owns policy, capability discovery, and telemetry. API layers/framework backends dispatch work through native contexts. Unsupported tasks stay on one native GPU.

Independent compute work can be partitioned explicitly using CUDA, OpenCL, SYCL, Vulkan device groups where supported, or framework backends. Arbitrary graphics command buffers cannot be moved between ICDs. AFR requires independent frames/resources and may add latency; SFR needs application or engine cooperation. An implicit Vulkan layer cannot safely substitute device handles from another ICD.

DMA-BUF shares objects; it does not guarantee cross-vendor importability, zero-copy, peer access, common virtual addresses, or cache coherence. Probe export/import per device pair, format, usage, and synchronization mode. Fall back to explicit copies through host memory. PCIe peer DMA is a separately probed optimization, not guaranteed by root-complex topology. Keep ownership, cache operations, and fences explicit.

## Vendor boundaries

| Vendor | Native stack and MVGAL boundary |
|---|---|
| AMD | `amdgpu` owns the device; RADV or AMDVLK owns Vulkan execution. AMDVLK is a userspace Vulkan driver built around PAL/LLPC and is discontinued upstream. Use Vulkan/DRM PRIME interfaces, not PAL internals or guessed VRAM addresses. |
| NVIDIA | NVIDIA kernel modules (`nvidia`, `nvidia-drm`, optionally UVM) cooperate with matching userspace components and firmware. The public kernel tree is not a general command submission ABI. Use CUDA/Vulkan/NVML and documented DMA-BUF/P2P paths only after runtime probing. |
| Intel | `i915`/`xe` own graphics; Mesa Vulkan/OpenCL/Level Zero serve graphics/compute. `intel/media-driver` is a VA-API userspace media driver, not a general GPU kernel driver or aggregation API. Treat media as a separate capability. |
| Moore Threads | The specified `mtgpu-drv` repository is archived and unmaintained. Treat MTT as optional and experimental, dependent on the installed driver/runtime and tested interfaces. |

At daemon startup, enumerate `/sys/class/drm/renderD*`, resolve each to PCI BDF and bound driver, and correlate with Vulkan/OpenCL/CUDA/Level Zero/VA-API enumerations. Build capabilities from runtime probes, not vendor IDs. Use one registry/policy path for 0, 1, 2, or N GPUs and any mix. Dispatch only when measured saved execution time exceeds partition, synchronization, and transfer cost; include queue delay, throughput, memory capacity, power, and thermal limits in scheduling.

NVLink, NCCL/RCCL, MPI, PyTorch/TensorFlow distributed, Vulkan device groups, SLI/CrossFire, Kompute, SYCL/OpenSYCL/HetCCL, FluidX3D, llama.cpp, and MLC-LLM are workload- or vendor-specific prior art. None supplies a universal transparent Linux device abstraction.

## Memory and binaries

The safe baseline is per-device allocations with explicit copies. Probe DMA-BUF import/export pairwise. Maintain explicit fences and ownership transitions; do not claim coherent unified VRAM or shared virtual addresses. NVIDIA PTX is NVIDIA-targeted virtual ISA; cubin/fatbin may contain device-specific code. AMD HSACO/LLVM bitcode/assembly target AMDGPU toolchains. Intel SPIR-V/bitcode/GEN binaries require compatible Intel runtimes and generations. Route to compatible native runtimes; parsing a container is not translation. SPIR-V is useful portable input only within the supported feature/target subset.

## Kernel/userspace split and tool choices

Keep kernel code in C and limit it to MVGAL-owned metadata/policy interfaces and kernel synchronization objects where needed. Do not bind vendor PCI functions, submit private vendor commands, fabricate VRAM allocations, or bypass native power controls. Put enumeration, API dispatch, scheduling, telemetry, shader compilation, power policy, packaging orchestration, and compatibility integration in userspace. C/C++ suit existing ABI-facing shims and daemon; Rust can serve isolated libraries behind stable C ABI; Python suits tooling. GCC/Clang with CMake/Ninja or Meson fit. Vulkan/OpenCL/CUDA/SYCL/MPI are workload interfaces, not interchangeable compiler targets. TCC, embedded-only compilers, Keil, IAR, Circle, CompCert, and Emscripten do not fit the core. Qt/GTK/wxWidgets/SDL remain optional UI choices.

## Findings and gaps in this checkout

The repository contains substantial scaffolding: kernel modules/UAPI, two daemon/runtime trees, Vulkan/OpenCL/CUDA interception, scheduler and memory code, Steam metadata, WoW64/NTSYNC code, and RPM/DEB/Arch/Nix packaging. Existing docs also record hardware validation and stub gaps. These artifacts do not establish a working universal aggregation path.

1. **RESOLVED.** `kernel/mvgal_core.c` no longer registers a PCI driver. The `pci_driver` and its `MODULE_DEVICE_TABLE` were deleted; the AMD/NVIDIA/Intel/MTT device ID list is retained only as an identity filter for read-only discovery. `mvgal.ko` now has no `alias:` in `modinfo` output, so udev cannot autoload it onto a GPU, and its undefined PCI symbols are limited to the read-only set (`pci_get_device`, `pci_dev_put`, `pcie_get_speed_cap`, `pcie_get_width_cap`, `pci_p2pdma_distance_many`, `pci_bus_type`). GPUs are discovered by read-only PCI scan and by bus notifier, and are never bound, enabled, or set to bus-master. Removing the driver also fixed two latent defects: every GPU was previously added to the device list twice, and each enumerated `pci_dev` reference was leaked.
2. **RESOLVED.** The four fabricated bump allocators in `kernel/vendors/` are gone. They were seeded at invented base addresses (4 GiB, 1 GiB, 256 MiB) with no backing buffer object, and the Intel one returned the allocation's sequential id as the GPU address, so the first call yielded address 0. All four now set `*gpu_addr = 0` and return `-EOPNOTSUPP`. All five `submit_cs` implementations now return `-EOPNOTSUPP` instead of transitioning state and returning 0 without dispatch, and the two dispatcher-level simulations in `kernel/mvgal_scheduler.c` that returned 0 and marked workloads complete now propagate `-EOPNOTSUPP` and restore the correct workload state. `free_vram` is a documented no-op, because no allocation is ever recorded.
3. **RESOLVED.** `mvgal_vkEnumeratePhysicalDevices` in `src/userspace/vulkan_icd/icd_entry.c` no longer publishes a synthetic device. It previously reported exactly one physical device whenever any GPU was present, populated from GPU 0's real `vendorID`/`deviceID`/`deviceType` and named "MVGAL Aggregated (<gpu0> + N more)" — a real vendor's PCI IDs attached to a device that could not aggregate. It now reports zero devices, warns once, and leaves daemon telemetry, scheduling, and policy intact. The interception layer in `src/userspace/intercept/vulkan/vk_layer.c` was already honest and was left alone: it enumerates the real ICDs and reports the true count. Separately, `mvgal_shader_route` no longer presents GLSL text through a `vendor_code` binary-blob interface, the NVIDIA backend no longer claims a "SPIRV-Cross PTX" path that does not exist (SPIRV-Cross cannot emit PTX), and `vk_layer.c` no longer runs a full SPIR-V optimise and decompile on every `vkCreateShaderModule` against a hardcoded AMD vendor, discarding the result.
4. Power docs overstate portable D3cold, DVFS, fan, emergency-shutdown, and PSU-budget controls. PSU capacity is generally not discoverable; expose only native-driver-supported controls and identify unsupported ones.
5. `compat/wow64` and `compat/ntsync` are project code, not a Wine/Proton fork. They do not provide Wine ABI/runtime machinery, complete Esync/Fsync, or general Windows application compatibility. Linux NTSYNC is an interface consumed by Wine.
6. Hardware evidence for vendor pairs, hotplug, API conformance, performance, memory import, and multi-GPU games is missing; synthetic tests do not close those gates.
7. Existing files contained direct privilege escalation instructions that conflicted with the task's policy. Project-owned references have been changed to `pkexec`; vendored upstream content is excluded.

## Runtime capability probing

Capability is now established by measurement at run time rather than by the presence of a function pointer in a vendor ops table. Each GPU carries a `cap_flags` bitmask, populated by a per-vendor `probe_capabilities` op that tests the actual resource: it opens the sysfs node, or inspects which driver owns the PCI function. A clear bit means "use the documented fallback", never "assume it works", and a GPU whose probe never ran reports no capabilities at all.

The distinction is load-bearing. An ops table can contain a pointer that validates arguments, logs, and returns success without doing anything; that is precisely the defect findings 2 and 3 describe. A probe that tests the resource cannot have that failure mode. `mvgal_gpu_can(gpu, cap)` is the only sanctioned way to ask, and the scheduler, memory manager, and power manager all consult it instead of testing `ops->foo != NULL`. The probed mask is visible per GPU at `capabilities` in sysfs, and the owning driver name at `native_driver`; both print `none` when there is nothing to report, so an unprobed or unbound device can never be mistaken for a capable one.

Four capability bits are deliberately never set for any vendor in this tree, and the reason is structural rather than a missing feature: `kernel-submit` (every vendor driver owns command submission internally and exports nothing to an out-of-tree module), `kernel-vram` (every vendor memory manager owns VRAM), `dmabuf-export` (the only reachable export is host-page re-export, which is staging, not VRAM sharing), and `wait-idle` (no vendor exports a completion entry point). `dmabuf-import` is settable because import is real: it attaches to the owning driver's device and returns a genuine DMA address.

Thus research and plan are documented; packaging scaffolding exists. A production aggregation path, complete Wine/Proton fork, universal binary translation, universal PSU-aware power allocation, and hardware-validated distribution support remain unimplemented. The next gate is no longer removal of PCI binding and fake submission/allocation, both of which are done; it is one narrow end-to-end userspace workload path validated on physical hardware.

## Primary references

* [NVIDIA open GPU kernel modules](https://github.com/NVIDIA/open-gpu-kernel-modules)
* [AMDVLK](https://github.com/GPUOpen-Drivers/AMDVLK)
* [Moore Threads mtgpu-drv](https://github.com/dixyes/mtgpu-drv)
* [Intel media-driver](https://github.com/intel/media-driver)

Upstream sources describe NVIDIA's kernel interface and OS-agnostic module portions, AMDVLK's PAL/LLPC architecture and discontinued state, the archived/unmaintained MTT driver, and Intel media-driver as a VA-API userspace driver. These boundaries require MVGAL to remain above native drivers and probe each capability.
