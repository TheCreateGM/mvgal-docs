# MVGAL Windows Compatibility Layer

> **Version**: 0.5.0  
> **Status**: Architecture Plan — Implementation in Workstream E  
> **Last Updated**: 2026-06-06

---

## Table of Contents

1. [Overview](#overview)
2. [WCL Architecture](#wcl-architecture)
3. [NTSYNC Kernel Module](#ntsync-kernel-module)
4. [DXGI Shim](#dxgi-shim)
5. [NVAPI / AGS Shim Interfaces](#nvapi--ags-shim-interfaces)
6. [WoW64 Filesystem Redirection](#wow64-filesystem-redirection)
7. [DXVK / VKD3D-Proton Integration](#dxvk--vkd3d-proton-integration)
8. [DLL Shim Loading](#dll-shim-loading)

---

## Overview

The Windows Compatibility Layer (WCL) enables Direct3D and other Windows
graphics APIs to run on MVGAL by intercepting and translating API calls.
It integrates with **Wine** / **Proton** to provide near-native performance
for Windows games and applications.

The WCL comprises:
- **Kernel-level**: NTSYNC module (`kernel/mvgal_ntsync.c`) for Windows
  synchronisation primitives
- **Userspace shims**: LD_PRELOAD / Wine-builtin DLL replacements for
  Windows graphics APIs (DXGI, D3D11, D3D12, D2D1)
- **Vendor extension shims**: NVAPI (NVIDIA), AGS (AMD) interception
- **WoW64 redirection**: 32-bit filesystem path translation

---

## WCL Architecture

```
Windows Application
        │
        ├── direct3d*.dll ──→ [DXVK / VKD3D-Proton] ──→ Vulkan ──→ MVGAL Intercept
        │                                                 (Layer 7)
        ├── dxgi.dll ──→ [DXGI Shim] ──→ MVGAL GPU enumeration
        │
        ├── nvapi.dll / amd_ags_x64.dll ──→ [Vendor Shim] ──→ MVGAL extensions
        │
        ├── kernel32.dll (CreateSemaphore etc.) ──→ [NTSYNC] ──→ mvgal_ntsync.ko
        │
        └── Wow64 (32-bit) ──→ [WoW64 Redirection] ──→ /usr/lib/mvgal/wcl/
```

### WCL Layers

| Layer | Purpose | Implementation |
|-------|---------|---------------|
| DLL Shim Layer | Intercept Windows DLL entry points | LD_PRELOAD / Wine builtin |
| API Translation | Translate D3D to Vulkan calls | Via DXVK/VKD3D-Proton |
| Vendor Extension | Convert NVAPI/AGS to MVGAL calls | Direct translation |
| Sync Translation | Map Windows sync to NTSYNC | Kernel module + Wine |
| Filesystem Redir | 32-bit path mapping | MVGAL WoW64 daemon |

---

## NTSYNC Kernel Module

### Purpose

Windows synchronisation primitives (`CreateSemaphore`, `CreateEvent`,
`WaitForSingleObject` etc.) are heavily used by games. The stock Linux
`futex` approach used by Wine has performance pathologies under high
contention. NTSYNC provides kernel-backed Windows-compatible sync objects.

### Source

`kernel/mvgal_ntsync.c` — independent from the core MVGAL module but
built and loaded alongside it.

### Sync Objects Exposed

| Windows API | NTSYNC Object | IOCTL |
|-------------|---------------|-------|
| `CreateSemaphore` | `ntsync_sem` | `NTSYNC_IOC_CREATE_SEM` |
| `CreateEvent` | `ntsync_event` | `NTSYNC_IOC_CREATE_EVENT` |
| `CreateMutex` | `ntsync_mutex` | `NTSYNC_IOC_CREATE_MUTEX` |
| `WaitForSingleObject` | — | `NTSYNC_IOC_WAIT_ANY` |
| `WaitForMultipleObjects` | — | `NTSYNC_IOC_WAIT_ALL` |
| `SetEvent` / `ResetEvent` | — | `NTSYNC_IOC_SET_EVENT` / `NTSYNC_IOC_RESET_EVENT` |
| `ReleaseSemaphore` | — | `NTSYNC_IOC_RELEASE_SEM` |
| `ReleaseMutex` | — | `NTSYNC_IOC_RELEASE_MUTEX` |

### Performance

NTSYNC provides ~5–15% FPS improvement over Wine's fsync implementation
in CPU-bound Windows games, especially those that make heavy use of
synchronisation (multi-threaded DX11 titles).

### Integration with Wine/Proton

- Wine must be compiled with `--with-ntsync` support.
- Proton experimental includes NTSYNC support since 2024.
- Enable with: `PROTON_NTSYNC=1 %command%` in Steam launch options.

---

## DXGI Shim

### Purpose

Intercept `dxgi.dll` calls to provide MVGAL-aware GPU enumeration and
swapchain management. Without the shim, DXGI would see only the primary
GPU; with the shim, it can enumerate all MVGAL-managed GPUs.

### Intercepted Functions

| DXGI Function | MVGAL Action |
|---------------|-------------|
| `CreateDXGIFactory` | Wrap factory with MVGAL enumerator |
| `IDXGIFactory::EnumAdapters` | Return MVGAL virtual adapters |
| `IDXGIAdapter::GetDesc` | Return MVGAL GPU description |
| `IDXGISwapChain::Present` | Frame pacing via `mvgal-pacer` |
| `IDXGISwapChain::ResizeBuffers` | Reconfigure framebuffer pool |
| `CreateDXGIFactory2` | Same as CreateDXGIFactory (DXGI 1.2+) |

### GPU Enumeration

The DXGI Shim presents MVGAL virtual adapters as DXGI adapters:

```c
// MVGAL adapter description filled in GetDesc
DXGI_ADAPTER_DESC {
    Description: "MVGAL Virtual Adapter N (Physical: GPU_Name)"
    VendorId:    MVGAL_VENDOR_ID  // 0x1MVG
    DeviceId:    physical_device_index
    SubSysId:    MVGAL_SUBSYS_ID
    Revision:    MVGAL_WCL_REVISION
    DedicatedVideoMemory:  available_vram_bytes
    DedicatedSystemMemory: 0
    SharedSystemMemory:    host_memory_bytes
}
```

### Swapchain Management

The DXGI Shim routes swapchain Present calls through the MVGAL frame
pacer (`tools/mvgal-pacer`), enabling:
- V-Sync control via MVGAL daemon
- Frame pacing across multiple GPUs (RLD strategy)
- Tearing control (GSPEED / VRR)

---

## NVAPI / AGS Shim Interfaces

### NVAPI Shim

Intercepts NVIDIA-specific API calls from `nvapi.dll` / `nvapi64.dll`
and translates them to MVGAL equivalents:

| NVAPI Function | MVGAL Equivalent |
|---------------|-----------------|
| `NvAPI_Initialize` | `mvgal_init()` |
| `NvAPI_EnumPhysicalGPUs` | `mvgal_device_enumerate()` |
| `NvAPI_GPU_GetMemoryInfo` | `mvgal_memory_info()` |
| `NvAPI_GPU_GetThermalSettings` | `mvgal_power_thermal()` |
| `NvAPI_D3D11_IsNvidiaShaderExtnOpCodeSupported` | Extension passthrough |
| `NvAPI_D3D_SetSleepMode` | Frame pacing hint |
| `NvAPI_GPU_GetPCIeInfo` | `mvgal_topology_pcie()` |

### AGS Shim

Intercepts AMD GPU Services (AGS) calls and translates to MVGAL:

| AGS Function | MVGAL Equivalent |
|-------------|-----------------|
| `agsInit` | `mvgal_init()` |
| `agsGetGPUMemory` | `mvgal_memory_info()` |
| `agsSetDisplayMode` | Frame pacing hint |
| `agsCheckDriverVersion` | Version compatibility check |

---

## WoW64 Filesystem Redirection

### Purpose

Windows-on-Windows 64 (WoW64) on Windows redirects 32-bit applications
to `SysWOW64`. MVGAL's WoW64 shim provides equivalent redirection for
MVGAL DLLs, allowing 32-bit Windows games to load the correct WCL libraries.

### Redirection Map

| 64-bit Path | 32-bit Redirect |
|-------------|----------------|
| `/usr/lib/mvgal/wcl/dxgi.dll` | `/usr/lib/mvgal/wcl/wow64/dxgi.dll` |
| `/usr/lib/mvgal/wcl/nvapi64.dll` | `/usr/lib/mvgal/wcl/wow64/nvapi.dll` |
| `/usr/lib/mvgal/wcl/d3d11.dll` | `/usr/lib/mvgal/wcl/wow64/d3d11.dll` |
| `/usr/lib/mvgal/wcl/d3d12.dll` | `/usr/lib/mvgal/wcl/wow64/d3d12.dll` |

### Implementation

The WoW64 redirection is handled via `include/mvgal/mvgal_wow64.h`:
```c
// Redirect a 32-bit DLL path to the wow64 variant
const char* mvgal_wow64_redirect(const char* dll_name);
```

The redirection daemon runs as part of `mvgald` and registers path
filters via `inotify` or `LD_LIBRARY_PATH` manipulation.

---

## DXVK / VKD3D-Proton Integration

MVGAL's WCL is designed to sit *above* DXVK and VKD3D-Proton, not
replace them.

```
Windows Game
     │
     ▼
  d3d9.dll ──→ DXVK ──→ Vulkan ──→ MVGAL Intercept Layer
  d3d11.dll ─→ DXVK ──→ Vulkan ──→ MVGAL Intercept Layer
  d3d12.dll ─→ VKD3D  ──→ Vulkan ──→ MVGAL Intercept Layer
     │
     ▼
  WCL Shim (DXGI, NVAPI, AGS, sync)
     │
     ▼
  MVGAL Daemon + Kernel
```

### Version Requirements

| Component | Minimum | Recommended |
|-----------|:-------:|:-----------:|
| DXVK | 2.3 | 2.4+ |
| VKD3D-Proton | 2.12 | 2.14+ |
| Wine | 9.0 | 9.20+ |
| Proton Experimental | — | Latest |

### Steam Integration

See `docs/STEAM_INTEGRATION.md` for Steam-specific setup, including
Proton launch configurations and the frame pacer (`mvgal-pacer`).

---

## DLL Shim Loading

### Mechanism

DLL shims are loaded via two mechanisms:

1. **Wine builtin overrides** (recommended for Proton):
   ```
   WINEDLLOVERRIDES="dxgi=n,b;nvapi64=n,b"
   ```

2. **LD_PRELOAD** (for wineprefix without Proton):
   ```bash
   LD_PRELOAD=/usr/lib/mvgal/wcl/dxgi.so:/usr/lib/mvgal/wcl/nvapi64.so
   ```

### Shim Directory Structure

```
/usr/lib/mvgal/wcl/
├── dxgi.dll         # DXGI shim (64-bit)
├── dxgi.so          # LD_PRELOAD version
├── nvapi64.dll      # NVAPI shim (64-bit)
├── nvapi.dll        # NVAPI shim (32-bit, WoW64)
├── amd_ags_x64.dll  # AGS shim (64-bit)
├── amd_ags_x86.dll  # AGS shim (32-bit)
├── d3d11.dll        # D3D11 intercept (passthrough to DXVK)
├── d3d12.dll        # D3D12 intercept (passthrough to VKD3D)
└── wow64/           # 32-bit WoW64 redirect targets
```

---

*See `docs/ARCHITECTURE.md` for overall system architecture.  
See `kernel/mvgal_ntsync.c` for NTSYNC implementation.  
See `include/mvgal/mvgal_wow64.h` for WoW64 types.*
