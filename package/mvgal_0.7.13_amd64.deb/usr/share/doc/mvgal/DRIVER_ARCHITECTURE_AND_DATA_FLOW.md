# MVGAL: Driver Architecture and Data Flow

**Version:** 1.1
**Date:** 2026-06-06
**Status:** Design & Implementation

---

## 1. Unified Driver Architecture

MVGAL implements a **decoupled multi-layer architecture** that sits between the Linux kernel's DRM subsystem and user-space graphics APIs.

### 1.1 Layered Approach

1.  **Layer 1: HAL (Hardware Abstraction Layer)**
    -   `mvgal.ko`: A kernel module that acts as a virtual DRM driver.
    -   Exposes `/dev/mvgal0` for management and `/dev/dri/renderDX` for rendering.
    -   Implements a unified command queue that dispatches to vendor-specific queues.

2.  **Layer 2: VGDD (Vendor GPU Driver Dispatch)**
    -   Shim layers for `amdgpu`, `nvidia`, `i915/xe`, and `mtgpu-drv`.
    -   Uses `struct mvgal_vendor_ops` to standardize operations like `submit_cs`, `alloc_vram`, and `export_dmabuf`.

3.  **Layer 3: Runtime Daemon (mvgald)**
    -   The brain of the system.
    -   **Scheduler**: Dynamic load balancing based on GPU scoring (compute units, utilization, VRAM pressure, thermal state).
    -   **Memory Manager**: Manages a Unified Virtual Address (UVA) space across all GPUs using DMA-BUF.
    -   **Power Manager**: Regulates power draw via PSU headroom tracking and per-GPU power curves.

4.  **Layer 4: API Interception**
    -   `VK_LAYER_MVGAL`: Vulkan layer for heterogeneous multi-GPU.
    -   `libmvgal_cuda.so`: Shim for CUDA applications.
    -   `libmvgal_gl.so`: LD_PRELOAD shim for OpenGL.

---

## 2. Data Flow

### 2.1 Memory Management & Data Flow

MVGAL uses a **Three-Tier Transfer Strategy** to ensure zero-copy or low-latency data movement:

1.  **DMA-BUF Zero-Copy (Tier 1)**:
    -   Used when both GPUs support DMA-BUF export/import.
    -   Kernel-level sharing avoids CPU bounce buffers.
    -   Supported by `amdgpu`, `nvidia-open`, and `intel`.

2.  **PCIe P2P Transfer (Tier 2)**:
    -   Used when GPUs are on the same PCIe root complex but DMA-BUF is unavailable.
    -   Direct BAR-to-BAR copy.

3.  **Host-RAM Staging (Tier 3)**:
    -   Fallback for all other cases.
    -   Uses a pinned staging buffer in system memory.

### 2.2 Workload Submission Flow

```mermaid
sequenceDiagram
    participant App as Application (Vulkan/CUDA)
    participant Shim as MVGAL API Shim
    participant Daemon as mvgald (Runtime Daemon)
    participant Kernel as mvgal.ko (HAL)
    participant Vendor as Vendor Driver (amdgpu/nvidia)

    App->>Shim: API Call (e.g., vkQueueSubmit)
    Shim->>Daemon: Submit Workload (IPC)
    Daemon->>Daemon: Scheduler selects best GPU
    Daemon->>Kernel: IOCTL_SUBMIT_WORKLOAD
    Kernel->>Vendor: Vendor-specific submission (e.g., amdgpu_job_submit)
    Vendor-->>Kernel: Work Complete (Fence Signal)
    Kernel-->>Daemon: Notify Completion
    Daemon-->>Shim: Signal Fence
    Shim-->>App: Return Success
```

---

## 3. Rendering Flow

### 3.1 Heterogeneous Workload Distribution

MVGAL supports multiple rendering strategies:

-   **AFR (Alternate Frame Rendering)**: Frame 0 on GPU A, Frame 1 on GPU B. Optimal for games.
-   **SFR (Split Frame Rendering)**: Single frame divided into tiles, distributed across GPUs.
-   **Compute Offload**: Graphics on primary GPU, compute kernels (e.g., PhysX, AI) offloaded to secondary GPUs.

### 3.2 Dynamic Scoring Algorithm

The scheduler uses a real-time scoring system:
$$Score = (ComputeUnits \times (1 - Utilization)) \times VRAM_{FreeRatio} \times ThermalFactor \times TypeBonus$$

-   **ThermalFactor**: Penalizes GPUs above 80°C.
-   **TypeBonus**: Extra weight for NVIDIA on CUDA workloads, or primary GPU on Graphics.

---

## 4. Synchronization (NTSYNC)

For Windows application compatibility (via Wine/Proton), MVGAL implements **NTSYNC**:
-   Replaces `Esync`/`Fsync` with kernel-level NT synchronization primitives.
-   Enables low-latency synchronization between 32-bit and 64-bit contexts (WoW64).
-   Provides `mvgal_fence` which wraps `dma_fence` for cross-vendor synchronization.

---

## 5. Power Management & PSU Regulation

MVGAL implements precise power draw regulation:
-   **PSU Headroom Tracking**: Monitors total system power draw and caps GPU consumption to stay within PSU limits.
-   **Dynamic Power Curves**: Adjusts power limits (via NVML or sysfs) based on GPU utilization.
-   **Idle Optimization**: Deep-sleep (PARK) mode for unused GPUs in a cluster.
