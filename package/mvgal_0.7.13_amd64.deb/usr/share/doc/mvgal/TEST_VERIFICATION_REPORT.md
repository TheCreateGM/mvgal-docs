# MVGAL Test Verification Report

**Date:** 2026-06-07  
**Environment:** Meson build (builddir)  

---

## Test Results Summary

### C Unit Tests

| Test | Passed | Failed | Total |
|------|--------|--------|-------|
| test_core_api | 17 | 0 | 17 |
| test_scheduler | 19 | 0 | 19 |
| test_memory | 18 | 0 | 18 |
| test_gpu_detection | 75 | 0 | 75 |
| test_execution | 38 | 0 | 38 |
| test_config | 7 | 0 | 7 |
| test_multi_gpu | 21 | 0 | 21 |

**C Total (Unit + Integration):** 195 passed, 0 failed

### Rust Tests (Cargo Workspace)

| Crate | Tests | Status |
|-------|-------|--------|
| mvgal_capability | 4 | ✅ Pass |
| mvgal_fence | 3 | ✅ Pass |
| mvgal_memory_safety | 3 | ✅ Pass |
| ffi_integration | 9 | ✅ Pass |
| mvgal_safe (combined) | 12 | ✅ Pass |

**Rust Total:** 31 tests, all passing

### CLI Tools

| Tool | Status | Notes |
|------|--------|-------|
| mvgal-info | ✅ Working | Detects 3 GPUs (NVIDIA, MTT, AMD) |
| mvgal-status | ✅ Working | Real-time monitoring with JSON output |
| mvgal-bench | ✅ Working | Memory, compute, scheduling, sync benchmarks |
| mvgal-compat | ✅ Working | System readiness check |

### Benchmark Results

| Benchmark | Result |
|-----------|--------|
| Memory bandwidth (read) | 51.06 GiB/s |
| Memory bandwidth (write) | 27.07 GiB/s |
| Memory copy | 11.11 GiB/s |
| Compute (DAXPY) | 1.043 GFLOPS |
| Scheduling latency (avg) | 1.71 µs |
| Scheduling latency (p99) | 2.33 µs |
| Sync overhead | 7.5 ns/op (134.07 Mops/s) |

---

## Detected Hardware

The test system has 3 GPUs detected:

| GPU | Vendor | Device | VRAM | Utilization |
|-----|--------|--------|------|-------------|
| 0 | NVIDIA | 0x2584 (RTX 4070?) | ~8 GiB | n/a |
| 1 | Moore Threads | 0x0102 (S80?) | 16 GiB | 0% |
| 2 | AMD | 0x743F (RX 7900?) | 4 GiB | 27% |

---

## Test Binary Summary

Total executable test binaries found in builddir:
- test_core_api
- test_scheduler  
- test_memory
- test_gpu_detection
- test_execution
- test_config
- test_multi_gpu
- test_vulkan_layer_submit

---

## Overall Status

✅ **All tests passing** (226 total tests: 195 C + 31 Rust)

### Notes

1. Kernel module (`mvgal.ko`) not loaded in test environment - expected for userspace-only testing
2. OpenCL ICD registration pending - requires proper ICD setup
3. Daemon not running - requires system installation
4. Hardware monitoring for NVIDIA shows n/a - may need NVML setup
5. All core functionality validated through unit tests