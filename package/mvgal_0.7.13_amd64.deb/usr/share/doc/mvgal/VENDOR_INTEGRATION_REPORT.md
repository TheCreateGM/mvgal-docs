# Vendor Integration Report: MVGAL Upstream Driver Analysis

**Date:** 2026-06-02  
**Status:** Research Complete

## Executive Summary

This report documents the analysis of four major GPU vendor kernel and user-space drivers for MVGAL integration. MVGAL is designed as an **above-driver coordination layer** that observes and coordinates existing vendor drivers without replacing them.

---

## 1. NVIDIA Open-GPU-Kernel-Modules

### Repository
https://github.com/NVIDIA/open-gpu-kernel-modules

### Key Components

| Component | Path | Purpose |
|-----------|------|---------|
| `nvidia.ko` | `kernel-open/nvidia/nv.c` | Main character device driver |
| `nvidia-drm.ko` | `kernel-open/nvidia-drm/nvidia-drm-drv.c` | DRM device registration |
| `nvidia-uvm.ko` | `kernel-open/nvidia-uvm/` | Unified Virtual Memory |
| `nvidia-peermem.ko` | `kernel-open/nvidia-peermem/` | PCIe Peer Memory support |

### Integration Points

1. **PCI Discovery**: `nv-pci.c` registers `nv_pci_driver` with Linux PCI core
2. **DRM Integration**: `nvidia-drm-drv.c` uses `drm_dev_alloc()` and `drm_dev_register()`
3. **DMA-BUF**: `nv-dmabuf.c` provides `nv_dma_buf_export()` and `nv_dma_buf_release()`
4. **P2P Support**: `nv-p2p.c` provides PCIe peer-to-peer memory access
5. **UVM**: `nvidia-uvm/` provides unified virtual memory management

### MVGAL Integration Strategy

**✅ Portable Integration Points:**
- Enumerate via PCI class/vendor/device IDs
- Access via `/dev/dri/cardN` render nodes
- Use DMA-BUF for cross-GPU memory sharing
- Query via `nvidia-ml-py3` or `nvml.h` for metrics
- Use `nvidia-smi` or `/sys/class/drm/cardN/device/` for power states

**⚠️ Limitations:**
- Cannot directly submit command buffers from kernel (proprietary interface)
- UVM ABI is not stable across versions
- Requires matching user-space driver (proprietary)

### Missing Hooks (from MVGAL perspective)

| Required Feature | Status | Workaround |
|------------------|--------|------------|
| Kernel-level command submission | Not available | User-space daemon via ioctl |
| Cross-vendor coherent VRAM | Not available | DMA-BUF + staging buffers |
| Direct VRAM allocation | Not exposed | Use user-space via CUDA/UVM |

---

## 2. AMDVLK / AMDGPU DRM

### Repository
https://github.com/GPUOpen-Drivers/AMDVLK

**Note:** AMDVLK is discontinued. AMD recommends using Mesa/RADV or AMD's ROCm stack.

### Key Components

| Component | Source | Purpose |
|-----------|--------|---------|
| `amdgpu.ko` | Upstream Linux kernel (`drivers/gpu/drm/amd/`) | Kernel DRM driver |
| `RADV` | Mesa (`src/vulkan/drivers/radv/`) | Vulkan driver |
| `AMDVLK` | This repository | Discontinued Vulkan driver |

### Integration Points

1. **DRM Render Nodes**: `/dev/dri/renderD128+` for compute/graphics
2. **TTM Memory Manager**: Translation Table Maps for VRAM/GTT
3. **PRIME**: DMA-BUF export/import via `drm_gem_prime_export()`
4. **Scheduler**: `amdgpu_scheduler` for command submission

### MVGAL Integration Strategy

**✅ Portable Integration Points:**
- Use standard DRM IOCTLs (`DRM_IOCTL_VERSION`, `DRM_IOCTL_CARDARITH`)
- Access via Mesa ACID for Vulkan loading
- Use ROCm/HIP for compute where available
- Query via sysfs: `/sys/class/drm/cardN/device/gpu_busy_percent`

### Missing Hooks

| Required Feature | Status | Workaround |
|------------------|--------|------------|
| PAL internal access | Not available | Use public Vulkan API |
| Direct TTM access | Kernel internal | DRM GEM objects |
| LLPC compiler access | Internal | SPIR-V → LLVM → AMDGPU backend |

**AMDVLK Status**: Discontinued as of 2023. MVGAL should target Mesa/RADV + ROCm for AMD GPUs.

---

## 3. Intel Media Driver / i915 xe

### Repository
https://github.com/intel/media-driver

### Key Components

| Component | Source | Purpose |
|-----------|--------|---------|
| `i915.ko` | Kernel (`drivers/gpu/drm/i915/`) | Legacy Intel DRM driver |
| `xe.ko` | Kernel (`drivers/gpu/drm/xe/`) | New Xe architecture driver |
| `media-driver` | `media_softlet/` | VA-API video decode/encode |

### Integration Points

1. **DRM Nodes**: `/dev/dri/card0` (render), `/dev/dri/renderD128+`
2. **Exec Buffers**: `DRM_IOCTL_I915_GEM_EXECBUFFER2`
3. **Level Zero**: Direct GPU access API
4. **VA-API**: `iHD_drv_video.so` for media offload

### MVGAL Integration Strategy

**✅ Portable Integration Points:**
- Use Xe driver for discrete GPUs (Arc)
- Use i915 for integrated graphics
- Access via ANV Vulkan driver (Mesa)
- Use Level Zero for compute
- Query via `/sys/class/drm/cardN/`

### Missing Hooks

| Required Feature | Status | Workaround |
|------------------|--------|------------|
| Media-driver as main path | Limited to video | Use Xe/ANV for graphics/compute |
| GUC/HUC firmware | Required | Kernel handles this |

---

## 4. Moore Threads mtgpu-drv

### Repository
https://github.com/dixyes/mtgpu-drv

### Key Components

| Component | Path | Purpose |
|-----------|------|---------|
| `mtgpu.ko` | `src/` | DRM driver |
| MUSA SDK | Published docs | User-mode compute API |
| MTML | Published docs | Management library |

### Integration Points

1. **DRM Registration**: Standard DRM character device
2. **GEM Objects**: GPU memory management
3. **Command Submission**: DRM IOCTL-based
4. **DMA-BUF**: Standard Linux DMA buffer export

### MVGAL Integration Strategy

**✅ Portable Integration Points:**
- Use standard DRM render nodes
- Use MUSA SDK for compute workloads
- Query via `/sys/class/drm/cardN/`

**⚠️ Status:** Experimental - requires license audit

### Required Actions

1. **License Audit**: Verify MIT/GPL dual license in source
2. **Version Mapping**: Map mtgpu version to MUSA/MTML capabilities
3. **Hardware Validation**: Test DMA-BUF import/export between MTT and other vendors

---

## 5. Cross-Vendor Integration Matrix

### DMA-BUF Export/Import Capability

| Vendor → \ Import ↓ | NVIDIA | AMD | Intel | MTT |
|---------------------|--------|-----|-------|-----|
| **NVIDIA** | ✅ own | ⚠️ P2P req | ⚠️ P2P req | ❌ |
| **AMD** | ✅ PRIME | ✅ own | ⚠️ P2P req | ⚠️ |
| **Intel** | ✅ PRIME | ⚠️ P2P req | ✅ own | ⚠️ |
| **MTT** | ❌ | ⚠️ | ⚠️ | ✅ own |

**Legend:**
- ✅ = Full support
- ⚠️ = Limited support, requires same root complex
- ❌ = Not supported

### P2P (PCIe Peer-to-Peer) Capability

| Vendor → \ Import ↓ | NVIDIA | AMD | Intel | MTT |
|---------------------|--------|-----|-------|-----|
| **NVIDIA** | NVLink | ❌ | NVLink req | ❌ |
| **AMD** | ❌ | ✅ | Limited | ❌ |
| **Intel** | ❌ | Limited | ✅ | ❌ |
| **MTT** | ❌ | ❌ | ❌ | ✅ |

---

## 6. Kernel Integration Requirements

### MVGAL-KM Design

MVGAL-kernel module (`mvgal.ko`) provides:

1. **Device Discovery**: Iterates PCI devices, identifies GPUs via class code
2. **Topology Interface**: Exposes via `/dev/mvgal0` ioctl and `/sys/class/mvgal/`
3. **DMA-BUF Coordinator**: Tracks cross-device buffer ownership
4. **Vendor Operations**: Per-vendor `.c` files in `kernel/vendors/`

### Vendor Operation Interface

```c
struct mvgal_vendor_ops {
    int  (*init)(struct mvgal_gpu_device *dev);
    void (*fini)(struct mvgal_gpu_device *dev);
    int  (*submit_cs)(struct mvgal_gpu_device *dev, struct mvgal_workload *wl);
    int  (*alloc_vram)(struct mvgal_gpu_device *dev, size_t size, uint64_t *addr);
    void (*free_vram)(struct mvgal_gpu_device *dev, uint64_t addr);
    int  (*wait_idle)(struct mvgal_gpu_device *dev, uint32_t timeout_ms);
    int  (*set_power_state)(struct mvgal_gpu_device *dev, enum mvgal_power_state);
    struct dma_buf *(*export_dmabuf)(struct mvgal_gpu_device *dev, uint64_t addr, size_t size);
    int  (*import_dmabuf)(struct mvgal_gpu_device *dev, struct dma_buf *buf, uint64_t *addr);
    int  (*query_utilization)(struct mvgal_gpu_device *dev, uint32_t *util_percent);
};
```

### Per-Vendor Implementation Status

| Vendor | Kernel Shim | Status | Notes |
|--------|-------------|--------|-------|
| NVIDIA | `kernel/vendors/mvgal_nvidia.c` | ✅ Prototype | Uses sysfs for power/util |
| AMD | `kernel/vendors/mvgal_amd.c` | ✅ Prototype | Reads sysfs, TTM stubbed |
| Intel | `kernel/vendors/mvgal_intel.c` | ✅ Prototype | Stub implementation |
| MTT | `kernel/vendors/mvgal_mtt.c` | ✅ Prototype | Stub with capability flags |

---

## 7. Recommendations

### Near-term (v0.3.x)

1. **Focus on user-space aggregation**: Implement Vulkan ICD and CUDA shim as primary paths
2. **DMA-BUF validation**: Test cross-vendor buffer sharing on real hardware
3. **Power management**: Use standard sysfs/hwmon interfaces for all vendors
4. **Keep kernel minimal**: Only topology and coordination in kernel space

### Mid-term (v0.4.x)

1. **Full Vulkan ICD**: Replace layer with ICD for better performance
2. **AMD support**: Target Mesa/RADV + ROCm integration
3. **Intel Arc**: Use Xe driver + ANV Vulkan
4. **MTT production**: Full license audit and hardware testing

### Long-term (v0.5.x+)

1. **Kernel-level submission**: Only after stable vendor UAPI exposed
2. **Cross-vendor VRAM**: Implement managed migration with copy semantics
3. **Network pooling**: Extend to distributed GPU scenarios

---

## 8. Conclusion

MVGAL can successfully coordinate heterogeneous GPUs through:

1. **Standard Linux interfaces**: PCI, DRM, DMA-BUF, sysfs
2. **Vendor-agnostic discovery**: No kernel-level driver claims
3. **API-level aggregation**: Vulkan ICD, OpenCL ICD, CUDA shim
4. **Graceful degradation**: Single-GPU fallback when unsafe

The key insight is that MVGAL must remain an **above-driver layer** and not attempt to replace vendor driver internals. Cross-vendor transparent scaling is achievable only through explicit API layers (Vulkan device groups,OpenCL ICD, CUDA context management) with proper fallback handling.