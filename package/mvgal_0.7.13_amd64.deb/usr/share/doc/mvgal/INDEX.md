# MVGAL Documentation Index

**Version:** 0.7.3  
**Last Updated:** July 2026

---

## 📚 Documentation Categories

### Getting Started
- [Quick Start Guide](docs/QUICKSTART.md) - 5-minute installation and test
- [Installation Guide](docs/INSTALL.md) - Detailed installation for all distros
- [Build Instructions](docs/BUILD.md) - Building from source
- [Steam Integration](docs/STEAM.md) - Gaming with MVGAL

### Architecture & Design
- [Architecture Overview](docs/ARCHITECTURE.md) - System architecture and layers
- [Design Document](docs/MVGAL_DESIGN_DOCUMENT.md) - Complete design specifications
- [Vendor Integration Guide](docs/VENDOR_INTEGRATION_GUIDE.md) - Adding new vendors
- [Vendor Analysis Report](docs/VENDOR_ANALYSIS_REPORT.md) - Vendor research findings

### API & Usage
- [API Reference](docs/API.md) - Complete public API reference
- [Configuration](docs/API.md#configuration) - Config file format
- [Scheduler Strategies](docs/STRATEGIES.md) - Workload distribution strategies

### Development
- [Developer Guide](docs/DEVELOPER_GUIDE.md) - Contributing and development
- [Rust Development](docs/RUST_DEVELOPMENT.md) - Memory-safe crates
- [Contributing](CONTRIBUTING.md) - How to contribute

### Testing & Validation
- [Test Matrix](docs/TEST_MATRIX.md) - Test coverage and hardware validation
- [Hardware Compatibility](docs/HARDWARE_COMPATIBILITY.md) - Supported GPUs

### Operations
- [Troubleshooting](docs/TROUBLESHOOTING.md) - Common issues and solutions
- [Security Review](docs/SECURITY_REVIEW.md) - Security considerations
- [Power Management](docs/POWER_MANAGEMENT.md) - GPU power control

---

## 🚀 Quick Reference

### Installation Commands

```bash
# Fedora/RHEL (COPR)
pkexec dnf copr enable axogm/mvgal
pkexec dnf install mvgal

# Ubuntu/Debian
pkexec apt install mvgal

# Arch Linux
pkexec pacman -S mvgal
```

### Verification

```bash
# Check GPU detection
mvgal-info

# Check system status
mvgal-status --watch

# Run benchmarks
mvgal-bench all
```

### Steam Launch Options

```bash
# Enable MVGAL with AFR
ENABLE_MVGAL=1 MVGAL_STRATEGY=afr %command%
```

---

## 📋 Documentation Structure

```
docs/
├── INDEX.md                    # This file
├── QUICKSTART.md               # Quick start guide
├── INSTALL.md                  # Installation guide
├── BUILD.md                    # Build instructions
├── ARCHITECTURE.md             # Architecture overview
├── MVGAL_DESIGN_DOCUMENT.md    # Full design spec
├── VENDOR_INTEGRATION_GUIDE.md # Vendor integration guide
├── VENDOR_ANALYSIS_REPORT.md   # Vendor research findings
├── API.md                      # API reference
├── STRATEGIES.md               # Scheduler strategies
├── STEAM.md                    # Steam/Proton guide
├── DEVELOPER_GUIDE.md         # Development guide
├── RUST_DEVELOPMENT.md         # Rust crate guide
├── TEST_MATRIX.md              # Test coverage
├── HARDWARE_COMPATIBILITY.md   # Hardware support
├── TROUBLESHOOTING.md          # Troubleshooting guide
├── SECURITY_REVIEW.md          # Security considerations
├── POWER_MANAGEMENT.md         # Power management
├── MTT_SOURCE_AUDIT.md         # Moore Threads driver source provenance (S30/S80/S2000)
└── MEMORY.md                   # Memory management deep-dive
```

---

## 🔧 API Interception Layers

| Layer | Component | Purpose |
|-------|-----------|---------|
| Vulkan | `VK_LAYER_MVGAL` | Vulkan API interception |
| OpenCL | `libmvgal_opencl.so` | OpenCL ICD Interception |
| CUDA | `libmvgal_cuda.so` | CUDA API interception |
| OpenGL | `libmvgal_gl.so` | LD_PRELOAD OpenGL shim |
| DirectX | `libmvgal_d3d.so` | DirectX/Vulkan translation |

---

## 🖥️ Supported Hardware

| Vendor | GPU Series | Driver | Status |
|--------|------------|--------|--------|
| **AMD** | RX 6000/7000, Vega, APU | `amdgpu` | ✅ Stable |
| **NVIDIA** | RTX 20/30/40xx, GTX 10/16xx | `nvidia-open` | ✅ Stable |
| **Intel** | Arc (DG2), i915/i915 | `i915`/`xe` | ✅ Stable |
| **Moore Threads** | MTT S60/S80/S2000 | `mtgpu-drv` | ⚠️ Experimental |

---

## 📞 Support & Community

- **GitHub:** https://github.com/TheCreateGM/mvgal
- **COPR:** https://copr.fedorainfracloud.org/coprs/axogm/mvgal/
- **Matrix:** #mvgal:matrix.org
- **Issues:** https://github.com/TheCreateGM/mvgal/issues

---

## 📄 License

- **Kernel module:** GPL-2.0-only
- **Userspace components:** GPL-3.0-only  
- **Rust crates:** MIT OR Apache-2.0