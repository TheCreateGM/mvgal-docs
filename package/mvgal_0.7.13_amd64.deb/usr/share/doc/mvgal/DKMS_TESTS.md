# DKMS Installation Test

This document describes how to test DKMS installation for MVGAL.

## Building with DKMS Support

```bash
# Build with DKMS enabled
cmake -B build -DMVGAL_DKMS=ON
cmake --build build

# Package for DKMS installation
cd build
make package  # Creates a tarball for DKMS
```

## Manual DKMS Installation Test

```bash
# 1. Copy source to /usr/src
pkexec tar -xzf mvgal-0.2.7.tar.gz -C /usr/src/
pkexec ln -s /usr/src/mvgal-0.2.7 /usr/src/mvgal-0.2.7

# 2. Add to DKMS
pkexec dkms add -m mvgal -v 0.2.7

# 3. Build
pkexec dkms build -m mvgal -v 0.2.7

# 4. Install
pkexec dkms install -m mvgal -v 0.2.7

# 5. Verify
dkms status
ls /sys/module/mvgal/
modinfo mvgal
```

## Kernel Version Compatibility

The DKMS configuration is tested against:
- Linux 5.10+ (for PCIe P2P support)
- Linux 6.12+ (for MODULE_IMPORT_NS namespace)
- RHEL 9+
- Fedora 40+
- Ubuntu 22.04+ with kernel 5.15+

## Build Verification

```bash
# Check all tests pass
cd build && ctest --output-on-failure

# Verify kernel module
modinfo /lib/modules/$(uname -r)/extra/mvgal.ko 2>/dev/null || \
modinfo kernel/mvgal.ko
```

## Automated Test Script

```bash
#!/bin/bash
set -e

echo "=== MVGAL DKMS Build Test ==="

# Build with DKMS
cmake -B build_test -DMVGAL_DKMS=ON -DMVGAL_BUILD_KERNEL=ON
cmake --build build_test

# Run tests
cd build_test
ctest --output-on-failure

echo "=== DKMS Test Complete ==="
echo "To install, run:"
echo "  pkexec dkms add -m mvgal -v 0.2.7"
echo "  pkexec dkms build -m mvgal -v 0.2.7"
echo "  pkexec dkms install -m mvgal -v 0.2.7"
```

## Notes

1. The kernel module uses `import_ns: DMA_BUF` which requires kernel 6.12+ for the newer namespace-based module import. For older kernels, the fallback mechanism is used.

2. Full-stack mode (`MVGAL_BUILD_FULL_STACK=1`) is enabled by default in DKMS builds, which includes all vendor backend shims.

3. The module is licensed under GPL-2.0-only and can be loaded without additional firmware.