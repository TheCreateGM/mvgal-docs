# MVGAL Kernel Module

> **Version**: 0.5.0  
> **Last Updated**: 2026-06-06

---

## Table of Contents

1. [Source Files](#source-files)
2. [DRM Driver Architecture](#drm-driver-architecture)
3. [Vendor Ops Interface](#vendor-ops-interface)
4. [NTSYNC Design](#ntsync-design)
5. [P2P DMA-BUF Design](#p2p-dma-buf-design)
6. [Memory Management](#memory-management)
7. [Build & Installation](#build--installation)

---

## Source Files

The kernel module comprises 9 `.c` source files and 7 `.h` headers under
`kernel/`, plus 4 vendor-specific integration pairs in `kernel/vendors/`.

### Core Files (9 .c)

| File | Lines | Purpose |
|------|:-----:|---------|
| `mvgal_main.c` | 930 | Module entry point, PCI driver, char dev, IOCTL dispatch |
| `mvgal_core.c` | — | Core data structures, GPU list management |
| `mvgal_device.c` | — | Per-GPU device lifecycle, DMA-BUF operations |
| `mvgal_memory.c` | — | GEM/buffer management, cross-vendor allocator |
| `mvgal_scheduler.c` | — | In-kernel scheduling hints and prioritisation |
| `mvgal_power.c` | — | DVFS, thermal throttling, power budgeting |
| `mvgal_sync.c` | — | Synchronisation primitives (fences, semaphores) |
| `mvgal_ntsync.c` | — | Windows NTSYNC compatibility (sem/event/mutex) |
| `mvgal_virt.c` | — | GPU virtualization / SR-IOV foundation |

### Headers (7 .h)

| Header | Purpose |
|--------|---------|
| `mvgal_core.h` | Core data structures, `mvgal_gpu_device`, vendor ops struct |
| `mvgal_device.h` | Device lifecycle helper functions |
| `mvgal_memory.h` | GEM buffer object types, memory region descriptors |
| `mvgal_scheduler.h` | Scheduling priority queue types |
| `mvgal_power.h` | DVFS modes, thermal state, power budget structs |
| `mvgal_sync.h` | Fence and semaphore object types |
| `mvgal_version.h` | Module version (`MVGAL_KERNEL_VERSION`) |

### Vendor Integration (kernel/vendors/)

| File | Purpose |
|------|---------|
| `mvgal_nvidia.c` / `.h` | NVIDIA GPU ops (NVML, nvidia-drm, DMA-BUF) |
| `mvgal_amd.c` / `.h` | AMD GPU ops (amdgpu, hwmon, XGMI) |
| `mvgal_intel.c` / `.h` | Intel GPU ops (i915, xe, DG2+) |
| `mvgal_mtt.c` / `.h` | Moore Threads GPU ops (mtgpu driver) |

### Auxiliary Files

| File | Purpose |
|------|---------|
| `Kbuild` | Kernel build integration |
| `Makefile` | Build targets (module, clean, install) |
| `dkms/dkms.conf` | DKMS build configuration |
| `LICENSE.GPL-2.0` | License text |

---

## DRM Driver Architecture

### Current: Char Device (Phase 1)

The current kernel module implements a **standalone char device** at
`/dev/mvgal0` — not a full DRM driver. This approach was chosen for rapid
iteration:

```
┌──────────────────────────────────────────────────────────────┐
│                  Userspace (mvgald, tools)                    │
└──────────────────────┬───────────────────────────────────────┘
                       │ IOCTL (read/write)
                       ▼
┌──────────────────────────────────────────────────────────────┐
│  /dev/mvgal0  ──→  mvgal_main.c  ──→  IOCTL dispatch         │
│  (char dev, major 238)              (mvgal_core.c)           │
└──────────────────────┬───────────────────────────────────────┘
                       │
          ┌────────────┼────────────┬────────────┐
          ▼            ▼            ▼            ▼
     amdgpu.ko    nvidia.ko     i915.ko     mtgpu.ko
```

### Planned: DRM Driver (Phase 2, Workstream B)

The migration path converts to a proper DRM driver:

```
┌──────────────────────────────────────────────────────────────┐
│  /dev/dri/card1  ──→ drm_driver  ──→  MVGAL GEM/Buffer Mgr  │
│  (DRM primary)                   │                           │
│  /dev/dri/renderD*               │                           │
│  ──→  DRM render nodes           │                           │
└──────────────────────┬───────────┴───────────────────────────┘
                       │
          ┌────────────┼────────────┬────────────┐
          ▼            ▼            ▼            ▼
     amdgpu.ko    nvidia.ko     i915.ko     mtgpu.ko
```

The DRM driver provides:
- DRM primary node (`/dev/dri/cardN`)
- Render nodes (`/dev/dri/renderD*`)
- GEM buffer object management
- DRM sync objects (fences, timeline semaphores)
- `drm_gem_prime_export` / `drm_gem_prime_import` for DMA-BUF

### IOCTL Dispatch

The char device dispatches 12 IOCTLs (defined in `mvgal_uapi.h`):

| Category | IOCTLs | Handler |
|----------|--------|---------|
| Query | `QUERY_VERSION`, `GET_GPU_COUNT`, `GET_GPU_INFO` | `mvgal_main.c` |
| Control | `ENABLE`, `DISABLE`, `RESCAN` | `mvgal_main.c` |
| Stats | `GET_STATS`, `GET_CAPS` | `mvgal_core.c` |
| DMA-BUF | `EXPORT_DMABUF`, `IMPORT_DMABUF` | `mvgal_device.c` |
| Cross-vendor | `ALLOC_CROSS_VENDOR`, `FREE_CROSS_VENDOR` | `mvgal_memory.c` |

---

## Vendor Ops Interface

Vendor-specific operations are abstracted through `mvgal_vendor_ops`,
defined in `mvgal_core.h`:

```c
struct mvgal_vendor_ops {
    // Device lifecycle
    int (*probe)(struct mvgal_gpu_device *gpu);
    void (*remove)(struct mvgal_gpu_device *gpu);

    // Memory management
    int (*alloc_vram)(struct mvgal_gpu_device *gpu, size_t size,
                      uint32_t flags, struct mvgal_mem_region *region);
    void (*free_vram)(struct mvgal_gpu_device *gpu,
                      struct mvgal_mem_region *region);

    // DMA-BUF
    int (*export_dmabuf)(struct mvgal_gpu_device *gpu,
                         struct mvgal_mem_region *region,
                         struct dma_buf **dmabuf);
    int (*import_dmabuf)(struct mvgal_gpu_device *gpu,
                         struct dma_buf *dmabuf,
                         struct mvgal_mem_region *region);

    // Power management
    int (*get_power_state)(struct mvgal_gpu_device *gpu,
                           struct mvgal_gpu_power *power);
    int (*set_power_limit)(struct mvgal_gpu_device *gpu, uint32_t watts);

    // Topology
    int (*get_peers)(struct mvgal_gpu_device *gpu,
                     struct mvgal_gpu_device ***peers, int *count);
};
```

Each vendor (NVIDIA, AMD, Intel, MTT) implements this interface:

```c
// kernel/vendors/
const struct mvgal_vendor_ops mvgal_nvidia_ops;
const struct mvgal_vendor_ops mvgal_amd_ops;
const struct mvgal_vendor_ops mvgal_intel_ops;
const struct mvgal_vendor_ops mvgal_mtt_ops;
```

### Vendor Detection

Vendors are detected during module init via PCI class code
(display controller, `0x03xxxx`):

| PCI VID | Vendor | Init Function |
|:-------:|--------|---------------|
| `0x10DE` | NVIDIA | `mvgal_nvidia_init()` |
| `0x1002` | AMD | `mvgal_amd_init()` |
| `0x8086` | Intel | `mvgal_intel_init()` |
| `0x1ED5` | Moore Threads | `mvgal_mtt_init()` |

---

## NTSYNC Design

### Purpose

NTSYNC provides kernel-backed Windows synchronisation primitives for Wine/
Proton. See `docs/WINDOWS_COMPAT.md` for the architectural context.

### Source File

`kernel/mvgal_ntsync.c` — independent module file built alongside MVGAL.

### Objects

| NTSYNC Object | Backed By | IOCTL Create |
|---------------|-----------|:------------:|
| Semaphore | `struct ntsync_sem` (kernel waitqueue + counter) | `NTSYNC_IOC_CREATE_SEM` |
| Event | `struct ntsync_event` (kernel waitqueue + boolean) | `NTSYNC_IOC_CREATE_EVENT` |
| Mutex | `struct ntsync_mutex` (kernel mutex + owner TID) | `NTSYNC_IOC_CREATE_MUTEX` |

### Wait Operations

| IOCTL | Semantics |
|-------|-----------|
| `NTSYNC_IOC_WAIT_ANY` | Wait until any of N objects is signalled |
| `NTSYNC_IOC_WAIT_ALL` | Wait until all N objects are signalled |
| `NTSYNC_IOC_SIGNAL` | Signal a single object (sem increment / event set) |

### Integration with Wine

- Wine 9.20+ detects NTSYNC via `/proc/sys/kernel/ntsync`.
- Enable: `PROTON_NTSYNC=1` or Wine config `ntsync=enabled`.
- NTSYNC objects are pool-allocated and reference-counted; automatic
  cleanup on fd close.

---

## P2P DMA-BUF Design

### Transfer Hierarchy

```
1. DMA-BUF zero-copy   (preferred — export/import fd)
2. PCIe P2P transfer   (fallback — same root complex)
3. Host-RAM staging    (last resort — memcpy through system memory)
```

### DMA-BUF Export/Import

```c
// Export: GPU → DMA-BUF fd
MVGAL_IOC_EXPORT_DMABUF
  struct mvgal_uapi_dmabuf_request {
      __s32 fd;            // Output: DMA-BUF file descriptor
      __s32 gpu_index;     // Source GPU
      __u32 flags;
      __u64 size;          // Allocation size
  };

// Import: DMA-BUF fd → GPU
MVGAL_IOC_IMPORT_DMABUF
  struct mvgal_uapi_dmabuf_request {
      __s32 fd;            // Input: DMA-BUF file descriptor
      __s32 gpu_index;     // Target GPU
      __u32 flags;
      __u64 size;
  };
```

### P2P Matrix

The kernel maintains a P2P matrix (`caps.p2p_matrix[32][32]`) where
`p2p_matrix[i][j]` indicates the supported transfer type:

| Value | Meaning |
|:-----:|---------|
| 0 | `MVGAL_UAPI_P2P_NONE` — No direct transfer |
| 1 | `MVGAL_UAPI_P2P_DMA` — DMA-BUF export/import |
| 2 | `MVGAL_UAPI_P2P_P2P` — True PCIe P2P (same root complex) |

### Cross-Vendor Allocation

Cross-vendor allocations are managed through `mvgal_memory.c`:

```c
MVGAL_IOC_ALLOC_CROSS_VENDOR
  struct mvgal_uapi_cross_vendor_alloc {
      __u32 src_vendor_id;
      __u32 dst_vendor_id;
      __u32 flags;
      __u64 size;
      __u64 token;         // Opaque allocation token
  };
```

---

## Memory Management

### GEM/Buffer Objects

Memory buffers are managed through `mvgal_memory.h` and `mvgal_memory.c`:

- **Type**: `struct mvgal_gem_obj` — GEM-style buffer object
- **Placement**: Per-GPU VRAM (via vendor ops) or system memory fallback
- **Migration**: Buffer migration across GPUs via DMA-BUF
- **Reference counting**: Kernel-side `kref` for buffer lifetime

### Memory Regions

```
┌─────────────────────────────────────────────────────────────────┐
│                        mvgal_mem_region                         │
├─────────────────────────────────────────────────────────────────┤
│  gpu_index    — owning GPU                                      │
│  vendor_id    — owning vendor                                   │
│  base         — physical base address in VRAM                   │
│  size         — allocation size                                 │
│  flags        — HOST_VALID, GPU_VALID, SHARED, P2P, REPLICATED  │
│  dmabuf_fd    — exported DMA-BUF fd (or -1)                     │
│  refcount     — kref reference count                            │
└─────────────────────────────────────────────────────────────────┘
```

### Allocation Flow

1. Userspace calls `MVGAL_IOC_EXPORT_DMABUF` (or userspace API).
2. Kernel selects target GPU via scheduler hint or policy.
3. Vendor `alloc_vram` op allocates VRAM on target GPU.
4. DMA-BUF is exported for cross-GPU sharing.
5. Buffer is registered in the kernel's region tracking table.

---

## Build & Installation

### Prerequisites

```bash
# Fedora / RHEL
pkexec dnf install kernel-devel kernel-headers gcc make

# Ubuntu / Debian
pkexec apt install linux-headers-$(uname -r) build-essential

# Arch
pkexec pacman -S linux-headers base-devel
```

### Build

```bash
cd kernel/
make -C /lib/modules/$(uname -r)/build M=$(pwd) modules
```

### Install

```bash
# Direct install (for testing)
pkexec make -C /lib/modules/$(uname -r)/build M=$(pwd) modules_install
pkexec depmod -a
pkexec modprobe mvgal

# Verify
lsmod | grep mvgal
ls -l /dev/mvgal0
```

### DKMS (for kernel updates)

```bash
cd kernel/
pkexec dkms add .
pkexec dkms build mvgal/VERSION
pkexec dkms install mvgal/VERSION
```

### udev Rules

Install the udev rule from `config/`:
```bash
pkexec cp config/99-mvgal.rules /etc/udev/rules.d/
pkexec udevadm control --reload-rules
pkexec udevadm trigger
```

This ensures `/dev/mvgal0` has group `video` with mode `0660`.

### Kernel Parameters

```ini
# /etc/modprobe.d/mvgal.conf (optional tuning)
options mvgal max_gpus=8
options mvgal enable_ntsync=1
options mvgal debug=0
```

### Verification

```bash
# Check module is loaded
modinfo mvgal
lsmod | grep mvgal

# Check device node
ls -l /dev/mvgal*
cat /sys/class/mvgal/mvgal0/version

# Run kernel tests
cd kernel/tests/
make
./mvgal_test
```

---

*See `docs/ARCHITECTURE.md` §1—HAL and §2—VGDD for layer context.  
See `kernel/` for full source.  
See `docs/HARDWARE_COMPATIBILITY.md` for supported hardware.*
