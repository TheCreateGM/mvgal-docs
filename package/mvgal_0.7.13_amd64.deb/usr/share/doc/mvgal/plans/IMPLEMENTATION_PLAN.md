# MVGAL Implementation Plan & Roadmap

This document outlines the phased implementation strategy for the Multi-Vendor GPU Aggregation Layer.

## Status Summary (May 2026)
- **Phase 0–8:** 95% Complete.
- **Core Engine:** Fully functional with 7 scheduling strategies.
- **API Interception:** Vulkan, OpenCL, and CUDA prototypes functional.
- **Safety Subsystems:** Rust-based fence and memory management implemented.

---

## Roadmap Milestones

### Milestone 1: Core Aggregation & Research (COMPLETED)
- [x] Vendor driver analysis (NVIDIA, AMD, Intel, MTT).
- [x] Kernel module (`mvgal.ko`) with device discovery.
- [x] Basic UAPI for memory and workload submission.

### Milestone 2: High-Performance Runtime (COMPLETED)
- [x] `mvgald` daemon with capability-aware scheduler.
- [x] DMA-BUF cross-vendor memory sharing.
- [x] Rust safety subsystems (Layer 2).

### Milestone 3: API Interception & Compatibility (COMPLETED)
- [x] Vulkan Layer (`VK_LAYER_MVGAL`).
- [x] OpenCL ICD and CUDA LD_PRELOAD shims.
- [x] Steam/Proton integration layer.

### Milestone 4: Advanced Features & Refinement (IN PROGRESS)
- [ ] **D3D/Metal/WebGPU intercept logic** (Medium Priority)
  - Target: Q3 2026
  - Goals: Support DXVK/VKD3D-Proton more natively; investigate WebGPU aggregation.
- [ ] **Full Vulkan ICD (Virtual Physical Device)** (Low Priority)
  - Target: Q4 2026
  - Goals: Hide physical GPUs entirely and present one `VkPhysicalDevice`.
- [ ] **Network-Distributed GPU Pooling** (Future)
  - Target: 2027
  - Goals: Aggregate GPUs across multiple nodes via RDMA/UCX.

---

## Task Checklist for AI/Dev Agent

### 1. Verification & Hardening
- [ ] Run stress tests on heterogeneous (AMD+NVIDIA) setups.
- [ ] Audit Rust-C FFI boundaries for memory leaks.
- [ ] Verify `pkexec` usage across all installation scripts.

### 2. Documentation
- [x] Create `CAPABILITY_MATRIX.md`.
- [ ] Create `SECURITY_REVIEW.md`.
- [x] Create `task.md` (Project Specification).

### 3. Samples & Benchmarks
- [x] Implement `cross_vendor_compute.c` sample app (`misc/benchmarks/`, CMake target `cross_vendor_compute`).
- [ ] Benchmark P2P vs. DMA-BUF vs. Staging overhead.

---

## Resource Estimates (Remaining Work)

| Task | Estimated Effort | Primary Language |
|------|------------------|------------------|
| D3D/Metal Shim | 8 weeks | C++ / HLSL |
| Virtual Vulkan ICD | 12 weeks | C++ / Vulkan |
| Network Pooling | 24 weeks | C / Go / UCX |
| AI Scheduler | 6 weeks | Python / C++ |

---

## Security & Compliance
- Ensure all kernel code remains GPL-2.0.
- Maintain MIT license for userspace components.
- Regular security audits of ioctl interfaces.
