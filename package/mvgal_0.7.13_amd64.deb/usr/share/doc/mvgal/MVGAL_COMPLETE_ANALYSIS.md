# MVGAL Complete Architecture and Implementation Analysis

**Version:** 1.0  
**Date:** 2026-06-07  
**Author:** Poolside Analysis  

---

## Executive Summary

MVGAL (Multi-Vendor GPU Aggregation Layer for Linux) is a sophisticated above-driver coordination system that enables heterogeneous GPUs from different vendors to work together. The current v0.4.0 codebase demonstrates a well-structured implementation with:

- **Kernel module** (`mvgal.ko`) - Character device `/dev/mvgal0` with 10 IOCTLs
- **Runtime daemon** (`mvgald`) - C++20 service with scheduler, memory manager, power manager
- **Rust safety subsystems** - Memory-safe fence, memory tracking, and capability management
- **API interception layers** - Vulkan layer, OpenCL ICD, CUDA shim, D3D wrappers
- **Steam/Proton integration** - Frame pacing, AFR, game profiles

---

## 1. Full Architecture Document

### System Architecture (8-Layer Stack)

```
┌──────────────────────────────────────────────────────────────────┐
│                        Applications                              │
│          (Games, Blender, PyTorch, OpenCL programs)              │
├──────────────────────────────────────────────────────────────────┤
│                Layer 8: Tooling & Bindings                        │
│  CLI tools · Qt Dashboard · REST API (Go) · Steam Frame Pacer    │
├──────────────────────────────────────────────────────────────────┤
│                Layer 7: API Interception                          │
│  VK_LAYER_MVGAL · libmvgal_opencl.so · libmvgal_cuda.so ·       │
│  libmvgal_gl.so · D3D9/11/12 shims · Metal shim · WebGPU shim    │
├──────────────────────────────────────────────────────────────────┤
│                Layer 6: Safety Subsystems (Rust)                  │
│  fence_manager · memory_safety · capability_model (MIT/Apache-2.0)│
├──────────────────────────────────────────────────────────────────┤
│          Layer 5: Work Distribution Engine (WDE)                  │
│  7+3 Scheduling Strategies · Memory Heap Hierarchy (Heaps 0-4)  │
│  Workload Analysis → Strategy Selection · RLD/REP/PPL extensions   │
├──────────────────────────────────────────────────────────────────┤
│          Layer 4: Intermediate Framing Layer (IMFL)               │
│  Frame Sessions · Cross-GPU Migration Plans · Steam Profiles       │
├──────────────────────────────────────────────────────────────────┤
│                Layer 3: Runtime Daemon (mvgald)                   │
│  Scheduler · MemoryManager · PowerManager · MetricsCollector       │
│  IpcServer · DeviceRegistry · D-Bus API · Daemon State Machine   │
├──────────────────────────────────────────────────────────────────┤
│          Layer 2: Vendor GPU Driver Dispatch (VGDD)               │
│  struct mvgal_vendor_ops · amdgpu / nvidia / intel / mtt         │
│  Per-vendor command submission · VRAM alloc · power mgmt          │
│  DMA-BUF export/import · PCIe P2P · Utilization query            │
├──────────────────────────────────────────────────────────────────┤
│          Layer 1: Hardware Abstraction Layer (HAL)                │
│  mvgal.ko · /dev/mvgal0 · PCI enumeration · GPU topology          │
│  IOCTL interface · NTSYNC · Cross-GPU DMA-BUF · sysfs             │
├──────────────────────────────────────────────────────────────────┤
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │ amdgpu.ko│  │nvidia.ko │  │i915/xe.ko│  │mtgpu-drv │       │
│  │  (AMD)   │  │ (NVIDIA) │  │ (Intel)  │  │  (MTT)   │       │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
│                    Vendor Kernel Drivers                          │
└──────────────────────────────────────────────────────────────────┘
```

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Character device (Phase 1) | Avoids claiming PCI devices from vendor drivers; simpler kernel version compatibility |
| DRM driver (Phase 2) planned | Will enable native compositor integration, DRM sync objects, GEM lifecycle |
| Vulkan layer vs full ICD | Transparent interception without application changes; full ICD planned for Phase 5 |
| 8-layer architecture | Clean separation of concerns; elevates Rust safety to dedicated layer |
| Rust for safety-critical paths | Eliminates memory safety bugs in fence/memory tracking |
| C17 + C++20 | C17 maximizes vendor driver header compatibility; C++20 provides modern abstractions |
| Unix socket IPC + SCM_CREDENTIALS | Zero-dependency authentication; video group restriction |
| D-Bus as optional interface | Standard Linux desktop integration |
| DMA-BUF for cross-GPU transfers | Kernel-supported zero-copy path across all vendors |
| Sysfs polling for metrics | No vendor SDK required; works universally |

---

## 2. Design Specification

### 2.1 Kernel Module Design (`kernel/`)

**Purpose:** Provides discovery, topology, and coordination foundation

**Key Files:**
- `mvgal_main.c` (~930 LOC) - Module init/exit, PCI scan, char dev registration
- `mvgal_core.h/c` - Core data structures
- `mvgal_device.c/h` - Device abstraction
- `mvgal_memory.c/h` - Memory management (stubs for full stack)
- `mvgal_power.c/h` - Power state management
- `mvgal_scheduler.c/h` - Workload queue (16 priority levels)
- `mvgal_sync.c/h` - Synchronization primitives
- `mvgal_ntsync.c` - Windows-compatible sync (WoW64 support)

**IOCTL Interface (10 commands):**

| IOCTL | Direction | Description |
|-------|-----------|-------------|
| `MVGAL_IOC_QUERY_VERSION` | Read | Version information |
| `MVGAL_IOC_GET_GPU_COUNT` | Read | Number of detected GPUs |
| `MVGAL_IOC_GET_GPU_INFO` | Read/Write | GPU descriptor by index |
| `MVGAL_IOC_ENABLE` | Write | Enable MVGAL aggregation |
| `MVGAL_IOC_DISABLE` | Write | Disable MVGAL aggregation |
| `MVGAL_IOC_GET_STATS` | Read | Statistics counters |
| `MVGAL_IOC_GET_CAPS` | Read | Aggregate capabilities |
| `MVGAL_IOC_RESCAN` | Write | Rescan for GPUs |
| `MVGAL_IOC_EXPORT_DMABUF` | Read/Write | Export buffer as DMA-BUF |
| `MVGAL_IOC_IMPORT_DMABUF` | Read/Write | Import DMA-BUF |

### 2.2 Runtime Daemon Design (`runtime/daemon/`)

**Purpose:** Central coordination service with policy enforcement

**Subsystems:**
- **DeviceRegistry** - Enumerates GPUs via `/sys/class/drm/`, normalizes metadata
- **Scheduler** - 5 modes: StaticPartitioning, DynamicLoadBalancing, ApplicationProfile
- **MemoryManager** - Cross-GPU allocation, DMA-BUF/P2P/host staging
- **PowerManager** - State machine: ACTIVE → SUSTAINED → IDLE → PARK
- **MetricsCollector** - Polls sysfs at 1000ms interval
- **IpcServer** - Unix socket (`/run/mvgal/mvgal.sock`), binary protocol
- **DBusService** - Standard Linux desktop API integration

### 2.3 Scheduler Design

**Scheduling Strategies (10 total):**

| Strategy | Enum | Description |
|----------|------|-------------|
| `MVGAL_STRATEGY_ROUND_ROBIN` | 0 | Even distribution across GPUs |
| `MVGAL_STRATEGY_AFR` | 1 | Alternate Frame Rendering (gaming) |
| `MVGAL_STRATEGY_SFR` | 2 | Split Frame Rendering (VR) |
| `MVGAL_STRATEGY_AUTO` | 3 | Auto-select based on workload |
| `MVGAL_STRATEGY_COMPUTE_OFFLOAD` | 4 | Route to highest-FLOPS GPU |
| `MVGAL_STRATEGY_HYBRID` | 5 | Adaptive selection |
| `MVGAL_STRATEGY_SINGLE_GPU` | 6 | Pass-through mode |
| `MVGAL_STRATEGY_TASK` | 7 | Route by workload type |
| `MVGAL_STRATEGY_RLD` | 8 | Render Layer Distribution |
| `MVGAL_STRATEGY_REPLICATION` | 9 | Replicate work for validation |
| `MVGAL_STRATEGY_PIPELINE_PARALLELISM` | 10 | Pipeline stages across GPUs |

**Scoring Algorithm:**
- Base score from GPU priority (0-100)
- Workload type modifier (compute/graphics/video)
- Utilization penalty (-100% at 100% util)
- Thermal penalty (above 80°C)
- Historical performance weighting

### 2.4 Memory Manager Design

**5-Tier Heap Hierarchy:**

| Heap | Location | Latency | Capacity | Best For |
|------|----------|---------|----------|----------|
| Heap 0 | GPU VRAM (local) | 1-10 µs | GB-tens of GB | Active rendering, compute |
| Heap 1 | GPU VRAM (peer) | 5-50 µs | GB-tens of GB | Shared textures via P2P |
| Heap 2 | Host RAM (NUMA-local) | 100-500 ns | GB-hundreds of GB | Staging, large buffers |
| Heap 3 | Host RAM (remote NUMA) | 200-1000 ns | GB-hundreds of GB | Cold data |
| Heap 4 | SSD/Storage | 10-100 µs | TB | Oversubscription |

**Transfer Strategy:**
1. DMA-BUF zero-copy (preferred - kernel-supported)
2. PCIe P2P (fallback - same root complex, kernel 5.10+)
3. Host-RAM staging (last resort - always works)

---

## 3. Component Diagrams

### 3.1 Module Dependency Graph

```mermaid
flowchart TB
    subgraph Applications
        Game[Games/Proton]
        Compute[PyTorch/OpenCL/CUDA apps]
        Vulkan[Vulkan Applications]
    end

    subgraph Interception["Layer 7 - API Interception"]
        VKL[VK_LAYER_MVGAL]
        OCL[libmvgal_opencl.so]
        CUDA[libmvgal_cuda.so]
        GL[libmvgal_gl.so]
    end

    subgraph Execution["Layer 4 - Execution"]
        EXE[execution.c]
        STEAM[Frame Pacer]
    end

    subgraph Runtime["Layer 3 - Runtime Daemon"]
        D[mvgald]
        SCH[Scheduler]
        MM[MemoryMgr]
        PWR[PowerMgr]
    end

    subgraph Safe["Layer 6 - Rust Safety"]
        FENCE[fence_manager]
        MEM[safe memory tracking]
        CAP[capability_model]
    end

    subgraph Kernel["Layer 1 - Kernel"]
        KO[mvgal.ko /dev/mvgal0]
    end

    subgraph Vendors["Vendor Drivers (Unchanged)"]
        AMD[amdgpu + RADV/AMDVLK]
        NV[nvidia + UMD]
        INTEL[i915/xe + ANV]
        MTT[mtgpu-drv]
    end

    Game --> VKL
    Compute --> OCL
    Compute --> CUDA
    Vulkan --> VKL

    VKL --> D
    OCL --> D
    CUDA --> D
    GL --> EXE

    D --> SCH & MM & PWR
    D --> KO
    SCH --> AMD & NV & INTEL & MTT
    MM --> AMD & NV & INTEL & MTT
```

### 3.2 Driver Interaction Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          MVGAL Integration Points                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  AMD (amdgpu)           Intel (i915/xe)         NVIDIA (nvidia.ko)         │
│  ────────────────────   ────────────────────   ────────────────────       │
│  DRM render nodes       DRM render nodes         DRM + procfs + DMA-BUF       │
│  PAL abstraction        Mesa ANV               CUDA/OpenCL/Vulkan ICDs    │
│  ROCm/HIP               Level Zero             NVML for metrics             │
│  TTM/GEM                GEM                    UVM                          │
│  PRIME export           PRIME export           PRIME import (open stack)    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     MVGAL Coordination Layer                        │   │
│  │                                                                     │   │
│  │  Discovery: PCI class, DRM nodes, sysfs                               │   │
│  │  Memory: DMA-BUF/PRIME, P2P matrix, staging fallback                 │   │
│  │  Scheduling: Per-API interception, workload routing                 │   │
│  │  Sync: timeline semaphores, cross-GPU fences                        │   │
│  │  Power: sysfs hwmon, driver power interfaces                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Moore Threads (mtgpu-drv)                                                  │
│  ────────────────────────────                                              │
│  DRM driver (experimental)                                                  │
│  MUSA SDK, MTML libraries                                                   │
│  Vendor-specific compiler/runtime                                           │
│  Graceful degradation when absent                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Driver Interaction Diagrams

### 4.1 PCI Enumeration Flow

```
System Boot
    │
    ▼
mvgal.ko initialization
    │
    ├── PCI display-class scan (vga, 3D, other)
    │       │
    │       ├── AMD GPUs → amdgpu driver (read-only observation)
    │       ├── NVIDIA GPUs → nvidia.ko (read-only observation)
    │       ├── Intel GPUs → i915/xe (read-only observation)
    │       └── MTT GPUs → mtgpu-drv (optional)
    │
    ▼
PCI hotplug notifier registration
    │
    ├── GPU added/removed → mvgal_rescan_locked()
    │
    ▼
/sys/class/mvgal/mvgal0/gpuN/ sysfs entries created
    │
    ├── enabled (RW) - Enable/disable specific GPU
    ├── pci_path (R) - PCI BDF identifier
    └── power_state (RW) - Power control
```

### 4.2 Memory Transfer Paths

```
Source GPU Buffer
    │
    ├── DMA-BUF export supported?
    │       ├── Yes → dma_buf_export() → FD
    │       │       │
    │       │       ├── Import to dest GPU via DRM prime
    │       │       └── Zero-copy (if same vendor P2P available)
    │       │
    │       └── No → Check PCIe P2P
    │               │
    │               ├── Same root complex?
    │               │       ├── Yes → pci_p2pdma (if driver supports)
    │               │       └── No → Host-RAM staging
    │               │
    │               └── Host-RAM staging fallback:
    │                       mmap source → memcpy → upload to dest
    │
    ▼
Destination GPU can access data
```

---

## 5. Scheduler Design

### 5.1 Performance Characteristics

**Reported Benchmark Results (AMD RX 6600 + NVIDIA RTX 4060):**

| Benchmark | 1 GPU | 2 GPUs (MVGAL) | Speedup |
|-----------|-------|----------------|---------|
| Memory copy bandwidth | baseline | 1.7× | ✅ |
| Compute (DAXPY) | baseline | 1.8× | ✅ |
| Scheduling latency avg | — | 1.81 µs | — |
| Scheduling latency p99 | — | 1.96 µs | — |
| Sync overhead | — | 6.2 ns/op | — |

### 5.2 Strategy Selection Matrix

| Workload Type | Recommended Strategy | Rationale |
|---------------|---------------------|-----------|
| Gaming (fast-paced) | AFR, SFR | Minimizes frame latency |
| Gaming (VR) | SFR | Split reduces latency |
| Gaming (complex scenes) | RLD | Separates render layers |
| AI Training | Compute offload, PPL | Batch sharding |
| AI Inference | Round-robin, Task-based | Even distribution |
| Media encoding | PPL | Pipeline stages |
| Scientific computing | REP | Cross-verification |
| Mixed workloads | Hybrid | Adaptive selection |

---

## 6. Memory Manager Design

### 6.1 DMA-BUF Matrix (Design)

```
            To GPU
           ┌───────┬───────┬───────┬───────┐
           │ AMD   │ NVIDIA│ Intel │ MTT   │
  From AMD │ DMA   │ DMA   │ DMA   │ ?     │
  GPU      ├───────┼───────┼───────┼───────┤
           │ NVIDIA│ DMA   │ DMA   │ ?     │
  From     ├───────┼───────┼───────┼───────┤
  NVIDIA   │ Intel │ Intel │ DMA   │ ?     │
           ├───────┼───────┼───────┼───────┤
           │ MTT   │ MTT   │ MTT   │ DMA   │
  From     └───────┴───────┴───────┴───────┘

Legend: DMA = DMA-BUF zero-copy, P2P = PCIe P2P, Staging = Host RAM
```

### 6.2 Memory Flags

| Flag | Value | Description |
|------|-------|-------------|
| `HOST_VALID` | `1<<0` | CPU can access (mapped) |
| `GPU_VALID` | `1<<1` | GPUs can access |
| `CPU_CACHED` | `1<<2` | CPU cached |
| `CPU_UNCACHED` | `1<<3` | CPU uncached (write-combined) |
| `SHARED` | `1<<4` | Shared across GPUs |
| `DMA_BUF` | `1<<5` | Use DMA-BUF |
| `P2P` | `1<<6` | Enable P2P transfers |
| `REPLICATED` | `1<<7` | Mirror across all GPUs |
| `PERSISTENT` | `1<<8` | Persistent mapping |
| `LAZY_ALLOCATE` | `1<<9` | Defer allocation |
| `ZERO_INITIALIZED` | `1<<10` | Zero on alloc |

---

## 7. Security Review and Threat Model

### 7.1 Security Architecture

| Layer | Security Mechanism |
|-------|-------------------|
| Kernel (`mvgal.ko`) | IOCTL validation, range checking, copy_to/from_user |
| IPC (`mvgald`) | Unix socket with SCM_CREDENTIALS, video group restriction |
| Rust Safety | Memory-safe fence/memory tracking, no unsafe FFI |
| Privilege | All ops via `pkexec` (Polkit), no direct `pkexec` |
| Vendor Boundaries | Above-driver coordination only, no command buffer rewriting |

### 7.2 Threat Model

| Threat | Mitigation |
|--------|------------|
| Unauthorized Workload Submission | SCM_CREDENTIALS auth, video group check |
| DoS (Memory Exhaustion) | Per-process and global memory limits |
| Cross-GPU Data Leakage | Standard DMA-BUF ownership model |
| Kernel Panic via IOCTL | Input validation, fuzzed interface |
| Privilege Escalation | Polkit policies, capability dropping |

### 7.3 Polkit Integration

Policy file: `config/org.freedesktop.policykit.mvgal.policy`
- Actions defined for module loading, power writes, memory allocation
- Only authorized users can perform privileged operations

---

## 8. Linux Packaging System

### 8.1 Package Formats

| Format | Location | Build Command |
|--------|----------|---------------|
| Debian | `packaging/deb/DEBIAN/` | `bash packaging/build_deb.sh` |
| RPM | `packaging/rpm/mvgal.spec` | `rpmbuild -bb packaging/rpm/mvgal.spec` |
| Arch | `packaging/arch/PKGBUILD` | `makepkg -si` |
| Flatpak | Planned (future) | |

### 8.2 Distribution Support

| Distribution | Status | Notes |
|--------------|--------|-------|
| Fedora 40-44 | ✅ COPR available | Primary target |
| RHEL/AlmaLinux/Rocky 9 & 10 | ✅ | Enterprise support |
| CentOS Stream 9 & 10 | ✅ | |
| Ubuntu/Debian | ✅ DEB packages | |
| Arch Linux | ✅ AUR support | |
| openSUSE | ✅ RPM | |
| Amazon Linux 2023 | ✅ RPM | |

---

## 9. API Documentation Completeness

### 9.1 Public Headers (`include/mvgal/`)

| Header | Lines | Functions | Status |
|--------|-------|-----------|--------|
| `mvgal.h` | ~330 | Core API | ✅ Complete |
| `mvgal_types.h` | ~180 | Types/enums | ✅ Complete |
| `mvgal_gpu.h` | ~470 | GPU management | ✅ Complete |
| `mvgal_memory.h` | ~420 | Memory API | ✅ Complete |
| `mvgal_scheduler.h` | ~440 | Scheduler API | ✅ Complete |
| `mvgal_execution.h` | ~100 | Execution engine | ✅ Complete |
| `mvgal_log.h` | ~120 | Logging (22 functions) | ✅ Complete |
| `mvgal_config.h` | ~380 | Config (19 functions) | ✅ Complete |
| `mvgal_ipc.h` | ~112 | IPC (11 message types) | ✅ Complete |
| `mvgal_intercept.h` | ~80 | Intercept helpers | ✅ Complete |
| `mvgal_uapi.h` | ~60 | Kernel IOCTL interface | ✅ Complete |

### 9.2 Rust FFI Interface

```c
// fence_manager (~248 LOC, 3 tests)
uint64_t mvgal_fence_create(uint32_t gpu_index);
void     mvgal_fence_submit(uint64_t handle);
void     mvgal_fence_signal(uint64_t handle);
uint32_t mvgal_fence_state(uint64_t handle);  // Pending=0, Signaled=2
void     mvgal_fence_reset(uint64_t handle);
void     mvgal_fence_destroy(uint64_t handle);

// memory_safety (~230 LOC, 3 tests)
uint64_t mvgal_mem_track(uint64_t size, uint32_t placement);
void     mvgal_mem_retain(uint64_t handle);
void     mvgal_mem_release(uint64_t handle);
void     mvgal_mem_set_dmabuf(uint64_t handle, int32_t fd);

// capability_model (~260 LOC, 6 tests)
uint64_t    mvgal_cap_compute(const GpuCapability *caps, uint32_t count);
uint64_t    mvgal_cap_total_vram(uint64_t handle);
const char *mvgal_cap_to_json(uint64_t handle);
```

---

## 10. Benchmark Methodology

### 10.1 Test Categories

| Suite | Description |
|-------|-------------|
| C unit tests | Core API, GPU detection, memory, scheduler, execution |
| Rust unit tests | Fence, memory safety, capability model (12 tests) |
| Synthetic benchmarks | Theoretical performance validation |
| Real-world benchmarks | Actual workload testing |
| Stress benchmarks | Concurrency, memory pressure |

### 10.2 Benchmark Tool (`mvgal-bench`)

| Test | Description |
|------|-------------|
| `--memory-bandwidth` | DMA-BUF throughput test |
| `--compute` | DAXPY kernel across GPUs |
| `--scheduling-latency` | Workload queue timing |
| `--sync-overhead` | Fence/semaphore overhead |

### 10.3 Hardware Validation Matrix

Required for production:
- AMD + NVIDIA combinations
- AMD + Intel combinations  
- NVIDIA + Intel combinations
- + MTT where available

Current status: Logs needed per configuration.

---

## 11. CI/CD Pipeline

### 11.1 Workflows

| Workflow | Triggers | Description |
|----------|----------|-------------|
| CI | `push` (main/develop), `PR`, `workflow_dispatch` | Build matrix (Ubuntu 22.04/24.04, GCC/Clang), tests, static analysis |
| COPR Build | Tag `v*`, `workflow_dispatch` | RPM build and Fedora COPR submission |

### 11.2 Build Matrix

```yaml
Build Configurations:
  - Ubuntu 22.04 / Ubuntu 24.04
  - GCC / Clang
  - WITH_VULKAN=ON/OFF
  - MVGAL_BUILD_TESTS=ON/OFF
```

---

## 12. Implementation Roadmap

### Phase A — Evidence and Safety (0-3 months)

| Item | Priority | Deliverable |
|------|----------|-------------|
| Hardware matrix | High | Reproducible logs for each vendor combination |
| DMA-BUF validation | High | `mvgal-dmabuf-matrix` on each pair |
| Vulkan fallback | High | Single-GPU pass-through default |
| Security audit | High | pkexec-only elevation, ioctl validation |
| Documentation alignment | Medium | README badges match validated claims |

### Phase B — Core Aggregation (3-9 months)

| Milestone | Features |
|-----------|----------|
| M1 | Vulkan ICD primary path |
| M2 | Cross-vendor DMA-BUF on supported pairs |
| M3 | AFR/SFR with frame-graph safety |
| M4 | SPIR-V vendor compiler backends |
| M5 | Unified VRAM migration with P2P probes |

### Phase C — Ecosystem (9-18 months)

| Milestone | Features |
|-----------|----------|
| M6 | NTSYNC production with Proton |
| AI integration | ONNX Runtime scheduler integration |
| Packaging | Flatpak/Snap if demanded |
| Professional | Blender, UE validation expansion |

### Phase D — Advanced (18+ months)

| Feature | Description |
|---------|-------------|
| Network GPU Pooling | Distributed GPU resources |
| Virtual DRM node | Composer integration |
| Hardware CI Farm | Multi-vendor continuous validation |

---

## 13. Risk Assessment

### 13.1 Technical Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Cross-vendor graphics incompatibility | High | High | Pass-through default, conservative fallback |
| DMA-BUF driver variations | High | Medium | Capability-probed paths, staging fallback |
| Anti-cheat detection | Medium | High | Disable for affected games |
| Thermal/Power complexity | Low | High | Per-vendor power managers |

### 13.2 Supply Chain Risks

| Risk | Mitigation |
|------|------------|
| MTT driver provenance | License audit before production claims |
| NVIDIA open modules | Use only public API surfaces |
| AMD VLK deprecation | Focus on RADV + ROCm |

### 13.3 Production Requirements

- Reproducible multi-vendor compute demo on ≥2 physical GPUs
- Vulkan path with validated frame-time stability
- Zero silent corruption (fail closed)
- Signed distro packages with ABI tracking

---

## Conclusion

MVGAL v0.4.0 represents a mature architectural foundation for heterogeneous GPU aggregation on Linux. The key strengths are:

1. **Clean layer separation** - Kernel, runtime, interception, safety
2. **Vendor-neutral design** - Via `mvgal_vendor_ops` abstraction
3. **Memory safety** - Rust subsystems for critical paths
4. **Production focus** - pkexec, Polkit, conservative defaults
5. **Gaming integration** - Steam/Proton with frame pacing

The main gaps for production readiness are:

1. Hardware validation logs for vendor combinations
2. Per-vendor compiler backend integration
3. Network GPU pooling implementation
4. MTT source provenance confirmation