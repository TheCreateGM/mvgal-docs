# MVGAL: Language and Toolchain Selection

**Project:** Multi-Vendor GPU Aggregation Layer
**Decision Date:** 2026-06-06

---

## 1. Core Stack Selection

| Component | Language | Rationale |
|-----------|----------|-----------|
| **Kernel HAL** | C (GPL-2.0) | Standard for Linux kernel modules. High performance, direct hardware access. |
| **Runtime Daemon** | C++20 | Modern features (std::jthread, concepts, ranges) for complex coordination. Excellent performance. |
| **Safety Subsystems** | Rust | Memory safety for critical synchronization (fence manager, memory safety) where C++ is prone to errors. |
| **API Interception** | C17 | Minimal overhead for high-frequency API calls. Broad compatibility with existing libraries. |
| **CLI & Tools** | Go / V | Fast development, easy distribution. Go is used for the REST API/Exporter; V is used for `mvgal-ctl`. |
| **GUI Dashboard** | C++ / Qt | Industry standard for cross-platform desktop UIs with high performance. |

---

## 2. Toolchain Selection

| Tool | Selection | Rationale |
|------|-----------|-----------|
| **Primary Compiler** | Clang / LLVM | Superior diagnostics, better cross-language optimization (LTO) with Rust, and excellent SPIR-V support. |
| **Kernel Compiler** | GCC | Standard and robust for Linux kernel module compilation. |
| **Build System** | CMake | De-facto standard for C/C++ projects. Excellent IDE support. |
| **Package Manager** | Conan | Robust dependency management for C/C++ libraries. |
| **Rust Compiler** | rustc / cargo | Standard for Rust development. |

---

## 3. Implementation Details

-   **Interoperability**: C FFI is used as the common bridge between C++, Rust, and the Kernel.
-   **Synchronization**: `NTSYNC` kernel module for Windows-compatible sync primitives.
-   **Memory**: DMA-BUF is the primary mechanism for cross-vendor memory sharing.
