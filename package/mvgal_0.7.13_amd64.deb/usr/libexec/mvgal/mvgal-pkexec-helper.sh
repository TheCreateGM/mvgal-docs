#!/bin/bash
# MVGAL PolicyKit Execution Helper
# 
# This script provides a unified interface for all privileged MVGAL operations.
# It is called via pkexec to ensure secure privilege escalation.
#
# Usage: pkexec /usr/lib/mvgal/mvgal-pkexec-helper.sh <action> [args...]
#
# Actions:
#   load-module       - Load all MVGAL kernel modules (combined mvgal.ko)
#   unload-module     - Unload all MVGAL kernel modules
#   enable-gpu N      - Enable GPU at index N
#   disable-gpu N     - Disable GPU at index N
#   set-power GPU STATE - Set GPU power state (auto, on, off)
#   rescan-gpus       - Rescan for GPU changes
#   reload-config     - Reload MVGAL configuration
#   install-vulkan-layer - Install Vulkan implicit layer
#   remove-vulkan-layer  - Remove Vulkan implicit layer
#   install-mtt-driver   - Run the Moore Threads DKMS installer
#
# Copyright (C) 2026 MVGAL Project
# SPDX-License-Identifier: MIT

set -e

LOG_FILE="/var/log/mvgal-pkexec.log"
MVGAL_CONFIG="/etc/mvgal/mvgal.conf"

# Parse global options before the action so callers can route config writes
# to a non-default file:
#   pkexec mvgal-pkexec-helper.sh --config /path/to.conf set-strategy hybrid
# The path is validated against shell metacharacters before use.
while [ $# -gt 0 ]; do
    case "$1" in
        -c|--config)
            if [ $# -lt 2 ]; then
                echo "Error: --config requires a path" >&2
                exit 1
            fi
            case "$2" in
                *[!A-Za-z0-9_./-]*|"")
                    echo "Error: invalid config path: $2" >&2
                    exit 1
                    ;;
            esac
            MVGAL_CONFIG="$2"
            shift 2
            ;;
        *)
            break
            ;;
    esac
done

ACTION="${1:-}"

# Logging function
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $*" >> "$LOG_FILE"
}

# Error handler
error_exit() {
    log "ERROR: $1"
    echo "Error: $1" >&2
    exit 1
}

# Print a hint when a module load failure is likely caused by Secure Boot
# rejecting the unsigned/un-enrolled module signature (test report C1).
secure_boot_hint() {
    if command -v mokutil >/dev/null 2>&1 && mokutil --sb-state 2>/dev/null | grep -qi "enabled"; then
        echo "Secure Boot is enabled. If the module signature was rejected, enroll the" >&2
        echo "MVGAL signing key in the MOK database and reboot:" >&2
        echo "    pkexec mvgal-enroll-mok" >&2
        echo "    pkexec reboot" >&2
        echo "(The certificate is /var/lib/mvgal/keys/mvgal-signing.der)" >&2
    fi
}

# Check if running with elevated privileges
check_privileges() {
    if [ "$(id -u)" -ne 0 ]; then
        error_exit "This operation requires root privileges"
    fi
}

# Load kernel module
load_module() {
    log "Loading MVGAL kernel modules"

    local MVGAL_MODULES=(
        "mvgal"         # Combined core + device + all subsystems
        "mvgal_ntsync"  # NTSYNC synchronization
        "mvgal_nvidia"  # NVIDIA vendor driver
        "mvgal_amd"     # AMD vendor driver
        "mvgal_intel"   # Intel vendor driver
    )
    local MODULE_DIR="/lib/modules/$(uname -r)/kernel/drivers/gpu/drm/mvgal"

    for MODULE in "${MVGAL_MODULES[@]}"; do
        if lsmod | grep -q "^${MODULE} "; then
            log "Module $MODULE already loaded"
            continue
        fi

        # Try modprobe first (preferred)
        if modprobe "${MODULE}" 2>/dev/null; then
            log "Module $MODULE loaded via modprobe"
            continue
        fi

        # Fallback to insmod
        local MODULE_PATH="${MODULE_DIR}/${MODULE}.ko"
        if [ -f "$MODULE_PATH" ] && insmod "$MODULE_PATH" 2>/dev/null; then
            log "Module $MODULE loaded via insmod from $MODULE_PATH"
            continue
        fi

        secure_boot_hint
        error_exit "Failed to load $MODULE. Check dmesg for details."
    done

    # Set device node permissions — group-writable only (not world-writable)
    # Uses the 'video' group which is standard for GPU device nodes on Linux.
    for dev in /dev/mvgal*; do
        if [ -e "$dev" ]; then
            chown root:video "$dev" 2>/dev/null || true
            chmod 660 "$dev" 2>/dev/null || true
        fi
    done

    log "All MVGAL modules loaded successfully"
    echo "MVGAL kernel modules loaded successfully"
}

# Unload kernel module
unload_module() {
    log "Unloading MVGAL kernel modules"

    local UNLOAD_ORDER=(
        "mvgal_intel"
        "mvgal_amd"
        "mvgal_nvidia"
        "mvgal_ntsync"
        "mvgal"
    )

    # Stop daemon first if running
    if systemctl is-active --quiet mvgald 2>/dev/null; then
        log "Stopping mvgald daemon"
        systemctl stop mvgald || true
    fi

    # Gracefully close open file descriptors to device nodes.
    # Send SIGTERM first so processes can clean up; escalate to SIGKILL
    # only for stragglers after a short grace period.
    for dev in /dev/mvgal*; do
        if [ -e "$dev" ]; then
            local pids
            pids=$(lsof "$dev" 2>/dev/null | awk 'NR>1 {print $2}' | sort -u)
            if [ -n "$pids" ]; then
                echo "$pids" | xargs -r kill -TERM 2>/dev/null || true
                sleep 1
                # Re-check which processes survived SIGTERM
                pids=$(lsof "$dev" 2>/dev/null | awk 'NR>1 {print $2}' | sort -u)
                if [ -n "$pids" ]; then
                    echo "$pids" | xargs -r kill -9 2>/dev/null || true
                fi
            fi
        fi
    done

    # Unload in reverse dependency order
    for MODULE in "${UNLOAD_ORDER[@]}"; do
        if ! lsmod | grep -q "^${MODULE} "; then
            continue
        fi

        if modprobe -r "${MODULE}" 2>/dev/null || rmmod "${MODULE}" 2>/dev/null; then
            log "Module $MODULE unloaded"
        else
            log "Warning: Failed to unload $MODULE (may be in use)"
        fi
    done

    if lsmod | grep -q "^mvgal"; then
        error_exit "Some MVGAL modules could not be unloaded. Check lsmod."
    fi

    log "All MVGAL modules unloaded successfully"
    echo "MVGAL kernel modules unloaded successfully"
}

# Enable GPU
enable_gpu() {
    local gpu_index="${1:-}"
    if [ -z "$gpu_index" ]; then
        error_exit "GPU index required"
    fi
    
    log "Enabling GPU $gpu_index"
    
    # Write to sysfs or use ioctl
    if [ -e "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled" ]; then
        echo 1 > "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled"
        log "GPU $gpu_index enabled via sysfs"
    fi
    
    # Update config — only edit the specific [gpu_N] section, not all sections.
    # If the section does not exist yet, create it at the end of the file.
    if [ -f "$MVGAL_CONFIG" ]; then
        if grep -q "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG"; then
            sed -i "/^\[gpu_${gpu_index}\]/,/^\[/{s/^enabled = false/enabled = true/}" "$MVGAL_CONFIG" 2>/dev/null || true
            if ! grep -A65535 "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG" | grep -q "^enabled[[:space:]]*="; then
                sed -i "/^\[gpu_${gpu_index}\]/a enabled = true" "$MVGAL_CONFIG" 2>/dev/null || true
            fi
        else
            printf '\n[gpu_%s]\nenabled = true\n' "$gpu_index" >> "$MVGAL_CONFIG"
        fi
        SIGHUP_DAEMON=1
    fi
    
    echo "GPU $gpu_index enabled in MVGAL"
}

# Disable GPU
disable_gpu() {
    local gpu_index="${1:-}"
    if [ -z "$gpu_index" ]; then
        error_exit "GPU index required"
    fi
    
    log "Disabling GPU $gpu_index"
    
    # Write to sysfs
    if [ -e "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled" ]; then
        echo 0 > "/sys/class/mvgal/mvgal0/gpu${gpu_index}/enabled"
        log "GPU $gpu_index disabled via sysfs"
    fi

    # Update config — mirror enable_gpu so the state survives restarts.
    # Only edit the specific [gpu_N] section, not all sections.
    # If the section does not exist yet, create it at the end of the file.
    if [ -f "$MVGAL_CONFIG" ]; then
        if grep -q "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG"; then
            sed -i "/^\[gpu_${gpu_index}\]/,/^\[/{s/^enabled = true/enabled = false/}" "$MVGAL_CONFIG" 2>/dev/null || true
            if ! grep -A65535 "^\[gpu_${gpu_index}\]" "$MVGAL_CONFIG" | grep -q "^enabled[[:space:]]*="; then
                sed -i "/^\[gpu_${gpu_index}\]/a enabled = false" "$MVGAL_CONFIG" 2>/dev/null || true
            fi
        else
            printf '\n[gpu_%s]\nenabled = false\n' "$gpu_index" >> "$MVGAL_CONFIG"
        fi
        SIGHUP_DAEMON=1
    fi

    echo "GPU $gpu_index disabled in MVGAL"
}

# Set GPU power state
set_power_state() {
    local gpu_index="${1:-}"
    local state="${2:-}"
    
    if [ -z "$gpu_index" ] || [ -z "$state" ]; then
        error_exit "Usage: set-power <gpu_index> <state (auto|on|off)>"
    fi
    
    log "Setting GPU $gpu_index power state to $state"
    
    # Validate state
    case "$state" in
        auto|on|off)
            ;;
        *)
            error_exit "Invalid power state: $state (must be auto, on, or off)"
            ;;
    esac
    
    # Find the GPU PCI device
    local pci_path="/sys/class/mvgal/mvgal0/gpu${gpu_index}/pci_path"
    if [ -f "$pci_path" ]; then
        local pci_addr
        pci_addr=$(cat "$pci_path")
        local power_control="/sys/bus/pci/devices/${pci_addr}/power/control"
        
        if [ -f "$power_control" ]; then
            echo "$state" > "$power_control"
            log "Power state set via PCI power control"
        fi
    fi
    
    # Also set via sysfs
    if [ -e "/sys/class/mvgal/mvgal0/gpu${gpu_index}/power_state" ]; then
        echo "$state" > "/sys/class/mvgal/mvgal0/gpu${gpu_index}/power_state"
    fi
    
    echo "GPU $gpu_index power state set to $state"
}

# Rescan GPUs
rescan_gpus() {
    log "Rescanning for GPU changes"
    
    if [ -e "/sys/class/mvgal/mvgal0/rescan" ]; then
        echo 1 > "/sys/class/mvgal/mvgal0/rescan"
        log "Rescan triggered via sysfs"
        echo "GPU rescan initiated"
    else
        error_exit "Rescan interface not available — is the mvgal kernel module loaded? (Try: mvgal load-module)"
    fi
}

# Reload configuration
reload_config() {
    log "Reloading MVGAL configuration"
    
    # Signal daemon if running
    if systemctl is-active --quiet mvgald 2>/dev/null; then
        systemctl kill -s HUP mvgald || true
        log "Sent SIGHUP to mvgald"
    fi
    
    echo "Configuration reload triggered"
}

# Install Vulkan layer
install_vulkan_layer() {
    log "Installing MVGAL Vulkan implicit layer"
    
    local layer_src="/usr/share/vulkan/implicit_layer.d/VK_LAYER_MVGAL.json"
    local layer_dst="/etc/vulkan/implicit_layer.d/VK_LAYER_MVGAL.json"
    
    if [ -f "$layer_src" ]; then
        mkdir -p "$(dirname "$layer_dst")"
        cp "$layer_src" "$layer_dst"
        chmod 644 "$layer_dst"
        log "Vulkan layer installed to $layer_dst"
        echo "Vulkan implicit layer installed"
    else
        error_exit "Vulkan layer source not found: $layer_src"
    fi
}

# Remove Vulkan layer
remove_vulkan_layer() {
    log "Removing MVGAL Vulkan implicit layer"
    
    local layer_file="/etc/vulkan/implicit_layer.d/VK_LAYER_MVGAL.json"
    
    if [ -f "$layer_file" ]; then
        rm -f "$layer_file"
        log "Vulkan layer removed"
        echo "Vulkan implicit layer removed"
    else
        log "Vulkan layer not installed"
        echo "Vulkan implicit layer was not installed"
    fi
}

# Install Moore Threads DKMS driver
install_mtt_driver() {
    log "Starting Moore Threads DKMS installer"

    local installer="/usr/share/mvgal/scripts/mtt-dkms-installer.sh"
    if [ ! -x "$installer" ]; then
        error_exit "MTT installer not found or not executable: $installer"
    fi

    "$installer" install
}

# Persist a single key under an INI section of the MVGAL config file.
# Usage: set_config_value <section> <key> <value>
set_config_value() {
    local section="$1" key="$2" value="$3"
    local conf="${MVGAL_CONFIG:-/etc/mvgal/mvgal.conf}"
    [ -f "$conf" ] || error_exit "Config file not found: $conf"

    # Validate inputs: section/key are identifiers, value has no metacharacters
    case "$section" in *[!A-Za-z0-9_]*|"") error_exit "Invalid section" ;; esac
    case "$key" in *[!A-Za-z0-9_]*|"") error_exit "Invalid key" ;; esac
    # Each alternative quoted separately — a combined bracket expression like
    # *[\'"`;&<>|]* breaks out of quoting and corrupts the rest of the script.
    case "$value" in *\\*|*"'"*|*\`*|*";"*|*"&"*|*"<"*|*">"*|*"|"*|"") error_exit "Invalid value" ;; esac

    # Replace (or append) 'key = value' inside '[section]' only.
    if sed -i "/^\[${section}\]/,/^\[/ { s|^[[:space:]]*${key}[[:space:]]*=.*|${key} = ${value}|; }" "$conf"; then
        # Section-scoped existence check: only look inside '[section]' so a key
        # that also appears in a LATER section does not suppress the append.
        if ! awk -v sec="[${section}]" -v key="${key}" '
            $0 == sec { in_sec = 1; next }
            /^\[/ && in_sec { in_sec = 0 }
            in_sec && $0 ~ "^[[:space:]]*" key "[[:space:]]*=" { found = 1 }
            END { exit !found }
        ' "$conf"; then
            # Key not present in the section — append it right after the header
            sed -i "/^\[${section}\]/a ${key} = ${value}" "$conf"
        fi
        log "Set ${section}.${key} = ${value}"
        SIGHUP_DAEMON=1
    else
        error_exit "Failed to update $conf"
    fi
}

# Main entry point
main() {
    check_privileges

    log "Action requested: $ACTION"

    case "$ACTION" in
        load-module)
            load_module
            ;;
        unload-module)
            unload_module
            ;;
        enable-gpu)
            enable_gpu "$2"
            ;;
        disable-gpu)
            disable_gpu "$2"
            ;;
        set-power)
            set_power_state "$2" "$3"
            ;;
        rescan-gpus)
            rescan_gpus
            ;;
        reload-config)
            reload_config
            ;;
        install-vulkan-layer)
            install_vulkan_layer
            ;;
        remove-vulkan-layer)
            remove_vulkan_layer
            ;;
        install-mtt-driver)
            install_mtt_driver
            ;;
        set-strategy)
            # Validated against the union of names accepted by the daemon
            # config parser and the CLI, so a persisted value always
            # round-trips (status and config file stay in sync).
            case "${2-}" in
                single|single_gpu|hybrid|task|afr|sfr|compute|compute_offload|round_robin|auto|custom)
                    set_config_value "core" "default_strategy" "$2"
                    ;;
                *) error_exit "Unknown strategy: ${2-}" ;;
            esac
            ;;
        set-priority)
            case "${2-}" in ''|*[!0-9]*) error_exit "Usage: set-priority <gpu_index> <priority 0-100>" ;; esac
            case "${3-}" in ''|*[!0-9]*) error_exit "Usage: set-priority <gpu_index> <priority 0-100>" ;; esac
            [ "$2" -le 63 ] || error_exit "GPU index out of range"
            [ "$3" -le 100 ] || error_exit "Priority out of range"
            set_config_value "gpu_$2" "priority" "$3"
            ;;
        psu-config)
            # psu-config <capacity_watts> <safety_margin_percent>
            case "${2-}" in ''|*[!0-9]*) error_exit "Usage: psu-config <capacity_watts> <margin_percent>" ;; esac
            case "${3-}" in ''|*[!0-9]*) error_exit "Usage: psu-config <capacity_watts> <margin_percent>" ;; esac
            set_config_value "power" "psu_capacity_watts" "$2"
            set_config_value "power" "psu_safety_margin_percent" "$3"
            ;;
        psu-headroom)
            # psu-headroom <on|off> — enable/disable PSU headroom tracking
            case "${2-}" in
                on|true|1|yes) set_config_value "power" "enable_psu_headroom" "true" ;;
                off|false|0|no) set_config_value "power" "enable_psu_headroom" "false" ;;
                *) error_exit "Usage: psu-headroom <on|off>" ;;
            esac
            ;;
        set-power-curve)
            # set-power-curve <profile> — persist the active curve profile
            case "${2-}" in
                silent|balanced|performance|custom)
                    set_config_value "power" "power_curve_profile" "$2"
                    ;;
                *) error_exit "Unknown power-curve profile: ${2-} (expected silent|balanced|performance|custom)" ;;
            esac
            ;;
        *)
            echo "Usage: $0 <action> [args...]"
            echo ""
            echo "Actions:"
            echo "  load-module              Load the MVGAL kernel module"
            echo "  unload-module            Unload the MVGAL kernel module"
            echo "  enable-gpu N             Enable GPU at index N"
            echo "  disable-gpu N            Disable GPU at index N"
            echo "  set-power GPU STATE      Set GPU power state (auto|on|off)"
            echo "  rescan-gpus              Rescan for GPU changes"
            echo "  reload-config            Reload MVGAL configuration"
            echo "  install-vulkan-layer     Install Vulkan implicit layer"
            echo "  remove-vulkan-layer      Remove Vulkan implicit layer"
            echo "  install-mtt-driver       Install Moore Threads DKMS driver"
            echo "  set-strategy NAME        Persist default_strategy to config"
            echo "  set-priority N P         Persist priority P for GPU N"
            echo "  psu-config WATTS MARGIN  Persist PSU capacity and margin"
            echo "  psu-headroom ON|OFF     Enable/disable PSU headroom tracking"
            echo "  set-power-curve PROFILE  Persist power-curve profile"
            exit 1
            ;;
    esac

    # Ask the daemon to pick up persisted changes (best effort)
    if [ "${SIGHUP_DAEMON:-0}" = "1" ]; then
        pkill -HUP -x mvgald 2>/dev/null || true
    fi
}

main "$@"
