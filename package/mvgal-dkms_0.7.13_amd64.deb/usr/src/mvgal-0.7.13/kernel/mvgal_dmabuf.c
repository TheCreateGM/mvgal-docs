/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 *
 * Shared DMA-BUF import / export implementations
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/dma-buf.h>
#include <linux/dma-direction.h>
#include <linux/vmalloc.h>

#include "mvgal_dmabuf.h"
#include "mvgal_dma.h"

int mvgal_dmabuf_attach_and_map(struct dma_buf *buf, struct device *dev,
                                 enum dma_data_direction dir,
                                 struct mvgal_dmabuf_state *state)
{
    struct dma_buf_attachment *attach;
    struct sg_table *sgt;

    if (!buf || !dev || !state)
        return -EINVAL;

    attach = dma_buf_attach(buf, dev);
    if (IS_ERR(attach))
        return PTR_ERR(attach);

    sgt = dma_buf_map_attachment(attach, dir);
    if (IS_ERR(sgt)) {
        dma_buf_detach(buf, attach);
        return PTR_ERR(sgt);
    }

    state->dmabuf = buf;
    state->attach = attach;
    state->sgt    = sgt;
    state->dir    = dir;
    return 0;
}
EXPORT_SYMBOL_GPL(mvgal_dmabuf_attach_and_map);

void mvgal_dmabuf_unmap_and_detach(struct mvgal_dmabuf_state *state)
{
    if (!state)
        return;

    if (state->sgt && state->attach)
        dma_buf_unmap_attachment(state->attach, state->sgt, state->dir);
    if (state->attach && state->dmabuf)
        dma_buf_detach(state->dmabuf, state->attach);

    state->dmabuf = NULL;
    state->attach = NULL;
    state->sgt    = NULL;
    state->dir    = DMA_NONE;
}
EXPORT_SYMBOL_GPL(mvgal_dmabuf_unmap_and_detach);

int mvgal_dmabuf_reexport(struct mvgal_dmabuf_state *state, int *out_fd)
{
    int fd;

    if (!state || !state->dmabuf || !out_fd)
        return -EINVAL;

    fd = dma_buf_fd(state->dmabuf, O_CLOEXEC);
    if (fd < 0)
        return fd;

    /* dma_buf_fd does not take a reference — take one so the caller
     * owns the fd independently of our import reference. */
    get_dma_buf(state->dmabuf);
    *out_fd = fd;
    return 0;
}
EXPORT_SYMBOL_GPL(mvgal_dmabuf_reexport);

/* ─── Export helpers ─────────────────────────────────────────── */

/**
 * mvgal_dmabuf_export_map - .map_dma_buf callback for exported buffers
 *
 * Returns the pre-created sg_table stored in priv.  The table is
 * persistent for the lifetime of the dma_buf.
 */
static struct sg_table *
mvgal_dmabuf_export_map(struct dma_buf_attachment *attachment,
                         enum dma_data_direction direction)
{
    struct mvgal_dmabuf_export_priv *priv = attachment->dmabuf->priv;

    if (!priv || !priv->sgt)
        return ERR_PTR(-EINVAL);

    return priv->sgt;
}

/**
 * mvgal_dmabuf_export_unmap - .unmap_dma_buf callback (no-op)
 *
 * The sg_table is owned by the dma_buf and freed in .release.
 */
static void
mvgal_dmabuf_export_unmap(struct dma_buf_attachment *attachment,
                           struct sg_table *sgt,
                           enum dma_data_direction direction)
{
    /* sgt is persistent — nothing to free here. */
}

/**
 * mvgal_dmabuf_export_release - .release callback
 *
 * Frees the sg_table that was transferred to us in mvgal_dmabuf_export().
 */
static void
mvgal_dmabuf_export_release(struct dma_buf *dmabuf)
{
    struct mvgal_dmabuf_export_priv *priv = dmabuf->priv;
    int i;

    if (priv) {
        if (priv->sgt) {
            sg_free_table(priv->sgt);
            kfree(priv->sgt);
        }
        if (priv->pages) {
            for (i = 0; i < priv->npages; i++) {
                if (priv->pages[i])
                    __free_page(priv->pages[i]);
            }
            kvfree(priv->pages);
        }
        kfree(priv);
        dmabuf->priv = NULL;
    }
}

/**
 * mvgal_dmabuf_export_mmap - .mmap callback (not supported)
 *
 * Exported buffers backed by arbitrary sg_tables do not have a single
 * contiguous page range that can be mmap'd directly.
 */
static int
mvgal_dmabuf_export_mmap(struct dma_buf *dmabuf, struct vm_area_struct *vma)
{
    return -ENODEV;
}

static const struct dma_buf_ops mvgal_dmabuf_export_ops = {
    .map_dma_buf    = mvgal_dmabuf_export_map,
    .unmap_dma_buf  = mvgal_dmabuf_export_unmap,
    .release        = mvgal_dmabuf_export_release,
    .mmap           = mvgal_dmabuf_export_mmap,
};

struct dma_buf *mvgal_dmabuf_export(struct sg_table *sgt, size_t size,
                                     unsigned int flags)
{
    DEFINE_DMA_BUF_EXPORT_INFO(exp_info);
    struct mvgal_dmabuf_export_priv *priv;

    if (!sgt || !size)
        return ERR_PTR(-EINVAL);

    priv = kzalloc(sizeof(*priv), GFP_KERNEL);
    if (!priv)
        return ERR_PTR(-ENOMEM);

    priv->sgt  = sgt;
    priv->size = size;

    exp_info.ops   = &mvgal_dmabuf_export_ops;
    exp_info.size  = size;
    exp_info.flags = flags;
    exp_info.priv  = priv;

    return dma_buf_export(&exp_info);
}
EXPORT_SYMBOL_GPL(mvgal_dmabuf_export);

int mvgal_dmabuf_export_fd(struct sg_table *sgt, size_t size,
                            unsigned int flags, int *out_fd)
{
    struct dma_buf *dmabuf;
    int fd;

    if (!out_fd)
        return -EINVAL;

    dmabuf = mvgal_dmabuf_export(sgt, size, flags);
    if (IS_ERR(dmabuf))
        return PTR_ERR(dmabuf);

    fd = dma_buf_fd(dmabuf, O_CLOEXEC);
    if (fd < 0) {
        dma_buf_put(dmabuf);
        return fd;
    }

    *out_fd = fd;
    return 0;
}
EXPORT_SYMBOL_GPL(mvgal_dmabuf_export_fd);

struct dma_buf *mvgal_dmabuf_export_host(size_t size, unsigned int flags)
{
    struct mvgal_dmabuf_export_priv *priv;
    struct sg_table *sgt;
    struct dma_buf *dmabuf;
    struct page **pages;
    struct scatterlist *sg;
    int npages;
    int i;
    int ret;

    if (!size)
        return ERR_PTR(-EINVAL);

    npages = (int)mvgal_dma_page_count(size);
    pages = kvcalloc(npages, sizeof(*pages), GFP_KERNEL);
    if (!pages)
        return ERR_PTR(-ENOMEM);

    for (i = 0; i < npages; i++) {
        pages[i] = alloc_page(GFP_KERNEL | __GFP_ZERO);
        if (!pages[i]) {
            while (i--)
                __free_page(pages[i]);
            kvfree(pages);
            return ERR_PTR(-ENOMEM);
        }
    }

    sgt = kzalloc(sizeof(*sgt), GFP_KERNEL);
    if (!sgt) {
        for (i = 0; i < npages; i++)
            __free_page(pages[i]);
        kvfree(pages);
        return ERR_PTR(-ENOMEM);
    }

    ret = sg_alloc_table(sgt, npages, GFP_KERNEL);
    if (ret) {
        kfree(sgt);
        for (i = 0; i < npages; i++)
            __free_page(pages[i]);
        kvfree(pages);
        return ERR_PTR(ret);
    }

    for_each_sg(sgt->sgl, sg, sgt->orig_nents, i)
        sg_set_page(sg, pages[i], PAGE_SIZE, 0);

    /*
     * Use a temporary priv via mvgal_dmabuf_export, then attach page
     * ownership so release frees both the sgt and the pages.
     */
    dmabuf = mvgal_dmabuf_export(sgt, size, flags);
    if (IS_ERR(dmabuf)) {
        sg_free_table(sgt);
        kfree(sgt);
        for (i = 0; i < npages; i++)
            __free_page(pages[i]);
        kvfree(pages);
        return dmabuf;
    }

    priv = dmabuf->priv;
    priv->pages = pages;
    priv->npages = npages;
    return dmabuf;
}
EXPORT_SYMBOL_GPL(mvgal_dmabuf_export_host);
