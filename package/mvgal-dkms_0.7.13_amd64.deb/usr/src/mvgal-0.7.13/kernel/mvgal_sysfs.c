/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 *
 * Sysfs Interface — Exposes /sys/class/mvgal/mvgal0/ with device-level
 * and per-GPU attributes per KERNEL_INTERFACE_SPEC.md Section 4.
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */

#include <linux/device.h>
#include <linux/kobject.h>
#include <linux/sysfs.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/kconfig.h>

#include "mvgal_core.h"
#include "mvgal_device.h"

#define MVGAL_CLASS_NAME	"mvgal"
#define MVGAL_DEV_NAME		"mvgal0"

/* Per-GPU sysfs directory */
struct mvgal_gpu_sysfs {
	struct kobject kobj;
	struct mvgal_gpu_device *gpu;
	struct mvgal_device *dev;
	unsigned int index;
};

static struct class *mvgal_class;
static struct device *mvgal_class_device;
static struct kobject *mvgal_root_kobj;

/* ---- Device-level attributes ---- */

/* gpu_count */
static ssize_t gpu_count_show(struct kobject *kobj,
			      struct kobj_attribute *attr, char *buf)
{
	struct mvgal_device *dev;
	unsigned int count = 0;
	struct mvgal_gpu_device *gpu;

	if (!mvgal_logical_device)
		return sysfs_emit(buf, "0\n");

	dev = mvgal_logical_device;
	mutex_lock(&dev->gpu_lock);
	list_for_each_entry(gpu, &dev->gpu_list, node)
		count++;
	mutex_unlock(&dev->gpu_lock);

	return sysfs_emit(buf, "%u\n", count);
}
static struct kobj_attribute gpu_count_attr = __ATTR_RO(gpu_count);

/* topology_generation */
static ssize_t topology_generation_show(struct kobject *kobj,
					struct kobj_attribute *attr,
					char *buf)
{
	if (!mvgal_logical_device)
		return sysfs_emit(buf, "0\n");

	return sysfs_emit(buf, "%lu\n", mvgal_logical_device->topology_generation);
}
static struct kobj_attribute topology_generation_attr =
	__ATTR_RO(topology_generation);

/* rescan (write-only: echo 1 to trigger rescan) */
static ssize_t rescan_store(struct kobject *kobj,
			    struct kobj_attribute *attr,
			    const char *buf, size_t count)
{
	int val;
	int ret;

	if (!mvgal_logical_device)
		return -ENODEV;

	ret = kstrtoint(buf, 10, &val);
	if (ret)
		return ret;

	if (val != 1)
		return -EINVAL;

	pr_info("MVGAL: sysfs rescan triggered\n");

	/* Clean up existing GPUs and rescan */
	mvgal_gpu_cleanup_all(mvgal_logical_device);
	ret = mvgal_enumerate_gpus(mvgal_logical_device);
	if (ret < 0)
		pr_warn("MVGAL: sysfs rescan enumeration failed: %d\n", ret);

	mvgal_logical_device->topology_generation++;
	atomic64_inc(&mvgal_logical_device->stats.rescans);

	return count;
}
static struct kobj_attribute rescan_attr = __ATTR_WO(rescan);

/* ---- Per-GPU attributes ---- */

/* gpu_index */
static ssize_t gpu_index_show(struct kobject *kobj,
			      struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);

	return sysfs_emit(buf, "%u\n", gpudev->gpu->gpu_index);
}
static struct kobj_attribute gpu_index_attr = __ATTR_RO(gpu_index);

/* enabled */
static ssize_t enabled_show(struct kobject *kobj,
			    struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);

	return sysfs_emit(buf, "%d\n", gpudev->gpu->enabled ? 1 : 0);
}

static ssize_t enabled_store(struct kobject *kobj,
			     struct kobj_attribute *attr,
			     const char *buf, size_t count)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	int val;
	int ret;

	ret = kstrtoint(buf, 10, &val);
	if (ret)
		return ret;

	if (val != 0 && val != 1)
		return -EINVAL;

	mutex_lock(&gpudev->gpu->lock);
	gpudev->gpu->enabled = (val == 1);
	mutex_unlock(&gpudev->gpu->lock);

	return count;
}
static struct kobj_attribute enabled_attr = __ATTR_RW(enabled);

/* name */
static ssize_t name_show(struct kobject *kobj,
			 struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);

	return sysfs_emit(buf, "%s\n", gpudev->gpu->name);
}
static struct kobj_attribute name_attr = __ATTR_RO(name);

/* vendor */
static ssize_t vendor_show(struct kobject *kobj,
			   struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);

	return sysfs_emit(buf, "0x%04x\n", gpudev->gpu->pci_vendor_id);
}
static struct kobj_attribute vendor_attr = __ATTR_RO(vendor);

/* vram_size */
static ssize_t vram_size_show(struct kobject *kobj,
			      struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);

	return sysfs_emit(buf, "%llu\n", gpudev->gpu->vram_size);
}
static struct kobj_attribute vram_size_attr = __ATTR_RO(vram_size);

/* pci_path */
static ssize_t pci_path_show(struct kobject *kobj,
			     struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);

	if (!gpudev->gpu->pdev)
		return sysfs_emit(buf, "N/A\n");

	return sysfs_emit(buf, "%s\n", dev_name(&gpudev->gpu->pdev->dev));
}
static struct kobj_attribute pci_path_attr = __ATTR_RO(pci_path);

/* power_state */
static ssize_t power_state_show(struct kobject *kobj,
				struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	const char *state;

	switch (gpudev->gpu->power_state) {
	case MVGAL_DEVICE_POWER_STATE_ACTIVE:
	case MVGAL_DEVICE_POWER_STATE_SUSTAINED:
		state = "on";
		break;
	case MVGAL_DEVICE_POWER_STATE_IDLE:
		state = "idle";
		break;
	case MVGAL_DEVICE_POWER_STATE_PARK:
		state = "off";
		break;
	case MVGAL_DEVICE_POWER_STATE_OFF:
		state = "off";
		break;
	default:
		state = "unknown";
		break;
	}

	return sysfs_emit(buf, "%s\n", state);
}

static ssize_t power_state_store(struct kobject *kobj,
				 struct kobj_attribute *attr,
				 const char *buf, size_t count)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);

	mutex_lock(&gpudev->gpu->lock);

	if (sysfs_streq(buf, "on")) {
		gpudev->gpu->power_state = MVGAL_DEVICE_POWER_STATE_ACTIVE;
		gpudev->gpu->enabled = true;
	} else if (sysfs_streq(buf, "off")) {
		gpudev->gpu->power_state = MVGAL_DEVICE_POWER_STATE_OFF;
		gpudev->gpu->enabled = false;
	} else if (sysfs_streq(buf, "auto")) {
		/* Restore to default — enabled with automatic power mgmt */
		gpudev->gpu->power_state = MVGAL_DEVICE_POWER_STATE_ACTIVE;
		gpudev->gpu->enabled = true;
	} else {
		mutex_unlock(&gpudev->gpu->lock);
		return -EINVAL;
	}

	mutex_unlock(&gpudev->gpu->lock);

	return count;
}
static struct kobj_attribute power_state_attr = __ATTR_RW(power_state);

/* capabilities */
static ssize_t capabilities_show(struct kobject *kobj,
				 struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	struct mvgal_gpu_device *gpu = gpudev->gpu;
	ssize_t len = 0;
	int i;

	/*
	 * Print only capabilities the probe actually verified.  A GPU whose
	 * probe has not run reports "none", so an unprobed device can never be
	 * mistaken for a fully capable one.
	 */
	if (!gpu->caps_probed) {
		return sysfs_emit(buf, "none\n");
	}

	len += sysfs_emit_at(buf, len, "0x%02x", gpu->cap_flags);
	for (i = 0; i < 8; i++) {
		uint32_t bit = (uint32_t)(1u << i);

		if (gpu->cap_flags & bit)
			len += sysfs_emit_at(buf, len, " %s",
					     mvgal_cap_name(bit));
	}
	len += sysfs_emit_at(buf, len, "\n");

	return len;
}
static struct kobj_attribute capabilities_attr = __ATTR_RO(capabilities);

/* native_driver - which driver actually owns the PCI function */
static ssize_t native_driver_show(struct kobject *kobj,
				  struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	const char *driver = gpudev->gpu->pdev ?
			     mvgal_native_driver(gpudev->gpu->pdev) : NULL;

	/*
	 * "none" means no driver owns this GPU.  Without one, amdgpu/nvidia/
	 * i915/xe/mtgpu is not loaded, and the capability probe will have
	 * reported nothing usable.
	 */
	return sysfs_emit(buf, "%s\n", driver ? driver : "none");
}
static struct kobj_attribute native_driver_attr = __ATTR_RO(native_driver);

/* ---------------------------------------------------------------------------
 * Idle gate control
 *
 * The gate puts a GPU into its low-power state after a period with no
 * measurable work.  It is only offered on GPUs that expose a real busy
 * signal; where none exists the gate is never armed and enabling it fails
 * with -EOPNOTSUPP rather than gating on a guess.
 * ------------------------------------------------------------------------- */

/* Accepts "0" to disable, any other integer to enable. */
static ssize_t idle_gate_store(struct kobject *kobj,
			       struct kobj_attribute *attr,
			       const char *buf, size_t count)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	int ret;
	bool enable;

	if (kstrtobool(buf, &enable))
		return -EINVAL;

	ret = mvgal_idle_gate_set_enabled(gpudev->gpu, enable);
	if (ret)
		return ret;

	return count;
}
static struct kobj_attribute idle_gate_attr = __ATTR_WO(idle_gate);

/*
 * Report why the gate is or is not doing anything.  "unavailable" means the
 * GPU exposes no busy signal, which is a different thing from "disabled":
 * a disabled gate can be turned on, an unavailable one cannot.
 */
static ssize_t idle_gate_status_show(struct kobject *kobj,
				     struct kobj_attribute *attr, char *buf)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	struct mvgal_idle_gate gate;
	const char *state;
	int ret;

	ret = mvgal_idle_gate_get(gpudev->gpu, &gate);
	if (ret == -ENODEV)
		return sysfs_emit(buf, "absent\n");
	if (ret)
		return ret;

	if (!gate.armed)
		state = "unavailable";
	else if (gate.gated)
		state = "gated";
	else if (gate.enabled)
		state = "watching";
	else
		state = "disabled";

	return sysfs_emit(buf, "%s %lu\n", state, gate.timeout_ms);
}
static struct kobj_attribute idle_gate_status_attr = __ATTR_RO(idle_gate_status);

/* Idle time in milliseconds before the GPU is gated. */
static ssize_t idle_gate_timeout_store(struct kobject *kobj,
				       struct kobj_attribute *attr,
				       const char *buf, size_t count)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	unsigned long timeout_ms;
	int ret;

	if (kstrtoul(buf, 10, &timeout_ms))
		return -EINVAL;

	ret = mvgal_idle_gate_set_timeout(gpudev->gpu, timeout_ms);
	if (ret)
		return ret;

	return count;
}
static struct kobj_attribute idle_gate_timeout_attr = __ATTR_WO(idle_gate_timeout);

/* Per-GPU sysfs attribute group */
static struct attribute *gpu_attrs[] = {
	&gpu_index_attr.attr,
	&enabled_attr.attr,
	&name_attr.attr,
	&vendor_attr.attr,
	&vram_size_attr.attr,
	&pci_path_attr.attr,
	&power_state_attr.attr,
	&capabilities_attr.attr,
	&native_driver_attr.attr,
	&idle_gate_attr.attr,
	&idle_gate_status_attr.attr,
	&idle_gate_timeout_attr.attr,
	NULL,
};

static const struct attribute_group gpu_group = {
	.attrs = gpu_attrs,
};

static void gpu_sysfs_release(struct kobject *kobj)
{
	struct mvgal_gpu_sysfs *gpudev =
		container_of(kobj, struct mvgal_gpu_sysfs, kobj);
	kfree(gpudev);
}

static const struct kobj_type gpu_ktype = {
	.sysfs_ops	= &kobj_sysfs_ops,
	.release	= gpu_sysfs_release,
	.default_groups = (const struct attribute_group *[]){
		&gpu_group,
	},
};

/* Device-level sysfs attribute group */
static struct attribute *mvgal_attrs[] = {
	&gpu_count_attr.attr,
	&topology_generation_attr.attr,
	&rescan_attr.attr,
	NULL,
};

static const struct attribute_group mvgal_group = {
	.attrs = mvgal_attrs,
};

static const struct kobj_type mvgal_ktype = {
	.sysfs_ops	= &kobj_sysfs_ops,
	.default_groups = (const struct attribute_group *[]){
		&mvgal_group,
	},
};

/*
 * mvgal_sysfs_init — Create /sys/class/mvgal/mvgal0/ hierarchy
 *
 * Called from mvgal_init() after device creation.
 */
int mvgal_sysfs_init(struct mvgal_device *dev)
{
	struct mvgal_gpu_device *gpu;
	unsigned int gpu_idx = 0;
	int ret;

	if (!dev)
		return -EINVAL;

	/* Create class /sys/class/mvgal/
	 * Kernel < 6.4: class_create(THIS_MODULE, name)
	 * Kernel >= 6.4: class_create(name)
	 * RHEL 9+ backported the 1-arg form to their 5.14 kernel,
	 * so detect via RHEL_MAJOR from <linux/kconfig.h>.
	 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0) || \
	(defined(RHEL_MAJOR) && RHEL_MAJOR >= 9)
	mvgal_class = class_create(MVGAL_CLASS_NAME);
#else
	mvgal_class = class_create(THIS_MODULE, MVGAL_CLASS_NAME);
#endif
	if (IS_ERR(mvgal_class)) {
		pr_err("MVGAL: failed to create sysfs class\n");
		return PTR_ERR(mvgal_class);
	}

	/* Create class device /sys/class/mvgal/mvgal0/ */
	mvgal_class_device = device_create(mvgal_class, NULL,
					   MKDEV(0, 0), NULL,
					   MVGAL_DEV_NAME);
	if (IS_ERR(mvgal_class_device)) {
		pr_err("MVGAL: failed to create sysfs class device\n");
		ret = PTR_ERR(mvgal_class_device);
		goto err_class;
	}

	/* Create root kobject backed by the class device */
	mvgal_root_kobj = &mvgal_class_device->kobj;
	ret = kobject_init_and_add(mvgal_root_kobj, &mvgal_ktype,
				   NULL, MVGAL_DEV_NAME);
	if (ret) {
		pr_err("MVGAL: failed to create root sysfs kobject\n");
		goto err_device;
	}

	/* Create per-GPU subdirectories */
	mutex_lock(&dev->gpu_lock);
	list_for_each_entry(gpu, &dev->gpu_list, node) {
		struct mvgal_gpu_sysfs *gpudev;

		gpudev = kzalloc(sizeof(*gpudev), GFP_KERNEL);
		if (!gpudev)
			continue;

		gpudev->gpu = gpu;
		gpudev->dev = dev;
		gpudev->index = gpu_idx;

		ret = kobject_init_and_add(&gpudev->kobj, &gpu_ktype,
					   mvgal_root_kobj,
					   "gpu%u", gpu_idx);
		if (ret) {
			pr_warn("MVGAL: failed to create sysfs for GPU %u\n",
				gpu_idx);
			kobject_put(&gpudev->kobj);
			continue;
		}

		gpu_idx++;
	}
	mutex_unlock(&dev->gpu_lock);

	pr_info("MVGAL: sysfs interface created at /sys/class/mvgal/%s/ (%u GPUs)\n",
		MVGAL_DEV_NAME, gpu_idx);

	return 0;

err_device:
	device_destroy(mvgal_class, MKDEV(0, 0));
err_class:
	class_destroy(mvgal_class);
	mvgal_class = NULL;
	return ret;
}

/*
 * mvgal_sysfs_exit — Remove /sys/class/mvgal/mvgal0/ hierarchy
 *
 * Called from mvgal_exit() before device cleanup.
 */
void mvgal_sysfs_exit(struct mvgal_device *dev)
{
	struct mvgal_gpu_device *gpu;

	if (!mvgal_root_kobj)
		return;

	/* Remove per-GPU kobjects */
	if (dev) {
		mutex_lock(&dev->gpu_lock);
		list_for_each_entry(gpu, &dev->gpu_list, node) {
			/* The kobject is embedded in per-GPU sysfs struct,
			 * which is freed via gpu_sysfs_release() when the
			 * last reference drops. Nothing to do here —
			 * kobject_put happens when the parent is removed.
			 */
		}
		mutex_unlock(&dev->gpu_lock);
	}

	/* Release root kobject — cascades to children */
	kobject_put(mvgal_root_kobj);
	mvgal_root_kobj = NULL;

	if (mvgal_class_device) {
		device_destroy(mvgal_class, MKDEV(0, 0));
		mvgal_class_device = NULL;
	}

	if (mvgal_class) {
		class_destroy(mvgal_class);
		mvgal_class = NULL;
	}

	pr_info("MVGAL: sysfs interface removed\n");
}
