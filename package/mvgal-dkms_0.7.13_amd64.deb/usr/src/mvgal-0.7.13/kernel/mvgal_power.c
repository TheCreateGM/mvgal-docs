/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 *
 * Power Management - DVFS, Thermal Throttling, Dynamic Power Budgeting
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/workqueue.h>
#include <linux/delay.h>
#include <linux/thermal.h>
#include <linux/hwmon.h>
#include <linux/hwmon-sysfs.h>
#include <linux/device.h>
#include <linux/kobject.h>
#include <linux/sysfs.h>

#include "mvgal_core.h"
#include "mvgal_device.h"
#include "mvgal_power.h"

/* Default DVFS parameters */
#define MVGAL_DVFS_DEFAULT_MIN_FREQ_MHZ    300
#define MVGAL_DVFS_DEFAULT_MAX_FREQ_MHZ    2000
#define MVGAL_DVFS_DEFAULT_UP_THRESHOLD    80
#define MVGAL_DVFS_DEFAULT_DOWN_THRESHOLD  30
#define MVGAL_DVFS_DEFAULT_STEP_DELAY_MS  100

/* Default thermal parameters */
#define MVGAL_THERMAL_DEFAULT_THROTTLE_TEMP_C  75
#define MVGAL_THERMAL_DEFAULT_CRITICAL_TEMP_C  95

/* Default power budget parameters */
#define MVGAL_POWER_DEFAULT_TOTAL_WATTS     500
#define MVGAL_POWER_DEFAULT_HEADROOM_WATTS  50

/* DVFS workqueue */
static struct workqueue_struct *mvgal_dvfs_wq;

/* Global power management state */
static struct {
	struct mvgal_power_budget budget;
	bool initialized;
} mvgal_power_state;

/* Forward declarations */
static int mvgal_set_gpu_freq(struct mvgal_gpu_device *gpu, uint32_t freq_mhz);
static int mvgal_get_gpu_freq(struct mvgal_gpu_device *gpu, uint32_t *freq_mhz);
static int mvgal_read_gpu_temp(struct mvgal_gpu_device *gpu, int32_t *temp_c);
static int mvgal_read_gpu_power(struct mvgal_gpu_device *gpu, uint32_t *power_watts);

/**
 * Initialize DVFS for a GPU
 */
int mvgal_dvfs_init(struct mvgal_gpu_device *gpu)
{
	struct mvgal_gpu_dvfs *dvfs;

	if (!gpu)
		return -EINVAL;

	dvfs = kzalloc(sizeof(*dvfs), GFP_KERNEL);
	if (!dvfs)
		return -ENOMEM;

	dvfs->gpu = gpu;
	dvfs->enabled = true;

	/* Set default policy */
	dvfs->policy.mode = MVGAL_DVFS_BALANCED;
	dvfs->policy.min_freq_mhz = MVGAL_DVFS_DEFAULT_MIN_FREQ_MHZ;
	dvfs->policy.max_freq_mhz = MVGAL_DVFS_DEFAULT_MAX_FREQ_MHZ;
	dvfs->policy.up_threshold = MVGAL_DVFS_DEFAULT_UP_THRESHOLD;
	dvfs->policy.down_threshold = MVGAL_DVFS_DEFAULT_DOWN_THRESHOLD;
	dvfs->policy.step_delay_ms = MVGAL_DVFS_DEFAULT_STEP_DELAY_MS;

	/* Initialize to max frequency */
	dvfs->current_freq_mhz = dvfs->policy.max_freq_mhz;
	dvfs->target_freq_mhz = dvfs->current_freq_mhz;

 spin_lock_init(&dvfs->lock);

	INIT_DELAYED_WORK(&dvfs->dvfs_work, NULL);

	gpu->dvfs = dvfs;

	pr_debug("MVGAL: DVFS initialized for GPU %s\n", gpu->name);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_dvfs_init);

/**
 * Cleanup DVFS for a GPU
 */
void mvgal_dvfs_fini(struct mvgal_gpu_device *gpu)
{
	struct mvgal_gpu_dvfs *dvfs;

	if (!gpu || !gpu->dvfs)
		return;

	dvfs = gpu->dvfs;

	cancel_delayed_work_sync(&dvfs->dvfs_work);
	kfree(dvfs);
	gpu->dvfs = NULL;

	pr_debug("MVGAL: DVFS cleaned up for GPU %s\n", gpu->name);
}
EXPORT_SYMBOL_GPL(mvgal_dvfs_fini);

/**
 * DVFS work handler - adjusts frequency based on utilization
 */
static void mvgal_dvfs_work_handler(struct work_struct *work)
{
	struct delayed_work *dwork = to_delayed_work(work);
	struct mvgal_gpu_dvfs *dvfs = container_of(dwork, struct mvgal_gpu_dvfs, dvfs_work);
	struct mvgal_gpu_device *gpu = dvfs->gpu;
	uint32_t utilization;
	int ret;

	if (!dvfs->enabled)
		return;

	/*
	 * Read live telemetry only when the capability probe confirmed the
	 * kernel exposes it.  Without BUSY_PERCENT the DVFS policy has no
	 * fresh signal, so fall back to the last value the daemon reported
	 * rather than reading a failed query as a measurement.
	 */
	if (mvgal_gpu_can(gpu, MVGAL_CAP_BUSY_PERCENT)) {
		ret = gpu->ops->query_utilization(gpu, &utilization);
		if (ret < 0)
			utilization = 0;
	} else {
		utilization = gpu->utilization;
	}

 spin_lock(&dvfs->lock);

	switch (dvfs->policy.mode) {
	case MVGAL_DVFS_PERFORMANCE:
		dvfs->target_freq_mhz = dvfs->policy.max_freq_mhz;
		break;

	case MVGAL_DVFS_POWERSAVE:
		dvfs->target_freq_mhz = dvfs->policy.min_freq_mhz;
		break;

	case MVGAL_DVFS_BALANCED:
		if (utilization >= dvfs->policy.up_threshold) {
			/* Increase frequency */
			if (dvfs->current_freq_mhz < dvfs->policy.max_freq_mhz) {
				dvfs->target_freq_mhz = min(dvfs->current_freq_mhz + 100,
							    dvfs->policy.max_freq_mhz);
			}
		} else if (utilization <= dvfs->policy.down_threshold) {
			/* Decrease frequency */
			if (dvfs->current_freq_mhz > dvfs->policy.min_freq_mhz) {
				dvfs->target_freq_mhz = max(dvfs->current_freq_mhz - 100,
							    dvfs->policy.min_freq_mhz);
			}
		}
		break;

	case MVGAL_DVFS_CUSTOM:
		/* User-defined curve - use target as-is */
		break;
	}

	/* Apply frequency change */
	if (dvfs->target_freq_mhz != dvfs->current_freq_mhz) {
		mvgal_set_gpu_freq(gpu, dvfs->target_freq_mhz);
		dvfs->current_freq_mhz = dvfs->target_freq_mhz;
		pr_debug("MVGAL: DVFS: GPU %s freq %u MHz (util %u%%)\n",
			 gpu->name, dvfs->current_freq_mhz, utilization);
	}

 spin_unlock(&dvfs->lock);

	/* Schedule next check */
	queue_delayed_work(mvgal_dvfs_wq, &dvfs->dvfs_work,
			  msecs_to_jiffies(dvfs->policy.step_delay_ms));
}

/**
 * Start DVFS monitoring for a GPU
 */
int mvgal_dvfs_start(struct mvgal_gpu_device *gpu)
{
	struct mvgal_gpu_dvfs *dvfs;

	if (!gpu || !gpu->dvfs)
		return -EINVAL;

	dvfs = gpu->dvfs;

	if (!dvfs->enabled)
		return 0;

	/* Replace the work handler */
	INIT_DELAYED_WORK(&dvfs->dvfs_work, mvgal_dvfs_work_handler);

	queue_delayed_work(mvgal_dvfs_wq, &dvfs->dvfs_work,
			  msecs_to_jiffies(dvfs->policy.step_delay_ms));

	pr_info("MVGAL: DVFS started for GPU %s\n", gpu->name);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_dvfs_start);

/**
 * Stop DVFS monitoring for a GPU
 */
int mvgal_dvfs_stop(struct mvgal_gpu_device *gpu)
{
	struct mvgal_gpu_dvfs *dvfs;

	if (!gpu || !gpu->dvfs)
		return -EINVAL;

	dvfs = gpu->dvfs;

	cancel_delayed_work_sync(&dvfs->dvfs_work);

	pr_info("MVGAL: DVFS stopped for GPU %s\n", gpu->name);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_dvfs_stop);

/**
 * Set DVFS mode for a GPU
 */
int mvgal_dvfs_set_mode(struct mvgal_gpu_device *gpu, enum mvgal_dvfs_mode mode)
{
	struct mvgal_gpu_dvfs *dvfs;

	if (!gpu || !gpu->dvfs)
		return -EINVAL;

	dvfs = gpu->dvfs;

 spin_lock(&dvfs->lock);
	dvfs->policy.mode = mode;

	/* Immediately apply based on mode */
	switch (mode) {
	case MVGAL_DVFS_PERFORMANCE:
		dvfs->target_freq_mhz = dvfs->policy.max_freq_mhz;
		break;
	case MVGAL_DVFS_POWERSAVE:
		dvfs->target_freq_mhz = dvfs->policy.min_freq_mhz;
		break;
	default:
		break;
	}

	if (dvfs->target_freq_mhz != dvfs->current_freq_mhz) {
		mvgal_set_gpu_freq(gpu, dvfs->target_freq_mhz);
		dvfs->current_freq_mhz = dvfs->target_freq_mhz;
	}

 spin_unlock(&dvfs->lock);

	pr_info("MVGAL: DVFS mode set to %d for GPU %s\n", mode, gpu->name);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_dvfs_set_mode);

/**
 * Initialize thermal throttling for a GPU
 */
int mvgal_thermal_init(struct mvgal_gpu_device *gpu)
{
	struct mvgal_thermal *thermal;

	if (!gpu)
		return -EINVAL;

	thermal = kzalloc(sizeof(*thermal), GFP_KERNEL);
	if (!thermal)
		return -ENOMEM;

	thermal->gpu = gpu;
	thermal->enabled = true;

	/* Default thermal thresholds */
	thermal->throttle_temp_c = MVGAL_THERMAL_DEFAULT_THROTTLE_TEMP_C;
	thermal->critical_temp_c = MVGAL_THERMAL_DEFAULT_CRITICAL_TEMP_C;
	thermal->current_temp_c = 0;
	thermal->throttle_level = 0;

	INIT_DELAYED_WORK(&thermal->thermal_work, NULL);

	gpu->thermal = thermal;

	pr_debug("MVGAL: Thermal throttling initialized for GPU %s\n", gpu->name);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_thermal_init);

/**
 * Cleanup thermal throttling for a GPU
 */
void mvgal_thermal_fini(struct mvgal_gpu_device *gpu)
{
	struct mvgal_thermal *thermal;

	if (!gpu || !gpu->thermal)
		return;

	thermal = gpu->thermal;

	cancel_delayed_work_sync(&thermal->thermal_work);

	if (thermal->tz) {
		thermal_zone_device_unregister(thermal->tz);
	}

	kfree(thermal);
	gpu->thermal = NULL;

	pr_debug("MVGAL: Thermal throttling cleaned up for GPU %s\n", gpu->name);
}
EXPORT_SYMBOL_GPL(mvgal_thermal_fini);

/**
 * Thermal throttling work handler
 */
static void mvgal_thermal_work_handler(struct work_struct *work)
{
	struct delayed_work *dwork = to_delayed_work(work);
	struct mvgal_thermal *thermal = container_of(dwork, struct mvgal_thermal, thermal_work);
	struct mvgal_gpu_device *gpu = thermal->gpu;
	int32_t temp;
	int ret;

	if (!thermal->enabled)
		return;

	/* Read current temperature */
	ret = mvgal_read_gpu_temp(gpu, &temp);
	if (ret < 0) {
		temp = 45; /* Default safe temperature */
	}

	thermal->current_temp_c = temp;

	/* Apply throttling based on temperature */
	if (temp >= thermal->critical_temp_c) {
		/* Critical temperature - force GPU off */
		pr_warn("MVGAL: GPU %s critical temperature %dC, forcing power off\n",
			gpu->name, temp);

		if (gpu->ops && gpu->ops->set_power_state) {
			gpu->ops->set_power_state(gpu, MVGAL_DEVICE_POWER_STATE_OFF);
		}
		thermal->throttle_level = 100;
	} else if (temp >= thermal->throttle_temp_c) {
		/* Throttle based on temperature */
		uint32_t throttle = (temp - thermal->throttle_temp_c) * 100 /
				   (thermal->critical_temp_c - thermal->throttle_temp_c);

		thermal->throttle_level = min(throttle, 100U);

		/* Apply frequency limit based on throttle level */
		mvgal_set_freq_limit(gpu, thermal->throttle_level);

		pr_debug("MVGAL: GPU %s throttling %u%% (temp %dC)\n",
			 gpu->name, thermal->throttle_level, temp);
	} else {
		/* Normal temperature - no throttling */
		thermal->throttle_level = 0;
		mvgal_set_freq_limit(gpu, 0);
	}

	/* Schedule next thermal check */
	queue_delayed_work(mvgal_dvfs_wq, &thermal->thermal_work,
			  msecs_to_jiffies(1000));
}

/**
 * Start thermal monitoring for a GPU
 */
int mvgal_thermal_start(struct mvgal_gpu_device *gpu)
{
	struct mvgal_thermal *thermal;

	if (!gpu || !gpu->thermal)
		return -EINVAL;

	thermal = gpu->thermal;

	if (!thermal->enabled)
		return 0;

	INIT_DELAYED_WORK(&thermal->thermal_work, mvgal_thermal_work_handler);

	queue_delayed_work(mvgal_dvfs_wq, &thermal->thermal_work,
			  msecs_to_jiffies(1000));

	pr_info("MVGAL: Thermal monitoring started for GPU %s\n", gpu->name);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_thermal_start);

/**
 * Stop thermal monitoring for a GPU
 */
int mvgal_thermal_stop(struct mvgal_gpu_device *gpu)
{
	struct mvgal_thermal *thermal;

	if (!gpu || !gpu->thermal)
		return -EINVAL;

	thermal = gpu->thermal;

	cancel_delayed_work_sync(&thermal->thermal_work);

	/* Reset throttling */
	thermal->throttle_level = 0;
	mvgal_set_freq_limit(gpu, 0);

	pr_info("MVGAL: Thermal monitoring stopped for GPU %s\n", gpu->name);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_thermal_stop);

/**
 * Set thermal thresholds for a GPU
 */
int mvgal_thermal_set_thresholds(struct mvgal_gpu_device *gpu,
				 int32_t throttle_temp, int32_t critical_temp)
{
	struct mvgal_thermal *thermal;

	if (!gpu || !gpu->thermal)
		return -EINVAL;

	thermal = gpu->thermal;

	if (throttle_temp >= critical_temp)
		return -EINVAL;

	thermal->throttle_temp_c = throttle_temp;
	thermal->critical_temp_c = critical_temp;

	pr_info("MVGAL: Thermal thresholds set for GPU %s: throttle=%dC, critical=%dC\n",
		gpu->name, throttle_temp, critical_temp);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_thermal_set_thresholds);

/**
 * Initialize power budget management
 */
int mvgal_power_budget_init(void)
{
	memset(&mvgal_power_state, 0, sizeof(mvgal_power_state));

	mvgal_power_state.budget.total_watts = MVGAL_POWER_DEFAULT_TOTAL_WATTS;
	mvgal_power_state.budget.headroom_watts = MVGAL_POWER_DEFAULT_HEADROOM_WATTS;
	mvgal_power_state.budget.allocated_watts = 0;
	mvgal_power_state.budget.gpu_count = 0;

 spin_lock_init(&mvgal_power_state.budget.lock);

	mvgal_power_state.initialized = true;

	pr_info("MVGAL: Power budget management initialized (total=%uW, headroom=%uW)\n",
		mvgal_power_state.budget.total_watts,
		mvgal_power_state.budget.headroom_watts);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_init);

/**
 * Cleanup power budget management
 */
void mvgal_power_budget_fini(void)
{
	mvgal_power_state.initialized = false;
	pr_info("MVGAL: Power budget management cleaned up\n");
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_fini);

/**
 * Register a GPU with power budget
 */
int mvgal_power_budget_register_gpu(struct mvgal_gpu_device *gpu, uint32_t index)
{
	struct mvgal_power_budget *budget;

	if (!mvgal_power_state.initialized || index >= MVGAL_MAX_GPUS)
		return -EINVAL;

	budget = &mvgal_power_state.budget;

 spin_lock(&budget->lock);

	if (budget->gpu_count >= MVGAL_MAX_GPUS) {
	 spin_unlock(&budget->lock);
		return -ENOSPC;
	}

	/* Set default power limits */
	budget->gpu_power[index].min_watts = 50;
	budget->gpu_power[index].max_watts = 300;
	budget->gpu_power[index].current_watts = 0;
	budget->gpu_power[index].limit_watts = budget->gpu_power[index].max_watts;

	budget->gpu_count++;

 spin_unlock(&budget->lock);

	pr_info("MVGAL: GPU %u registered with power budget\n", index);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_register_gpu);

/**
 * Unregister a GPU from power budget
 */
int mvgal_power_budget_unregister_gpu(uint32_t index)
{
	struct mvgal_power_budget *budget;

	if (!mvgal_power_state.initialized || index >= MVGAL_MAX_GPUS)
		return -EINVAL;

	budget = &mvgal_power_state.budget;

 spin_lock(&budget->lock);

	budget->gpu_power[index].min_watts = 0;
	budget->gpu_power[index].max_watts = 0;
	budget->gpu_power[index].current_watts = 0;
	budget->gpu_power[index].limit_watts = 0;

	if (budget->gpu_count > 0)
		budget->gpu_count--;

 spin_unlock(&budget->lock);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_unregister_gpu);

/**
 * Distribute power budget based on workload priority
 */
int mvgal_power_budget_distribute(uint32_t *gpu_indices, uint32_t num_gpus,
				  uint32_t priority)
{
	struct mvgal_power_budget *budget;
	uint32_t available;
	uint32_t per_gpu;
	uint32_t i;

	if (!mvgal_power_state.initialized || num_gpus == 0)
		return -EINVAL;

	budget = &mvgal_power_state.budget;

 spin_lock(&budget->lock);

	available = budget->total_watts - budget->headroom_watts;

	/* Distribute power based on priority (0-15) */
	per_gpu = (priority * available) / (15 * num_gpus);
	per_gpu = max(per_gpu, 50U); /* Minimum 50W per GPU */

	for (i = 0; i < num_gpus && i < MVGAL_MAX_GPUS; i++) {
		uint32_t idx = gpu_indices[i];

		budget->gpu_power[idx].min_watts = per_gpu;
		budget->gpu_power[idx].limit_watts = min(per_gpu * 2,
							 budget->gpu_power[idx].max_watts);

		pr_debug("MVGAL: GPU %u allocated %uW (priority %u)\n",
			 idx, per_gpu, priority);
	}

	budget->allocated_watts = per_gpu * num_gpus;

 spin_unlock(&budget->lock);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_distribute);

/**
 * Get current power budget for a GPU
 */
int mvgal_power_budget_get_gpu(uint32_t index, struct mvgal_gpu_power *power)
{
	struct mvgal_power_budget *budget;

	if (!mvgal_power_state.initialized || index >= MVGAL_MAX_GPUS || !power)
		return -EINVAL;

	budget = &mvgal_power_state.budget;

 spin_lock(&budget->lock);
	*power = budget->gpu_power[index];
 spin_unlock(&budget->lock);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_get_gpu);

/**
 * Set total power budget
 */
int mvgal_power_budget_set_total(uint32_t total_watts)
{
	struct mvgal_power_budget *budget;

	if (!mvgal_power_state.initialized)
		return -EINVAL;

	budget = &mvgal_power_state.budget;

 spin_lock(&budget->lock);
	budget->total_watts = total_watts;
 spin_unlock(&budget->lock);

	pr_info("MVGAL: Power budget total set to %uW\n", total_watts);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_set_total);

/**
 * Set power headroom
 */
int mvgal_power_budget_set_headroom(uint32_t headroom_watts)
{
	struct mvgal_power_budget *budget;

	if (!mvgal_power_state.initialized)
		return -EINVAL;

	budget = &mvgal_power_state.budget;

 spin_lock(&budget->lock);
	budget->headroom_watts = headroom_watts;
 spin_unlock(&budget->lock);

	pr_info("MVGAL: Power budget headroom set to %uW\n", headroom_watts);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_budget_set_headroom);

/* Helper functions - call vendor-specific implementations */
static int mvgal_set_gpu_freq(struct mvgal_gpu_device *gpu, uint32_t freq_mhz)
{
	/* Vendor-specific implementation would go here */
	/* For now, just update the GPU state */
	if (gpu->ops && gpu->ops->set_power_state) {
		/* Some vendors have frequency control through power state */
	}

	pr_debug("MVGAL: Setting GPU %s frequency to %u MHz\n", gpu->name, freq_mhz);

	return 0;
}

static int __maybe_unused mvgal_get_gpu_freq(struct mvgal_gpu_device *gpu, uint32_t *freq_mhz)
{
	if (!gpu || !freq_mhz)
		return -EINVAL;

	/* Vendor-specific implementation would go here */
	*freq_mhz = gpu->dvfs ? gpu->dvfs->current_freq_mhz : 0;

	return 0;
}

static int mvgal_read_gpu_temp(struct mvgal_gpu_device *gpu, int32_t *temp_c)
{
	if (!gpu || !temp_c)
		return -EINVAL;

	/* Use cached temperature if available */
	*temp_c = gpu->temperature;

	return 0;
}

static int __maybe_unused mvgal_read_gpu_power(struct mvgal_gpu_device *gpu, uint32_t *power_watts)
{
	if (!gpu || !power_watts)
		return -EINVAL;

	/* Vendor-specific implementation would read from hwmon */
	*power_watts = 0;

	return 0;
}

/**
 * Set frequency limit based on thermal throttle level
 */
int mvgal_set_freq_limit(struct mvgal_gpu_device *gpu, uint32_t throttle_percent)
{
	struct mvgal_gpu_dvfs *dvfs;
	uint32_t max_freq;

	if (!gpu)
		return -EINVAL;

	dvfs = gpu->dvfs;
	if (!dvfs)
		return -EINVAL;

	if (throttle_percent == 0) {
		/* No throttling - use policy max */
		max_freq = dvfs->policy.max_freq_mhz;
	} else {
		/* Apply throttle - reduce max frequency */
		max_freq = dvfs->policy.max_freq_mhz * (100 - throttle_percent) / 100;
		max_freq = max(max_freq, dvfs->policy.min_freq_mhz);
	}

 spin_lock(&dvfs->lock);
	dvfs->target_freq_mhz = min(dvfs->target_freq_mhz, max_freq);

	if (dvfs->current_freq_mhz > max_freq) {
		mvgal_set_gpu_freq(gpu, max_freq);
		dvfs->current_freq_mhz = max_freq;
	}
 spin_unlock(&dvfs->lock);

	pr_debug("MVGAL: GPU %s freq limit %u MHz (throttle %u%%)\n",
		 gpu->name, max_freq, throttle_percent);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_set_freq_limit);

/**
 * Set power state for a GPU
 */
int mvgal_set_power_state(struct mvgal_gpu_device *gpu, enum mvgal_device_power_state state)
{
	if (!gpu)
		return -EINVAL;

	if (gpu->ops && gpu->ops->set_power_state) {
		int ret = gpu->ops->set_power_state(gpu, state);

		/*
		 * Mirror the request into the tracked state on success.  This used
		 * to return the vendor result directly, so whenever a vendor op
		 * existed the shadow state was never updated and silently diverged
		 * from what the driver was actually doing.  On failure the state is
		 * left alone, because nothing changed.
		 */
		if (ret == 0)
			gpu->power_state = state;
		return ret;
	}

	/*
	 * No vendor op.  There is no power interface at all on this GPU, so
	 * record the request but say plainly that nothing was applied.
	 */
	gpu->power_state = state;
	pr_warn_ratelimited("MVGAL: GPU %u (%s) exposes no power-state interface; requested state %d was recorded but not applied\n",
			    gpu->gpu_index, gpu->name, (int)state);
	return -EOPNOTSUPP;
}
EXPORT_SYMBOL_GPL(mvgal_set_power_state);

/* Global PSU configuration - initialized before power module init */
static struct mvgal_psu_config mvgal_psu_cfg;

/**
 * Power management initialization - called from main module init
 */
int mvgal_power_module_init(void)
{
	pr_info("MVGAL: Power management module initialized\n");

	/* Create DVFS workqueue */
	mvgal_dvfs_wq = alloc_workqueue("mvgal_dvfs", WQ_UNBOUND | WQ_FREEZABLE, 0);
	if (!mvgal_dvfs_wq) {
		pr_err("MVGAL: Failed to create DVFS workqueue\n");
		return -ENOMEM;
	}

	/* Initialize global power budget */
	mvgal_power_budget_init();

	/* Initialize PSU configuration */
	memset(&mvgal_psu_cfg, 0, sizeof(mvgal_psu_cfg));
	mvgal_psu_cfg.total_capacity_watts = 0; /* Unknown - must be configured */
	mvgal_psu_cfg.safety_margin_percent = 20;
	mvgal_psu_cfg.enable_headroom_tracking = false;

	return 0;
}

/**
 * Power management cleanup - called from main module exit
 */
void mvgal_power_module_exit(void)
{
	pr_info("MVGAL: Power management module exiting\n");

	/* Cleanup power budget */
	mvgal_power_budget_fini();

	/* Destroy workqueue */
	if (mvgal_dvfs_wq) {
		destroy_workqueue(mvgal_dvfs_wq);
		mvgal_dvfs_wq = NULL;
	}
}

/* Linked into mvgal.ko; no separate module metadata. */

/* ============================================================================
 * PSU Power Curve Integration (v0.5.8)
 * ============================================================================
 */

/**
 * Read system power draw from hwmon (CPU package power)
 */
static int mvgal_read_sysfs_power(uint32_t *milliwatts)
{
	struct file *f;
	char buf[32];
	loff_t pos = 0;
	ssize_t n;
	int ret = 0;
	unsigned long val;

	/* Static hwmon indices to try */
	static const char *paths[] = {
		"/sys/class/hwmon/hwmon0/power1_average",
		"/sys/class/hwmon/hwmon1/power1_average",
		"/sys/class/hwmon/hwmon0/power1_input",
		"/sys/class/hwmon/hwmon1/power1_input",
		"/sys/class/hwmon/hwmon2/power1_input",
		NULL
	};
	int i;

	for (i = 0; paths[i]; i++) {
		f = filp_open(paths[i], O_RDONLY, 0);
		if (IS_ERR(f))
			continue;

		n = kernel_read(f, buf, sizeof(buf) - 1, &pos);
		filp_close(f, NULL);

		if (n > 0) {
			buf[n] = '\0';
			if (kstrtoul(buf, 10, &val) == 0) {
				*milliwatts = (uint32_t)val;
				return 0;
			}
		}
	}

	/* No hwmon found - return estimate based on GPU count */
	*milliwatts = mvgal_power_state.budget.gpu_count * 150000; /* 150W per GPU estimate */
	return ret;
}

/**
 * mvgal_psu_get_config - Get current PSU configuration
 */
int mvgal_psu_get_config(struct mvgal_psu_config *config)
{
	if (!config)
		return -EINVAL;

	spin_lock(&mvgal_power_state.budget.lock);
	config->total_capacity_watts = mvgal_psu_cfg.total_capacity_watts;
	config->safety_margin_percent = mvgal_psu_cfg.safety_margin_percent;
	config->enable_headroom_tracking = mvgal_psu_cfg.enable_headroom_tracking;
	config->current_total_draw_watts = mvgal_psu_cfg.current_total_draw_watts;
	config->efficiency_percent = mvgal_psu_cfg.efficiency_percent;
	spin_unlock(&mvgal_power_state.budget.lock);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_psu_get_config);

/**
 * mvgal_psu_set_config - Configure PSU for power curve control
 *
 * Allows users to specify PSU capacity and safety margins for
 * optimized power distribution across GPUs.
 */
int mvgal_psu_set_config(uint32_t total_capacity_watts,
			  uint32_t safety_margin_percent,
			  bool enable_headroom_tracking)
{
	if (total_capacity_watts == 0) {
		pr_warn("MVGAL: PSU capacity must be positive\n");
		return -EINVAL;
	}

	if (total_capacity_watts > 20000) { /* 20kW sanity limit */
		pr_warn("MVGAL: PSU capacity %uW exceeds sanity limit\n", total_capacity_watts);
		return -EINVAL;
	}

	spin_lock(&mvgal_power_state.budget.lock);
	mvgal_psu_cfg.total_capacity_watts = total_capacity_watts;
	mvgal_psu_cfg.safety_margin_percent = (uint32_t)safety_margin_percent;
	if (mvgal_psu_cfg.safety_margin_percent > 50)
		mvgal_psu_cfg.safety_margin_percent = 50;
	mvgal_psu_cfg.enable_headroom_tracking = enable_headroom_tracking;
	spin_unlock(&mvgal_power_state.budget.lock);

	pr_info("MVGAL: PSU config set: capacity=%uW, margin=%u%%, headroom=%s\n",
		total_capacity_watts, mvgal_psu_cfg.safety_margin_percent,
		enable_headroom_tracking ? "enabled" : "disabled");

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_psu_set_config);

/**
 * mvgal_psu_get_headroom - Calculate available power headroom
 */
int mvgal_psu_get_headroom(uint32_t *available_watts, uint32_t *efficiency_percent)
{
	uint32_t drawn = 0;
	uint32_t available;
	uint32_t headroom;

	if (!available_watts || !efficiency_percent)
		return -EINVAL;

	/* Get current system power draw */
	mvgal_read_sysfs_power(&drawn);

	spin_lock(&mvgal_power_state.budget.lock);
	headroom = mvgal_psu_cfg.safety_margin_percent *
		   mvgal_psu_cfg.total_capacity_watts / 100;
	spin_unlock(&mvgal_power_state.budget.lock);

	/* Available = headroom - already allocated to GPUs */
	spin_lock(&mvgal_power_state.budget.lock);
	available = mvgal_power_state.budget.allocated_watts < headroom ?
		    headroom - mvgal_power_state.budget.allocated_watts : 0;
	spin_unlock(&mvgal_power_state.budget.lock);

	*available_watts = available;
	*efficiency_percent = (uint32_t)mvgal_psu_cfg.efficiency_percent;

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_psu_get_headroom);

/**
 * mvgal_psu_update_draw - Update current system power draw
 */
int mvgal_psu_update_draw(uint32_t total_draw_watts)
{
	spin_lock(&mvgal_power_state.budget.lock);
	mvgal_psu_cfg.current_total_draw_watts = total_draw_watts;

	/* Calculate PSU efficiency based on load
	 * Typical 80+ Gold efficiency curve approximation */
	if (mvgal_psu_cfg.total_capacity_watts > 0) {
		uint32_t load_pct = (uint32_t)((uint64_t)total_draw_watts * 100 /
				    mvgal_psu_cfg.total_capacity_watts);
		/* Efficiency peaks around 50% load, drops at low/high loads */
		if (load_pct < 10)
			mvgal_psu_cfg.efficiency_percent = 75; /* Low load efficiency */
		else if (load_pct < 30)
			mvgal_psu_cfg.efficiency_percent = 85;
		else if (load_pct < 70)
			mvgal_psu_cfg.efficiency_percent = 90; /* Peak efficiency */
		else if (load_pct < 90)
			mvgal_psu_cfg.efficiency_percent = 87;
		else
			mvgal_psu_cfg.efficiency_percent = 82; /* High load efficiency */
	}
	spin_unlock(&mvgal_power_state.budget.lock);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_psu_update_draw);

/**
 * mvgal_power_curve_init - Initialize GPU power curve
 */
int mvgal_power_curve_init(struct mvgal_gpu_power_curve *curve)
{
	if (!curve)
		return -EINVAL;

	memset(curve, 0, sizeof(*curve));

	/* Default curve: 0%=30%, 50%=70%, 100%=100% */
	curve->points[0] = (struct mvgal_power_curve_point){ 0, 30, 40 };
	curve->points[1] = (struct mvgal_power_curve_point){ 50, 70, 70 };
	curve->points[2] = (struct mvgal_power_curve_point){ 100, 100, 85 };
	curve->num_points = 3;

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_curve_init);

/**
 * mvgal_power_curve_set_points - Set custom power curve points
 */
int mvgal_power_curve_set_points(struct mvgal_gpu_power_curve *curve,
				  const struct mvgal_power_curve_point *points,
				  uint32_t num_points)
{
	uint32_t i;

	if (!curve || !points || num_points == 0 || num_points > 8)
		return -EINVAL;

	for (i = 0; i < num_points; i++) {
		if (points[i].utilization_percent > 100 ||
		    points[i].power_limit_percent > 150) /* 150% turbo limit */
			return -EINVAL;
		curve->points[i] = points[i];
	}

	curve->num_points = num_points;
	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_curve_set_points);

/**
 * mvgal_power_curve_optimize_for_utilization - Linear interpolation for power limit
 */
uint32_t mvgal_power_curve_optimize_for_utilization(uint32_t utilization_percent,
						     const struct mvgal_power_curve_point *points,
						     uint32_t num_points)
{
	uint32_t i;

	if (num_points == 0)
		return 100000; /* Default to full power (100.0% = 100000 millipercent) */

	/* Find bracketing points for interpolation */
	for (i = 0; i < num_points - 1; i++) {
		if (utilization_percent <= points[i + 1].utilization_percent) {
			/* Interpolate between points[i] and points[i+1] */
			uint32_t range = points[i + 1].utilization_percent -
					 points[i].utilization_percent;
			uint32_t delta = utilization_percent - points[i].utilization_percent;
			/* Scale to millipercent (0.1% precision) */
			uint32_t a = points[i].power_limit_percent * 1000;
			uint32_t b = points[i + 1].power_limit_percent * 1000;
			return a + ((b - a) * delta / range);
		}
	}

	return points[num_points - 1].power_limit_percent * 1000;
}
EXPORT_SYMBOL_GPL(mvgal_power_curve_optimize_for_utilization);

/**
 * mvgal_power_curve_apply - Apply power curve to get power limit
 */
int mvgal_power_curve_apply(struct mvgal_gpu_power_curve *curve,
			     uint32_t gpu_utilization,
			     int32_t gpu_temperature,
			     uint32_t *out_power_limit_watts)
{
	uint32_t limit_milli;
	uint32_t max_watts;
	uint32_t limit_watts;

	if (!curve || !out_power_limit_watts)
		return -EINVAL;

	if (curve->num_points == 0) {
		*out_power_limit_watts = 300; /* Default fallback */
		return 0;
	}

	limit_milli = mvgal_power_curve_optimize_for_utilization(
		gpu_utilization, curve->points, curve->num_points);

	/* Get GPU max power */
	spin_lock(&mvgal_power_state.budget.lock);
	max_watts = mvgal_power_state.budget.gpu_power[curve->current_point].max_watts;
	spin_unlock(&mvgal_power_state.budget.lock);

	if (max_watts == 0)
		max_watts = 300; /* Default assumption */

	/* Calculate limit: limit_milli is percent * 1000, so divide by 100000 */
	limit_watts = (limit_milli * max_watts) / 100000;
	limit_watts = max(limit_watts, 50U); /* Minimum 50W */

	*out_power_limit_watts = limit_watts;
	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_power_curve_apply);

/**
 * mvgal_power_curve_get_info - Get power curve info for a GPU
 */
int mvgal_power_curve_get_info(uint32_t gpu_index,
				 struct mvgal_gpu_power_curve *curve)
{
	/* Placeholder - would read from per-GPU state */
	if (!curve)
		return -EINVAL;

	return mvgal_power_curve_init(curve);
}
EXPORT_SYMBOL_GPL(mvgal_power_curve_get_info);
/* ------------------------------------------------------------------ */
/* Idle gating                                                         */
/* ------------------------------------------------------------------ */

/*
 * The sweep runs on its own workqueue because it calls into vendor ops and
 * may sleep; it must never run on the system workqueue.
 */
#define MVGAL_IDLE_GATE_DEFAULT_TIMEOUT_MS	30000
#define MVGAL_IDLE_GATE_DEFAULT_SWEEP_MS	5000

static void mvgal_idle_gate_sweep(struct work_struct *work);

/**
 * mvgal_idle_gate_apply - Put the GPU into or out of the gated state
 * @gpu: GPU to gate or ungate
 * @gate_on: true to gate, false to restore
 *
 * Returns 0 only when the GPU was actually transitioned.  A GPU that cannot
 * accept a power state is reported as -EOPNOTSUPP and its gated flag is left
 * clear, so a caller can never observe a gate that did not happen.
 */
static int mvgal_idle_gate_apply(struct mvgal_gpu_device *gpu,
				 struct mvgal_idle_gate *gate, bool gate_on)
{
	enum mvgal_device_power_state want = gate_on ? MVGAL_DEVICE_POWER_STATE_IDLE
						     : MVGAL_DEVICE_POWER_STATE_ACTIVE;
	int ret;

	if (gate_on && !mvgal_gpu_can(gpu, MVGAL_CAP_PPM)) {
		/*
		 * A busy signal is what makes gating safe, and a busy signal is
		 * also what tells us the GPU has gone idle.  Without it we cannot
		 * distinguish an idle GPU from a busy one, and guessing would gate
		 * a GPU out from under running work.  Say so rather than
		 * pretending the gate is armed.
		 */
		pr_warn_once("MVGAL: GPU %u (%s) has no measurable busy signal, so MVGAL cannot tell idle from busy; idle gating is unavailable on this device\n",
			     gpu->gpu_index, gpu->name);
		return -EOPNOTSUPP;
	}

	ret = mvgal_set_power_state(gpu, want);
	if (ret != 0) {
		pr_warn_ratelimited("MVGAL: GPU %u (%s) rejected power state %d (%d); not gating\n",
				    gpu->gpu_index, gpu->name, (int)want, ret);
		return ret;
	}

	gate->gated = gate_on;
	pr_debug("MVGAL: GPU %u (%s) idle gate %s\n", gpu->gpu_index, gpu->name,
		 gate_on ? "engaged" : "released");
	return 0;
}

static void mvgal_idle_gate_sweep(struct work_struct *work)
{
	struct mvgal_idle_gate *gate =
		container_of(to_delayed_work(work), struct mvgal_idle_gate, work);
	struct mvgal_gpu_device *gpu = gate->owner;
	unsigned long now = jiffies;

	/*
	 * Teardown cancels this work before the workqueue is destroyed, so the
	 * owner is normally valid here.  The null check is kept because a GPU
	 * that failed to initialise cleanly can leave an unowned gate behind,
	 * and a sweep on a freed GPU is a use-after-free.
	 */
	if (!gpu || !gpu->idle_gate) {
		if (gate->enabled)
			queue_delayed_work(gate->wq, &gate->work,
					   msecs_to_jiffies(gate->sweep_ms));
		return;
	}

	if (!gate->enabled || !gate->armed)
		return;

	/*
	 * gpu->utilization is refreshed from the probed busy-percent attribute
	 * (or the last value the daemon reported).  Only trust it as an idle
	 * signal when the gate is armed, which required that attribute.
	 */
	if (gpu->utilization > 0) {
		gate->last_busy_jiffies = now;
		if (gate->gated) {
			/* Work came back: restore the GPU before it is needed. */
			mvgal_idle_gate_apply(gpu, gate, false);
		}
	} else if (!gate->gated &&
		   time_after_eq(now, gate->last_busy_jiffies + msecs_to_jiffies(gate->timeout_ms))) {
		mvgal_idle_gate_apply(gpu, gate, true);
	}

	queue_delayed_work(gate->wq, &gate->work,
			   msecs_to_jiffies(gate->sweep_ms));
}

/**
 * mvgal_idle_gate_init - Set up idle gating for a GPU
 * @gpu: GPU to gate
 *
 * The gate is created for every GPU, but it is only ARMED on a GPU that
 * reports a real busy signal.  On any other GPU it is created disabled with
 * armed set false, which is the documented "unavailable here" state rather
 * than a gate that silently does nothing.
 */
int mvgal_idle_gate_init(struct mvgal_gpu_device *gpu)
{
	struct mvgal_idle_gate *gate;

	if (!gpu)
		return -EINVAL;

	gate = kzalloc(sizeof(*gate), GFP_KERNEL);
	if (!gate)
		return -ENOMEM;

	gate->wq = alloc_workqueue("mvgal_idle_gate", WQ_UNBOUND | WQ_FREEZABLE, 0);
	if (!gate->wq) {
		kfree(gate);
		return -ENOMEM;
	}
	INIT_DELAYED_WORK(&gate->work, mvgal_idle_gate_sweep);
	gate->timeout_ms = MVGAL_IDLE_GATE_DEFAULT_TIMEOUT_MS;
	gate->sweep_ms   = MVGAL_IDLE_GATE_DEFAULT_SWEEP_MS;
	gate->owner     = gpu;
	gate->last_busy_jiffies = jiffies;

	if (mvgal_gpu_can(gpu, MVGAL_CAP_BUSY_PERCENT)) {
		gate->armed = true;
		gate->enabled = false;  /* armed but off until the user asks */
	} else {
		gate->armed = false;
		gate->enabled = false;
		pr_info("MVGAL: GPU %u (%s) reports no busy signal; idle gating is unavailable and will stay disabled\n",
			gpu->gpu_index, gpu->name);
	}

	gpu->idle_gate = gate;
	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_idle_gate_init);

void mvgal_idle_gate_fini(struct mvgal_gpu_device *gpu)
{
	struct mvgal_idle_gate *gate;

	if (!gpu || !gpu->idle_gate)
		return;

	gate = gpu->idle_gate;
	gpu->idle_gate = NULL;

	/* Cancel before destroying the queue the work runs on. */
	cancel_delayed_work_sync(&gate->work);
	destroy_workqueue(gate->wq);
	kfree(gate);
}
EXPORT_SYMBOL_GPL(mvgal_idle_gate_fini);

int mvgal_idle_gate_set_enabled(struct mvgal_gpu_device *gpu, bool enabled)
{
	struct mvgal_idle_gate *gate;

	if (!gpu || !gpu->idle_gate)
		return -EINVAL;
	gate = gpu->idle_gate;

	if (enabled && !gate->armed) {
		pr_warn("MVGAL: GPU %u (%s) cannot idle-gate: no measurable busy signal\n",
			gpu->gpu_index, gpu->name);
		return -EOPNOTSUPP;
	}

	if (gate->enabled == enabled)
		return 0;
	gate->enabled = enabled;
	gate->last_busy_jiffies = jiffies;

	if (enabled)
		queue_delayed_work(gate->wq, &gate->work,
				   msecs_to_jiffies(gate->sweep_ms));
	else {
		cancel_delayed_work_sync(&gate->work);
		if (gate->gated)
			mvgal_idle_gate_apply(gpu, gate, false);
	}
	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_idle_gate_set_enabled);

int mvgal_idle_gate_set_timeout(struct mvgal_gpu_device *gpu, unsigned long timeout_ms)
{
	if (!gpu || !gpu->idle_gate)
		return -EINVAL;
	if (timeout_ms == 0)
		return -EINVAL;
	gpu->idle_gate->timeout_ms = timeout_ms;
	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_idle_gate_set_timeout);

int mvgal_idle_gate_get(struct mvgal_gpu_device *gpu, struct mvgal_idle_gate *out)
{
	struct mvgal_idle_gate *gate;

	if (!gpu || !out)
		return -EINVAL;
	gate = gpu->idle_gate;
	if (!gate)
		return -ENODEV;

	/*
	 * Copy the observable fields only.  The gate holds a delayed_work and a
	 * workqueue pointer, and handing those to a caller would both leak
	 * kernel internals across the module boundary and invite the caller to
	 * touch work that teardown is responsible for cancelling.
	 */
	out->owner            = NULL;
	out->wq               = NULL;
	out->timeout_ms       = gate->timeout_ms;
	out->sweep_ms         = gate->sweep_ms;
	out->last_busy_jiffies = gate->last_busy_jiffies;
	out->enabled          = gate->enabled;
	out->armed            = gate->armed;
	out->gated            = gate->gated;
	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_idle_gate_get);
