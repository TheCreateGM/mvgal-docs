// SPDX-License-Identifier: GPL-2.0-only
/*
 * KUnit tests for MVGAL NVIDIA vendor module
 *
 * Tests integration with the NVIDIA kernel module through the MVGAL vendor
 * interface: device detection, BAR mapping, P2P, power management.
 */
#include <kunit/test.h>
#include <linux/pci.h>
#include <linux/device.h>
#include "../mvgal_vendor.h" /* Vendor module API */

/* ── PCI device simulation ──────────────────────────────────────────── */

static struct pci_dev *create_mock_pci_dev(struct kunit *test)
{
    struct pci_dev *pdev = kunit_kzalloc(test, sizeof(*pdev), GFP_KERNEL);
    KUNIT_ASSERT_NOT_NULL(test, pdev);
    pdev->vendor = 0x10DE; /* NVIDIA */
    pdev->device = 0x1EB8; /* TU104 */
    pdev->revision = 0xA1;
    return pdev;
}

/* ── Device registration ────────────────────────────────────────────── */

static void test_nvidia_device_probe(struct kunit *test)
{
    struct pci_dev *pdev = create_mock_pci_dev(test);
    struct mvgal_vendor_device *vdev;
    int ret;

    ret = mvgal_vendor_nvidia_probe(pdev, &vdev);
    KUNIT_EXPECT_EQ(test, ret, 0);
    KUNIT_EXPECT_NOT_NULL(test, vdev);
    KUNIT_EXPECT_EQ(test, vdev->vendor, MVGAL_VENDOR_NVIDIA);
}

static void test_nvidia_device_remove(struct kunit *test)
{
    struct pci_dev *pdev = create_mock_pci_dev(test);
    struct mvgal_vendor_device *vdev;
    int ret;

    ret = mvgal_vendor_nvidia_probe(pdev, &vdev);
    KUNIT_ASSERT_EQ(test, ret, 0);

    mvgal_vendor_nvidia_remove(vdev);
    /* Verify cleanup - no double-free, no use-after-free */
    KUNIT_SUCCEED(test);
}

/* ── BAR mapping ────────────────────────────────────────────────────── */

static void test_nvidia_bar_map(struct kunit *test)
{
    struct pci_dev *pdev = create_mock_pci_dev(test);
    struct mvgal_vendor_device *vdev;
    struct mvgal_vendor_bar bar;
    int ret;

    ret = mvgal_vendor_nvidia_probe(pdev, &vdev);
    KUNIT_ASSERT_EQ(test, ret, 0);

    ret = mvgal_vendor_nvidia_get_bar(vdev, 0, &bar);
    if (ret == 0) {
        KUNIT_EXPECT_NE(test, bar.physical_addr, 0);
        KUNIT_EXPECT_GT(test, bar.size, 0);
    } else {
        /* BAR 0 may not be available - that's OK */
        KUNIT_SUCCEED(test);
    }
}

/* ── Power management ───────────────────────────────────────────────── */

static void test_nvidia_power_management(struct kunit *test)
{
    struct pci_dev *pdev = create_mock_pci_dev(test);
    struct mvgal_vendor_device *vdev;
    int ret;

    ret = mvgal_vendor_nvidia_probe(pdev, &vdev);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Test power state transitions */
    ret = mvgal_vendor_nvidia_set_power_state(vdev, MVGAL_VENDOR_POWER_D0);
    KUNIT_EXPECT_EQ(test, ret, 0);

    ret = mvgal_vendor_nvidia_set_power_state(vdev, MVGAL_VENDOR_POWER_D3HOT);
    KUNIT_EXPECT_EQ(test, ret, 0);

    /* Back to D0 */
    ret = mvgal_vendor_nvidia_set_power_state(vdev, MVGAL_VENDOR_POWER_D0);
    KUNIT_EXPECT_EQ(test, ret, 0);
}

/* ── P2P DMA (BAR-to-BAR mapping) ───────────────────────────────────── */

static void test_nvidia_p2p(struct kunit *test)
{
    struct pci_dev *pdev1 = create_mock_pci_dev(test);
    struct pci_dev *pdev2 = create_mock_pci_dev(test);
    struct mvgal_vendor_device *vdev1, *vdev2;
    struct mvgal_vendor_p2p_map p2p;
    int ret;

    ret = mvgal_vendor_nvidia_probe(pdev1, &vdev1);
    KUNIT_ASSERT_EQ(test, ret, 0);
    ret = mvgal_vendor_nvidia_probe(pdev2, &vdev2);
    KUNIT_ASSERT_EQ(test, ret, 0);

    ret = mvgal_vendor_nvidia_p2p_enable(vdev1, vdev2, &p2p);
    if (ret == 0) {
        KUNIT_EXPECT_NE(test, p2p.dma_addr, 0);
        KUNIT_EXPECT_GT(test, p2p.size, 0);

        mvgal_vendor_nvidia_p2p_disable(vdev1, vdev2, &p2p);
    }
    /* P2P may not be supported in test env - not a failure */
}

static struct kunit_case nvidia_test_cases[] = {
    KUNIT_CASE(test_nvidia_device_probe),
    KUNIT_CASE(test_nvidia_device_remove),
    KUNIT_CASE(test_nvidia_bar_map),
    KUNIT_CASE(test_nvidia_power_management),
    KUNIT_CASE(test_nvidia_p2p),
    {}
};

static struct kunit_suite nvidia_test_suite = {
    .name = "mvgal-nvidia",
    .test_cases = nvidia_test_cases,
};

kunit_test_suite(nvidia_test_suite);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("MVGAL Project");
MODULE_DESCRIPTION("KUnit tests for MVGAL NVIDIA vendor module");
