// SPDX-License-Identifier: GPL-2.0-only
/*
 * KUnit tests for MVGAL NTSYNC kernel module
 *
 * Tests the Windows NT synchronization primitive implementations:
 *   - NtCreateEvent / NtSetEvent / NtResetEvent / NtWaitForSingleObject
 *   - NtCreateMutant / NtReleaseMutant
 *   - NtCreateSemaphore / NtReleaseSemaphore
 *   - NtWaitForMultipleObjects (all/wait-any)
 *   - NtSignalAndWaitForSingleObject
 */
#include <kunit/test.h>
#include <linux/slab.h>
#include <linux/sched.h>
#include <linux/wait.h>
#include <linux/atomic.h>
#include <uapi/linux/mvgal.h>

/* Include ntsync declarations from kernel ntsync module */
extern struct miscdevice mvgal_ntsync_misc;
extern long mvgal_ntsync_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

/* Test file struct simulation */
static struct file *create_test_file(void)
{
    struct file *f = kzalloc(sizeof(*f), GFP_KERNEL);
    KUNIT_ASSERT_NOT_NULL_MSG(f, "failed to allocate test file");
    return f;
}

static void destroy_test_file(struct kunit *test, struct file *f)
{
    kfree(f);
}

/* ── Helper: create test file + call ioctl ──────────────────────────── */

static long ntsync_ioctl(struct kunit *test, struct file *f,
                          unsigned int cmd, unsigned long arg)
{
    return mvgal_ntsync_ioctl(f, cmd, arg);
}

/* ── NtCreateEvent / NtSetEvent / NtResetEvent / NtWaitForSingleObject ─ */

static void test_ntsync_create_event(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_event_args args;
    mvgal_ntsync_handle_t handle;
    int ret;

    /* Create manual-reset event, initially unsignaled */
    memset(&args, 0, sizeof(args));
    args.event_type = MVGAL_NTSYNC_EVENT_MANUAL_RESET;
    args.initial_state = 0;

    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&args);
    KUNIT_EXPECT_EQ(test, ret, 0);
    KUNIT_EXPECT_GT(test, args.handle, 0);

    handle = args.handle;
    KUNIT_SUCCEED(test);
}

static void test_ntsync_set_event(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_event_args args;
    struct mvgal_ntsync_set_args set_args;
    int ret;

    /* Create auto-reset event, initially unsignaled */
    memset(&args, 0, sizeof(args));
    args.event_type = MVGAL_NTSYNC_EVENT_AUTO_RESET;
    args.initial_state = 0;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&args);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Set the event */
    memset(&set_args, 0, sizeof(set_args));
    set_args.handle = args.handle;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_SET_EVENT,
                        (unsigned long)&set_args);
    KUNIT_EXPECT_EQ(test, ret, 0);
    KUNIT_EXPECT_GT(test, set_args.previous_state, 0);
}

static void test_ntsync_reset_event(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_event_args args;
    struct mvgal_ntsync_set_args set_args, reset_args;
    int ret;

    /* Create manual-reset event, initially signaled */
    memset(&args, 0, sizeof(args));
    args.event_type = MVGAL_NTSYNC_EVENT_MANUAL_RESET;
    args.initial_state = 1;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&args);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Reset the event */
    memset(&reset_args, 0, sizeof(reset_args));
    reset_args.handle = args.handle;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_RESET_EVENT,
                        (unsigned long)&reset_args);
    KUNIT_EXPECT_EQ(test, ret, 0);
    KUNIT_EXPECT_EQ(test, reset_args.previous_state, 1);

    /* Verify event is now unsignaled by trying to wait (non-blocking) */
    /* If event is unsignaled, wait should return timeout */
    memset(&set_args, 0, sizeof(set_args));
    set_args.handle = args.handle;
    set_args.timeout = 0; /* Immediate return */
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_SINGLE,
                        (unsigned long)&set_args);
    /* Expected: timeout or not signaled */
    KUNIT_EXPECT_TRUE(test, ret == -ETIMEDOUT || ret == -EBUSY);
}

static void test_ntsync_wait_single(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_event_args args;
    struct mvgal_ntsync_wait_args wait_args;
    int ret;

    /* Create auto-reset event, initially signaled */
    memset(&args, 0, sizeof(args));
    args.event_type = MVGAL_NTSYNC_EVENT_AUTO_RESET;
    args.initial_state = 1;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&args);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Wait on the signaled event (non-blocking) */
    memset(&wait_args, 0, sizeof(wait_args));
    wait_args.handle = args.handle;
    wait_args.timeout = 0;

    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_SINGLE,
                        (unsigned long)&wait_args);
    KUNIT_EXPECT_EQ(test, ret, 0);

    /* For auto-reset, event should now be unsignaled */
    /* Second wait should return timeout */
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_SINGLE,
                        (unsigned long)&wait_args);
    KUNIT_EXPECT_TRUE(test, ret == -ETIMEDOUT || ret == -EBUSY);
}

/* ── NtCreateMutant / NtReleaseMutant ───────────────────────────────── */

static void test_ntsync_create_mutant(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_mutant_args args;
    int ret;

    memset(&args, 0, sizeof(args));
    args.initial_owner = 1; /* Create with calling thread as owner */

    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_MUTANT,
                        (unsigned long)&args);
    KUNIT_EXPECT_EQ(test, ret, 0);
    KUNIT_EXPECT_GT(test, args.handle, 0);
}

static void test_ntsync_release_mutant(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_mutant_args args;
    struct mvgal_ntsync_release_args release_args;
    int ret;

    memset(&args, 0, sizeof(args));
    args.initial_owner = 1;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_MUTANT,
                        (unsigned long)&args);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Release the mutant */
    memset(&release_args, 0, sizeof(release_args));
    release_args.handle = args.handle;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_RELEASE_MUTANT,
                        (unsigned long)&release_args);
    KUNIT_EXPECT_EQ(test, ret, 0);
}

/* ── NtCreateSemaphore / NtReleaseSemaphore ─────────────────────────── */

static void test_ntsync_create_semaphore(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_sem_args args;
    int ret;

    memset(&args, 0, sizeof(args));
    args.initial_count = 5;
    args.max_count = 10;

    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_SEM,
                        (unsigned long)&args);
    KUNIT_EXPECT_EQ(test, ret, 0);
    KUNIT_EXPECT_GT(test, args.handle, 0);
}

static void test_ntsync_release_semaphore(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_sem_args args;
    struct mvgal_ntsync_release_args release_args;
    int ret;

    memset(&args, 0, sizeof(args));
    args.initial_count = 5;
    args.max_count = 10;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_SEM,
                        (unsigned long)&args);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Release (increment) the semaphore */
    memset(&release_args, 0, sizeof(release_args));
    release_args.handle = args.handle;
    release_args.release_count = 3;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_RELEASE_SEM,
                        (unsigned long)&release_args);
    KUNIT_EXPECT_EQ(test, ret, 0);
    KUNIT_EXPECT_EQ(test, release_args.previous_count, 5);
}

/* ── NtWaitForMultipleObjects ───────────────────────────────────────── */

static void test_ntsync_wait_multiple(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_event_args ev1, ev2;
    struct mvgal_ntsync_wait_multiple_args wait_args;
    int handles[2];
    int ret;

    /* Create two auto-reset events, both signaled */
    memset(&ev1, 0, sizeof(ev1));
    ev1.event_type = MVGAL_NTSYNC_EVENT_AUTO_RESET;
    ev1.initial_state = 1;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&ev1);
    KUNIT_ASSERT_EQ(test, ret, 0);

    memset(&ev2, 0, sizeof(ev2));
    ev2.event_type = MVGAL_NTSYNC_EVENT_AUTO_RESET;
    ev2.initial_state = 1;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&ev2);
    KUNIT_ASSERT_EQ(test, ret, 0);

    handles[0] = ev1.handle;
    handles[1] = ev2.handle;

    /* Wait for all (wait_any=0) - non-blocking */
    memset(&wait_args, 0, sizeof(wait_args));
    wait_args.handles = (unsigned long)handles;
    wait_args.count = 2;
    wait_args.wait_any = 0;
    wait_args.timeout = 0;

    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_MULTIPLE,
                        (unsigned long)&wait_args);
    KUNIT_EXPECT_EQ(test, ret, 0);

    /* wait_any = 1 */
    wait_args.wait_any = 1;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_MULTIPLE,
                        (unsigned long)&wait_args);
    /* Should succeed quickly since events may have been re-signaled or we test initially */
    KUNIT_EXPECT_TRUE(test, ret == 0 || ret == -ETIMEDOUT);
}

/* ── NtSignalAndWaitForSingleObject ─────────────────────────────────── */

static void test_ntsync_signal_and_wait(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_event_args ev_signal, ev_wait;
    struct mvgal_ntsync_signal_and_wait_args sw_args;
    int ret;

    /* Create auto-reset event to signal */
    memset(&ev_signal, 0, sizeof(ev_signal));
    ev_signal.event_type = MVGAL_NTSYNC_EVENT_AUTO_RESET;
    ev_signal.initial_state = 0;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&ev_signal);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Create auto-reset event to wait on (signaled) */
    memset(&ev_wait, 0, sizeof(ev_wait));
    ev_wait.event_type = MVGAL_NTSYNC_EVENT_AUTO_RESET;
    ev_wait.initial_state = 1;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&ev_wait);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Signal + wait (non-blocking) */
    memset(&sw_args, 0, sizeof(sw_args));
    sw_args.signal_handle = ev_signal.handle;
    sw_args.wait_handle = ev_wait.handle;
    sw_args.timeout = 0;

    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_SIGNAL_AND_WAIT,
                        (unsigned long)&sw_args);
    KUNIT_EXPECT_EQ(test, ret, 0);
}

/* ── Edge cases ─────────────────────────────────────────────────────── */

static void test_ntsync_invalid_handle(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_wait_args wait_args;
    int ret;

    memset(&wait_args, 0, sizeof(wait_args));
    wait_args.handle = 0xDEADBEEF;
    wait_args.timeout = 0;

    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_SINGLE,
                        (unsigned long)&wait_args);
    KUNIT_EXPECT_LT(test, ret, 0);
}

static void test_ntsync_double_wait(struct kunit *test)
{
    struct file *f = create_test_file();
    struct mvgal_ntsync_event_args args;
    struct mvgal_ntsync_wait_args wait_args;
    int ret;

    /* Create auto-reset event, initially unsignaled */
    memset(&args, 0, sizeof(args));
    args.event_type = MVGAL_NTSYNC_EVENT_AUTO_RESET;
    args.initial_state = 0;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_CREATE_EVENT,
                        (unsigned long)&args);
    KUNIT_ASSERT_EQ(test, ret, 0);

    /* Two threads waiting on the same unsignaled event */
    /* First wait should block (non-blocking returns immediately) */
    memset(&wait_args, 0, sizeof(wait_args));
    wait_args.handle = args.handle;
    wait_args.timeout = 0;
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_SINGLE,
                        (unsigned long)&wait_args);
    KUNIT_EXPECT_TRUE(test, ret == -ETIMEDOUT || ret == -EBUSY);

    /* Second concurrent wait should also not crash */
    ret = ntsync_ioctl(test, f, MVGAL_IOCTL_NTSYNC_WAIT_SINGLE,
                        (unsigned long)&wait_args);
    KUNIT_EXPECT_TRUE(test, ret == -ETIMEDOUT || ret == -EBUSY);
}

static struct kunit_case ntsync_test_cases[] = {
    KUNIT_CASE(test_ntsync_create_event),
    KUNIT_CASE(test_ntsync_set_event),
    KUNIT_CASE(test_ntsync_reset_event),
    KUNIT_CASE(test_ntsync_wait_single),
    KUNIT_CASE(test_ntsync_create_mutant),
    KUNIT_CASE(test_ntsync_release_mutant),
    KUNIT_CASE(test_ntsync_create_semaphore),
    KUNIT_CASE(test_ntsync_release_semaphore),
    KUNIT_CASE(test_ntsync_wait_multiple),
    KUNIT_CASE(test_ntsync_signal_and_wait),
    KUNIT_CASE(test_ntsync_invalid_handle),
    KUNIT_CASE(test_ntsync_double_wait),
    {}
};

static struct kunit_suite ntsync_test_suite = {
    .name = "mvgal-ntsync",
    .test_cases = ntsync_test_cases,
};

kunit_test_suite(ntsync_test_suite);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("MVGAL Project");
MODULE_DESCRIPTION("KUnit tests for MVGAL NTSYNC module");
