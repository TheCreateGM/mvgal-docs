/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 * 
 * Test Infrastructure for Multi-GPU Validation
 * 
 * SPDX-License-Identifier: GPL-2.0-only
 */

#ifndef _MVGAL_TEST_H_
#define _MVGAL_TEST_H_

#include <linux/types.h>
#include <linux/ktime.h>

/* Test result codes */
#define MVGAL_TEST_PASS        0
#define MVGAL_TEST_FAIL       -1
#define MVGAL_TEST_SKIP       -2
#define MVGAL_TEST_ERROR      -3

/* Test categories */
#define MVGAL_TEST_CATEGORY_KERNEL    1
#define MVGAL_TEST_CATEGORY_RUNTIME   2
#define MVGAL_TEST_CATEGORY_MEMORY    3
#define MVGAL_TEST_CATEGORY_SCHEDULER 4
#define MVGAL_TEST_CATEGORY_SYNC      5
#define MVGAL_TEST_CATEGORY_POWER     6
#define MVGAL_TEST_CATEGORY_INTEGRATION 7

/*
 * Test suite structure
 */
struct mvgal_test_suite {
    const char *name;
    int (*init)(void);
    void (*cleanup)(void);
    int category;
    int requires_dmabuf;
    int requires_p2p;
    int min_gpu_count;
};

/*
 * Test case structure
 */
struct mvgal_test_case {
    const char *name;
    const char *description;
    int (*test_func)(void);
    int category;
    int skip_if_no_dmabuf;
    int skip_if_no_p2p;
    int min_gpu_count;
};

/*
 * Test utilities
 */

/**
 * Register a test suite
 */
int mvgal_test_register_suite(struct mvgal_test_suite *suite);

/**
 * Run all registered test suites
 */
int mvgal_test_run_all(void);

/**
 * Run tests for a specific category
 */
int mvgal_test_run_category(int category);

/**
 * Get test results as JSON string
 */
const char *mvgal_test_get_results_json(void);

/*
 * Specific test functions
 */

/* Kernel module tests */
int test_kernel_module_load(void);
int test_kernel_module_unload(void);
int test_gpu_enumeration(void);
int test_pci_topology_detection(void);

/* Memory management tests */
int test_memory_alloc_single_gpu(void);
int test_memory_alloc_multi_gpu(void);
int test_dma_buf_export_import(void);
int test_p2p_transfer(void);
int test_host_staging(void);
int test_memory_migration(void);

/* Scheduler tests */
int test_scheduler_init(void);
int test_scheduler_submit_workload(void);
int test_scheduler_gpu_selection(void);
int test_scheduler_priority(void);

/* Synchronization tests */
int test_fence_creation(void);
int test_fence_signal_wait(void);
int test_timeline_sync(void);

/* Power management tests */
int test_power_init(void);
int test_dvfs_mode(void);
int test_thermal_throttling(void);

/* Integration tests */
int test_vulkan_layer_interception(void);
int test_opencl_interception(void);
int test_cuda_interception(void);
int test_cross_vendor_memory(void);

/*
 * Test macros
 */
#define MVGAL_TEST_ASSERT(condition, msg) \
    do { \
        if (!(condition)) { \
            pr_err("MVGAL_TEST: ASSERT FAILED: %s (%s:%d)\n", msg, __func__, __LINE__); \
            return MVGAL_TEST_FAIL; \
        } \
    } while (0)

#define MVGAL_TEST_ASSERT_EQ(expected, actual, msg) \
    do { \
        if ((expected) != (actual)) { \
            pr_err("MVGAL_TEST: ASSERT_EQ FAILED: %s (%s:%d) - expected %ld, got %ld\n", \
                   msg, __func__, __LINE__, (long)(expected), (long)(actual)); \
            return MVGAL_TEST_FAIL; \
        } \
    } while (0)

#define MVGAL_TEST_ASSERT_GE(expected, actual, msg) \
    do { \
        if ((actual) < (expected)) { \
            pr_err("MVGAL_TEST: ASSERT_GE FAILED: %s (%s:%d) - expected >= %ld, got %ld\n", \
                   msg, __func__, __LINE__, (long)(expected), (long)(actual)); \
            return MVGAL_TEST_FAIL; \
        } \
    } while (0)

#define MVGAL_TEST_ASSERT_LT(expected, actual, msg) \
    do { \
        if ((actual) >= (expected)) { \
            pr_err("MVGAL_TEST: ASSERT_LT FAILED: %s (%s:%d) - expected < %ld, got %ld\n", \
                   msg, __func__, __LINE__, (long)(expected), (long)(actual)); \
            return MVGAL_TEST_FAIL; \
        } \
    } while (0)

#endif /* _MVGAL_TEST_H_ */