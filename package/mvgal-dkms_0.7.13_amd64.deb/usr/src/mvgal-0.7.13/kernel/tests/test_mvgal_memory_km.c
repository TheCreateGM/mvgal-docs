// SPDX-License-Identifier: GPL-2.0-only
#include <kunit/test.h>
#include "../mvgal_memory.h"

static void test_alignment_defaults(struct kunit *test)
{
	struct mvgal_memory mem = {0};

	KUNIT_EXPECT_EQ(test, mem.alignment, 0U);

	/* Verify ALIGN(1024, 128) = 1024 (already aligned) */
	KUNIT_EXPECT_EQ(test, ALIGN(1024, 128), (unsigned long)1024);

	/* Verify ALIGN(1025, 128) = 1152 */
	KUNIT_EXPECT_EQ(test, ALIGN(1025, 128), (unsigned long)1152);

	/* Verify ALIGN(1, 128) = 128 */
	KUNIT_EXPECT_EQ(test, ALIGN(1, 128), (unsigned long)128);
}

static void test_alignment_power_of_two_check(struct kunit *test)
{
	/* Power of 2 test pattern */
	KUNIT_EXPECT_TRUE(test, 128 && !(128 & (128 - 1)));
	KUNIT_EXPECT_TRUE(test, 256 && !(256 & (256 - 1)));
	KUNIT_EXPECT_FALSE(test, 0 && !(0 & (0 - 1)));
	KUNIT_EXPECT_FALSE(test, 127 && !(127 & (127 - 1)));
}

static struct kunit_case mvgal_memory_alignment_tests[] = {
	KUNIT_CASE(test_alignment_defaults),
	KUNIT_CASE(test_alignment_power_of_two_check),
	{}
};

static struct kunit_suite mvgal_memory_alignment_suite = {
	.name = "mvgal-memory-alignment",
	.test_cases = mvgal_memory_alignment_tests,
};
kunit_test_suite(mvgal_memory_alignment_suite);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AxoGM");
MODULE_DESCRIPTION("KUnit tests for MVGAL 128-byte memory alignment");
