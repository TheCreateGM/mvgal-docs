/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * mvgal_p2p.h - PCIe P2P DMA channel management for MVGAL
 *
 * Manages peer-to-peer memory mappings between GPUs on the same
 * PCI root complex. Provides channel setup, data transfer, and
 * teardown for PCIe P2P DMA operations.
 */

#ifndef _MVGAL_P2P_H_
#define _MVGAL_P2P_H_

#include <linux/types.h>
#include <linux/dma-buf.h>
#include <linux/pci.h>

struct mvgal_device;
struct mvgal_gpu_device;
struct mvgal_memory;

/*
 * P2P channel states
 */
enum mvgal_p2p_channel_state {
	MVGAL_P2P_CHAN_IDLE = 0,
	MVGAL_P2P_CHAN_MAPPED,
	MVGAL_P2P_CHAN_ACTIVE,
};

/*
 * Represents a P2P DMA channel between two GPUs.
 *
 * A channel encapsulates the peer-side DMA-BUF mapping that allows
 * one GPU to perform DMA operations directly into another GPU's
 * memory over the PCIe bus (or NVLink/xGMI interconnect).
 */
struct mvgal_p2p_channel {
	uint32_t			src_gpu;
	uint32_t			dst_gpu;
	enum mvgal_p2p_channel_state	state;

	/* Peer-side DMA-BUF mapping for dst to access src memory */
	struct dma_buf			*peer_buf;
	struct dma_buf_attachment	*peer_attach;
	struct sg_table			*peer_sgt;
	enum dma_data_direction		peer_dir;

	/* DMA addresses visible to the destination GPU */
	dma_addr_t			peer_dma_addr;
	size_t				peer_size;

	/* Back-reference */
	struct mvgal_gpu_device		*src_dev;
	struct mvgal_gpu_device		*dst_dev;
};

/*
 * Module-level initialization and cleanup.
 */
int mvgal_p2p_init(void);
void mvgal_p2p_fini(void);

/*
 * Check if P2P transfer is supported between two GPUs.
 *
 * Returns a positive integer indicating the P2P capability level
 * (see enum mvgal_p2p_support in mvgal_memory.h), or 0 if unsupported.
 */
int mvgal_p2p_check_support(struct mvgal_gpu_device *gpu1,
			    struct mvgal_gpu_device *gpu2);

/*
 * Check if any P2P path exists in the system.
 */
bool mvgal_p2p_any_supported(struct mvgal_device *dev);

/*
 * Create a P2P channel from src_gpu to dst_gpu.
 *
 * Sets up the DMA-BUF peer mapping so that dst_gpu can perform
 * DMA operations into src_gpu's memory. The channel must be
 * destroyed with mvgal_p2p_channel_destroy() when no longer needed.
 *
 * Returns 0 on success, negative errno on failure.
 */
int mvgal_p2p_channel_create(struct mvgal_device *dev,
			     uint32_t src_gpu, uint32_t dst_gpu,
			     struct mvgal_p2p_channel *channel);

/*
 * Execute a P2P data transfer through an established channel.
 *
 * Copies @size bytes from @src_offset in the source memory to
 * @dst_offset in the destination memory, using the peer-side DMA
 * mapping for direct PCIe P2P transfer.
 *
 * Returns 0 on success, negative errno on failure.
 */
int mvgal_p2p_transfer(struct mvgal_p2p_channel *channel,
		       struct mvgal_memory *src_mem,
		       struct mvgal_memory *dst_mem,
		       size_t src_offset, size_t dst_offset,
		       size_t size);

/*
 * Destroy a P2P channel and release all resources.
 */
void mvgal_p2p_channel_destroy(struct mvgal_p2p_channel *channel);

#endif /* _MVGAL_P2P_H_ */
