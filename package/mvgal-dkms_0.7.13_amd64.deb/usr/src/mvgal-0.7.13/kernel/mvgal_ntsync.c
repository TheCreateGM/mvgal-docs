/**
 * MVGAL NTSYNC Kernel Module - Wine NT Synchronization Primitives
 *
 * Provides NT-style synchronization objects for Wine/Proton integration:
 * - Mutexes (fast mutexes)
 * - Events (notification events, auto-reset events)
 * - Semaphores (counting semaphores)
 * - Timers
 * - Critical sections
 *
 * Integrates with MVGAL's cross-GPU fence system for zero-CPU-stall synchronization.
 *
 * SPDX-License-Identifier: GPL-2.0
 */

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/wait.h>
#include <linux/slab.h>
#include <linux/dma-fence.h>
#include <linux/dma-buf.h>
#include <linux/anon_inodes.h>
#include <linux/poll.h>
#include <linux/atomic.h>
#include <linux/jiffies.h>
#include <linux/limits.h>
#include <linux/module.h>

#include <mvgal/mvgal_uapi.h>
#include "mvgal_ntsync.h"

#define MVGAL_NTSYNC_VERSION "0.3.0"

/* Module initialized flag — gates mvgal_ntsync_query() */
static bool ntsync_initialized;

/* ------------------------------------------------------------------ */
/*  NTSYNC IOCTL Definitions                                            */
/* ------------------------------------------------------------------ */

#define MVGAL_NTSYNC_IOC_MAGIC 'N'

#define MVGAL_NTSYNC_IOC_CREATE_EVENT     _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 1, struct mvgal_ntsync_create_args)
#define MVGAL_NTSYNC_IOC_OPEN_EVENT       _IOW(MVGAL_NTSYNC_IOC_MAGIC, 2, struct mvgal_ntsync_open_args)
#define MVGAL_NTSYNC_IOC_WAIT_EVENT       _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 3, struct mvgal_ntsync_wait_args)
#define MVGAL_NTSYNC_IOC_SIGNAL_EVENT     _IOW(MVGAL_NTSYNC_IOC_MAGIC, 4, struct mvgal_ntsync_signal_args)
#define MVGAL_NTSYNC_IOC_CREATE_SEMAPHORE _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 5, struct mvgal_ntsync_create_args)
#define MVGAL_NTSYNC_IOC_WAIT_SEMAPHORE    _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 6, struct mvgal_ntsync_wait_args)
#define MVGAL_NTSYNC_IOC_RELEASE_SEMAPHORE  _IOW(MVGAL_NTSYNC_IOC_MAGIC, 7, struct mvgal_ntsync_signal_args)
#define MVGAL_NTSYNC_IOC_CREATE_MUTEX     _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 8, struct mvgal_ntsync_create_args)
#define MVGAL_NTSYNC_IOC_ACQUIRE_MUTEX      _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 9, struct mvgal_ntsync_wait_args)
#define MVGAL_NTSYNC_IOC_RELEASE_MUTEX      _IOW(MVGAL_NTSYNC_IOC_MAGIC, 10, struct mvgal_ntsync_signal_args)
#define MVGAL_NTSYNC_IOC_CREATE_TIMER     _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 11, struct mvgal_ntsync_create_args)
#define MVGAL_NTSYNC_IOC_SET_TIMER        _IOW(MVGAL_NTSYNC_IOC_MAGIC, 12, struct mvgal_ntsync_timer_args)
#define MVGAL_NTSYNC_IOC_CREATE_FENCE     _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 13, struct mvgal_ntsync_fence_args)
#define MVGAL_NTSYNC_IOC_WAIT_FENCE       _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 14, struct mvgal_ntsync_wait_args)
#define MVGAL_NTSYNC_IOC_SIGNAL_FENCE     _IOW(MVGAL_NTSYNC_IOC_MAGIC, 15, struct mvgal_ntsync_signal_args)

/* ------------------------------------------------------------------ */
/*  NTSYNC Structures (defined in mvgal_ntsync.h)                     */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/*  NTSYNC Object Structure                                             */
/* ------------------------------------------------------------------ */

struct mvgal_ntsync_object {
    struct list_head node;
    atomic_t refcount;

    __u32 type;
    __u32 flags;
    __u32 fd;          /* Internal FD */

    /* Event fields */
    atomic_t signaled;
    atomic_t waiters;
    wait_queue_head_t waitq;

    /* Semaphore fields */
    atomic_t count;
    atomic_t max_count;

    /* Fence fields */
    struct dma_fence *dma_fence;

    /* Timer fields */
    struct timer_list timer;
    atomic_t timer_expired;
    atomic_t timer_period_ns;

    /* Mutex owner tracking */
    __u32 owner_tid;
};

/* ------------------------------------------------------------------ */
/*  Global State                                                        */
/* ------------------------------------------------------------------ */

static DEFINE_SPINLOCK(ntsync_lock);
static LIST_HEAD(ntsync_objects);
static const struct file_operations ntsync_fops;

static int debug_level;
module_param(debug_level, int, 0644);
MODULE_PARM_DESC(debug_level, "NTSYNC debug verbosity (0=off, 1=info, 2=trace)");

/* ------------------------------------------------------------------ */
/*  Object Management                                                   */
/* ------------------------------------------------------------------ */

static struct mvgal_ntsync_object *find_object_by_fd(__u32 fd)
{
    struct mvgal_ntsync_object *obj;

    spin_lock(&ntsync_lock);
    list_for_each_entry(obj, &ntsync_objects, node) {
        if (obj->fd == fd) {
            atomic_inc(&obj->refcount);
            spin_unlock(&ntsync_lock);
            return obj;
        }
    }
    spin_unlock(&ntsync_lock);
    return NULL;
}

static void release_object(struct mvgal_ntsync_object *obj)
{
    if (!obj)
        return;

    if (atomic_dec_and_test(&obj->refcount)) {
        /* Disarm any pending timer before freeing — timer callback
         * runs asynchronously and would UAF if it fires after kfree.
         * Loop in case a periodic callback re-arms. */
        if (obj->type == MVGAL_NTSYNC_TYPE_TIMER)
            while (timer_delete_sync(&obj->timer)) {}

        spin_lock(&ntsync_lock);
        list_del(&obj->node);
        spin_unlock(&ntsync_lock);

        if (obj->dma_fence)
            dma_fence_put(obj->dma_fence);

        kfree(obj);
    }
}

/* Timer callback for NTSYNC timer objects */
static void ntsync_timer_callback(struct timer_list *t)
{
    struct mvgal_ntsync_object *obj = container_of(t, struct mvgal_ntsync_object, timer);
    unsigned long period_jiffies;

    /* Timers signal via the same 'signaled' field used by events,
     * so the wait path (which checks obj->signaled) works for timers too */
    atomic_set(&obj->signaled, 1);
    wake_up_all(&obj->waitq);

    /* Re-arm for periodic timers */
    period_jiffies = nsecs_to_jiffies(atomic_read(&obj->timer_period_ns));
    if (period_jiffies > 0)
        mod_timer(&obj->timer, jiffies + period_jiffies);
}

/* ------------------------------------------------------------------ */
/*  Multi-Object Wait Helpers                                          */
/* ------------------------------------------------------------------ */

static int ntsync_is_signaled(struct mvgal_ntsync_object *obj)
{
	switch (obj->type) {
	case MVGAL_NTSYNC_TYPE_EVENT:
	case MVGAL_NTSYNC_TYPE_TIMER:
		return atomic_read(&obj->signaled);
	case MVGAL_NTSYNC_TYPE_SEMAPHORE:
		return atomic_read(&obj->count) > 0;
	case MVGAL_NTSYNC_TYPE_MUTEX:
		return atomic_read(&obj->signaled);
	case MVGAL_NTSYNC_TYPE_FENCE:
		return obj->dma_fence && dma_fence_is_signaled(obj->dma_fence);
	default:
		return 0;
	}
}

static void ntsync_consume_signal(struct mvgal_ntsync_object *obj)
{
	if (!(obj->flags & MVGAL_NTSYNC_FLAG_AUTO_RESET))
		return;

	switch (obj->type) {
	case MVGAL_NTSYNC_TYPE_EVENT:
	case MVGAL_NTSYNC_TYPE_TIMER:
		atomic_set(&obj->signaled, 0);
		break;
	case MVGAL_NTSYNC_TYPE_SEMAPHORE:
		if (atomic_read(&obj->count) > 0)
			atomic_dec(&obj->count);
		break;
	case MVGAL_NTSYNC_TYPE_MUTEX:
		atomic_set(&obj->signaled, 0);
		break;
	}
}

/** ntsync_ioctl_wait_multi — Wait on multiple NTSYNC objects
 *
 * Implements WaitForMultipleObjects semantics:
 *   wait_type=0 (WaitAny): returns when any one object is signaled
 *   wait_type=1 (WaitAll): returns when all objects are signaled
 *
 * Uses kernel prepare_to_wait() on ALL object waitqueues simultaneously,
 * so it wakes correctly when ANY object changes state.
 */
static int ntsync_ioctl_wait_multi(struct mvgal_ntsync_multi_wait_args *args,
				    struct file *file)
{
	struct mvgal_ntsync_object *objs[MVGAL_NTSYNC_MAX_WAIT_OBJECTS];
	struct wait_queue_entry *wait_entries;
	__u32 fds[MVGAL_NTSYNC_MAX_WAIT_OBJECTS];
	int i, j, ret = 0;
	unsigned long timeout_jiffies, expire;
	bool timed;

	if (args->count == 0 || args->count > MVGAL_NTSYNC_MAX_WAIT_OBJECTS)
		return -EINVAL;

	pr_debug("ntsync: wait_multi count=%u wait_type=%u timeout=%llu\n",
		 args->count, args->wait_type, args->timeout_ns);

	wait_entries = kmalloc_array(args->count, sizeof(*wait_entries), GFP_KERNEL);
	if (!wait_entries)
		return -ENOMEM;

	/* Copy FDs from userspace */
	if (copy_from_user(fds, (__u32 __user *)(unsigned long)args->fds,
			   args->count * sizeof(__u32))) {
		kfree(wait_entries);
		return -EFAULT;
	}

	/* Look up all objects */
	memset(objs, 0, sizeof(objs));
	for (i = 0; i < args->count; i++) {
		objs[i] = find_object_by_fd(fds[i]);
		if (!objs[i]) {
			for (j = 0; j < i; j++)
				release_object(objs[j]);
			ret = -ENOENT;
			goto out;
		}
	}

	timeout_jiffies = args->timeout_ns ?
			  nsecs_to_jiffies(args->timeout_ns) :
			  MAX_SCHEDULE_TIMEOUT;
	timed = (timeout_jiffies != MAX_SCHEDULE_TIMEOUT);
	expire = timed ? jiffies + timeout_jiffies : 0;

	/* Initialize wait entries */
	for (i = 0; i < args->count; i++)
		init_wait_entry(&wait_entries[i], 0);

	for (;;) {
		int signaled_idx = -1;
		int all_signaled = 1;

		/* Register on ALL waitqueues BEFORE checking conditions.
		 * This eliminates the check-then-sleep race where a signal
		 * arrives between our condition check and prepare_to_wait(),
		 * causing a lost wakeup.  The standard kernel pattern is:
		 *   prepare_to_wait → check condition → schedule. */
		for (i = 0; i < args->count; i++)
			prepare_to_wait(&objs[i]->waitq,
					&wait_entries[i],
					TASK_INTERRUPTIBLE);

		/* Check all objects */
		for (i = 0; i < args->count; i++) {
			if (ntsync_is_signaled(objs[i])) {
				if (args->wait_type == 0) { /* WaitAny */
					signaled_idx = i;
					break;
				}
			} else {
				all_signaled = 0;
			}
		}

		if (signaled_idx >= 0) {
			for (i = 0; i < args->count; i++)
				finish_wait(&objs[i]->waitq, &wait_entries[i]);
			ntsync_consume_signal(objs[signaled_idx]);
			args->status = 0;
			args->index = signaled_idx;
			goto out;
		}

		if (all_signaled && args->wait_type == 1) { /* WaitAll */
			for (i = 0; i < args->count; i++) {
				ntsync_consume_signal(objs[i]);
				finish_wait(&objs[i]->waitq, &wait_entries[i]);
			}
			args->status = 0;
			args->index = args->count;
			goto out;
		}

		/* Check timeout */
		if (timed && time_after_eq(jiffies, expire)) {
			for (i = 0; i < args->count; i++)
				finish_wait(&objs[i]->waitq, &wait_entries[i]);
			args->status = 1; /* Timeout */
			args->index = args->count;
			goto out;
		}

		/* Sleep — wake_up_all from signalers will reschedule us */
		if (timed)
			schedule_timeout(expire - jiffies);
		else
			schedule();

		/* Unregister all wait entries */
		for (i = 0; i < args->count; i++)
			finish_wait(&objs[i]->waitq, &wait_entries[i]);

		/* Handle signals */
		if (signal_pending(current)) {
			ret = -ERESTARTSYS;
			goto out;
		}
	}

out:
	kfree(wait_entries);
	for (i = 0; i < args->count; i++)
		release_object(objs[i]);
	return ret;
}

static struct mvgal_ntsync_object *create_object(__u32 type, __u32 flags)
{
    struct mvgal_ntsync_object *obj;

    obj = kzalloc(sizeof(*obj), GFP_KERNEL);
    if (!obj)
        return NULL;

    atomic_set(&obj->refcount, 1);
    obj->type = type;
    obj->flags = flags;
    init_waitqueue_head(&obj->waitq);

    pr_debug("ntsync: create type=%u flags=0x%x\n", type, flags);

    switch (type) {
    case MVGAL_NTSYNC_TYPE_EVENT:
        atomic_set(&obj->signaled, flags & MVGAL_NTSYNC_FLAG_SIGNALED ? 1 : 0);
        atomic_set(&obj->waiters, 0);
        break;

    case MVGAL_NTSYNC_TYPE_SEMAPHORE:
        atomic_set(&obj->count, 0);
        atomic_set(&obj->max_count, 0);
        break;

    case MVGAL_NTSYNC_TYPE_MUTEX:
        atomic_set(&obj->signaled, 1); /* Unlocked */
        obj->owner_tid = 0;
        break;

    case MVGAL_NTSYNC_TYPE_TIMER:
        atomic_set(&obj->signaled, 0);
        atomic_set(&obj->timer_period_ns, 0);
        timer_setup(&obj->timer, ntsync_timer_callback, 0);
        /* Auto-reset: wait consumes the signal so periodic timers work correctly */
        obj->flags |= MVGAL_NTSYNC_FLAG_AUTO_RESET;
        break;

    case MVGAL_NTSYNC_TYPE_FENCE:
        /* Fence is created on-demand when signaled */
        obj->dma_fence = NULL;
        break;
    }

    spin_lock(&ntsync_lock);
    list_add_tail(&obj->node, &ntsync_objects);
    spin_unlock(&ntsync_lock);

    return obj;
}

/* ------------------------------------------------------------------ */
/*  File Operations                                                   */
/* ------------------------------------------------------------------ */

static int ntsync_open(struct inode *inode, struct file *file)
{
    file->private_data = NULL;
    return 0;
}

static int ntsync_release(struct inode *inode, struct file *file)
{
    struct mvgal_ntsync_object *obj = file->private_data;
    release_object(obj);
    return 0;
}

static __poll_t ntsync_poll(struct file *file, struct poll_table_struct *wait)
{
    struct mvgal_ntsync_object *obj = file->private_data;
    __poll_t mask = 0;

    if (!obj)
        return POLLERR;

    switch (obj->type) {
    case MVGAL_NTSYNC_TYPE_EVENT:
        poll_wait(file, &obj->waitq, wait);
        if (atomic_read(&obj->signaled))
            mask |= POLLIN | POLLRDNORM;
        break;

    case MVGAL_NTSYNC_TYPE_SEMAPHORE:
        poll_wait(file, &obj->waitq, wait);
        if (atomic_read(&obj->count) > 0)
            mask |= POLLIN | POLLRDNORM;
        break;

    case MVGAL_NTSYNC_TYPE_TIMER:
        poll_wait(file, &obj->waitq, wait);
        if (atomic_read(&obj->signaled))
            mask |= POLLIN | POLLRDNORM;
        break;

    case MVGAL_NTSYNC_TYPE_MUTEX:
        poll_wait(file, &obj->waitq, wait);
        if (atomic_read(&obj->signaled))
            mask |= POLLIN | POLLRDNORM;
        break;

    case MVGAL_NTSYNC_TYPE_FENCE:
        poll_wait(file, &obj->waitq, wait);
        if (obj->dma_fence && dma_fence_is_signaled(obj->dma_fence))
            mask |= POLLIN | POLLRDNORM;
        break;

    default:
        mask = POLLIN | POLLOUT;
        break;
    }

    return mask;
}

/* ------------------------------------------------------------------ */
/*  IOCTL Handlers                                                      */
/* ------------------------------------------------------------------ */

static long ntsync_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct mvgal_ntsync_create_args create_args;
    struct mvgal_ntsync_wait_args wait_args;
    struct mvgal_ntsync_signal_args signal_args;
    struct mvgal_ntsync_fence_args fence_args;
    struct mvgal_ntsync_object *obj;
    __u32 type;
    int ret = 0;

    switch (cmd) {
    case MVGAL_NTSYNC_IOC_CREATE_EVENT:
        type = MVGAL_NTSYNC_TYPE_EVENT;
        goto create_regular;
    case MVGAL_NTSYNC_IOC_CREATE_SEMAPHORE:
        type = MVGAL_NTSYNC_TYPE_SEMAPHORE;
        goto create_regular;
    case MVGAL_NTSYNC_IOC_CREATE_MUTEX:
        type = MVGAL_NTSYNC_TYPE_MUTEX;
        goto create_regular;
    case MVGAL_NTSYNC_IOC_CREATE_TIMER:
        type = MVGAL_NTSYNC_TYPE_TIMER;
        goto create_regular;

create_regular:
        if (copy_from_user(&create_args, (void __user *)arg, sizeof(create_args)))
            return -EFAULT;

        obj = create_object(type, create_args.flags);
        if (!obj)
            return -ENOMEM;

        /* Set initial values for semaphores — max_count = INT_MAX (Windows LONG_MAX behavior) */
        if (type == MVGAL_NTSYNC_TYPE_SEMAPHORE) {
            if ((__s32)create_args.initial < 0) {
                release_object(obj);
                return -EINVAL;
            }
            atomic_set(&obj->count, create_args.initial);
            atomic_set(&obj->max_count, INT_MAX);
        }

        /* Create anon inode FD */
        ret = anon_inode_getfd("mvgal_ntsync", &ntsync_fops, obj,
                               O_RDWR | (create_args.flags & MVGAL_NTSYNC_FLAG_SHARED ? 0 : O_CLOEXEC));
        if (ret < 0) {
            release_object(obj);
            return ret;
        }

        create_args.type = type;
        create_args.fd = ret;
        obj->fd = ret;

        if (copy_to_user((void __user *)arg, &create_args, sizeof(create_args)))
            return -EFAULT;

        return 0;

    case MVGAL_NTSYNC_IOC_SET_TIMER:
    {
        struct mvgal_ntsync_timer_args timer_args;

        if (copy_from_user(&timer_args, (void __user *)arg, sizeof(timer_args)))
            return -EFAULT;

        obj = find_object_by_fd(timer_args.fd);
        if (!obj)
            return -ENOENT;

        if (obj->type != MVGAL_NTSYNC_TYPE_TIMER) {
            release_object(obj);
            return -EINVAL;
        }

        /* Disarm any existing timer */
        timer_delete_sync(&obj->timer);

        /* Set period for re-arm in callback */
        atomic_set(&obj->timer_period_ns, timer_args.period_ns);

        /* Arm: due_time > 0 = absolute delta; <= 0 = immediate */
        if (timer_args.due_time_ns > 0) {
            unsigned long due_jiffies = nsecs_to_jiffies(timer_args.due_time_ns);
            mod_timer(&obj->timer, jiffies + (due_jiffies ? : 1));
        } else {
            mod_timer(&obj->timer, jiffies);
        }

        release_object(obj);
        return 0;
    }

    case MVGAL_NTSYNC_IOC_CREATE_FENCE:
        if (copy_from_user(&fence_args, (void __user *)arg, sizeof(fence_args)))
            return -EFAULT;

        obj = create_object(MVGAL_NTSYNC_TYPE_FENCE, fence_args.flags);
        if (!obj)
            return -ENOMEM;

        /* For fences, store GPU index for cross-GPU integration. */
        obj->owner_tid = fence_args.gpu_index;

        /* Create anon inode FD */
        ret = anon_inode_getfd("mvgal_ntsync", &ntsync_fops, obj,
                               O_RDWR | (fence_args.flags & MVGAL_NTSYNC_FLAG_SHARED ? 0 : O_CLOEXEC));
        if (ret < 0) {
            release_object(obj);
            return ret;
        }

        fence_args.fd = ret;
        obj->fd = ret;

        if (copy_to_user((void __user *)arg, &fence_args, sizeof(fence_args)))
            return -EFAULT;

        return 0;

    case MVGAL_NTSYNC_IOC_WAIT_EVENT:
    case MVGAL_NTSYNC_IOC_WAIT_SEMAPHORE:
    case MVGAL_NTSYNC_IOC_ACQUIRE_MUTEX:
    case MVGAL_NTSYNC_IOC_WAIT_FENCE:
        if (copy_from_user(&wait_args, (void __user *)arg, sizeof(wait_args)))
            return -EFAULT;

        obj = find_object_by_fd(wait_args.fd);
        if (!obj)
            return -ENOENT;

        atomic_inc(&obj->waiters);

        switch (obj->type) {
        case MVGAL_NTSYNC_TYPE_EVENT:
            if (wait_args.timeout_ns == 0) {
                wait_event(obj->waitq, atomic_read(&obj->signaled) != 0);
            } else {
                unsigned long timeout = nsecs_to_jiffies(wait_args.timeout_ns);
                if (!wait_event_timeout(obj->waitq,
                                       atomic_read(&obj->signaled) != 0,
                                       timeout)) {
                    wait_args.status = 1; /* Timed out */
                    atomic_dec(&obj->waiters);
                    release_object(obj);
                    goto out_copy_wait;
                }
            }
            wait_args.status = 0;
            if (obj->flags & MVGAL_NTSYNC_FLAG_AUTO_RESET) {
                atomic_set(&obj->signaled, 0);
            }
            break;

        case MVGAL_NTSYNC_TYPE_SEMAPHORE:
            while (atomic_read(&obj->count) == 0) {
                if (wait_args.timeout_ns == 0) {
                    wait_event(obj->waitq, atomic_read(&obj->count) > 0);
                } else {
                    unsigned long timeout = nsecs_to_jiffies(wait_args.timeout_ns);
                    if (!wait_event_timeout(obj->waitq,
                                           atomic_read(&obj->count) > 0,
                                           timeout)) {
                        wait_args.status = 1; /* Timed out */
                        atomic_dec(&obj->waiters);
                        release_object(obj);
                        goto out_copy_wait;
                    }
                }
            }
            atomic_dec(&obj->count);
            wait_args.status = 0;
            break;

        case MVGAL_NTSYNC_TYPE_MUTEX:
            if (wait_args.timeout_ns == 0) {
                wait_event(obj->waitq, atomic_read(&obj->signaled) != 0);
            } else {
                unsigned long timeout = nsecs_to_jiffies(wait_args.timeout_ns);
                if (!wait_event_timeout(obj->waitq,
                                       atomic_read(&obj->signaled) != 0,
                                       timeout)) {
                    wait_args.status = 1; /* Timed out */
                    atomic_dec(&obj->waiters);
                    release_object(obj);
                    goto out_copy_wait;
                }
            }
            atomic_set(&obj->signaled, 0);
            obj->owner_tid = current->pid;
            wait_args.status = 0;
            break;

        case MVGAL_NTSYNC_TYPE_FENCE:
            /* For cross-GPU fences, we need to wait on the DMA fence */
            if (obj->dma_fence) {
                if (dma_fence_wait_timeout(obj->dma_fence, true,
                                          nsecs_to_jiffies(wait_args.timeout_ns))) {
                    wait_args.status = 0;
                } else {
                    wait_args.status = 1; /* Timed out */
                }
            } else {
                wait_args.status = 0; /* No fence = already signaled */
            }
            break;
        }

        atomic_dec(&obj->waiters);
        release_object(obj);
        break;

	case MVGAL_NTSYNC_IOC_SIGNAL_EVENT:
	case MVGAL_NTSYNC_IOC_RELEASE_SEMAPHORE:
	case MVGAL_NTSYNC_IOC_RELEASE_MUTEX:
	case MVGAL_NTSYNC_IOC_SIGNAL_FENCE:
		if (copy_from_user(&signal_args, (void __user *)arg, sizeof(signal_args)))
			return -EFAULT;

		obj = find_object_by_fd(signal_args.fd);
		if (!obj)
			return -ENOENT;

		switch (obj->type) {
		case MVGAL_NTSYNC_TYPE_EVENT:
			atomic_set(&obj->signaled, 1);
			wake_up_all(&obj->waitq);
			break;

        case MVGAL_NTSYNC_TYPE_SEMAPHORE:
            atomic_inc(&obj->count);
            if (atomic_read(&obj->count) > atomic_read(&obj->max_count)) {
                atomic_set(&obj->count, atomic_read(&obj->max_count));
            }
            wake_up_all(&obj->waitq);
            break;

        case MVGAL_NTSYNC_TYPE_MUTEX:
            atomic_set(&obj->signaled, 1); /* Unlocked */
            obj->owner_tid = 0;
            wake_up_all(&obj->waitq);
            break;

        case MVGAL_NTSYNC_TYPE_FENCE:
            if (obj->dma_fence)
                dma_fence_signal(obj->dma_fence);
            wake_up_all(&obj->waitq);
            break;
        }

        release_object(obj);
        return 0;

    case MVGAL_NTSYNC_IOC_WAIT_MULTI:
    {
        struct mvgal_ntsync_multi_wait_args multi_args;

        if (copy_from_user(&multi_args, (void __user *)arg, sizeof(multi_args)))
            return -EFAULT;

        ret = ntsync_ioctl_wait_multi(&multi_args, file);
        if (ret == -ERESTARTSYS)
            return ret;

        if (copy_to_user((void __user *)arg, &multi_args, sizeof(multi_args)))
            return -EFAULT;

        return ret;
    }

    default:
        return -ENOTTY;
    }

out_copy_wait:
    if (copy_to_user((void __user *)arg, &wait_args, sizeof(wait_args)))
        return -EFAULT;

    return ret;
}

/* ------------------------------------------------------------------ */
/*  File Operations Structure                                           */
/* ------------------------------------------------------------------ */

static const struct file_operations ntsync_fops = {
    .owner          = THIS_MODULE,
    .open           = ntsync_open,
    .release        = ntsync_release,
    .poll           = ntsync_poll,
    .unlocked_ioctl = ntsync_ioctl,
    .compat_ioctl   = ntsync_ioctl,
};

/* ------------------------------------------------------------------ */
/*  Misc Device                                                       */
/* ------------------------------------------------------------------ */

static struct miscdevice ntsync_miscdev = {
    .minor = MISC_DYNAMIC_MINOR,
    .name  = "mvgal_ntsync",
    .fops  = &ntsync_fops,
};

/* ------------------------------------------------------------------ */
/*  NTSYNC Query (userspace capability discovery)                     */
/* ------------------------------------------------------------------ */

int mvgal_ntsync_query(struct mvgal_uapi_ntsync_info *info)
{
	if (!ntsync_initialized)
		return -ENODEV;

	memset(info, 0, sizeof(*info));

	/* Parse MVGAL_NTSYNC_VERSION "0.3.0" */
	if (sscanf(MVGAL_NTSYNC_VERSION, "%u.%u.%u",
		   &info->version_major, &info->version_minor,
		   &info->version_patch) != 3) {
		pr_err("MVGAL NTSYNC: failed to parse version string\n");
		return -EIO;
	}

	/* All primitive types are supported */
	info->capabilities = (MVGAL_NTSYNC_CAP_EVENT     |
			      MVGAL_NTSYNC_CAP_SEMAPHORE |
			      MVGAL_NTSYNC_CAP_MUTEX     |
			      MVGAL_NTSYNC_CAP_TIMER     |
			      MVGAL_NTSYNC_CAP_FENCE);

	return 0;
}
EXPORT_SYMBOL(mvgal_ntsync_query);

/* ------------------------------------------------------------------ */
/*  Module Entry/Exit                                                 */
/* ------------------------------------------------------------------ */

int __init mvgal_ntsync_init(void)
{
    int ret;

    pr_info("MVGAL NTSYNC module loaded (v%s)\n", MVGAL_NTSYNC_VERSION);

    ret = misc_register(&ntsync_miscdev);
    if (ret) {
        pr_err("Failed to register misc device: %d\n", ret);
        return ret;
    }

    ntsync_initialized = true;
    pr_info("MVGAL NTSYNC: /dev/mvgal_ntsync ready\n");
    return 0;
}

void __exit mvgal_ntsync_exit(void)
{
	struct mvgal_ntsync_object *obj, *tmp;

	ntsync_initialized = false;

	/*
	 * Deregister the misc device first so no new opens/ioctls can arrive.
	 * Then walk the object list: cancel any pending timers before freeing,
	 * otherwise the timer callback fires after module text is unmapped.
	 */
	misc_deregister(&ntsync_miscdev);

	spin_lock(&ntsync_lock);
	list_for_each_entry_safe(obj, tmp, &ntsync_objects, node) {
		list_del(&obj->node);
		spin_unlock(&ntsync_lock);

		if (obj->type == MVGAL_NTSYNC_TYPE_TIMER)
			while (timer_delete_sync(&obj->timer)) {}

		if (obj->dma_fence)
			dma_fence_put(obj->dma_fence);

		kfree(obj);
		spin_lock(&ntsync_lock);
	}
	spin_unlock(&ntsync_lock);

	pr_info("MVGAL NTSYNC module unloaded\n");
}

module_init(mvgal_ntsync_init);
module_exit(mvgal_ntsync_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AxoGM");
MODULE_DESCRIPTION("MVGAL NTSYNC - Wine NT Synchronization Primitives for multi-GPU");


