/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * MVGAL trace provider — tracefs-based scheduling and event logging
 *
 * Provides a ring-buffer trace log exposed via /sys/kernel/debug/mvgal/trace
 * for debugging scheduling decisions, memory migrations, P2P transfers,
 * power events, and errors.
 */
#ifndef _MVGAL_TRACE_H_
#define _MVGAL_TRACE_H_

#include <linux/types.h>

#define MVGAL_TRACE_MSG_LEN	128
#define MVGAL_TRACE_MAX_ENTRIES	1024

enum mvgal_trace_type {
	MVGAL_TRACE_SCHEDULE = 0,	/* Workload scheduling decisions */
	MVGAL_TRACE_MEMORY,		/* Memory allocation / migration */
	MVGAL_TRACE_P2P,		/* P2P DMA transfers */
	MVGAL_TRACE_POWER,		/* Power state changes */
	MVGAL_TRACE_DEVICE,		/* Device add/remove/state */
	MVGAL_TRACE_ERROR,		/* Errors and warnings */
	MVGAL_TRACE_TYPE_COUNT
};

struct mvgal_trace_entry {
	u64			timestamp;	/* ktime_get_ns() */
	enum mvgal_trace_type	type;
	char			msg[MVGAL_TRACE_MSG_LEN];
};

struct mvgal_trace_buffer {
	struct mvgal_trace_entry entries[MVGAL_TRACE_MAX_ENTRIES];
	unsigned int		head;		/* Next write index */
	unsigned int		count;		/* Total entries written (wraps) */
	spinlock_t		lock;
	bool			initialized;
};

/* Module init/fini — called from mvgal_core.c */
int mvgal_trace_init(void);
void mvgal_trace_fini(void);

/* Log a trace event (can be called from any context) */
void mvgal_trace_event(enum mvgal_trace_type type, const char *fmt, ...)
	__printf(2, 3);

/* Convenience macros for common trace types */
#define mvgal_trace_schedule(fmt, ...) \
	mvgal_trace_event(MVGAL_TRACE_SCHEDULE, fmt, ##__VA_ARGS__)
#define mvgal_trace_memory(fmt, ...) \
	mvgal_trace_event(MVGAL_TRACE_MEMORY, fmt, ##__VA_ARGS__)
#define mvgal_trace_p2p(fmt, ...) \
	mvgal_trace_event(MVGAL_TRACE_P2P, fmt, ##__VA_ARGS__)
#define mvgal_trace_power(fmt, ...) \
	mvgal_trace_event(MVGAL_TRACE_POWER, fmt, ##__VA_ARGS__)
#define mvgal_trace_device(fmt, ...) \
	mvgal_trace_event(MVGAL_TRACE_DEVICE, fmt, ##__VA_ARGS__)
#define mvgal_trace_error(fmt, ...) \
	mvgal_trace_event(MVGAL_TRACE_ERROR, fmt, ##__VA_ARGS__)

#endif /* _MVGAL_TRACE_H_ */
