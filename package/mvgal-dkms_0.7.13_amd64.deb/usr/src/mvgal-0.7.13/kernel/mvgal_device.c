/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 * 
 * Device Management - Logical device creation and GPU enumeration
 * 
 * SPDX-License-Identifier: GPL-2.0-only
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/version.h>
#include <linux/pci.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/dma-buf.h>
#include <linux/pci-p2pdma.h>
#include <linux/fs.h>
#include <drm/drm_device.h>
#include <drm/drm_drv.h>

#include "mvgal_core.h"
#include "mvgal_device.h"
#include "mvgal_memory.h"
#include "mvgal_power.h"

/* Previously included mvgal_sync.h for fence definitions */
#include "mvgal_sync.h"

/* DRM driver (defined in mvgal_core.c) */
extern struct drm_driver mvgal_drm_driver;

/*
 * mvgal_device_init - Initialize the MVGAL logical device
 */
int mvgal_device_init(struct mvgal_device **dev_out, struct device *parent)
{
	struct mvgal_device *dev;
	int ret = 0;

	dev = kzalloc(sizeof(*dev), GFP_KERNEL);
	if (!dev) {
		return -ENOMEM;
	}

	dev->dev = parent;

	/* Initialize DRM device */
	dev->drm = drm_dev_alloc(&mvgal_drm_driver, parent);
	if (IS_ERR(dev->drm)) {
		ret = PTR_ERR(dev->drm);
		pr_err("MVGAL: Failed to allocate DRM device\n");
		goto err_free_dev;
	}

	/* Initialize lists and locks */
	INIT_LIST_HEAD(&dev->gpu_list);
	mutex_init(&dev->gpu_lock);
	INIT_LIST_HEAD(&dev->workload_queue);
	mutex_init(&dev->workload_lock);
	init_waitqueue_head(&dev->workload_waitq);
	INIT_LIST_HEAD(&dev->fence_list);
	mutex_init(&dev->fence_lock);
	atomic_set(&dev->next_fence_seq, 1);

	dev->gpu_count = 0;
	dev->initialized = true;
	dev->daemon_connected = false;

	/* Enumerate physical GPUs via PCI bus */
	mvgal_enumerate_gpus(dev);

	*dev_out = dev;
	return 0;

err_free_dev:
	kfree(dev);
	return ret;
}

/**
 * mvgal_device_fini - Cleanup the MVGAL logical device
 */
void mvgal_device_fini(struct mvgal_device *dev)
{
	if (!dev) {
		return;
	}

	pr_debug("MVGAL: Cleaning up logical device\n");

	/* Cleanup all GPUs */
	mvgal_gpu_cleanup_all(dev);

	/* Cleanup DRM device */
	drm_dev_put(dev->drm);

	/* Free device */
	kfree(dev);
}

/**
 * mvgal_gpu_alloc - Allocate a new GPU device structure
 */
struct mvgal_gpu_device *mvgal_gpu_alloc(enum mvgal_vendor_id vendor)
{
	struct mvgal_gpu_device *gpu;

	gpu = kzalloc(sizeof(*gpu), GFP_KERNEL);
	if (!gpu) {
		return NULL;
	}

	gpu->vendor = vendor;
	gpu->available = true;
	gpu->enabled = true;
	gpu->gpu_index = 0;
	gpu->power_draw = 0;
	gpu->dvfs = NULL;
	gpu->thermal = NULL;
	mutex_init(&gpu->lock);

	/* Look up vendor operations from registration table */
	gpu->ops = mvgal_core_find_vendor_ops(vendor);

	return gpu;
}

/**
 * mvgal_gpu_free - Free a GPU device structure
 */
void mvgal_gpu_free(struct mvgal_gpu_device *gpu)
{
	if (!gpu) {
		return;
	}

	/* Stop and cleanup DVFS */
	if (gpu->dvfs) {
		mvgal_dvfs_stop(gpu);
		mvgal_dvfs_fini(gpu);
	}

	/* Stop and cleanup thermal */
	if (gpu->thermal) {
		mvgal_thermal_stop(gpu);
		mvgal_thermal_fini(gpu);
	}

	/* Unregister from power budget */
	mvgal_power_budget_unregister_gpu(gpu->gpu_index);

	if (gpu->ops && gpu->ops->fini) {
		gpu->ops->fini(gpu);
	}

	mutex_destroy(&gpu->lock);
	kfree(gpu->vendor_priv);

	/*
	 * Release the read-only pci_dev reference taken by
	 * mvgal_enumerate_gpus() when this GPU was discovered.  MVGAL does
	 * not own the function, so it must not call pci_disable_device()
	 * or pci_set_master() here — the native driver owns those.
	 */
	if (gpu->pdev)
		pci_dev_put(gpu->pdev);

	kfree(gpu);
}

/**
 * mvgal_probe_gpu_capabilities - Ask the vendor what it can really do
 * @gpu: GPU to probe
 *
 * Delegates to the vendor's probe_capabilities() op and caches the result in
 * gpu->cap_flags.  Every bit is a verified fact about this machine, not an
 * assumption about the vendor family.
 *
 * If there is no ops table at all, or the vendor provides no probe op, the
 * result is zero capabilities with caps_probed left clear: the core refuses
 * to assume anything on a vendor's behalf.  That is the safe default - an
 * unprobed GPU is treated exactly like a GPU whose driver is missing.
 *
 * Return: 0 on success (including "probed, nothing available"),
 *         -EINVAL on bad arguments, -EOPNOTSUPP if the vendor cannot probe.
 */
int mvgal_probe_gpu_capabilities(struct mvgal_gpu_device *gpu)
{
	uint32_t caps = 0;
	int ret;

	if (!gpu)
		return -EINVAL;

	gpu->cap_flags = 0;
	gpu->caps_probed = false;

	if (!gpu->ops || !gpu->ops->probe_capabilities) {
		pr_debug("MVGAL: GPU %u (%s) has no capability probe; assuming no capabilities\n",
			 gpu->gpu_index, gpu->name);
		return -EOPNOTSUPP;
	}

	ret = gpu->ops->probe_capabilities(gpu, &caps);
	if (ret < 0) {
		gpu->cap_flags = 0;
		pr_warn("MVGAL: Capability probe failed for GPU %u (%s): %d; assuming no capabilities\n",
			gpu->gpu_index, gpu->name, ret);
		return ret;
	}

	gpu->cap_flags = caps;
	gpu->caps_probed = true;

	pr_info("MVGAL: GPU %u (%s) capabilities: 0x%02x [%s%s%s%s%s%s%s%s]\n",
		gpu->gpu_index, gpu->name, caps,
		mvgal_gpu_can(gpu, MVGAL_CAP_KERNEL_SUBMIT)  ? "submit " : "",
		mvgal_gpu_can(gpu, MVGAL_CAP_KERNEL_VRAM)    ? "vram "    : "",
		mvgal_gpu_can(gpu, MVGAL_CAP_BUSY_PERCENT)   ? "busy "    : "",
		mvgal_gpu_can(gpu, MVGAL_CAP_PPM)            ? "ppm "     : "",
		mvgal_gpu_can(gpu, MVGAL_CAP_DMABUF_EXPORT)  ? "exp "     : "",
		mvgal_gpu_can(gpu, MVGAL_CAP_DMABUF_IMPORT)  ? "imp "     : "",
		mvgal_gpu_can(gpu, MVGAL_CAP_WAIT_IDLE)      ? "idle "    : "",
		mvgal_gpu_can(gpu, MVGAL_CAP_BO_QUERY)       ? "boq "     : "");

	return 0;
}

/**
 * mvgal_gpu_can - Test whether a GPU has a probed capability
 * @gpu: GPU to query
 * @cap: A single MVGAL_CAP_* bit
 *
 * An unprobed GPU never reports a capability.  Callers use this instead of
 * testing "ops->foo != NULL", because an op can be present in the table and
 * still be unsupported on a given device.
 */
bool mvgal_gpu_can(const struct mvgal_gpu_device *gpu, uint32_t cap)
{
	if (!gpu || !gpu->caps_probed)
		return false;
	return (gpu->cap_flags & cap) == cap;
}

/**
 * mvgal_cap_name - Map a capability bit to a stable lowercase name
 *
 * Used for sysfs and trace output so the mask is greppable and diffable.
 */
const char *mvgal_cap_name(uint32_t cap)
{
	switch (cap) {
	case MVGAL_CAP_KERNEL_SUBMIT: return "kernel-submit";
	case MVGAL_CAP_KERNEL_VRAM:   return "kernel-vram";
	case MVGAL_CAP_BUSY_PERCENT:  return "busy-percent";
	case MVGAL_CAP_PPM:           return "power-level";
	case MVGAL_CAP_DMABUF_EXPORT: return "dmabuf-export";
	case MVGAL_CAP_DMABUF_IMPORT: return "dmabuf-import";
	case MVGAL_CAP_WAIT_IDLE:     return "wait-idle";
	case MVGAL_CAP_BO_QUERY:      return "bo-query";
	default:                      return "unknown";
	}
}

/**
 * mvgal_native_driver - Name of the driver currently bound to a PCI function
 * @pdev: PCI device to inspect
 *
 * MVGAL never binds a GPU itself (see the note in mvgal_device.h), so the
 * only driver that can own a GPU here is the vendor's native one.  Reading
 * pdev->driver is the authoritative, read-only answer to "is this GPU actually
 * usable right now", and it costs nothing and perturbs nothing.
 *
 * Return: driver name, or NULL if nothing is bound to the function.
 */
const char *mvgal_native_driver(struct pci_dev *pdev)
{
	if (!pdev || !pdev->driver)
		return NULL;
	return pdev->driver->name;
}

/**
 * mvgal_dev_attr_exists - Test whether a sysfs attribute exists for a PCI function
 * @pdev: PCI device to look under
 * @attr: Attribute file name, e.g. "gpu_busy_percent"
 *
 * This is the ground truth for telemetry and power-control availability: the
 * attribute exists only if the bound driver created it on this kernel.  It
 * opens the file read-only and closes it immediately; nothing is read or
 * written.
 */
bool mvgal_dev_attr_exists(struct pci_dev *pdev, const char *attr)
{
	char path[128];
	struct file *f;

	if (!pdev || !attr)
		return false;

	snprintf(path, sizeof(path),
		 "/sys/bus/pci/devices/%04x:%02x:%02x.%u/%s",
		 (unsigned int)pci_domain_nr(pdev->bus),
		 pdev->bus->number,
		 PCI_SLOT(pdev->devfn), PCI_FUNC(pdev->devfn),
		 attr);

	f = filp_open(path, O_RDONLY, 0);
	if (IS_ERR(f))
		return false;

	filp_close(f, NULL);
	return true;
}
EXPORT_SYMBOL_GPL(mvgal_dev_attr_exists);

EXPORT_SYMBOL_GPL(mvgal_native_driver);

/**
 * mvgal_gpu_add - Add a GPU to the MVGAL logical device
 */
int mvgal_gpu_add(struct mvgal_device *dev, struct mvgal_gpu_device *gpu)
{
	int ret;

	if (!dev || !gpu) {
		return -EINVAL;
	}

	mutex_lock(&dev->gpu_lock);

	if (dev->gpu_count >= MVGAL_MAX_GPUS) {
		mutex_unlock(&dev->gpu_lock);
		return -ENOSPC;
	}

	/* Set GPU index */
	gpu->gpu_index = dev->gpu_count;

	/* Initialize GPU if ops are available */
	if (gpu->ops && gpu->ops->init) {
		ret = gpu->ops->init(gpu);
		if (ret < 0) {
			mutex_unlock(&dev->gpu_lock);
			return ret;
		}
	}

	/*
	 * Probe what this vendor can actually do before anything downstream
	 * makes a scheduling or memory decision based on it.  Non-fatal: a GPU
	 * with no capabilities is still enumerated and reported, it just has
	 * every accelerated path disabled and falls back everywhere.
	 */
	ret = mvgal_probe_gpu_capabilities(gpu);
	if (ret < 0) {
		pr_info("MVGAL: GPU %u (%s) exposes no probed capabilities; every accelerated path falls back\n",
			gpu->gpu_index, gpu->name);
	}

	/* Initialize DVFS for this GPU */
	ret = mvgal_dvfs_init(gpu);
	if (ret < 0) {
		pr_warn("MVGAL: Failed to initialize DVFS for GPU %s: %d\n",
			gpu->name, ret);
		/* Non-fatal - continue without DVFS */
	}

	/* Initialize thermal throttling for this GPU */
	ret = mvgal_thermal_init(gpu);
	if (ret < 0) {
		pr_warn("MVGAL: Failed to initialize thermal for GPU %s: %d\n",
			gpu->name, ret);
		/* Non-fatal - continue without thermal */
	}

	/* Register GPU with power budget */
	ret = mvgal_power_budget_register_gpu(gpu, gpu->gpu_index);
	if (ret < 0) {
		pr_warn("MVGAL: Failed to register GPU %s with power budget: %d\n",
			gpu->name, ret);
		/* Non-fatal - continue without power budget */
	}

	/* Add to GPU list */
	list_add_tail(&gpu->node, &dev->gpu_list);
	dev->gpu_count++;

	pr_info("MVGAL: Added GPU '%s' (vendor=%d, vram=%llu MB, index=%u)\n",
		gpu->name, gpu->vendor,
		(unsigned long long)(gpu->vram_size / (1024ULL * 1024ULL)),
		gpu->gpu_index);

	mutex_unlock(&dev->gpu_lock);

	return 0;
}

/**
 * mvgal_gpu_remove - Remove a GPU from the MVGAL logical device
 */
void mvgal_gpu_remove(struct mvgal_device *dev, struct mvgal_gpu_device *gpu)
{
	if (!dev || !gpu) {
		return;
	}

	mutex_lock(&dev->gpu_lock);
	
	list_del(&gpu->node);
	dev->gpu_count--;

	mutex_unlock(&dev->gpu_lock);

	pr_info("MVGAL: Removed GPU '%s'\n", gpu->name);

	mvgal_gpu_free(gpu);
}

/**
 * mvgal_gpu_cleanup_all - Cleanup all GPUs in the device
 */
void mvgal_gpu_cleanup_all(struct mvgal_device *dev)
{
	struct mvgal_gpu_device *gpu, *tmp;

	mutex_lock(&dev->gpu_lock);
	
	list_for_each_entry_safe(gpu, tmp, &dev->gpu_list, node) {
		list_del(&gpu->node);
		dev->gpu_count--;
		mutex_unlock(&dev->gpu_lock);
		
		mvgal_gpu_free(gpu);
		
		mutex_lock(&dev->gpu_lock);
	}
	
	mutex_unlock(&dev->gpu_lock);
}

/**
 * mvgal_gpu_find_by_vendor - Find a GPU by vendor ID
 */
struct mvgal_gpu_device *mvgal_gpu_find_by_vendor(struct mvgal_device *dev, enum mvgal_vendor_id vendor)
{
	struct mvgal_gpu_device *gpu;

	mutex_lock(&dev->gpu_lock);
	
	list_for_each_entry(gpu, &dev->gpu_list, node) {
		if (gpu->vendor == vendor) {
			mutex_unlock(&dev->gpu_lock);
			return gpu;
		}
	}
	
	mutex_unlock(&dev->gpu_lock);
	return NULL;
}

/**
 * mvgal_enumerate_gpus - Enumerate all GPUs and populate the device
 * Called during module initialization to discover all physical GPUs
 */
int mvgal_enumerate_gpus(struct mvgal_device *dev)
{
	struct pci_dev *pdev = NULL;
	int ret = 0;

	pr_info("MVGAL: Enumerating GPUs via PCI bus\n");

	/* Iterate through all PCI devices */
	while ((pdev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID, pdev)) != NULL) {
		uint16_t vendor_id = pdev->vendor;
		uint16_t device_id = pdev->device;
		uint16_t pci_class = pdev->class >> 8;
		enum mvgal_vendor_id mvgal_vendor = MVGAL_VENDOR_UNKNOWN;

		/*
		 * Only VGA (0x0300) and 3D controllers (0x0302).
		 * GPU vendor IDs also appear on HD-audio / USB / bridge
		 * functions which must not enter the aggregation pool.
		 */
		if (pci_class != PCI_CLASS_DISPLAY_VGA &&
		    pci_class != PCI_CLASS_DISPLAY_3D) {
			pci_dev_put(pdev);
			continue;
		}

		/* Determine vendor */
		if (vendor_id == PCI_VENDOR_ID_ATI) {
			mvgal_vendor = MVGAL_VENDOR_AMD;
		} else if (vendor_id == PCI_VENDOR_ID_NVIDIA) {
			mvgal_vendor = MVGAL_VENDOR_NVIDIA;
		} else if (vendor_id == PCI_VENDOR_ID_INTEL) {
			mvgal_vendor = MVGAL_VENDOR_INTEL;
		} else if (vendor_id == 0x1ED5) {
			mvgal_vendor = MVGAL_VENDOR_MTT;
		} else if (vendor_id == 0x17CB) {
			/* Qualcomm Adreno (if vendor module present) */
			mvgal_vendor = MVGAL_VENDOR_UNKNOWN;
		}

		if (mvgal_vendor != MVGAL_VENDOR_UNKNOWN) {
			struct mvgal_gpu_device *gpu;

			gpu = mvgal_gpu_alloc(mvgal_vendor);
			if (!gpu) {
				ret = -ENOMEM;
				goto out;
			}

			/* Set basic info */
			gpu->pdev = pdev;
			gpu->pci_vendor_id = vendor_id;
			gpu->pci_device_id = device_id;
			snprintf(gpu->name, sizeof(gpu->name), "%04x:%04x",
				 vendor_id, device_id);

			/* Defaults; vendor ops->init refine VRAM/API flags */
			gpu->vram_size = 0;
			gpu->vram_bandwidth = 500 * 1024;
			gpu->compute_units = 64;
			gpu->api_flags = MVGAL_API_VULKAN | MVGAL_API_OPENCL;
			gpu->pcie_gen = pcie_get_speed_cap(pdev) >= 0 ?
					pcie_get_speed_cap(pdev) : 4;
			gpu->pcie_lanes = pcie_get_width_cap(pdev) >= 0 ?
					 pcie_get_width_cap(pdev) : 16;
			gpu->numa_node = dev_to_node(&pdev->dev);

			/* Add to device */
			ret = mvgal_gpu_add(dev, gpu);
			if (ret < 0) {
				mvgal_gpu_free(gpu);
				goto out;
			}

			/* Keep pdev reference for lifetime of GPU entry */
			continue;
		}

		pci_dev_put(pdev);
	}

out:
	/*
	 * Single put for the pdev that terminated the loop.  On the success
	 * path pdev is NULL (pci_get_device returned NULL) and pci_dev_put
	 * ignores it; on the error path it is the device we failed on.
	 * Each retained GPU owns its own reference, released by
	 * mvgal_gpu_cleanup_all() -> mvgal_gpu_free().
	 */
	pci_dev_put(pdev);
	return ret;
}

/**
 * mvgal_compute_capability_profile - Compute unified capability profile
 */
void mvgal_compute_capability_profile(struct mvgal_device *dev)
{
	struct mvgal_gpu_device *gpu;
	uint64_t total_vram = 0;
	uint32_t total_cus = 0;
	uint32_t total_bandwidth = 0;
	uint32_t common_api_flags = ~0U;
	uint32_t union_api_flags = 0;
	bool has_graphics = false;
	bool different_nodes = false;
	int first_node = -1;
	bool has_p2p = false;

	mutex_lock(&dev->gpu_lock);

	list_for_each_entry(gpu, &dev->gpu_list, node) {
		total_vram += gpu->vram_size;
		total_cus += gpu->compute_units;
		total_bandwidth += gpu->vram_bandwidth;
		common_api_flags &= gpu->api_flags;
		union_api_flags |= gpu->api_flags;

		if (gpu->api_flags & MVGAL_API_VULKAN) {
			has_graphics = true;
		}

		if (first_node == -1) {
			first_node = gpu->numa_node;
		} else if (gpu->numa_node != first_node) {
			different_nodes = true;
		}
	}

	mutex_unlock(&dev->gpu_lock);

	/* Detect P2P matrix (handles its own locking) */
	mvgal_detect_all_p2p(dev);

	/* Determine tier */
	dev->caps.tier = TIER_FULL;
	if (common_api_flags != union_api_flags) {
		if (!has_graphics) {
			dev->caps.tier = TIER_COMPUTE_ONLY;
		} else {
			dev->caps.tier = TIER_MIXED;
		}
	}

	dev->caps.total_vram = total_vram;
	dev->caps.max_compute_units = total_cus;
	dev->caps.max_memory_bandwidth = total_bandwidth;
	dev->caps.supported_api_flags = union_api_flags;
	dev->caps.min_vulkan_version = 0x10300; /* Vulkan 1.3 default */
	dev->caps.gpu_count = dev->gpu_count;
	dev->caps.p2p_supported = has_p2p;
	dev->caps.numa_aware = different_nodes;

	pr_info("MVGAL: Capability profile: tier=%d, vram=%llu GB, cus=%d, bandwidth=%d GB/s\n",
		dev->caps.tier,
		(unsigned long long)(dev->caps.total_vram / (1024ULL * 1024ULL * 1024ULL)),
		dev->caps.max_compute_units,
		(int)(dev->caps.max_memory_bandwidth / 1024U));
}

/*
 * P2P Detection and Enablement (Section 4.2.2)
 */

static bool mvgal_amd_has_xgmi(struct pci_dev *pdev)
{
	/* High-end Instinct server GPUs support xGMI */
	u16 device_id = pdev->device;
	return (device_id == 0x738C || device_id == 0x7408 || device_id == 0x740F);
}

/**
 * mvgal_detect_p2p_support - Detect P2P capability between two GPUs
 * 
 * Checks if two GPUs can perform peer-to-peer DMA transfers.
 * Returns one of:
 *   MVGAL_P2P_SUPPORTED - Same PCI root complex, P2P possible
 *   MVGAL_P2P_NVLINK - NVIDIA GPUs with NVLink connection
 *   MVGAL_P2P_XGMI - AMD GPUs with xGMI/Infinity Fabric
 *   MVGAL_P2P_UNSUPPORTED - P2P not possible
 */
int mvgal_detect_p2p_support(struct mvgal_gpu_device *gpu1,
			    struct mvgal_gpu_device *gpu2)
{
	if (!gpu1 || !gpu2) {
		return MVGAL_P2P_UNSUPPORTED;
	}

	/* Same GPU - not P2P */
	if (gpu1 == gpu2) {
		return MVGAL_P2P_UNSUPPORTED;
	}

	/* Check for vendor-specific high-speed interconnects first */
	if (gpu1->vendor == MVGAL_VENDOR_NVIDIA && gpu2->vendor == MVGAL_VENDOR_NVIDIA) {
		if (gpu1->nvlink_capable && gpu2->nvlink_capable) {
			/* In a real driver, we'd check if they are actually connected */
			return MVGAL_P2P_NVLINK;
		}
	}

	if (gpu1->vendor == MVGAL_VENDOR_AMD && gpu2->vendor == MVGAL_VENDOR_AMD) {
		if (mvgal_amd_has_xgmi(gpu1->pdev) && mvgal_amd_has_xgmi(gpu2->pdev)) {
			return MVGAL_P2P_XGMI;
		}
	}

	/* Check if both GPUs are on the same PCI root complex */
	/* This uses the kernel's pci_p2pdma_distance() when available */
	if (gpu1->numa_node == gpu2->numa_node && gpu1->numa_node >= 0) {
		/* Same NUMA node - likely same root complex */
		pr_debug("MVGAL: GPUs %s and %s on same NUMA node (%d) - P2P supported\n",
			gpu1->name, gpu2->name, gpu1->numa_node);
		return MVGAL_P2P_SUPPORTED;
	}

	/* Fallback: use pci_p2pdma_distance if kernel supports it */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 20, 0)
	if (pci_p2pdma_distance(gpu1->pdev, &gpu2->pdev->dev, true) >= 0) {
		return MVGAL_P2P_SUPPORTED;
	}
#endif

	return MVGAL_P2P_UNSUPPORTED;
}

/**
 * mvgal_detect_all_p2p - Detect P2P support between all pairs of GPUs
 */
void mvgal_detect_all_p2p(struct mvgal_device *dev)
{
	struct mvgal_gpu_device *gpu1, *gpu2;
	u64 matrix = 0;

	if (!dev)
		return;

	mutex_lock(&dev->gpu_lock);

	list_for_each_entry(gpu1, &dev->gpu_list, node) {
		list_for_each_entry(gpu2, &dev->gpu_list, node) {
			int p2p_type = mvgal_detect_p2p_support(gpu1, gpu2);
			if (p2p_type != MVGAL_P2P_UNSUPPORTED) {
				/* Set bit (i * MAX_GPUS + j) in the matrix */
				matrix |= (1ULL << (gpu1->gpu_index * MVGAL_MAX_GPUS + gpu2->gpu_index));
			}
		}
	}

	dev->p2p_matrix = matrix;
	dev->caps.p2p_supported = (matrix != 0);

	mutex_unlock(&dev->gpu_lock);

	pr_info("MVGAL: P2P detection complete (matrix: 0x%llx)\n", matrix);
}

/*
 * There is intentionally no mvgal_pci_probe()/mvgal_pci_remove() here.
 *
 * MVGAL is an above-driver coordinator.  Registering a struct pci_driver
 * whose probe called pci_enable_device() and pci_set_master() would take
 * the physical GPU away from the native driver that already owns it
 * (amdgpu, nvidia, i915/xe, mtgpu-drv), and would additionally register a
 * second copy of every GPU because mvgal_enumerate_gpus() has already
 * discovered it read-only.
 *
 * GPUs reach mvgal_gpu_add() only through mvgal_enumerate_gpus(), which
 * uses pci_get_device() for read-only inspection and never enables the
 * function or takes bus-master ownership.
 */
