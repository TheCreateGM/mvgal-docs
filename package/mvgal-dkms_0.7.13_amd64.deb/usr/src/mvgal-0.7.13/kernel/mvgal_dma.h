/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 *
 * Low-level DMA helpers (sg_table iteration, cache sync, page count)
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */
#ifndef MVGAL_DMA_H
#define MVGAL_DMA_H

#include <linux/types.h>
#include <linux/scatterlist.h>
#include <linux/dma-direction.h>
#include <linux/dma-mapping.h>

/**
 * mvgal_sgt_total_size - total buffer size from sg_table
 * @sgt: scatter-gather table
 *
 * Sums sg->length across all original entries (DMA-mappable size).
 */
static inline size_t mvgal_sgt_total_size(struct sg_table *sgt)
{
    struct scatterlist *sg;
    size_t total = 0;
    int i;

    for_each_sg(sgt->sgl, sg, sgt->orig_nents, i)
        total += sg->length;
    return total;
}

/**
 * mvgal_sgt_nents - number of DMA-mapped entries
 * @sgt: scatter-gather table
 */
static inline unsigned int mvgal_sgt_nents(struct sg_table *sgt)
{
    return sgt->nents;
}

/**
 * mvgal_sgt_first_dma - first DMA address from sg_table
 * @sgt: scatter-gather table
 *
 * Returns the DMA address of the first entry, or 0 if empty.
 */
static inline dma_addr_t mvgal_sgt_first_dma(struct sg_table *sgt)
{
    if (!sgt || sgt->nents == 0)
        return 0;
    return sg_dma_address(sgt->sgl);
}

/**
 * mvgal_sgt_first_len - DMA-mapped length of first entry
 * @sgt: scatter-gather table
 */
static inline size_t mvgal_sgt_first_len(struct sg_table *sgt)
{
    if (!sgt || sgt->nents == 0)
        return 0;
    return sg_dma_len(sgt->sgl);
}

/**
 * mvgal_sgt_for_each - iterate DMA-mapped entries
 * @sgt: scatter-gather table
 * @sg: scatterlist cursor (struct scatterlist *)
 * @i: int loop index
 */
#define mvgal_sgt_for_each(sgt, sg, i)                                    \
    for_each_sg((sgt)->sgl, sg, (sgt)->nents, i)

/**
 * mvgal_dma_sync_for_device - sync buffer to device (writeback + invalidate)
 * @dev: DMA device
 * @addr: DMA address
 * @size: size in bytes
 * @dir: DMA direction
 */
static inline void
mvgal_dma_sync_for_device(struct device *dev, dma_addr_t addr,
                           size_t size, enum dma_data_direction dir)
{
    dma_sync_single_for_device(dev, addr, size, dir);
}

/**
 * mvgal_dma_sync_for_cpu - sync buffer to CPU (invalidate)
 * @dev: DMA device
 * @addr: DMA address
 * @size: size in bytes
 * @dir: DMA direction
 */
static inline void
mvgal_dma_sync_for_cpu(struct device *dev, dma_addr_t addr,
                        size_t size, enum dma_data_direction dir)
{
    dma_sync_single_for_cpu(dev, addr, size, dir);
}

/**
 * mvgal_dma_page_count - number of pages needed for a given size
 * @size: size in bytes
 *
 * Rounds up to PAGE_SIZE granularity and returns page count.
 */
static inline unsigned long mvgal_dma_page_count(size_t size)
{
    return PAGE_ALIGN(size) / PAGE_SIZE;
}

#endif /* MVGAL_DMA_H */
