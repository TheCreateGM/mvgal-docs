// SPDX-License-Identifier: GPL-2.0-only
/*
 * MVGAL trace provider — tracefs-based scheduling and event logging
 *
 * Exposes /sys/kernel/debug/mvgal/trace for reading the ring buffer
 * and /sys/kernel/debug/mvgal/trace_clear for clearing it.
 */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/debugfs.h>
#include <linux/seq_file.h>
#include <linux/slab.h>
#include <linux/time.h>
#include <linux/vmalloc.h>

#include "mvgal_trace.h"

static struct dentry *mvgal_debugfs_root;
static struct mvgal_trace_buffer trace_buf;

static const char * const trace_type_names[MVGAL_TRACE_TYPE_COUNT] = {
	[MVGAL_TRACE_SCHEDULE] = "SCHED",
	[MVGAL_TRACE_MEMORY]   = "MEM",
	[MVGAL_TRACE_P2P]      = "P2P",
	[MVGAL_TRACE_POWER]    = "PWR",
	[MVGAL_TRACE_DEVICE]   = "DEV",
	[MVGAL_TRACE_ERROR]    = "ERR",
};

/*
 * mvgal_trace_event — log a trace event into the ring buffer.
 *
 * Safe to call from any context including interrupt context.
 * Uses spin_lock_irqsave to protect the ring buffer.
 */
void mvgal_trace_event(enum mvgal_trace_type type, const char *fmt, ...)
{
	struct mvgal_trace_entry *entry;
	unsigned long flags;
	va_list args;
	unsigned int idx;

	if (!trace_buf.initialized)
		return;

	if (type >= MVGAL_TRACE_TYPE_COUNT)
		return;

	spin_lock_irqsave(&trace_buf.lock, flags);

	idx = trace_buf.head % MVGAL_TRACE_MAX_ENTRIES;
	entry = &trace_buf.entries[idx];

	entry->timestamp = ktime_get_ns();
	entry->type = type;

	va_start(args, fmt);
	vsnprintf(entry->msg, MVGAL_TRACE_MSG_LEN, fmt, args);
	va_end(args);

	trace_buf.head = (trace_buf.head + 1) % MVGAL_TRACE_MAX_ENTRIES;
	trace_buf.count++;

	spin_unlock_irqrestore(&trace_buf.lock, flags);
}
EXPORT_SYMBOL_GPL(mvgal_trace_event);

/*
 * trace_seq_show — seq_file show callback for /sys/kernel/debug/mvgal/trace
 *
 * Displays the ring buffer contents from oldest to newest with timestamps.
 */
static int trace_seq_show(struct seq_file *s, void *v)
{
	unsigned int start, end, i;
	unsigned long flags;

	spin_lock_irqsave(&trace_buf.lock, flags);

	if (trace_buf.count == 0) {
		spin_unlock_irqrestore(&trace_buf.lock, flags);
		seq_puts(s, "No trace events recorded.\n");
		return 0;
	}

	/* Calculate display range: oldest to newest */
	if (trace_buf.count >= MVGAL_TRACE_MAX_ENTRIES) {
		start = trace_buf.head; /* oldest is at current head (wraps) */
		end = trace_buf.head;
	} else {
		start = 0;
		end = trace_buf.head;
	}

	seq_printf(s, "MVGAL Trace Buffer (%u entries, max %u):\n",
		   min(trace_buf.count, (unsigned int)MVGAL_TRACE_MAX_ENTRIES),
		   MVGAL_TRACE_MAX_ENTRIES);
	seq_puts(s, "-----------------------------"
		 "------------------------------------------\n");

	for (i = start; i != end; i = (i + 1) % MVGAL_TRACE_MAX_ENTRIES) {
		struct mvgal_trace_entry *e = &trace_buf.entries[i];
		struct timespec64 ts;
		u64 ns;

		if (e->timestamp == 0)
			continue;

		ns = e->timestamp;
		ts = ns_to_timespec64(ns);

		seq_printf(s, "[%8lld.%06ld] %-5s %s\n",
			   ts.tv_sec, ts.tv_nsec / 1000,
			   trace_type_names[e->type] ? trace_type_names[e->type] : "???",
			   e->msg);
	}

	spin_unlock_irqrestore(&trace_buf.lock, flags);
	return 0;
}

static int trace_open(struct inode *inode, struct file *file)
{
	return single_open(file, trace_seq_show, NULL);
}

static const struct file_operations trace_fops = {
	.open    = trace_open,
	.read    = seq_read,
	.llseek  = seq_lseek,
	.release = single_release,
};

/*
 * trace_clear_write — write callback for /sys/kernel/debug/mvgal/trace_clear
 *
 * Any write clears the trace buffer.
 */
static ssize_t trace_clear_write(struct file *file, const char __user *buf,
				 size_t count, loff_t *ppos)
{
	unsigned long flags;

	spin_lock_irqsave(&trace_buf.lock, flags);
	trace_buf.head = 0;
	trace_buf.count = 0;
	memset(trace_buf.entries, 0, sizeof(trace_buf.entries));
	spin_unlock_irqrestore(&trace_buf.lock, flags);

	mvgal_trace_device("Trace buffer cleared");

	return count;
}

static const struct file_operations trace_clear_fops = {
	.write = trace_clear_write,
	.open  = simple_open,
};

/*
 * mvgal_trace_init — create debugfs entries and initialize ring buffer
 */
int mvgal_trace_init(void)
{
	memset(&trace_buf, 0, sizeof(trace_buf));
	spin_lock_init(&trace_buf.lock);
	trace_buf.initialized = true;

	mvgal_debugfs_root = debugfs_create_dir("mvgal", NULL);
	if (IS_ERR(mvgal_debugfs_root)) {
		pr_err("mvgal: failed to create debugfs directory\n");
		trace_buf.initialized = false;
		return PTR_ERR(mvgal_debugfs_root);
	}

	debugfs_create_file("trace", 0444, mvgal_debugfs_root,
			    NULL, &trace_fops);
	debugfs_create_file("trace_clear", 0200, mvgal_debugfs_root,
			    NULL, &trace_clear_fops);

	mvgal_trace_device("Trace subsystem initialized (max %d entries)",
			   MVGAL_TRACE_MAX_ENTRIES);

	return 0;
}

/*
 * mvgal_trace_fini — remove debugfs entries and mark uninitialized
 */
void mvgal_trace_fini(void)
{
	trace_buf.initialized = false;

	if (!IS_ERR_OR_NULL(mvgal_debugfs_root)) {
		debugfs_remove_recursive(mvgal_debugfs_root);
		mvgal_debugfs_root = NULL;
	}
}

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("MVGAL trace provider — tracefs scheduling and event log");
