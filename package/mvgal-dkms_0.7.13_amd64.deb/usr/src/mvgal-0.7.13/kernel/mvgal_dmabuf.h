/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 *
 * Shared DMA-BUF import / export interface
 *
 * Eliminates identical dma_buf_attach → map → sg_dma_address patterns
 * across AMD, NVIDIA, Intel, and MTT vendor modules.
 *
 * All functions are exported via EXPORT_SYMBOL_GPL from mvgal_core.ko
 * and callable from the vendor modules (separate .ko files).
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */
#ifndef MVGAL_DMABUF_H
#define MVGAL_DMABUF_H

#include <linux/types.h>
#include <linux/dma-buf.h>
#include <linux/dma-direction.h>

struct device;

/**
 * struct mvgal_dmabuf_state - holds all state from a DMA-BUF import
 *
 * Each vendor driver stores one of these in its per-allocation tracking
 * struct so it can properly free the import later.
 */
struct mvgal_dmabuf_state {
    struct dma_buf              *dmabuf;
    struct dma_buf_attachment   *attach;
    struct sg_table             *sgt;
    enum dma_data_direction      dir;
};

/**
 * mvgal_dmabuf_attach_and_map - attach + map a DMA-BUF to a device
 * @buf: the dma_buf to import (already obtained, e.g. from dma_buf_get)
 * @dev: device to attach to
 * @dir: DMA data direction
 * @state: output — populated with attach, sgt, dmabuf (caller must kfree if
 *         embedding this in a larger allocation)
 *
 * Performs dma_buf_attach + dma_buf_map_attachment in one call.
 * On success @state is fully populated.
 *
 * Caller must call mvgal_dmabuf_unmap_and_detach() when done with the
 * mapping, BEFORE dma_buf_put().
 *
 * Returns 0 on success, negative errno on failure.
 */
int mvgal_dmabuf_attach_and_map(struct dma_buf *buf, struct device *dev,
                                 enum dma_data_direction dir,
                                 struct mvgal_dmabuf_state *state);

/**
 * mvgal_dmabuf_unmap_and_detach - unmap + detach (reverse of attach_and_map)
 * @state: state from a previous successful attach_and_map call
 *
 * NULL-safe on all fields inside @state.  After this call @state is
 * zeroed (ready for re-use or stack discard).
 */
void mvgal_dmabuf_unmap_and_detach(struct mvgal_dmabuf_state *state);

/**
 * mvgal_dmabuf_reexport - create a new fd for an already-imported DMA-BUF
 * @state: the import state (must have a valid dmabuf)
 * @out_fd: output file descriptor
 *
 * Calls dma_buf_fd() + get_dma_buf() to produce a new fd that refers to
 * the same underlying buffer.  The caller must close the fd when done.
 *
 * Returns 0 on success, negative errno on failure.
 */
int mvgal_dmabuf_reexport(struct mvgal_dmabuf_state *state, int *out_fd);

/**
 * mvgal_dmabuf_size - convenience helper for buffer size
 */
static inline size_t mvgal_dmabuf_size(struct dma_buf *buf)
{
    return buf ? buf->size : 0;
}

/**
 * struct mvgal_dmabuf_export_priv - private data for exported DMA-BUF ops
 *
 * Holds the sg_table that backs the exported buffer.  The sg_table is
 * owned by the dma_buf object and freed in the .release callback.
 */
struct mvgal_dmabuf_export_priv {
    struct sg_table    *sgt;
    size_t              size;
    struct page       **pages;   /* optional host pages (export_host) */
    int                 npages;
};

/**
 * mvgal_dmabuf_export - create a DMA-BUF from an sg_table (export wrapper)
 * @sgt:   scatter-gather table backing the buffer (ownership transferred)
 * @size:  buffer size in bytes
 * @flags: dma_buf flags (O_RDWR, O_CLOEXEC, etc.)
 *
 * Wraps dma_buf_export() with a standard set of dma_buf_ops that:
 *   - .map_dma_buf returns the owned sg_table directly
 *   - .unmap_dma_buf is a no-op (the sgt is persistent)
 *   - .release frees the sg_table
 *   - .mmap returns -ENODEV (not backed by a single contiguous allocation)
 *
 * The caller transfers ownership of @sgt to the returned dma_buf.
 * On error @sgt is NOT freed (caller must clean up).
 *
 * Returns pointer to dma_buf, or ERR_PTR on failure.
 */
struct dma_buf *mvgal_dmabuf_export(struct sg_table *sgt, size_t size,
                                     unsigned int flags);

/**
 * mvgal_dmabuf_export_fd - create a DMA-BUF fd from an sg_table
 * @sgt:   scatter-gather table (ownership transferred on success)
 * @size:  buffer size in bytes
 * @flags: dma_buf flags
 * @out_fd: output file descriptor
 *
 * Convenience: mvgal_dmabuf_export() + dma_buf_fd() in one call.
 * The returned fd is O_CLOEXEC.
 *
 * Returns 0 on success, negative errno on failure.
 */
int mvgal_dmabuf_export_fd(struct sg_table *sgt, size_t size,
                            unsigned int flags, int *out_fd);

/**
 * mvgal_dmabuf_export_host - allocate host pages and export as DMA-BUF
 * @size:  buffer size in bytes
 * @flags: dma_buf flags (O_RDWR, etc.)
 *
 * Portable cross-vendor fallback when a vendor GEM object is unavailable.
 * Allocates GFP_KERNEL pages, builds an sg_table, and exports via
 * mvgal_dmabuf_export().  Pages are freed in the dma_buf .release path.
 *
 * Returns pointer to dma_buf, or ERR_PTR on failure.
 */
struct dma_buf *mvgal_dmabuf_export_host(size_t size, unsigned int flags);

#endif /* MVGAL_DMABUF_H */
