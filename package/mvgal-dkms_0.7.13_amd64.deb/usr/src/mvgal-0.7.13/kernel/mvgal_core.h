/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 * 
 * Kernel Core Module Header - Main data structures and definitions
 * 
 * SPDX-License-Identifier: GPL-2.0-only
 */
 
#ifndef _MVGAL_CORE_H_
#define _MVGAL_CORE_H_
 
#include <linux/types.h>
#include <linux/pci.h>
#include <linux/mutex.h>
#include <linux/list.h>
#include <linux/dma-buf.h>
#include <linux/cdev.h>
#include <drm/drm_device.h>
#include <drm/drm_drv.h>
#include <drm/drm_file.h>
#include <drm/drm_ioctl.h>
#include <drm/drm.h>
 
/* Maximum number of MVGAL devices */
#define MVGAL_MAX_DEVICES 16
 
/* Maximum number of physical GPUs per logical device */
#define MVGAL_MAX_GPUS 8
 
/* Maximum IOCTL argument size */
#define MVGAL_MAX_IOCTL_ARGS 4096
 
/*
 * DRM-private ioctl offsets (relative to DRM_COMMAND_BASE + 0x80).
 * DRM_IOCTL_DEF_DRV(MVGAL_*, ...) expects DRM_IOCTL_MVGAL_* names.
 */
/* Private DRM ioctl indices (must stay within the driver ioctl table size) */
#define MVGAL_QUERY_DEVICES		0x00
#define MVGAL_QUERY_CAPABILITIES	0x01
#define MVGAL_SUBMIT_WORKLOAD		0x02
#define MVGAL_ALLOC_MEMORY		0x03
#define MVGAL_FREE_MEMORY		0x04
#define MVGAL_IMPORT_DMABUF		0x05
#define MVGAL_EXPORT_DMABUF		0x06
#define MVGAL_WAIT_FENCE		0x07
#define MVGAL_SIGNAL_FENCE		0x08
#define MVGAL_SET_GPU_AFFINITY		0x09

/* Windows Compatibility (NTSYNC style) */
#define MVGAL_NTSYNC_CREATE_SEM		0x0A
#define MVGAL_NTSYNC_WAIT_ANY		0x0B
#define MVGAL_NTSYNC_WAIT_ALL		0x0C
#define MVGAL_NTSYNC_SIGNAL		0x0D

/* Placeholder UAPI types for DRM ioctl sizing (handlers validate real structs) */
struct drm_mvgal_generic {
	__u64 data;
};

/* Internal struct for MVGAL_SET_GPU_AFFINITY ioctl */
struct mvgal_uapi_set_affinity {
	__u32 gpu_index;
	__u32 flags;
	__u64 affinity_mask;
};

#define DRM_IOCTL_MVGAL_QUERY_DEVICES \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_QUERY_DEVICES, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_QUERY_CAPABILITIES \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_QUERY_CAPABILITIES, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_SUBMIT_WORKLOAD \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_SUBMIT_WORKLOAD, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_ALLOC_MEMORY \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_ALLOC_MEMORY, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_FREE_MEMORY \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_FREE_MEMORY, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_IMPORT_DMABUF \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_IMPORT_DMABUF, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_EXPORT_DMABUF \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_EXPORT_DMABUF, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_WAIT_FENCE \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_WAIT_FENCE, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_SIGNAL_FENCE \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_SIGNAL_FENCE, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_SET_GPU_AFFINITY \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_SET_GPU_AFFINITY, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_NTSYNC_CREATE_SEM \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_NTSYNC_CREATE_SEM, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_NTSYNC_WAIT_ANY \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_NTSYNC_WAIT_ANY, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_NTSYNC_WAIT_ALL \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_NTSYNC_WAIT_ALL, struct drm_mvgal_generic)
#define DRM_IOCTL_MVGAL_NTSYNC_SIGNAL \
	DRM_IOWR(DRM_COMMAND_BASE + MVGAL_NTSYNC_SIGNAL, struct drm_mvgal_generic)

/* Legacy aliases for in-tree ioctl handlers */
#define MVGAL_IOCTL_QUERY_DEVICES	DRM_IOCTL_MVGAL_QUERY_DEVICES
#define MVGAL_IOCTL_QUERY_CAPABILITIES	DRM_IOCTL_MVGAL_QUERY_CAPABILITIES
#define MVGAL_IOCTL_SUBMIT_WORKLOAD	DRM_IOCTL_MVGAL_SUBMIT_WORKLOAD
#define MVGAL_IOCTL_ALLOC_MEMORY	DRM_IOCTL_MVGAL_ALLOC_MEMORY
#define MVGAL_IOCTL_FREE_MEMORY		DRM_IOCTL_MVGAL_FREE_MEMORY
#define MVGAL_IOCTL_IMPORT_DMABUF	DRM_IOCTL_MVGAL_IMPORT_DMABUF
#define MVGAL_IOCTL_EXPORT_DMABUF	DRM_IOCTL_MVGAL_EXPORT_DMABUF
#define MVGAL_IOCTL_WAIT_FENCE		DRM_IOCTL_MVGAL_WAIT_FENCE
#define MVGAL_IOCTL_SIGNAL_FENCE	DRM_IOCTL_MVGAL_SIGNAL_FENCE
#define MVGAL_IOCTL_SET_GPU_AFFINITY	DRM_IOCTL_MVGAL_SET_GPU_AFFINITY
#define MVGAL_IOCTL_NTSYNC_CREATE_SEM	DRM_IOCTL_MVGAL_NTSYNC_CREATE_SEM
#define MVGAL_IOCTL_NTSYNC_WAIT_ANY	DRM_IOCTL_MVGAL_NTSYNC_WAIT_ANY
#define MVGAL_IOCTL_NTSYNC_WAIT_ALL	DRM_IOCTL_MVGAL_NTSYNC_WAIT_ALL
#define MVGAL_IOCTL_NTSYNC_SIGNAL	DRM_IOCTL_MVGAL_NTSYNC_SIGNAL
 
/*
 * Capability tiers
 */
enum mvgal_capability_tier {
	TIER_FULL = 0,        /* All GPUs support same API set */
	TIER_COMPUTE_ONLY = 1, /* Heterogeneous compute but not all support graphics */
	TIER_MIXED = 2,       /* Some GPUs graphics-only, some compute-only */
};
 
/*
 * Device power state (core lifecycle — distinct from mvgal_power.h states)
 */
enum mvgal_device_power_state {
	MVGAL_DEVICE_POWER_STATE_ACTIVE = 0,
	MVGAL_DEVICE_POWER_STATE_SUSTAINED = 1,
	MVGAL_DEVICE_POWER_STATE_IDLE = 2,
	MVGAL_DEVICE_POWER_STATE_PARK = 3,
	MVGAL_DEVICE_POWER_STATE_OFF = 4,
};
 
/*
 * Vendor IDs
 */
enum mvgal_vendor_id {
	MVGAL_VENDOR_UNKNOWN = 0,
	MVGAL_VENDOR_AMD = 1,
	MVGAL_VENDOR_NVIDIA = 2,
	MVGAL_VENDOR_INTEL = 3,
	MVGAL_VENDOR_MTT = 4,
	MVGAL_VENDOR_QUALCOMM = 5,
};
 
/*
 * API support flags
 */
#define MVGAL_API_VULKAN   (1 << 0)
#define MVGAL_API_OPENGL   (1 << 1)
#define MVGAL_API_OPENCL   (1 << 2)
#define MVGAL_API_CUDA     (1 << 3)
#define MVGAL_API_SYCL     (1 << 4)
 
/*
 * GPU feature flags
 */
#define MVGAL_FEATURE_TENSOR_CORES  (1 << 0)
#define MVGAL_FEATURE_RT_CORES      (1 << 1)
#define MVGAL_FEATURE_PEER_ACCESS   (1 << 2)

/*
 * Probed runtime capabilities (MVGAL_CAP_*)
 *
 * These are NOT static claims about a vendor.  Each bit is set only when
 * mvgal_vendor_ops::probe_capabilities() has confirmed the operation is
 * actually reachable on this machine with this driver loaded.  A clear bit
 * means "do not call this op, use the documented fallback instead" - it never
 * means "assume it works".
 *
 * MVGAL_CAP_KERNEL_SUBMIT is deliberately clear for every vendor in this
 * tree: amdgpu, nvidia, i915/xe and mtgpu-drv all own command submission
 * internally and export no submission entry point to an out-of-tree module.
 * Workloads are dispatched by mvgald through the vendor userspace driver.
 * MVGAL_CAP_KERNEL_VRAM is clear for the same reason: the vendor's own memory
 * manager (TTM, GEM, the MTT allocator) owns VRAM and there is no interface an
 * out-of-tree module may use to obtain a real GPU address.
 */
#define MVGAL_CAP_KERNEL_SUBMIT   (1 << 0) /* submit_cs() can dispatch        */
#define MVGAL_CAP_KERNEL_VRAM     (1 << 1) /* alloc_vram() returns real VRAM  */
#define MVGAL_CAP_BUSY_PERCENT    (1 << 2) /* gpu_busy_percent telemetry reads */
#define MVGAL_CAP_PPM             (1 << 3) /* power_dpm_force_perf_level r/w  */
#define MVGAL_CAP_DMABUF_EXPORT   (1 << 4) /* export_dmabuf() is implemented  */
#define MVGAL_CAP_DMABUF_IMPORT   (1 << 5) /* import_dmabuf() is implemented  */
#define MVGAL_CAP_WAIT_IDLE       (1 << 6) /* wait_idle() can really block    */
#define MVGAL_CAP_BO_QUERY        (1 << 7) /* query_bo() can describe a BO    */
 
/*
 * Forward declarations
 */
struct mvgal_gpu_device;
struct mvgal_vendor_ops;
struct mvgal_fence;
struct mvgal_workload;
 
/*
 * Buffer object info returned by query_bo
 */
struct mvgal_bo_info {
	uint64_t size;         /* Allocation size in bytes */
	bool is_imported;      /* true if created via import_dmabuf */
	uint32_t flags;        /* Reserved for future use */
};

/*
 * Vendor operations structure
 * Each GPU vendor implements these functions
 */
struct mvgal_vendor_ops {
	int (*init)(struct mvgal_gpu_device *dev);
	void (*fini)(struct mvgal_gpu_device *dev);
	int (*submit_cs)(struct mvgal_gpu_device *dev, struct mvgal_workload *workload);
	int (*alloc_vram)(struct mvgal_gpu_device *dev, size_t size, uint64_t *gpu_addr);
	void (*free_vram)(struct mvgal_gpu_device *dev, uint64_t gpu_addr);
	int (*wait_idle)(struct mvgal_gpu_device *dev, uint32_t timeout_ms);
	int (*set_power_state)(struct mvgal_gpu_device *dev, enum mvgal_device_power_state state);
	struct dma_buf *(*export_dmabuf)(struct mvgal_gpu_device *dev, uint64_t gpu_addr, size_t size);
	int (*import_dmabuf)(struct mvgal_gpu_device *dev, struct dma_buf *buf, uint64_t *gpu_addr);
	int (*query_utilization)(struct mvgal_gpu_device *dev, uint32_t *util_percent);
	int (*query_bo)(struct mvgal_gpu_device *dev, uint64_t gpu_addr, struct mvgal_bo_info *info);
	/*
	 * probe_capabilities - report what this vendor can really do on this
	 * machine right now, as a mask of MVGAL_CAP_* bits.
	 *
	 * Called once from mvgal_gpu_add() and again whenever the device is
	 * re-scanned.  It must actually test for the resource (open the sysfs
	 * node, check the driver's module list, inspect the PCI device) and must
	 * NOT set a bit for an op that is merely present in the ops table.  An op
	 * may exist in the table and still be unsupported on a given device.
	 *
	 * Returning 0 with *caps = 0 is valid and means "nothing is reachable".
	 */
	int (*probe_capabilities)(struct mvgal_gpu_device *dev, uint32_t *caps);
};
 
/*
 * Unified capability profile for the logical MVGAL device
 */
struct mvgal_capability_profile {
	uint64_t total_vram;           /* Sum of all GPU VRAM */
	uint32_t max_compute_units;   /* Aggregate compute unit count */
	uint32_t max_memory_bandwidth;/* Aggregate memory bandwidth in MB/s */
	uint32_t supported_api_flags;  /* Bitmask of MVGAL_API_* flags */
	uint32_t min_vulkan_version;   /* Minimum Vulkan version across all GPUs */
	enum mvgal_capability_tier tier;
	uint32_t gpu_count;            /* Number of physical GPUs */
	bool p2p_supported;            /* Peer-to-peer DMA supported */
	bool numa_aware;               /* NUMA-aware placement possible */
};
 
/*
 * Atomic statistics counters for the logical device.
 * Accessed via MVGAL_IOC_GET_STATS; incremented on each event.
 */
struct mvgal_stats {
	atomic64_t open_count;
	atomic64_t release_count;
	atomic64_t ioctl_count;
	atomic64_t rescans;
	atomic64_t hotplug_events;
	atomic64_t dma_buf_export_count;
	atomic64_t dma_buf_import_count;
	atomic64_t cross_vendor_alloc_count;
	atomic64_t unsupported_dmabuf_exports;
	atomic64_t unsupported_dmabuf_imports;
	atomic64_t unsupported_cross_vendor;
	atomic64_t p2p_transfer_count;
	atomic64_t host_staging_transfer_count;
};

/*
 * Per-file private data
 */
struct mvgal_file {
	struct list_head workloads;
	struct mutex lock;
	uint32_t next_workload_id;
};
 
/*
 * Main MVGAL logical device structure
 */
struct mvgal_device {
	struct drm_device *drm;
	struct device *dev;
	struct cdev cdev;
	dev_t devt;
 
	/* GPU list */
	struct list_head gpu_list;
	struct mutex gpu_lock;
	uint32_t gpu_count;
 
	/* Capability profile */
	struct mvgal_capability_profile caps;
 
	/* P2P Matrix (bits [i][j] indicate P2P support between GPU i and GPU j) */
	u64 p2p_matrix;
 
	/* Workload queue */
	struct list_head workload_queue;
	struct mutex workload_lock;
	wait_queue_head_t workload_waitq;
 
	/* Fence management */
	struct list_head fence_list;
	struct mutex fence_lock;
	atomic_t next_fence_seq;
 
	/* Statistics */
	struct mvgal_stats stats;

	/* Flags */
	bool initialized;
	bool daemon_connected;

	/* Sysfs */
	unsigned long topology_generation;
};
 
/*
 * Extern declarations
 */
extern struct mvgal_device *mvgal_logical_device;
 
/*
 * IOCTL handlers (implemented in various files)
 */
int mvgal_ioctl_query_devices(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_query_capabilities(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_submit_workload(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_alloc_memory(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_free_memory(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_import_dmabuf(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_export_dmabuf(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_wait_fence(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_signal_fence(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_set_gpu_affinity(struct drm_device *drm, void *data, struct drm_file *file);

/* Windows Compatibility (NTSYNC) ioctls */
int mvgal_ioctl_ntsync_create_sem(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_ntsync_wait_any(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_ntsync_wait_all(struct drm_device *drm, void *data, struct drm_file *file);
int mvgal_ioctl_ntsync_signal(struct drm_device *drm, void *data, struct drm_file *file);
 
/*
 * Character device operations
 */
int mvgal_char_open(struct inode *inode, struct file *filp);
int mvgal_char_release(struct inode *inode, struct file *filp);
long mvgal_char_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);
int mvgal_char_mmap(struct file *filp, struct vm_area_struct *vma);
 
/* GPU discovery
 *
 * There is no mvgal_pci_probe()/mvgal_pci_remove().  MVGAL is an
 * above-driver coordinator: physical GPUs are discovered read-only by
 * mvgal_enumerate_gpus() and observed via the PCI bus notifier
 * (mvgal_hotplug_init).  MVGAL never registers a struct pci_driver and
 * never binds a GPU that a native driver already owns.
 */
 
/* Device initialization */
int mvgal_device_init(struct mvgal_device **dev_out, struct device *parent);
void mvgal_device_fini(struct mvgal_device *dev);
 
/* GPU management */
struct mvgal_gpu_device *mvgal_gpu_alloc(enum mvgal_vendor_id vendor);
void mvgal_gpu_free(struct mvgal_gpu_device *gpu);
int mvgal_gpu_add(struct mvgal_device *dev, struct mvgal_gpu_device *gpu);
void mvgal_gpu_remove(struct mvgal_device *dev, struct mvgal_gpu_device *gpu);

/* Full aggregation stack (linked when MVGAL_BUILD_FULL_STACK=1) */
int mvgal_stack_init(struct device *parent);
void mvgal_stack_exit(void);

/*
 * Vendor registration API — used by vendor modules to register
 * their ops with mvgal_core.ko at module_init time.
 */
int mvgal_core_register_vendor(enum mvgal_vendor_id id, const struct mvgal_vendor_ops *ops);
void mvgal_core_unregister_vendor(enum mvgal_vendor_id id, const struct mvgal_vendor_ops *ops);
const struct mvgal_vendor_ops *mvgal_core_find_vendor_ops(enum mvgal_vendor_id id);

/*
 * Sysfs interface (kernel/mvgal_sysfs.c)
 */
int mvgal_sysfs_init(struct mvgal_device *dev);
void mvgal_sysfs_exit(struct mvgal_device *dev);

/*
 * PCI hotplug notifier (kernel/mvgal_core.c)
 */
int mvgal_hotplug_init(void);
void mvgal_hotplug_exit(void);

#endif /* _MVGAL_CORE_H_ */
