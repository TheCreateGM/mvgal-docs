/**
 * @file mvgal_power.h
 * @brief MVGAL Power Management Kernel Header
 *
 * Runtime PM, S0ix idle states, thermal management, and PSU-aware power control
 * for multi-GPU systems.
 *
 * SPDX-License-Identifier: GPL-2.0-only
 */

#ifndef _MVGAL_POWER_H_
#define _MVGAL_POWER_H_

#include <linux/types.h>
#include <linux/workqueue.h>
#include <linux/thermal.h>

/* Forward declarations */
struct mvgal_gpu_device;

/*
 * There is deliberately only one power-state vocabulary in MVGAL:
 * enum mvgal_device_power_state in mvgal_core.h.  A second, differently
 * ordered enum used to live here (OFF, SUSPEND, IDLE, ON, PERFORMANCE) and
 * mvgal_set_power_state() took that one while every vendor op took the
 * device one.  The values then crossed silently: asking for ON (3) reached
 * the driver as PARK, and PERFORMANCE (4) reached it as OFF.  Only IDLE (2)
 * happened to coincide.  Anything that needs a power state now names the
 * device enum.
 */

/**
 * DVFS modes
 */
enum mvgal_dvfs_mode {
	MVGAL_DVFS_PERFORMANCE = 0,
	MVGAL_DVFS_BALANCED,
	MVGAL_DVFS_POWERSAVE,
	MVGAL_DVFS_CUSTOM
};

/**
 * DVFS policy structure
 */
struct mvgal_dvfs_policy {
	enum mvgal_dvfs_mode mode;
	uint32_t min_freq_mhz;
	uint32_t max_freq_mhz;
	uint32_t up_threshold;
	uint32_t down_threshold;
	uint32_t step_delay_ms;
};

/**
 * Per-GPU DVFS state
 */
struct mvgal_gpu_dvfs {
	struct mvgal_dvfs_policy policy;
	uint32_t current_freq_mhz;
	uint32_t target_freq_mhz;
	struct delayed_work dvfs_work;
	struct mvgal_gpu_device *gpu;
 spinlock_t lock;
	bool enabled;
};

/**
 * Thermal throttling state
 */
struct mvgal_thermal {
	int32_t current_temp_c;
	int32_t throttle_temp_c;
	int32_t critical_temp_c;
	uint32_t throttle_level;
	struct thermal_zone_device *tz;
	struct mvgal_gpu_device *gpu;
	struct delayed_work thermal_work;
	bool enabled;
};

/**
 * Per-GPU power info
 */
struct mvgal_gpu_power {
	uint32_t min_watts;
	uint32_t max_watts;
	uint32_t current_watts;
	uint32_t limit_watts;
};

/**
 * Power budget management
 */
struct mvgal_power_budget {
	uint32_t total_watts;
	uint32_t headroom_watts;
	uint32_t allocated_watts;
	struct mvgal_gpu_power gpu_power[8];
	uint32_t gpu_count;
 spinlock_t lock;
};

/* DVFS and thermal are used via pointers in struct mvgal_gpu_device (defined in mvgal_device.h) */

/* DVFS functions */
int mvgal_dvfs_init(struct mvgal_gpu_device *gpu);
void mvgal_dvfs_fini(struct mvgal_gpu_device *gpu);
int mvgal_dvfs_start(struct mvgal_gpu_device *gpu);
int mvgal_dvfs_stop(struct mvgal_gpu_device *gpu);
int mvgal_dvfs_set_mode(struct mvgal_gpu_device *gpu, enum mvgal_dvfs_mode mode);

/* Thermal functions */
int mvgal_thermal_init(struct mvgal_gpu_device *gpu);
void mvgal_thermal_fini(struct mvgal_gpu_device *gpu);
int mvgal_thermal_start(struct mvgal_gpu_device *gpu);
int mvgal_thermal_stop(struct mvgal_gpu_device *gpu);
int mvgal_thermal_set_thresholds(struct mvgal_gpu_device *gpu,
				 int32_t throttle_temp, int32_t critical_temp);

/* Power budget functions */
int mvgal_power_budget_init(void);
void mvgal_power_budget_fini(void);
int mvgal_power_budget_register_gpu(struct mvgal_gpu_device *gpu, uint32_t index);
int mvgal_power_budget_unregister_gpu(uint32_t index);
int mvgal_power_budget_distribute(uint32_t *gpu_indices, uint32_t num_gpus,
				  uint32_t priority);
int mvgal_power_budget_get_gpu(uint32_t index, struct mvgal_gpu_power *power);
int mvgal_power_budget_set_total(uint32_t total_watts);
int mvgal_power_budget_set_headroom(uint32_t headroom_watts);

/* Power module lifecycle */
int mvgal_power_module_init(void);
void mvgal_power_module_exit(void);

/* Utility functions */
int mvgal_set_freq_limit(struct mvgal_gpu_device *gpu, uint32_t throttle_percent);
int mvgal_set_power_state(struct mvgal_gpu_device *gpu, enum mvgal_device_power_state state);

/**
 * Idle gating
 *
 * A gated GPU has been asked to drop to a low-power state after being unused
 * for a configured interval, and is restored to
 * MVGAL_DEVICE_POWER_STATE_ACTIVE when work
 * arrives again.
 *
 * Gating requires a real busy signal, so it requires MVGAL_CAP_BUSY_PERCENT.
 * Without a measurable busy percentage there is no way to tell an idle GPU
 * from a busy one, and guessing would gate a GPU out from under running work.
 * On a GPU lacking that capability the gate reports itself unavailable rather
 * than pretending to be armed; see mvgal_idle_gate_init().
 */
struct mvgal_idle_gate {
	struct delayed_work work;
	struct workqueue_struct *wq;
	struct mvgal_gpu_device *owner; /* GPU this gate belongs to */
	unsigned long timeout_ms;    /* idle time before gating */
	unsigned long sweep_ms;      /* how often to check */
	/*
	 * unsigned long, not u64, to match jiffies.  time_after_eq() compares
	 * its two arguments with subtraction, and a u64 here makes the kernel
	 * typecheck warn about comparing distinct pointer types.
	 */
	unsigned long last_busy_jiffies;  /* when the GPU was last seen busy */
	bool enabled;
	bool armed;                  /* gate is live: a busy signal exists */
	bool gated;                  /* GPU is currently in the low-power state */
};

int mvgal_idle_gate_init(struct mvgal_gpu_device *gpu);
void mvgal_idle_gate_fini(struct mvgal_gpu_device *gpu);
int mvgal_idle_gate_set_enabled(struct mvgal_gpu_device *gpu, bool enabled);
int mvgal_idle_gate_set_timeout(struct mvgal_gpu_device *gpu, unsigned long timeout_ms);
int mvgal_idle_gate_get(struct mvgal_gpu_device *gpu, struct mvgal_idle_gate *out);

/* ============================================================================
 * PSU Power Curve Integration (v0.5.8)
 * ============================================================================
 *
 * These functions provide direct PSU integration for power curve control.
 * They interface with hardware monitoring (hwmon) and optionally IPMI for
 * systems with smart PSUs.
 */

/**
 * PSU configuration structure
 * Stores the configured PSU capacity and safety margins
 */
struct mvgal_psu_config {
	uint32_t total_capacity_watts;      /* Total PSU capacity in watts */
	uint32_t safety_margin_percent;     /* Safety margin (default 20%) */
	bool enable_headroom_tracking;      /* Track available headroom */
	uint32_t current_total_draw_watts;  /* Current system draw */
	int32_t efficiency_percent;         /* Current PSU efficiency (0-100) */
	uint64_t last_update_ns;            /* Last update timestamp */
};

/**
 * Per-GPU power curve point
 */
struct mvgal_power_curve_point {
	uint32_t utilization_percent;    /* GPU utilization (0-100) */
	uint32_t power_limit_percent;    /* Power limit as % of GPU TDP */
	int32_t temp_target_celsius;     /* Target temperature */
};

/**
 * GPU power curve state
 */
struct mvgal_gpu_power_curve {
	struct mvgal_power_curve_point points[8]; /* Up to 8 curve points */
	uint32_t num_points;             /* Number of configured points */
	uint32_t current_point;          /* Currently active point index */
	uint32_t power_limit_watts;      /* Calculated power limit */
};

/* PSU power curve functions */
int mvgal_psu_get_config(struct mvgal_psu_config *config);
int mvgal_psu_set_config(uint32_t total_capacity_watts,
			  uint32_t safety_margin_percent,
			  bool enable_headroom_tracking);
int mvgal_psu_get_headroom(uint32_t *available_watts, uint32_t *efficiency_percent);
int mvgal_psu_update_draw(uint32_t total_draw_watts);

/* GPU power curve functions */
int mvgal_power_curve_init(struct mvgal_gpu_power_curve *curve);
int mvgal_power_curve_set_points(struct mvgal_gpu_power_curve *curve,
				  const struct mvgal_power_curve_point *points,
				  uint32_t num_points);
int mvgal_power_curve_apply(struct mvgal_gpu_power_curve *curve,
			     uint32_t gpu_utilization,
			     int32_t gpu_temperature,
			     uint32_t *out_power_limit_watts);
int mvgal_power_curve_get_info(uint32_t gpu_index,
				 struct mvgal_gpu_power_curve *curve);

/* Power curve optimization */
uint32_t mvgal_power_curve_optimize_for_utilization(uint32_t utilization_percent,
						     const struct mvgal_power_curve_point *points,
						     uint32_t num_points);

#endif /* _MVGAL_POWER_H_ */
