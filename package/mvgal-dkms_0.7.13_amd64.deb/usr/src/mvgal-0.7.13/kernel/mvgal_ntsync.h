/**
 * MVGAL NTSYNC Kernel Module - Standalone Header
 *
 * Defines NTSYNC synchronization primitives structures for
 * Wine/Proton compatibility as an independent misc device.
 *
 * SPDX-License-Identifier: GPL-2.0
 */

#ifndef _MVGAL_NTSYNC_H_
#define _MVGAL_NTSYNC_H_

#include <linux/types.h>

/* ------------------------------------------------------------------ */
/*  NTSYNC Object Types                                                */
/* ------------------------------------------------------------------ */

#define MVGAL_NTSYNC_TYPE_EVENT       1
#define MVGAL_NTSYNC_TYPE_SEMAPHORE   2
#define MVGAL_NTSYNC_TYPE_MUTEX       3
#define MVGAL_NTSYNC_TYPE_TIMER       4
#define MVGAL_NTSYNC_TYPE_FENCE       5

/* ------------------------------------------------------------------ */
/*  NTSYNC Object Flags                                                 */
/* ------------------------------------------------------------------ */

#define MVGAL_NTSYNC_FLAG_AUTO_RESET   (1 << 0)
#define MVGAL_NTSYNC_FLAG_SIGNALED     (1 << 1)
#define MVGAL_NTSYNC_FLAG_SHARED       (1 << 2)

/* ------------------------------------------------------------------ */
/*  NTSYNC Arg Structures                                               */
/* ------------------------------------------------------------------ */

struct mvgal_ntsync_create_args {
	__u32 type;
	__u32 flags;
	__u32 initial;
	__u32 fd;
};

struct mvgal_ntsync_open_args {
	__u32 fd;
};

struct mvgal_ntsync_wait_args {
	__u32 fd;
	__u32 status;
	__u64 timeout_ns;
};

struct mvgal_ntsync_signal_args {
	__u32 fd;
	__u32 count;
	__u32 alertable;
};

struct mvgal_ntsync_timer_args {
	__u32 fd;
	__u64 due_time_ns;
	__u64 period_ns;
};

struct mvgal_ntsync_fence_args {
	__u32 fd;
	__u32 gpu_index;
	__u32 flags;
	__u64 timeout_ns;
};

#define MVGAL_NTSYNC_MAX_WAIT_OBJECTS 64

struct mvgal_ntsync_multi_wait_args {
	__u32 count;         /* Number of objects (1-64) */
	__u32 wait_type;     /* 0=WaitAny, 1=WaitAll */
	__u32 status;        /* 0=signaled, 1=timeout, 2=error */
	__u32 index;         /* Index of signaled object (WaitAny) */
	__u64 timeout_ns;    /* Timeout in ns (0=infinite) */
	__u64 fds;           /* Pointer to userspace array of __u32 handles */
};

/* Wait for multiple NTSYNC objects (WaitForMultipleObjects NT compat) */
#define MVGAL_NTSYNC_IOC_WAIT_MULTI  _IOWR(MVGAL_NTSYNC_IOC_MAGIC, 16, struct mvgal_ntsync_multi_wait_args)

/* ------------------------------------------------------------------ */
/*  Integration API called from mvgal_core.c                            */
/* ------------------------------------------------------------------ */

int  mvgal_ntsync_init(void);
void mvgal_ntsync_exit(void);

/**
 * mvgal_ntsync_query() - Return NTSYNC subsystem info for MVGAL_IOC_NTSYNC_QUERY
 * @info:   Pointer to struct mvgal_uapi_ntsync_info to fill
 *
 * Returns 0 on success, -ENODEV if NTSYNC is not initialized.
 */
struct mvgal_uapi_ntsync_info;
int mvgal_ntsync_query(struct mvgal_uapi_ntsync_info *info);

#endif /* _MVGAL_NTSYNC_H_ */
