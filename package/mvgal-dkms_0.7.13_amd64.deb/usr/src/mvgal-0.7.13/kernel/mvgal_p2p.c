// SPDX-License-Identifier: GPL-2.0-only
/*
 * mvgal_p2p.c - PCIe P2P DMA channel management for MVGAL
 *
 * Manages peer-to-peer memory mappings between GPUs on the same
 * PCI root complex.  Provides channel setup, data transfer, and
 * teardown for PCIe P2P DMA operations.
 *
 * The actual DMA-BUF attach/map work is delegated to the helpers
 * in mvgal_dmabuf.c.  This module adds channel lifecycle tracking,
 * P2P capability queries, and statistics accounting.
 */

#define pr_fmt(fmt) "MVGAL-P2P: " fmt

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/dma-buf.h>
#include <linux/pci.h>
#include <linux/dma-mapping.h>

#include "mvgal_core.h"
#include "mvgal_device.h"
#include "mvgal_memory.h"
#include "mvgal_dmabuf.h"
#include "mvgal_p2p.h"

/* ---------------------------------------------------------------------------
 * Module-level state
 * --------------------------------------------------------------------------- */

static bool p2p_module_initialized;

/* ---------------------------------------------------------------------------
 * Capability queries
 * --------------------------------------------------------------------------- */

/**
 * mvgal_p2p_check_support - Check if P2P is supported between two GPUs
 * @gpu1: First GPU device
 * @gpu2: Second GPU device
 *
 * Delegates to the per-vendor P2P detection in mvgal_device.c which checks
 * NVLink, xGMI, NUMA locality, and pci_p2pdma_distance().
 *
 * Returns: Positive P2P level (see enum mvgal_p2p_support), or 0 if
 *          P2P is not supported between these GPUs.
 */
int mvgal_p2p_check_support(struct mvgal_gpu_device *gpu1,
			    struct mvgal_gpu_device *gpu2)
{
	if (!gpu1 || !gpu2)
		return 0;

	return mvgal_detect_p2p_support(gpu1, gpu2);
}
EXPORT_SYMBOL_GPL(mvgal_p2p_check_support);

/**
 * mvgal_p2p_any_supported - Check if any P2P path exists in the system
 * @dev: The MVGAL logical device
 *
 * Looks at the pre-computed p2p_matrix bitmask built by
 * mvgal_detect_all_p2p().
 *
 * Returns: true if at least one GPU pair supports P2P.
 */
bool mvgal_p2p_any_supported(struct mvgal_device *dev)
{
	if (!dev)
		return false;

	return dev->caps.p2p_supported && dev->p2p_matrix != 0;
}
EXPORT_SYMBOL_GPL(mvgal_p2p_any_supported);

/* ---------------------------------------------------------------------------
 * GPU lookup helpers
 * --------------------------------------------------------------------------- */

/**
 * find_gpu_by_index - Find a GPU device by its pool index
 * @dev: The MVGAL logical device
 * @index: GPU pool index to search for
 *
 * Caller must hold dev->gpu_lock.
 *
 * Returns: Pointer to the GPU device, or NULL if not found.
 */
static struct mvgal_gpu_device *
find_gpu_by_index(struct mvgal_device *dev, uint32_t index)
{
	struct mvgal_gpu_device *gpu;
	uint32_t idx = 0;

	list_for_each_entry(gpu, &dev->gpu_list, node) {
		if (idx == index)
			return gpu;
		idx++;
	}

	return NULL;
}

/* ---------------------------------------------------------------------------
 * Channel lifecycle
 * --------------------------------------------------------------------------- */

/**
 * mvgal_p2p_channel_create - Create a P2P channel from src to dst
 * @dev: The MVGAL logical device
 * @src_gpu: Source GPU pool index
 * @dst_gpu: Destination GPU pool index
 * @channel: Caller-allocated channel structure to initialize
 *
 * Locates the source and destination GPU devices, obtains a DMA-BUF
 * representing the source GPU's memory, and attaches/maps it to the
 * destination GPU device so that the destination can perform DMA
 * operations directly into the source's memory over PCIe.
 *
 * The channel must be destroyed with mvgal_p2p_channel_destroy() when
 * no longer needed.
 *
 * Returns: 0 on success, negative errno on failure.
 */
int mvgal_p2p_channel_create(struct mvgal_device *dev,
			     uint32_t src_gpu, uint32_t dst_gpu,
			     struct mvgal_p2p_channel *channel)
{
	struct mvgal_gpu_device *src, *dst;
	struct mvgal_p2p_channel *ch;

	if (!dev || !channel)
		return -EINVAL;

	if (src_gpu >= MVGAL_MAX_GPUS || dst_gpu >= MVGAL_MAX_GPUS)
		return -EINVAL;

	if (src_gpu == dst_gpu)
		return -EINVAL;

	memset(channel, 0, sizeof(*ch));
	ch = channel;

	/* Look up GPU devices */
	mutex_lock(&dev->gpu_lock);
	src = find_gpu_by_index(dev, src_gpu);
	dst = find_gpu_by_index(dev, dst_gpu);
	mutex_unlock(&dev->gpu_lock);

	if (!src || !dst) {
		pr_err("GPU not found: src=%u dst=%u\n", src_gpu, dst_gpu);
		return -ENODEV;
	}

	ch->src_gpu = src_gpu;
	ch->dst_gpu = dst_gpu;
	ch->src_dev = src;
	ch->dst_dev = dst;
	ch->state = MVGAL_P2P_CHAN_IDLE;

	/*
	 * Validate that P2P is possible between these two GPUs.
	 * This checks NVLink, xGMI, NUMA locality, and PCI topology.
	 */
	if (!mvgal_p2p_check_support(src, dst)) {
		pr_debug("P2P not supported between GPU %u and GPU %u\n",
			 src_gpu, dst_gpu);
		return -EOPNOTSUPP;
	}

	/*
	 * To set up the peer mapping we need a DMA-BUF from the source
	 * GPU.  In the migration path, the caller (mvgal_residency_migrate)
	 * ensures a DMA-BUF exists in mem->dmabufs[src_gpu] before calling
	 * into the P2P module.  For standalone channel creation we attempt
	 * a vendor export if available.
	 *
	 * The actual DMA-BUF attach+map is performed lazily in
	 * mvgal_p2p_transfer() when the source memory is known, because
	 * the channel does not own a specific allocation.  This keeps the
	 * channel lightweight and reusable across multiple transfers.
	 */
	ch->peer_dir = DMA_BIDIRECTIONAL;
	ch->state = MVGAL_P2P_CHAN_MAPPED;

	pr_debug("Channel created: GPU %u -> GPU %u (P2P capable)\n",
		 src_gpu, dst_gpu);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_p2p_channel_create);

/**
 * mvgal_p2p_transfer - Execute a P2P data transfer through a channel
 * @channel: Established P2P channel
 * @src_mem: Source memory region (must have DMA-BUF on src_gpu)
 * @dst_mem: Destination memory region (must be populated on dst_gpu)
 * @src_offset: Byte offset within source memory
 * @dst_offset: Byte offset within destination memory
 * @size: Number of bytes to transfer
 *
 * Performs the P2P transfer by attaching the source memory's DMA-BUF
 * to the destination GPU device.  This establishes a direct PCIe DMA
 * path from dst to src, allowing the destination GPU's DMA engine to
 * read from source memory without going through system RAM.
 *
 * On success the P2P transfer statistics counter is incremented.
 *
 * Returns: 0 on success, negative errno on failure.
 */
int mvgal_p2p_transfer(struct mvgal_p2p_channel *channel,
		       struct mvgal_memory *src_mem,
		       struct mvgal_memory *dst_mem,
		       size_t src_offset, size_t dst_offset,
		       size_t size)
{
	struct mvgal_p2p_channel *ch;
	struct mvgal_dmabuf_state peer_state;
	struct dma_buf *dmabuf;
	int ret;

	if (!channel || !src_mem || !dst_mem)
		return -EINVAL;

	ch = channel;

	if (ch->state == MVGAL_P2P_CHAN_IDLE)
		return -EINVAL;

	if (src_offset + size > src_mem->size ||
	    dst_offset + size > dst_mem->size)
		return -EINVAL;

	/*
	 * Obtain the source DMA-BUF.  Prefer an existing one stored in
	 * the memory tracking structure; fall back to a vendor export.
	 */
	dmabuf = src_mem->dmabufs[ch->src_gpu];
	if (dmabuf) {
		get_dma_buf(dmabuf);
	} else if (ch->src_dev->ops && ch->src_dev->ops->export_dmabuf &&
		   src_mem->gpu_addrs[ch->src_gpu]) {
		dmabuf = ch->src_dev->ops->export_dmabuf(
			ch->src_dev,
			src_mem->gpu_addrs[ch->src_gpu],
			src_mem->size);
		if (IS_ERR(dmabuf)) {
			pr_debug("Vendor export failed for P2P: %ld\n",
				 PTR_ERR(dmabuf));
			return PTR_ERR(dmabuf);
		}
	} else {
		pr_debug("No DMA-BUF available for P2P transfer\n");
		return -EOPNOTSUPP;
	}

	/*
	 * Attach the source DMA-BUF to the destination GPU device.
	 * This is the core P2P operation: it tells the IOMMU / DMA
	 * mapping layer that the destination device should be able to
	 * DMA into the source device's memory.
	 */
	memset(&peer_state, 0, sizeof(peer_state));
	peer_state.dir = DMA_BIDIRECTIONAL;

	ret = mvgal_dmabuf_attach_and_map(dmabuf, &ch->dst_dev->dev,
					  DMA_BIDIRECTIONAL, &peer_state);
	if (ret) {
		pr_debug("P2P attach failed GPU %u -> GPU %u: %d\n",
			 ch->src_gpu, ch->dst_gpu, ret);
		dma_buf_put(dmabuf);
		return ret;
	}

	/*
	 * Store the peer mapping in the channel for potential reuse
	 * and bookkeeping.
	 */
	ch->peer_buf = dmabuf;
	ch->peer_attach = peer_state.attach;
	ch->peer_sgt = peer_state.sgt;
	ch->peer_dma_addr = sg_dma_address(peer_state.sgt->sgl);
	ch->peer_size = src_mem->size;
	ch->state = MVGAL_P2P_CHAN_ACTIVE;

	/*
	 * Update destination memory tracking: mark the destination as
	 * populated via P2P and record the GPU-visible DMA address.
	 */
	if (dst_mem->sgt[ch->dst_gpu])
		sg_free_table(dst_mem->sgt[ch->dst_gpu]);

	/* Store the peer sgt in the destination memory for cleanup */
	dst_mem->attachments[ch->dst_gpu] = peer_state.attach;
	dst_mem->sgt[ch->dst_gpu] = peer_state.sgt;
	dst_mem->gpu_addrs[ch->dst_gpu] = ch->peer_dma_addr;
	dst_mem->populated[ch->dst_gpu] = true;

	/* Record in stats */
	if (mvgal_logical_device)
		atomic64_inc(
			&mvgal_logical_device->stats.p2p_transfer_count);

	pr_debug("P2P transfer: GPU %u -> GPU %u, %zu bytes "
		 "(src_off=%zu dst_off=%zu dma_addr=0x%llx)\n",
		 ch->src_gpu, ch->dst_gpu, size,
		 src_offset, dst_offset,
		 (unsigned long long)ch->peer_dma_addr);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_p2p_transfer);

/**
 * mvgal_p2p_channel_destroy - Destroy a P2P channel and release resources
 * @channel: P2P channel to destroy
 *
 * Unmaps and detaches the peer DMA-BUF mapping, then resets the
 * channel to IDLE state.  Safe to call on a zeroed or IDLE channel.
 */
void mvgal_p2p_channel_destroy(struct mvgal_p2p_channel *channel)
{
	struct mvgal_p2p_channel *ch;

	if (!channel)
		return;

	ch = channel;

	if (ch->state == MVGAL_P2P_CHAN_IDLE)
		return;

	/* Tear down the peer mapping if it was established */
	if (ch->peer_buf) {
		struct mvgal_dmabuf_state peer_state = {
			.dmabuf  = ch->peer_buf,
			.attach  = ch->peer_attach,
			.sgt     = ch->peer_sgt,
			.dir     = ch->peer_dir,
		};

		mvgal_dmabuf_unmap_and_detach(&peer_state);
		dma_buf_put(ch->peer_buf);
	}

	ch->peer_buf = NULL;
	ch->peer_attach = NULL;
	ch->peer_sgt = NULL;
	ch->peer_dma_addr = 0;
	ch->peer_size = 0;
	ch->state = MVGAL_P2P_CHAN_IDLE;

	pr_debug("Channel destroyed: GPU %u -> GPU %u\n",
		 ch->src_gpu, ch->dst_gpu);
}
EXPORT_SYMBOL_GPL(mvgal_p2p_channel_destroy);

/* ---------------------------------------------------------------------------
 * Module init / cleanup
 * --------------------------------------------------------------------------- */

/**
 * mvgal_p2p_init - Initialize the P2P subsystem
 *
 * Called once during module load.  Currently a no-op because all state
 * is per-channel and capability detection is done by mvgal_device.c.
 * Retained as an explicit init point for future global resource
 * allocation (e.g. a P2P channel pool or sysfs entries).
 *
 * Returns: 0 on success.
 */
int mvgal_p2p_init(void)
{
	if (p2p_module_initialized)
		return 0;

	p2p_module_initialized = true;
	pr_info("P2P subsystem initialized\n");

	return 0;
}

/**
 * mvgal_p2p_fini - Clean up the P2P subsystem
 *
 * Called once during module unload.  Currently a no-op complement to
 * mvgal_p2p_init().
 */
void mvgal_p2p_fini(void)
{
	if (!p2p_module_initialized)
		return;

	p2p_module_initialized = false;
	pr_info("P2P subsystem finalized\n");
}

/* ---------------------------------------------------------------------------
 * Module boilerplate
 * --------------------------------------------------------------------------- */

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("MVGAL P2P DMA channel management");
MODULE_AUTHOR("MVGAL Project");
