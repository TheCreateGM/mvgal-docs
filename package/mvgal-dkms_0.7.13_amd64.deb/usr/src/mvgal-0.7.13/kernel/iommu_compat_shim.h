/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 * 
 * IOMMU Compatibility Shim for Kernel 6.13+
 * 
 * In Linux kernels 6.13 and newer, the IOMMU subsystem was refactored:
 * - iommu_paging_domain_alloc() was replaced with iommu_domain_alloc()
 * - iommu_present() was removed (functionality merged into iommu_domain_alloc())
 * 
 * This shim provides backward-compatible implementations for older out-of-tree
 * drivers like Moore Threads' mtgpu-drv that depend on the deprecated symbols.
 * 
 * SPDX-License-Identifier: GPL-2.0-only
 */

#include <linux/version.h>
#include <linux/iommu.h>
#include <linux/of.h>
#include <linux/module.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)

/**
 * mvgal_compat_iommu_present - Compatibility wrapper for deprecated iommu_present()
 * 
 * In kernels < 6.13, this function checked if an IOMMU was present for a bus.
 * In kernels >= 6.13, IOMMU domain allocation serves this purpose.
 * 
 * @bus: The bus type to check for IOMMU presence
 * 
 * Returns: true if an IOMMU domain can be allocated (IOMMU present), false otherwise
 */
bool mvgal_compat_iommu_present(const struct bus_type *bus)
{
	struct device dev = {
		.bus = (struct bus_type *)bus,
	};
	struct iommu_domain *domain;

	/* Try to allocate a domain - if successful, IOMMU is present */
	domain = iommu_domain_alloc(&dev);
	if (domain) {
		iommu_domain_free(domain);
		return true;
	}
	return false;
}
EXPORT_SYMBOL_GPL(mvgal_compat_iommu_present);

/**
 * mvgal_compat_iommu_paging_domain_alloc - Compatibility wrapper for deprecated iommu_paging_domain_alloc()
 * 
 * In kernels < 6.13, this function allocated a paging domain for a device.
 * In kernels >= 6.13, this is replaced by iommu_domain_alloc() which serves
 * the same purpose with a unified domain interface.
 * 
 * @dev: The device to allocate a domain for
 * 
 * Returns: A pointer to the allocated iommu_domain, or ERR_PTR on failure
 */
struct iommu_domain *mvgal_compat_iommu_paging_domain_alloc(struct device *dev)
{
	return iommu_domain_alloc(dev->bus);
}
EXPORT_SYMBOL_GPL(mvgal_compat_iommu_paging_domain_alloc);

/**
 * mvgal_iommu_present - Inline wrapper macro for iommu_present compatibility
 * 
 * This provides a simple function call interface that maps to either the
 * original iommu_present() on older kernels or mvgal_compat_iommu_present()
 * on newer kernels.
 */
#ifdef iommu_present
/* Kernel has native iommu_present - use it directly */
#define mvgal_iommu_present(bus) iommu_present(bus)
#else
/* Use compatibility wrapper */
#define mvgal_iommu_present(bus) mvgal_compat_iommu_present(bus)
#endif

#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0) */