/**
 * @file mvgal_nvml.h
 * @brief Minimal C-side NVML query helper for NVIDIA VRAM detection
 *
 * The NVIDIA proprietary driver publishes no VRAM size in sysfs, so the C
 * GPU-detection path (gpu_manager.c) and the mvgal-info tool cannot read it
 * the way they read AMD's mem_info_vram_total or Intel's lmem_total_bytes.
 * NVML is the only supported source.  The C++ daemon already links a full
 * NvmlLoader; this is the C-side equivalent, kept deliberately small.
 */

#ifndef MVGAL_NVML_H
#define MVGAL_NVML_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Query total VRAM (bytes) for an NVIDIA GPU by PCI bus id.
 *
 * @param pci_bdf PCI bus id in NVML form, e.g. "0000:04:00.0".
 * @return Total VRAM in bytes, or 0 when NVML is unavailable or the device
 *         is unknown.  Never fabricates a value.
 */
uint64_t mvgal_nvml_vram_total_by_pci(const char *pci_bdf);

#ifdef __cplusplus
}
#endif

#endif /* MVGAL_NVML_H */
