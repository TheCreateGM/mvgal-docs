# MVGAL Power Management

> **Version**: 0.7.28
> **Last Updated**: 2026-10-25
> **Status**: Implementation exists at three layers, but the control loops are
> **not fully wired to runtime triggers**. Each section below states exactly
> what is implemented, what is initialized-but-idle, and what does not exist.

---

## Table of Contents

1. [Overview](#overview)
2. [Power Curve System](#power-curve-system)
3. [Idle State Machine](#idle-state-machine)
4. [DVFS Control](#dvfs-control)
5. [Thermal Throttling](#thermal-throttling)
6. [Fan Curves](#fan-curves)
7. [PSU Headroom Tracking](#psu-headroom-tracking)
8. [Configuration](#configuration)
9. [What Does Not Exist](#what-does-not-exist)
10. [Vendor-Specific Power Management](#vendor-specific-power-management)
11. [Testing](#testing)

---

## Overview

MVGAL power management is split across three layers:

1. **Kernel module** (`kernel/mvgal_power.c`, `kernel/mvgal_power.h`, 1395 lines):
   - Per-GPU DVFS policy structures and a frequency-limit control function
   - Thermal state tracking with a continuous throttle calculation
   - Power budget registry and PSU headroom configuration
   - Initialized per GPU from `mvgal_device.c` (dvfs init, thermal init,
     budget register) and at module load from `mvgal_core.c`
     (`mvgal_power_module_init`).

2. **Runtime daemon** (`runtime/daemon/power_manager.cpp`, `.hpp`):
   - Four-state idle machine (ACTIVE → SUSTAINED → IDLE → PARK)
   - Five-tier thermal classification
   - Fan curve interpolation and manual fan control
   - Power curve → clock-ceiling computation, PSU headroom tracking
   - Runs in the daemon main loop (`daemon.cpp` calls `processEvents()` each
     iteration).

3. **Userspace power library** (`src/userspace/power/`):
   - `power_curve.c` (712 lines): curve math, PSU efficiency table,
     per-vendor power-profile helpers
   - `power_manager.c` (1416 lines): park/unpark, suspend/resume, S0ix,
     thermal check, power monitor thread (`mvgal_pm_*` API)

### Wiring status (read this first)

Honest state of each control path as of this audit:

| Path | Status |
|------|--------|
| Daemon idle/thermal state machines | **Running** — driven by `processEvents()` in the daemon loop |
| Daemon fan curve / power curve / PSU APIs | **Implemented** — callable in-process; no CLI or D-Bus method exposes them |
| Kernel DVFS/thermal periodic work handlers | **Armed but never queued** — `mvgal_dvfs_start()` / `mvgal_thermal_start()` have no callers outside tests, so the tick handlers never run |
| Kernel power control entry points (`mvgal_dvfs_set_mode`, `mvgal_set_freq_limit`, `mvgal_thermal_set_thresholds`, `mvgal_set_power_state`, `mvgal_power_budget_distribute`) | **No runtime caller** — no ioctl or sysfs write path reaches them; only KUnit tests call them |
| `[power]` section of `mvgal.conf` | **Not wired to the daemon** — `PowerManager::setConfig()` has no external callers; the daemon uses compiled defaults (see [Configuration](#configuration)) |
| D-Bus power interface | **Signal only** — `PowerLimitReached` is emitted; there are no power/fan/thermal methods |

---

## Power Curve System

Power curves map GPU workload intensity to a power limit expressed as a
percentage of TDP.

### Structures

- Kernel: `struct mvgal_power_curve_point` and the default curve table in
  `kernel/mvgal_power.c`.
- Daemon: `PowerCurvePoint { utilizationPercent, powerLimitPercent }` with
  `MVGAL_MAX_POWER_CURVE_POINTS = 8` per GPU (`power_manager.hpp`).
- Userspace library: enhanced curve entries
  `{ utilization_percent, power_limit_percent, boost_offset }` with up to 16
  points (`src/userspace/power/power_curve.c`).

### Kernel default curve

The kernel ships exactly **three** points (`kernel/mvgal_power.c`, default
curve table):

| Utilization | Power Limit | Temp Target |
|:-----------:|:-----------:|:-----------:|
| 0% | 30% | 40°C |
| 50% | 70% | 70°C |
| 100% | 100% | 85°C |

Linear interpolation applies between points. There is no voltage column —
the kernel curve carries no voltage data.

### Shipped config curve

`config/mvgal.conf` `[power] power_curve=` ships five points:

```
0:30, 25:50, 50:70, 75:90, 100:100
```

### Profiles

The public header (`include/mvgal/mvgal_power.h`) defines an **eight-value**
profile enum:

| Value | Profile |
|:-----:|---------|
| 0 | `PERFORMANCE` |
| 1 | `BALANCED` |
| 2 | `POWERSAVER` |
| 3 | `AUTO` |
| 4 | `CUSTOM` |
| 5 | `ADAPTIVE` |
| 6 | `RENDERING` |
| 7 | `GAMING` |

Profiles are selected through `mvgal_set_power_profile()` in the userspace
library. There is no `turbo` profile and no fixed "%TDP per profile" table —
profile behavior is curve-driven, not a static power cap table.

---

## Idle State Machine

Defined in `runtime/daemon/power_manager.hpp`:

```c++
enum class PowerState { ACTIVE = 0, SUSTAINED = 1, IDLE = 2, PARK = 3 };
```

```
   ┌──────────┐  idleTimeoutMs  ┌───────────┐  +sustained  ┌───────┐  +park   ┌──────┐
   │  ACTIVE  │ ──────────────→ │ SUSTAINED │ ───────────→ │ IDLE  │ ───────→ │ PARK │
   └──────────┘                 └───────────┘              └───────┘          └──────┘
        ↑                             │                        │                 │
        └─────────────────────────────┴── notifyActivity() ────┴─────────────────┘
```

### Transition timers (cumulative)

Timers are **cumulative from the last activity**, driven by
`checkIdleTimeouts()` (`power_manager.cpp`). Compiled defaults:

| Transition | Trigger | Default |
|------------|---------|:-------:|
| ACTIVE → SUSTAINED | `idleTimeoutMs` of inactivity | 5 000 ms |
| SUSTAINED → IDLE | `idleTimeoutMs + sustainedTimeoutMs` | 15 000 ms |
| IDLE → PARK | `idleTimeoutMs + sustainedTimeoutMs + parkTimeoutMs` | 45 000 ms |
| Any → ACTIVE | `notifyActivity()` | instant |

The config keys are `idle_timeout_ms`, `sustained_timeout_ms`,
`park_timeout_ms` (see [Configuration](#configuration)). There are no
`idle_sustained_ms` / `idle_park_ms` / `park_delay_ms` keys.

### State semantics

The daemon tracks these states for policy decisions (clock ceilings, fan
curves, power limits). The daemon does **not** drive PCI power states —
there is no D0/D3hot/D3cold transition code, and no wake-latency figures are
implemented anywhere in the tree.

---

## DVFS Control

Four DVFS modes are defined in `kernel/mvgal_power.h`:

| Mode | Enum |
|------|------|
| `MVGAL_DVFS_PERFORMANCE` | Max clock always |
| `MVGAL_DVFS_BALANCED` | Scale on demand (default) |
| `MVGAL_DVFS_POWERSAVE` | Min clock preferred |
| `MVGAL_DVFS_CUSTOM` | User-defined curve |

### Policy parameters

`struct mvgal_dvfs_policy` (`kernel/mvgal_power.h`) with compiled defaults
(`kernel/mvgal_power.c`):

| Parameter | Description | Default |
|-----------|-------------|:-------:|
| `min_freq_mhz` | Minimum GPU clock | 300 MHz |
| `max_freq_mhz` | Maximum GPU clock | 2000 MHz |
| `up_threshold` | Util% to scale up | 80% |
| `down_threshold` | Util% to scale down | 30% |
| `step_delay_ms` | Min interval between changes | **100 ms** |

### Runtime status — not wired

- `mvgal_dvfs_init()` runs per GPU at device init: it allocates state,
  installs the default policy, and arms `INIT_DELAYED_WORK` with a real tick
  handler. It does **not** queue the work.
- `mvgal_dvfs_start()` (which queues the tick) has **no callers** outside
  tests, so the periodic DVFS handler never executes on a running system.
- `mvgal_dvfs_set_mode()` and `mvgal_set_freq_limit()` have **no callers**
  outside tests — no ioctl or sysfs path reaches them.
- The daemon's `applyDvfs()` computes a target clock from utilization, the
  power curve, and the PSU cap, but `DvfsState::currentClockMhz` stays 0
  while no clock-write path exists (documented in `power_manager.hpp`).

### Querying DVFS state

There is **no** `mvgal-info --dvfs` or `mvgal-info --power` flag.
`mvgal-info` accepts only `--json`, `--count`, `--vulkan-groups`,
`--version`, and `--help`. DVFS state is not currently exposed through any
CLI.

---

## Thermal Throttling

Two independent thermal implementations exist.

### Daemon classification (running)

`checkThermalState()` (`runtime/daemon/power_manager.cpp`) classifies
against two config thresholds — `thermalThreshold` (default 85°C) and
`criticalThreshold` (default 95°C):

| State | Condition (defaults) |
|-------|----------------------|
| `NORMAL` | < 70°C |
| `WARN` | ≥ 70°C (`threshold − 15`) |
| `HOT` | ≥ 80°C (`threshold − 5`) |
| `THROTTLING` | ≥ 85°C (`thermalThreshold`) |
| `CRITICAL` | ≥ 95°C (`criticalThreshold`) |

The five-tier enum lives in `power_manager.hpp`. The daemon classifies and
emits `PowerLimitReached`; it does not itself write clocks.

### Kernel throttle (armed, not queued)

`mvgal_thermal_init()` runs per GPU: allocates state, installs defaults
(`throttle_temp_c = 75`, `critical_temp_c = 95`), and arms a 1-second
delayed work item. It does **not** register a `thermal_zone_device` and does
**not** queue the work; `mvgal_thermal_start()` has no callers outside
tests.

The handler (`mvgal_thermal_work_handler`) computes a **continuous** throttle
level, not discrete steps:

```
temp ≥ critical (95°C)  → power off, level = 100
temp ≥ throttle (75°C)  → level = (temp − 75) × 100 / (95 − 75), clamped to 100
otherwise               → level = 0
```

The level feeds `mvgal_set_freq_limit()`, which itself has no runtime
caller. There is no 3-level (10/25/50%) throttle table and no hysteresis
temperature ladder in the code.

### Temperature monitoring

Temperature is read by the daemon (`readTemperature()` via hwmon/NVML) and
by the kernel helper `mvgal_read_sysfs_power()`. There is **no**
`mvgal-info --temperature` flag and no thermal-history feature.

---

## Fan Curves

Implemented in the daemon (`power_manager.hpp` / `.cpp`):

- `FanCurvePoint { temperatureCelsius, fanSpeedPercent }`,
  `MVGAL_MAX_FAN_CURVE_POINTS = 10`
- `GpuFanCurve`, `GpuFanControl { enabled, automatic, manualSpeedPercent,
  currentSpeedPercent, currentRpm }`
- API: `setFanCurve()`, `getFanCurve()`, `setFanSpeed()`,
  `setFanAutomatic()`, `applyFanControl()`, `interpolateFanSpeed()`

Fan control is in-process only: no CLI command, D-Bus method, or config key
exposes it today.

---

## PSU Headroom Tracking

- Daemon: `PsuConfig { totalCapacityWatts, safetyMarginPercent,
  enableHeadroomTracking }` and `PsuHeadroom { totalCapacityWatts,
  currentDrawWatts, headroomWatts, safetyMarginPercent }`; updated by
  `updatePsuHeadroom()` and consumed as a clock ceiling
  (`psuCapClockMhz`) in `applyDvfs()`.
- Kernel: `mvgal_psu_get_config()` / `mvgal_psu_set_config()` with default
  `{ capacity = 0 (unknown), margin = 20%, headroom off }`.
- Userspace: 80-Plus efficiency curve (`g_psu_efficiency_curve`) and
  `calculate_cross_gpu_power_optimization()` in `power_curve.c`.

PSU capacity is a **user-provided** value (config `psu_capacity_watts`,
default 0 = unknown). MVGAL does not discover PSU capacity from hardware —
it is not reliably discoverable on PC platforms.

---

## Configuration

`config/mvgal.conf` `[power]` section (shipped defaults):

```ini
[power]
idle_timeout_ms = 5000
sustained_timeout_ms = 10000
park_timeout_ms = 30000
thermal_threshold = 85
critical_threshold = 95
power_curve = 0:30,25:50,50:70,75:90,100:100
psu_capacity_watts = 0
psu_safety_margin_percent = 20
enable_psu_headroom = false
power_limit_watts = 0
enable_power_capping = false
enable_dvfs = true
enable_aggressive_power_down = false
```

### Wiring gap (known)

The C++ daemon currently reads only `[core] default_strategy` from
`mvgal.conf` (`daemon.cpp` `readDefaultStrategy()`; `reloadConfig()` re-reads
only the strategy). `PowerManager::setConfig()` has no external callers, so
the daemon's power behavior uses the **compiled defaults** listed above
(they happen to match the shipped file). The C config parser
(`src/userspace/daemon/config.c`) parses only `scheduler.thermal_aware` /
`scheduler.power_aware` keys — it does not parse `[power]`.

Other readers of power keys today:

- `steam_profile_loader.cpp` reads `power.idle_timeout_ms` (default 10000)
- `mvgal_exporter.go` reads the JSON `idle_timeout_s` metric field

---

## What Does Not Exist

Documented explicitly so readers do not go looking for these:

| Claim in older docs | Reality |
|---------------------|---------|
| `mvgal-powercurve` CLI tool | Does not exist; `tools/` has no power tool, and `mvgal` CLI has no power/fan/profile subcommands |
| `mvgal-info --dvfs / --power / --temperature / --history` | Flags do not exist |
| Gamemode integration (`/etc/mvgal/gamemode.conf`) | No gamemode reference anywhere in `src/`, `runtime/`, or `tools/` |
| Custom curve file `/etc/mvgal/powercurve.json` | No code reads it |
| Moore Threads MTGX power API | No MTGX reference in the tree |
| PCI D-state mapping (D0/D3hot/D3cold) | Not implemented |
| Fixed per-state TDP tables and wake-latency numbers | Not implemented |
| 3-level throttle ladder with hysteresis | Kernel uses one continuous formula |

---

## Vendor-Specific Power Management

### NVIDIA

- `runtime/daemon/nvml_loader.cpp` / `.hpp` loads NVML dynamically.
- The daemon reads power draw and temperature through the NVML path where
  available (`readPowerDraw()`, `readTemperature()`).
- `power_curve.c` provides `set_nvidia_power_limit()` as a library helper.

### AMD

- hwmon interface: `/sys/class/drm/card*/device/hwmon/hwmon*/` (kernel
  helper `mvgal_read_sysfs_power()`; daemon hwmon reads).
- `power_curve.c` provides `set_amd_power_profile()`.
- Clock control on `amdgpu` is firmware-owned (DVFS via the vendor driver);
  MVGAL does not write AMD clocks directly.

### Intel

- hwmon interface, same path pattern as AMD.
- `power_curve.c` provides `set_intel_power_profile()`.
- No dedicated Intel power API beyond hwmon.

### Moore Threads

- No vendor power API integration exists in the tree. Any MTT power support
  would be future work.

---

## Testing

`kernel/tests/test_mvgal_power.c` — KUnit suite (~17 tests) covering:

- Power state transitions
- All four DVFS modes
- Thermal threshold classification (normal / throttling / critical / range)
- Power draw calculation and budget allocation
- Frequency up/downscale decisions
- Idle/active detection

Run with the kernel test harness (`kernel/tests/`).

---

*See `docs/ARCHITECTURE.md` for daemon architecture.
See `runtime/daemon/power_manager.cpp` for the daemon implementation.
See `kernel/mvgal_power.c` for the kernel-side DVFS/thermal structures.
See `docs/SPEC_COMPLIANCE.md` finding 4 for the original gap report that
prompted this document's honesty rewrite.*
