# MVGAL Windows Compatibility Layer

> **Version**: 0.7.28
> **Status**: Partial implementation — NTSYNC kernel module and DXGI
> interception exist; DLL shim tree, vendor shims, and WoW64 redirection
> are **not implemented**
> **Last Updated**: 2026-10-25

---

## Table of Contents

1. [Overview](#overview)
2. [What Exists vs What Does Not](#what-exists-vs-what-does-not)
3. [NTSYNC Kernel Module](#ntsync-kernel-module)
4. [DXGI Interception](#dxgi-interception)
5. [DXVK / VKD3D-Proton Integration](#dxdxk--vkd3d-proton-integration)
6. [Not Implemented](#not-implemented)

---

## Overview

The Windows Compatibility Layer (WCL) is MVGAL's planned path for running
Direct3D and other Windows graphics APIs on Linux by intercepting and
translating API calls, integrating with **Wine** / **Proton**.

This document is an honest scope statement. Earlier revisions described a
complete shim stack (DLL directory tree, NVAPI/AGS translation tables,
WoW64 filesystem redirection, a frame-pacer tool) that **does not exist in
the repository**. Those sections have been removed or explicitly marked.

---

## What Exists vs What Does Not

| Component | Status | Evidence |
|-----------|--------|----------|
| NTSYNC kernel module | ✅ Implemented, loads at runtime | `kernel/mvgal_ntsync.c`; `mvgal_ntsync.ko` loaded (refcount 2 alongside `ntsync`) |
| DXGI interception (C) | ✅ Implemented | `src/userspace/intercept/d3d/d3d_wrapper.c` (~1 595 lines) + integration test |
| D3D12-style WoW64 types | ✅ Header exists | `include/mvgal/mvgal_wow64.h` (context/fence/semaphore/queue types) |
| DXVK / VKD3D-Proton layering | ✅ Design-compatible | MVGAL Vulkan intercept sits above DXVK output |
| `tools/mvgal-pacer` frame pacer | ❌ Does not exist | no such file in `tools/` |
| `/usr/lib/mvgal/wcl/` DLL tree | ❌ Does not exist | no packaging or CMake reference |
| NVAPI / AGS translation shims | ❌ Not implemented | only type definitions in `d3d_wrapper.c`; no translation tables |
| `mvgal_wow64_redirect()` filesystem redirection | ❌ Not implemented | function does not exist; no inotify daemon |
| APIs `mvgal_power_thermal`, `mvgal_topology_pcie`, `mvgal_device_enumerate`, `mvgal_memory_info` | ❌ Do not exist | not declared in any `include/mvgal/*.h` |
| ~5–15% FPS improvement claim | ❌ Unverified | no benchmark evidence in the repository |

---

## NTSYNC Kernel Module

### Purpose

Windows synchronisation primitives (`CreateSemaphore`, `CreateEvent`,
`WaitForSingleObject`, …) are heavily used by games. Wine's stock `futex`
approach has performance pathologies under high contention. NTSYNC provides
kernel-backed Windows-compatible sync objects.

### Source

`kernel/mvgal_ntsync.c` — independent from the core MVGAL module, built and
loaded alongside it. Verified loaded on the validation bench
(`lsmod`: `ntsync` + `mvgal_ntsync`, refcount 2).

### IOCTLs actually implemented

The module defines these ioctls (verified by grep of the source — use these
names, not the ones in older documentation):

| IOCTL | Purpose |
|-------|---------|
| `NTSYNC_IOC_CREATE_SEMAPHORE` | Create semaphore object |
| `NTSYNC_IOC_CREATE_EVENT` | Create event object |
| `NTSYNC_IOC_CREATE_MUTEX` | Create mutex object |
| `NTSYNC_IOC_CREATE_FENCE` | Create fence object |
| `NTSYNC_IOC_CREATE_TIMER` | Create timer object |
| `NTSYNC_IOC_OPEN_EVENT` | Open existing event |
| `NTSYNC_IOC_SET_TIMER` | Arm timer |
| `NTSYNC_IOC_SIGNAL_EVENT` | Signal event (Windows `SetEvent`) |
| `NTSYNC_IOC_SIGNAL_FENCE` | Signal fence |
| `NTSYNC_IOC_WAIT_EVENT` | Wait on event |
| `NTSYNC_IOC_WAIT_FENCE` | Wait on fence |
| `NTSYNC_IOC_WAIT_MULTI` | Wait on multiple objects |
| `NTSYNC_IOC_WAIT_SEMAPHORE` | Wait on semaphore |
| `NTSYNC_IOC_RELEASE_SEMAPHORE` | Release semaphore |
| `NTSYNC_IOC_RELEASE_MUTEX` | Release mutex |
| `NTSYNC_IOC_ACQUIRE_MUTEX` | Acquire mutex |

Older documentation listed `NTSYNC_IOC_CREATE_SEM`, `WAIT_ANY`, `WAIT_ALL`,
`SET_EVENT`, `RESET_EVENT`, `RELEASE_SEM` — **those names do not exist**.
There is no `RESET_EVENT` ioctl; event reset semantics are not exposed.

### Performance

No benchmark evidence for NTSYNC-vs-fsync performance exists in this
repository. Any FPS-improvement figure should be treated as unverified
until a reproducible benchmark is published.

### Integration with Wine/Proton

Wine/Proton-side NTSYNC wiring (e.g. `--with-ntsync` builds,
`PROTON_NTSYNC=1`) is **not validated here** — no such configuration or
evidence exists in the repository. The kernel side is ready; the userspace
consumer is out of scope for this tree.

---

## DXGI Interception

### What is implemented

`src/userspace/intercept/d3d/d3d_wrapper.c` (~1 595 lines, no separate
header) provides real function-pointer interception of:

| DXGI Function | Behavior |
|---------------|----------|
| `CreateDXGIFactory1` / `CreateDXGIFactory2` | Wrapped factory creation |
| `IDXGIFactory::EnumAdapters1` | Adapter enumeration through the wrapper |
| Workload submission | `submit_d3d_workload` logging path |

Covered by `src/tests/tests/integration/test_d3d_wrapper.c`.

### What is not implemented

- Virtual adapter descriptions (`MVGAL Virtual Adapter N`, fake vendor IDs)
  — not present; the wrapper does not fabricate adapters.
- Swapchain Present routing through a frame pacer — `tools/mvgal-pacer`
  does not exist.
- `ResizeBuffers` framebuffer pool management — not implemented.

---

## DXVK / VKD3D-Proton Integration

MVGAL's design sits *above* DXVK and VKD3D-Proton, not replace them:

```
Windows Game
     │
     ▼
  d3d9/d3d11.dll ──→ DXVK ──→ Vulkan ──→ MVGAL Intercept Layer
  d3d12.dll ───────→ VKD3D-Proton ──→ Vulkan ──→ MVGAL Intercept Layer
```

The MVGAL Vulkan layer enumerates real ICD devices truthfully and the MVGAL
ICD publishes no physical device (see `docs/SPEC_COMPLIANCE.md`). Steam/Proton
launch integration is described in `docs/STEAM_INTEGRATION.md` (file exists)
and `docs/STEAM.md`.

Version requirements for DXVK/VKD3D-Proton/Wine are upstream project
concerns; this tree does not pin or validate them.

---

## Not Implemented

The following appear in older revisions of this document and are **absent
from the codebase**. They are listed so readers do not go looking for them:

1. **`tools/mvgal-pacer`** — no frame-pacer tool exists.
2. **`/usr/lib/mvgal/wcl/` DLL shim directory** — no dxgi.dll/nvapi.dll/
   amd_ags DLL shims, no LD_PRELOAD `.so` variants, no packaging entries.
3. **NVAPI / AGS translation tables** — `NvAPI_Initialize → mvgal_init()`
   style mappings do not exist; only unrelated type definitions appear in
   `d3d_wrapper.c`.
4. **`mvgal_wow64_redirect()` and the redirection map** — the header
   `mvgal_wow64.h` defines D3D12-style object types, not filesystem path
   redirection; no inotify-based redirection daemon exists in `mvgald`.
5. **`mvgal_power_thermal` / `mvgal_topology_pcie` /
   `mvgal_device_enumerate` / `mvgal_memory_info`** — not part of the
   public API (`include/mvgal/mvgal.h`).
6. **Wrong IOCTL names** (`CREATE_SEM`, `WAIT_ANY`, `WAIT_ALL`,
   `SET_EVENT`, `RESET_EVENT`, `RELEASE_SEM`) — see the corrected table
   above.

---

*See `docs/ARCHITECTURE.md` for overall system architecture.
See `kernel/mvgal_ntsync.c` for the NTSYNC implementation.
See `include/mvgal/mvgal_wow64.h` for WoW64 object types.
See `docs/SPEC_COMPLIANCE.md` finding 5 for the original gap report that
prompted this document's scope rewrite.*
