# MVGAL Hardware Validation Report

**Date:** 2026-10-25
**System:** Linux 7.2.11-200.fc44.x86_64 (x86_64)
**MVGAL Version:** 0.7.27
**Build:** `build_output/` (CMake Release, full rebuild)

## Summary

Full-stack validation on a physical three-vendor bench (AMD + NVIDIA + Intel).
All gates pass after fixing three GPU-detection defects found during this run:

- **ctest:** 26/26 pass
- **mvgal-workload:** `GATE: PASS` — 3 distinct vendors executed and validated
- **mvgal-hw-validate:** 19 PASS / 0 FAIL / 5 SKIP (all skips documented below)
- **mvgal-dmabuf-matrix:** 3 GPUs enumerated with honest VRAM labels

## Hardware Detection (Live System)

### Detected GPUs

| Index | Vendor | Device ID | PCI Slot | Driver | VRAM | Type |
|-------|--------|-----------|----------|--------|------|------|
| 0 | AMD | 0x743F (Navi 24) | 0000:03:00.0 | amdgpu | 3.98 GiB | discrete (boot_vga) |
| 1 | NVIDIA | 0x2584 (RTX 3050 6GB) | 0000:04:00.0 | nvidia | 6.00 GiB | discrete |
| 2 | Intel | 0x56A5 (Arc A380, DG2) | 0000:0a:00.0 | i915 | unknown (no sysfs size) | discrete |

Notes:

- This system has **no Intel iGPU** — the only Intel device is the discrete Arc
  A380 behind PCIe bridges (`boot_vga=0`; the AMD card is `boot_vga=1`).
- i915 exposes **no** `mem_info_vram_total` / `mem_info_vis_vram_total` /
  `lmem_total_bytes` sysfs attributes for this device, so VRAM size is
  genuinely unknown from the kernel.
- `renderD131` is a virtual device and is skipped by enumeration.
- Kernel modules `mvgal` and `mvgal_ntsync` loaded; `/dev/mvgal0` present.

### OpenCL ICDs

`amdocl64`, `intel`, `musa`, **`mvgal` → `/usr/lib64/libmvgal_opencl.so`**,
`nvidia`, `rusticl`. The MVGAL ICD forwards to native ICDs, so the workload
tool inspects 6 devices (3 native + 3 forwarded) but executes 3 distinct
vendors — this is by design, not duplication.

## Validation Matrix (post-fix)

| Check | Command | Result |
|-------|---------|--------|
| Full rebuild | `cmake --build build_output --parallel $(nproc)` | ✅ exit 0 (LTO notes only) |
| Unit/integration tests | `ctest --output-on-failure` | ✅ 26/26 pass (4.35 s) |
| Multi-vendor workload gate | `./build_output/tools/mvgal-workload` | ✅ `GATE: PASS`, 6 devices, 3 vendors (NVIDIA 1.93 ms, AMD 0.60 ms, Intel 5.52 ms) |
| Hardware validation | `./build_output/tools/mvgal-hw-validate` | ✅ 19 PASS / 0 FAIL / 5 SKIP, exit 0 |
| DMA-BUF matrix | `./build_output/tools/mvgal-dmabuf-matrix` | ✅ 3 GPUs, all pairs "PCIe P2P (same root complex)" (advisory) |
| GPU info | `./build_output/tools/mvgal-info` | ✅ aggregate 9.98 GiB dedicated + 62.64 GiB shared (honestly labeled) |
| CLI listing | `mvgal list-gpus` | ✅ honest labels (see below) |

### Post-fix device labels

```
[0] Intel GPU [8086:56a5] (VRAM unknown) (Intel) - Enabled, VRAM: unknown
[1] AMD GPU [1002:743f] (4.0 GiB) (AMD) - Enabled, VRAM: 3.98 GB
[2] NVIDIA GPU [10de:2584] (6.0 GiB) (NVIDIA) - Enabled, VRAM: 6.00 GB
```

## Defects Found and Fixed

All three were in `src/userspace/daemon/gpu_manager.c` and violated the M7
honesty contract ("never fabricate a VRAM size").

### B1 — Every Intel GPU was classified INTEGRATED

**Symptom:** the discrete Arc A380 reported `62.64 GiB` — the machine's system
RAM — as if it were an iGPU's shared memory.

**Root cause:** two sites hardcoded
`vendor == INTEL ? MVGAL_GPU_TYPE_INTEGRATED : MVGAL_GPU_TYPE_DISCRETE`
(`finalize_gpu_descriptor` and the DRM scan path). With no iGPU present, the
M7 fallback then substituted `sysinfo` system RAM and set `vram_shared=true`.

**Fix:** classify Intel as integrated only at the conventional iGPU address
`pci_bus == 0 && pci_device == 0x02` (iGPU is always `00:02.0`; a discrete
card behind a root port has a non-zero bus). A parse failure yields all-zero
PCI fields and therefore fails safe to `DISCRETE` — honest "VRAM unknown"
instead of fabricated shared memory. Applied at both sites.

**Verified:** `mvgal list-gpus` now shows `(VRAM unknown)` for the Arc; the M7
system-RAM substitution no longer fires.

### B2 — Name fallback truncated and printed "(0 GiB)"

**Symptom:** AMD shown as `AMD GPU [1002:743f] (3 GiB)` (3.98 truncated to 3);
unknown sizes shown as `(0 GiB)`.

**Root cause:** `%u` cast of a `double` GiB value, and no branch for unknown.

**Fix:** three-branch formatting — `(VRAM unknown)` when `vram_total == 0`,
`(shared system memory)` when `vram_shared`, otherwise `%.1f GiB`.

**Verified:** `(4.0 GiB)` for AMD, `(6.0 GiB)` for NVIDIA, `(VRAM unknown)` for
Intel.

### B3 — NVIDIA fallback path fabricated 8 GiB

**Symptom (latent):** `scan_nvidia_devices_locked` hardcoded
`gpu->vram_total = 8ULL << 30` for any NVIDIA char node without a matching DRM
GPU — wrong for every card that isn't 8 GiB (this RTX 3050 is 6 GiB).

**Root cause:** placeholder value predating the NVML integration.

**Fix:** resolve the PCI address from sysfs (`stat` → `/sys/dev/char/M:m` →
`realpath` → `parse_pci_address`, with a parent-directory retry for layouts
where realpath ends one level below the PCI device), then query
`mvgal_nvml_vram_total_by_pci(bdf)`. On any failure `vram_total` stays `0`
(unknown). Added `<sys/stat.h>` and `<sys/sysmacros.h>` includes.

**Status:** latent path — on this machine the DRM scan wins and NVML fills the
value there; the fabricated constant is gone regardless. Not directly
exercisable on this bench.

### Related: stale build artifacts

Pre-rebuild `mvgal-info` contained **no** NVML symbols and `mvgal-workload`
was missing from `build_output/` despite being present in source — the tree had
not been fully rebuilt since the 0.7.27 NVML fix landed. A full rebuild
resolved both; raw NVML was verified independently
(`nvmlDeviceGetHandleByPciBusId_v2("0000:04:00.0")` → 6442450944 bytes).

## Known Gaps and Observations (not fixed here)

1. **`MVGAL_IOC_GET_DISPATCH_INFO` is not implemented in the kernel module.**
   The ioctl is defined locally in `tools/mvgal-hw-validate.c` but no
   implementation exists anywhere in `kernel/`, `include/`, or `src/`. The tool
   skips gracefully. Documented as a gap; no code changed.
2. **`mvgal-info` applies its own Intel VRAM fallback** to all Intel devices
   (`apply_intel_vram_fallback` in `tools/mvgal-info.c`), so it still displays
   `62.64 GiB` for the discrete Arc — but honestly labeled: *"driver reports no
   memory size; system RAM shown, not dedicated VRAM"*. Out of scope for this
   fix round; the daemon-side descriptor (B1) is now correct.
3. **Remaining hw-validate SKIPs (all optional/graceful):** MTT vendor driver
   (no such GPU present), SPIR-V tools (`spirv-opt`/`llvm-spirv` not
   installed), WoW64 library (not installed, x86-64 host).
4. **ocl-icd warnings** (`pci id for fd … driver (null)`) are cosmetic —
   forwarded devices have no direct PCI binding in the forwarding shim.
5. **"Resizable BAR not detected for 0000:0a:00.0"** — advisory observation
   from the workload tool; the Arc sits behind PCIe bridges.
6. **P2P connectivity matrix in `mvgal-info` is all dots** while
   `mvgal-dmabuf-matrix` reports same-root-complex P2P — the matrix is only
   populated after actual transfers (counters are all 0 on an idle system).

## Reproducible Commands

```bash
cmake --build build_output --parallel $(nproc)
(cd build_output && ctest --output-on-failure)
./build_output/tools/mvgal-workload
./build_output/tools/mvgal-hw-validate
./build_output/tools/mvgal-dmabuf-matrix
./build_output/tools/mvgal-info
./build_output/tools/mvgal list-gpus
```

## Test Inventory

- **ctest (26):** test_gpu_detection, test_memory, test_scheduler,
  test_core_api, test_execution, test_config, test_wow64, test_spirv,
  test_barrier_translate, test_cmd_dag, test_shader_backend, test_unified_heap,
  test_multi_gpu, test_opencl_intercept, test_d3d_wrapper, test_metal_wrapper,
  test_mvgal_transport, test_mvgal_ai_features, test_dmabuf_integration,
  test_uapi_probe, test_p2p_matrix, test_webgpu_wrapper_synthetic,
  test_hardware_validation, test_mock_gpu, test_p2p_cross_vendor, and the
  barrier/heap companions — all pass.
- **mvgal-hw-validate (24 checks):** 19 pass (PCI discovery, sysfs
  capabilities, DMA-BUF, ntsync events/wait, vendor driver presence for
  AMD/NVIDIA/Intel), 0 fail, 5 skip (documented above).

---

## Phase D Addendum — CUDA Shim Multi-Device Correctness (2026-10-25)

The Phase A run above recorded **26/26 ctest (4.35 s)**. Phase D fixed the
CUDA interception shim's multi-device correctness defects and added a new
LD_PRELOAD integration test, bringing the suite to **27/27 ctest (4.73 s)**.
The Phase A numbers above are historical and remain as recorded.

### Defects fixed (`src/userspace/intercept/cuda/cuda_wrapper.c`)

1. **Device-count override fabricated 3 CUDA devices.** `cuDeviceGetCount` /
   `cudaGetDeviceCount` returned the MVGAL GPU count (3) instead of the native
   CUDA count (1 on this bench). Removed — counts now pass through natively.
2. **Modulo attribution mapped CUDA ordinal 0 to MVGAL GPU 0 (Intel Arc).**
   Replaced with a one-time BDF-based probe (`cuda_probe_device_map`) that
   matches each CUDA ordinal's PCI BDF against the MVGAL GPU list. On this
   bench CUDA 0 (RTX 3050, `0000:04:00.0`) → MVGAL GPU 2 (NVIDIA).
3. **`-1` sentinel caused an out-of-bounds write.** The old guard
   `mvgal_gpu < gpu_count` is TRUE for `-1`, so an unresolvable mapping wrote
   `g_gpus[-1]`. All callers (`cuCtxCreate`, `cuMemAlloc`, `cuLaunchKernel`,
   runtime `cudaLaunchKernel`) now check `>= 0` before indexing.
4. **`cuLaunchKernel` / `cudaLaunchKernel` were not restricted to eligible
   GPUs.** Both now reject launches on non-eligible devices.
5. **Debug logging was unreachable.** `MVGAL_CUDA_DEBUG=1` now calls
   `mvgal_log_set_level(DEBUG)` so the `cuCtxCreate: CUDA device=%d -> MVGAL
   GPU=%d` attribution line is visible (the logger defaults to WARN).

### New test: `test_cuda_multidevice`

`src/tests/tests/integration/test_cuda_multidevice.c`, registered in
`src/tests/tests/integration/CMakeLists.txt`, run under
`LD_PRELOAD=libmvgal_cuda.so` with `MVGAL_CUDA_ENABLED=1
MVGAL_CUDA_DEBUG=1`. It resolves CUDA symbols via `dlsym(RTLD_DEFAULT, ...)`
*before* `dlopen(libcuda.so.1)`, so a missing preload yields a clean SKIP
(exit 0) instead of silently testing the native driver. Three assertions:

- **A — ordinal resolution:** every native CUDA ordinal resolves to a valid
  MVGAL GPU index (`>= 0`).
- **B — BDF set equality:** the set of CUDA ordinal BDFs equals the set of
  NVIDIA MVGAL GPU BDFs.
- **C — attribution:** the `cuCtxCreate` INFO log line is captured (via
  `tmpfile()` + `dup2` on fd 2) and its BDF is checked against the expected
  NVIDIA device.

### Results on this bench (genuinely executed, not SKIP)

```
CUDA native devices: 1; MVGAL GPUs: 3 (1 NVIDIA)
ordinal 0: NVIDIA GeForce RTX 3050 at 0000:04:00
A: all 1 CUDA ordinal(s) resolve — PASS
B: CUDA ordinal BDFs match NVIDIA MVGAL GPUs — PASS
C: CUDA device 0 -> MVGAL GPU 2 (BDF match) — PASS
```

Full suite: **ctest 27/27 pass (4.73 s)** — test #27 is
`test_cuda_multidevice` (0.32 s).

### What the old shim would have produced

- Assertion A would have **failed**: `cuDeviceGetCount` returned 3 (fabricated)
  and modulo mapping could yield `-1`/OOB.
- Assertion B would have **failed**: CUDA reported 3 ordinals vs. 1 NVIDIA
  MVGAL GPU — set mismatch.
- Assertion C would have **failed**: CUDA 0 → MVGAL GPU 0 = Intel Arc A380
  (`0000:0a:00.0`), not the RTX 3050 (`0000:04:00.0`).

### Reproduce

```bash
cmake --build build_output --parallel $(nproc)
(cd build_output && ctest --output-on-failure)
# or the new test alone:
LD_PRELOAD=$PWD/build_output/src/tests/libmvgal_cuda.so \
MVGAL_CUDA_ENABLED=1 MVGAL_CUDA_DEBUG=1 \
./build_output/src/tests/test_cuda_multidevice
```
