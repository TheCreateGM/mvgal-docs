# D1 - Narrow end-to-end userspace workload path

**Status:** design (approved for implementation as D2)
**Date:** 2026-10-18
**Closes:** gap G1 in `docs/SPEC_COMPLIANCE.md`
**Related:** `docs/SPEC_COMPLIANCE.md`, `docs/SPECIFICATION.md`, `docs/ARCHITECTURE.md`, `docs/plans/task.md`

## 1. Problem

`docs/SPEC_COMPLIANCE.md` names the next gate:

> The next gate is no longer removal of PCI binding and fake submission/allocation, both of which are done; it is one narrow end-to-end userspace workload path validated on physical hardware.

Today the repository plans work but never executes it. `src/tests/test_cross_vendor_compute.c` calls `mvgal_execution_submit()` and inspects the returned plan; it never dispatches a kernel to a GPU or checks a result. `src/userspace/execution/execution.c` is a planning engine (`choose_strategy`, `detect_cross_vendor`, `submit_scheduler_workload`) with no native API dispatch. The P2P probe prints `unknown`. Nothing in the tree proves that a real compute result was produced on a real device.

This document specifies the narrowest path that produces and validates a real result on physical hardware, without claiming universal aggregation, cross-vendor memory coherence, or P2P.

## 2. Scope

In scope:

- One portable compute interface: OpenCL.
- One kernel, one input, one output, executed on each of at least two different-vendor GPUs.
- A host-staged data path (no P2P, no DMA-BUF requirement).
- Result validation against a CPU reference.
- Capability gating through the existing `mvgal_gpu_can()` contract.

Out of scope (explicitly not claimed):

- Cross-vendor memory coherence or shared virtual addresses.
- Peer-to-peer transfers or DMA-BUF export.
- Kernel-level command submission (`kernel-submit` stays clear).
- Universal binary translation or a Wine/Proton fork.
- Performance claims.

## 3. Interface choice: OpenCL

OpenCL is chosen because it is the only interface present on all three vendors in the test system with a standard, vendor-neutral loader:

- The Khronos ICD loader (`libOpenCL.so.1`, ocl-icd) enumerates every installed vendor runtime through `/etc/OpenCL/vendors/*.icd`.
- `cl_khr_icd` is present on 91.1% of platforms in the OpenCL hardware database, so the loader path is the common case.
- The same kernel source compiles on AMD, NVIDIA, and Intel runtimes.
- Host-staged buffers need no P2P and no DMA-BUF.

The existing `src/userspace/intercept/opencl/` scaffolding (`cl_platform.c` already dlopens `libOpenCL.so.1` and chains `clGetPlatformIDs`) is the natural host for the path.

## 4. Research findings (external libraries)

| Library / extension | Finding | Consequence for D1 |
| --- | --- | --- |
| Khronos ICD loader / ocl-icd (`libOpenCL.so.1`) | Standard loader; discovers vendor ICDs via `/etc/OpenCL/vendors/*.icd`; `cl_khr_icd` on 91.1% of platforms | Use as the single entry point; dlopen it, never link a vendor runtime directly |
| `cl_khr_external_memory` | 15.4% device coverage | Not a baseline |
| `cl_khr_external_memory_dma_buf` | 2.3% device coverage (97.7% of devices lack it) | Rejected as a baseline; DMA-BUF import is a later, per-pair optimisation only |
| `cl_khr_fp64` | 56.9% device coverage | Keep the reference kernel in 32-bit float so it builds everywhere |
| Host-staged copy (`clEnqueueReadBuffer` + `clEnqueueWriteBuffer`) | Universal | The baseline data path |

Sources: Khronos OpenCL registry (`registry.khronos.org/OpenCL`), OpenCL hardware database (`opencl.gpuinfo.org`), ocl-icd.

## 5. Design

### 5.1 Components

- **Device selection** (`mvgal_cl_enumerate_devices`, existing): enumerate platforms, map each device to an MVGAL GPU by PCI BDF, and expose the vendor string.
- **Capability gate** (existing contract): before dispatch, require `mvgal_gpu_can(gpu, MVGAL_CAP_...)` for the capability the path needs. The path needs only "a native OpenCL runtime is present and the device is usable"; it does not need `kernel-submit`, `kernel-vram`, `dmabuf-export`, or `wait-idle`, all of which stay clear.
- **Executor** (new, thin): the minimal OpenCL host sequence on a chosen device.
- **Validator** (new, thin): compare device output to a CPU reference.

### 5.2 Host sequence per device

1. `clGetPlatformIDs` / `clGetPlatformInfo` to pick the platform whose `CL_PLATFORM_VENDOR` matches the target GPU.
2. `clGetDeviceIDs` (GPU), `clCreateContext`, `clCreateCommandQueue`.
3. `clCreateProgramWithSource` + `clBuildProgram`; on failure, report the build log and stop.
4. `clCreateKernel`, `clCreateBuffer` (input, output), `clEnqueueWriteBuffer` (input).
5. `clSetKernelArg`, `clEnqueueNDRangeKernel`, `clFinish`.
6. `clEnqueueReadBuffer` (output), compare to the CPU reference.

### 5.3 Data flow (host-staged, no P2P)

```
host input buffer
      |  clEnqueueWriteBuffer
      v
  device A buffer  --kernel-->  device A output
      |  clEnqueueReadBuffer
      v
host intermediate buffer
      |  clEnqueueWriteBuffer
      v
  device B buffer  --kernel-->  device B output
      |  clEnqueueReadBuffer
      v
host output buffer  -->  validate vs CPU reference
```

The host is the only shared medium. This is the documented safe baseline when P2P and DMA-BUF are unavailable, and it is what the spec's "host-staged fallback" constraint requires.

### 5.4 Reference kernel

A single 32-bit-float kernel (for example an element-wise `out[i] = a[i] * b[i] + c`) so it builds on every vendor without `cl_khr_fp64`. The CPU reference computes the same expression in `double` and compares within a tolerance.

## 6. Capability gating

The path consults `mvgal_gpu_can()` rather than testing function pointers, consistent with the "Runtime capability probing" contract. A device whose probe never ran reports no capabilities and is skipped. The four deliberately-clear bits (`kernel-submit`, `kernel-vram`, `dmabuf-export`, `wait-idle`) are not required by this path, so their absence does not block it.

## 7. Validation and acceptance

The path is accepted when, on the physical test system:

1. At least two different-vendor GPUs each execute the kernel and return a result.
2. Each result matches the CPU reference within tolerance.
3. The run is reproducible and the per-device vendor is reported.
4. No P2P or DMA-BUF capability is required or claimed.

This is the narrow gate. It does not assert aggregation of a single workload across devices; it asserts that MVGAL can drive real compute on real, different-vendor hardware and verify it.

## 8. Risks

| Risk | Mitigation |
| --- | --- |
| A vendor runtime is absent | Detect via platform enumeration; skip that device; require at least two vendors present for the acceptance run |
| Kernel build differences across vendors | Keep the kernel to core OpenCL C; report build logs on failure |
| Float tolerance | Compare in double on the host with an explicit tolerance |
| Scope creep toward P2P | P2P and DMA-BUF are explicitly out of scope for D1 |

## 9. References

- `docs/SPEC_COMPLIANCE.md` - findings, capability-probing contract, the gate.
- `docs/SPECIFICATION.md` - spec-to-code traceability.
- `docs/plans/task.md` - the task specification.
- Khronos OpenCL registry: https://registry.khronos.org/OpenCL/
- OpenCL hardware database: https://opencl.gpuinfo.org/
- ocl-icd: https://github.com/OCL-dev/ocl-icd
