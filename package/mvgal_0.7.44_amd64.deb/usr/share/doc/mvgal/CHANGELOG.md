# Changelog

## [0.7.44] - 2026-11-09

### Added

- **CUDA execution backend.** `runtime/daemon/cuda_backend.cpp/.hpp`
  submits the reference compute kernel as PTX through the CUDA driver
  API, loaded at runtime so the daemon still runs on systems without
  NVIDIA userspace libraries.

- **Vulkan execution backend.** `runtime/daemon/vulkan_backend.cpp/.hpp`
  registers a Vulkan compute path; command submission is an honest stub
  pending per-ICD integration rather than a synthetic success.

- **SYCL execution backend.** `runtime/daemon/sycl_backend.cpp/.hpp`
  provides the SYCL backend slot for oneAPI/DPC++ environments.

- **Partition planning.** `runtime/daemon/partition_plan.hpp` splits
  workloads across heterogeneous GPUs and `scheduler.cpp/.hpp` dispatches
  through the new backends.

- **Unit test.** `src/tests/tests/unit/test_partition_plan.cpp` covers
  the partition planner.

- **Documentation.** Vendor research, vendor capability matrix, power
  management design, and research/gap audit documents under `docs/`.

## [0.7.43] - 2026-11-08

### Added

- **Execution backend abstraction in the daemon.** New
  `runtime/daemon/execution_backend.hpp` interface with an OpenCL backend
  (`opencl_backend.cpp`) and a mock backend (`mock_backend.cpp`) so
  workloads can be offloaded through a common backend contract and the
  scheduling path can be exercised without physical GPUs.

- **`mvgal-doctor` diagnostic tool.** Reports distribution, kernel, CPU,
  RAM, PCIe devices, GPUs, drivers, Vulkan/OpenCL/CUDA/ROCm/HIP/MUSA/SYCL/
  Level Zero availability, IOMMU, resizable BAR, topology, permissions,
  MVGAL version, and backend status with actionable recommendations.

- **`mvgal-exec` workload execution CLI.** Submits workloads through the
  daemon's execution backend path for testing and benchmarking.

- **Scheduler rework.** Capability-aware scheduling updates in
  `runtime/daemon/scheduler.cpp/.hpp` plus IPC and D-Bus wiring in
  `ipc_server.cpp` and `dbus_service.cpp`.

- **Documentation.** Development audit, implementation gap analysis,
  complete architecture, scheduling strategy matrix, and vendor driver
  integration guide under `docs/`.

## [0.7.42] - 2026-11-07

### Fixed

- **DVFS and thermal work handlers could re-arm themselves after teardown
  started.** Both handlers re-queued their delayed work unconditionally at
  the end of every run.  A handler already in flight when `mvgal_dvfs_stop()`
  / `mvgal_thermal_stop()` cleared `enabled` and called
  `cancel_delayed_work_sync()` could queue the work again behind the cancel,
  leaving a pending item on a structure teardown then freed -- the same
  self-requeue race class that wedged `module_exit()` in
  `MODULE_STATE_GOING` ("Unloading", refcount -1) for the idle-gate sweep.
  The re-arm decision is now made under a lock paired with the stop path:
  `mvgal_thermal` gained a `spinlock_t`, and `mvgal_gpu_dvfs` reuses its
  existing one.

- **Unload wedge detection only inspected the core `mvgal` module.** A
  wedged vendor shim or `mvgal_ntsync` produced the same unrecoverable
  state but was not detected.  `mvgal-pkexec-helper.sh` and
  `config/unload-module.sh` now scan every module in the shared inventory
  (`/proc/modules`: state `Unloading` or negative refcount) before and
  after the unload loop, and name each wedged module.

- **`mvgal unload-module` could wait forever on the polkit prompt.** The
  call is now bounded by `timeout -k 5 120`, matching `load-module`.  This
  is safe precisely because the helper uses non-blocking `rmmod`: a timeout
  can abandon a partially-completed unload but can never leave a module in
  the GOING state.

- **`config/unload-module.sh` tried `rmmod -f` as a fallback.** Force
  removal of a module that still has references is a kernel use-after-free
  vector.  The fallback is gone; failures now name the holding modules
  instead.

### Added

- **Daemon-down diagnostics in `mvgal status`.** When the daemon is not
  running, `mvgal status` now prints the IPC socket path, stale PID files,
  the systemd unit state/result/exit status, and the exact
  `systemctl`/`journalctl` commands to inspect it.
- **`mvgal-status` reports the daemon socket path and journal hint when
  the daemon is down**, honours `MVGAL_RUN_DIR` like the other tools, and
  reports a wedged kernel module explicitly instead of only "not loaded".
- **`cli_smoke` ctest suite.** `src/tests/tests/test_all.sh` is now
  registered with CTest and gained a check that all three module-list
  consumers share `config/mvgal-modules.sh`.

### Documentation

- TROUBLESHOOTING.md documents which `mvgal-hw-validate` SKIP results are
  expected (spirv-opt/llvm-spirv, libmvgal-wow64.so, Moore Threads
  hardware, per-pair DMA-BUF validation).

## [0.7.41] - 2026-11-07

### Fixed

- **DKMS rebuilt `mvgal_ntsync` into `extra/` while the RPM claimed the DRM
  path.** `DEST_MODULE_LOCATION` was `/updates/dkms` and only
  `INSTALL_MOD_DIR[0]` pointed at `kernel/drivers/gpu/drm/mvgal`. After a
  DKMS rebuild, `rpm -V mvgal-dkms` reported
  `.../mvgal_ntsync.ko.xz` missing even though the module was loaded from
  `extra/`. Every built module now uses the same DRM destination so DKMS
  replaces the packaged modules in place.

### Added

- Task-required documentation: `docs/ANALYSIS.md`, `docs/TOOLCHAIN.md`,
  `docs/USAGE.md`, `docs/CONFIGURATION.md`, `docs/SUPPORTED_HARDWARE.md`,
  `docs/ROADMAP.md`, `docs/THIRD_PARTY.md`. Live three-vendor validation
  results from this host are recorded in ANALYSIS.

## [0.7.40] - 2026-11-05

### Fixed

- **The 0.7.33 documentation packaging fix never took effect.** The install
  rule excluded internal docs by pattern, and the patterns did not cover what
  `docs/` actually contains: the package still shipped 76 pages, including
  `API_REFERENCE.md`, `ARCHITECTURE_RESEARCH.md`,
  `BOTTLENECKS_AND_OPTIMIZATION.md`, `BUILD_ARTIFACTS.md`,
  `CAPABILITY_MATRIX.md`, `CHANGES_2025.md` and the `research/`, `plans/` and
  `design/` trees. `CMakeLists.txt` now installs an explicit allowlist —
  `README.md`, `LICENSE`, `CHANGELOG.md` and 16 user-facing pages — so a new
  internal document cannot reach an end-user package by being added to
  `docs/`. `-DMVGAL_INSTALL_INTERNAL_DOCS=ON` still installs everything for a
  development build.

- **`LICENSE` and the top-level `README.md`/`CHANGELOG.md` were not installed
  at all.** A GPL-3.0-only binary package shipped without its license text.

## [0.7.39] - 2026-11-04

### Fixed

- **The Vulkan ICD was compiled on systems whose headers predate Vulkan
  1.3.** `src/userspace/vulkan_icd/CMakeLists.txt` only ran its compile
  check when a Vulkan include directory had been discovered; otherwise it
  treated "Vulkan was found" as "headers are 1.3 or newer". pkg-config
  reports success for a 1.2 SDK, so on openEuler 22.03 the ICD was built
  against 1.2 headers and failed with `unknown type name
  'VkPhysicalDeviceToolProperties'` and a series of `expected expression
  before ')' token` errors around
  `VkPhysicalDeviceShaderDrawParametersFeatures`. The check now always
  runs — letting the compiler search its default include path when no
  directory is reported — and the target is skipped with a warning when 1.3
  headers are absent, so the rest of MVGAL still builds there.

## [0.7.38] - 2026-11-04

### Fixed

- **The command DAG did not build against Vulkan 1.2 headers.** openEuler
  22.03 has no `VkDependencyInfo` and no `PFN_vkCmdPipelineBarrier2`.
  `include/mvgal/mvgal_cmd_dag.h` now defines `MVGAL_HAVE_SYNC2` from
  `VK_VERSION_1_3` / `VK_KHR_synchronization2`, makes
  `mvgal_dependency_info_t` an opaque handle when the extension is absent,
  and gates the emit slot, the widen/lower helpers and the
  `vkCmdPipelineBarrier2` initializer. A recorded `MVGAL_CMD_BARRIER` node
  with a non-NULL sync2 payload now reports `VK_ERROR_FEATURE_NOT_PRESENT`
  with an explanatory log instead of being silently dropped.

## [0.7.37] - 2026-11-04

### Fixed

- **`VK_API_VERSION_1_3` was undeclared on Vulkan 1.2 systems.**
  `src/userspace/intercept/vulkan/vk_layer.c` now falls back to a local
  `VK_MAKE_API_VERSION(0, 1, 3, 0)` / `VK_MAKE_VERSION(1, 3, 0)` when the
  headers predate 1.3 (openEuler 22.03).
- **openEuler 24.03 configures out of tree.** The spec builds whichever
  directory actually received the CMake cache instead of assuming
  `%{_vpath_builddir}`.

## [0.7.36] - 2026-11-04

### Fixed

- **Chroots without `cmake-rpm-macros` ran the literal `%cmake_build`
  token.** openEuler 20.03/22.03/24.03 have no `cmake_build` macro, so bash
  executed `fg` and aborted the build after configure. The spec defines
  `%{!?cmake_build:...}` / `%{!?cmake_install:...}` fallbacks and dispatches
  on the presence of `CMakeCache.txt`.

## [0.7.35] - 2026-11-04

### Fixed

- **openSUSE Leap 16 and Mageia Cauldron had no `drm/drm.h`.**
  `runtime/daemon/kernel_ioctl_types.hpp` falls back to local `_IOC`-based
  DRM ioctl definitions when the libdrm headers are missing, instead of
  failing the daemon build.
- **`mvgal-config set-strategy` left a running daemon on the old
  strategy.** It now reloads the daemon after saving, matching `mvgal
  set-strategy`.

## [0.7.34] - 2026-11-04

### Fixed

- **`mvgal unload-module` wedged the kernel module permanently.** The
  idle-gate sweep re-queued itself unconditionally, including on its
  `!gpu || !gpu->idle_gate` early return, so `cancel_delayed_work_sync()`
  never returned and `mvgal_exit()` blocked forever. The module stayed in
  `MODULE_STATE_GOING` (`/proc/modules`: `mvgal ... -1 - Unloading`),
  `/dev/mvgal0` existed but every `open()` failed with `ENXIO`, and
  `modprobe mvgal` refused with "Device or resource busy" until reboot. The
  sweep now checks a `stopping` flag set before the cancel and the enabled
  flag before re-arming, so cancellation always completes.
- **The spec did not parse.** A comment containing `%install` was treated as
  a real section marker ("second %install"); section macros are kept out of
  comments.
- **The spec required `dkms` at build time.** The tool is only used by the
  `%post` scriptlets, so the build-time requirement made chroots without
  dkms (CentOS Stream 8, AlmaLinux Kitten 10, EL9 aarch64) fail dependency
  resolution.

## [0.7.33] - 2026-11-04

Fixes from the 0.7.32 test report, plus shader-format routing.

### Fixed

- **Module state is reported honestly (C1/C2/H1/M6).** A new
  `tools/mvgal_device_state.h` opens `/dev/mvgal0` for real, so `status`,
  `info`, `probe`, `hw-validate` and the dashboard distinguish *not loaded*
  / *wedged* / *loaded but unusable* / *OK* instead of trusting `stat()` on
  the node.
- **`unload-module` detects the Unloading wedge (C1/H4).** It uses
  non-blocking `rmmod`, lists only modules that are actually loaded, in
  reverse dependency order, and no longer leaks shell job-control noise from
  the pkexec helper.
- **`--force` is documented and unified (H3).** `mvgal --help`, the man page
  and `mvgal set-strategy --help` describe it, and `mvgal set-strategy
  --force` emits the same single-GPU fallback warning as `mvgal-config -f`.
- **`set-strategy` applies immediately (H2/M4).** A successful save reloads
  a running daemon; `custom` validates that the script exists and warns when
  the shipped stub is an intentional no-op.
- **One daemon-liveness probe (M1).** Every tool uses the same socket probe
  and none of them suggests the `mvgald` alias unit name.
- **Exit codes agree (M2/M3).** `mvgal-status` and `mvgal show-stats` exit 2
  when the daemon is down and say so instead of printing a zeroed table.
- **`restart` on a stopped daemon says it started it (M5).**
- **Vulkan ICD reporting has one phrasing (M7).** "available, not
  registered (opt-in: …)".
- **Benchmark help no longer claims a daemon is required (L1).**
- **JSON output has no trailing blank line (L6)**, and the ASCII dash is
  used consistently in `show-stats` (L4).

### Added

- **Shell completions** for bash, zsh and fish (L2).
- **`Also see:` section** listing companion tools in `mvgal --help` (L5).
- **`intercept/mvgal_shader_format.{c,h}`** detects and routes SPIR-V, PTX,
  cubin, fatbin, hsaco, LLVM IR/bitcode, assembly and Intel GEN payloads.

### Changed

- **Packaging ships only user-facing documentation**; internal engineering
  notes stay out of the RPM (L3).

## [0.7.32] - 2026-11-02

Fixes from the 0.7.31 test report.

### Fixed

- **`mvgal unload-module` always failed.** The core `mvgal` module has hard
  dependents (the vendor shims mvgal_intel/amd/nvidia/mtt/adreno and
  mvgal_ntsync), but the CLI ran `pkexec modprobe -r mvgal` directly, which
  cannot remove a module with dependents. It now routes through the pkexec
  helper, which unloads in reverse dependency order and reports which module
  is still holding a reference if it cannot.
- **`mvgal-bench --json` produced invalid JSON** in the compute and
  memory-bandwidth suites: a missing comma after the `measurement_note`
  field. The field is no longer marked as last.
- **Misleading `--force` advice on `mvgal set-strategy`.** The error
  message suggested `--force`, but `mvgal` did not implement it (only
  `mvgal-config` did). `--force` is now a real flag on `mvgal
  set-strategy`.
- **Shipped config used `round_robin` as the default strategy** on
  single-GPU installs, which the CLI refuses without force. The daemon
  fallback is now `single`, the merge normalizes a stale `round_robin` to
  `single` on upgrade, and `listen_addr` is normalized from a stale
  `0.0.0.0` to `127.0.0.1`.
- **`mvgal -c <unreadable> show-config` exited 0.** It now exits 1.
- **`mvgal-probe` reported zeros** for PCIe generation, link width, BAR
  sizes and subsystem ID in the live query path. The kernel query now
  populates those fields and falls back to the capability values when the
  live read returns 0.
- **`mvgal-gui` hung forever with no display.** It now calls
  `gtk_init_check()` and fails fast with a clear message.
- **`mvgal-config set-power-curve` is gated behind `--experimental`**
  until the daemon consumes the profile.
- **MTT S30 blacklisted detection** now prints which modprobe file to
  inspect and the consequence of unblacklisting.
- Documented exit codes for all `mvgal` subcommands.

## [0.7.28] - 2026-10-25

Phase C (documentation gap closure) and Phase D (CUDA shim multi-device
correctness) of the 2026-10-25 full campaign, validated on the physical
three-vendor bench (AMD Navi 24 + NVIDIA RTX 3050 + Intel Arc A380).

### Fixed

- **CUDA device counts pass through natively.** `cuDeviceGetCount` /
  `cudaGetDeviceCount` no longer return the MVGAL GPU count; the fabricated
  override is gone.
- **CUDA ordinal → MVGAL GPU attribution is BDF-based.** A one-time PCI
  BDF probe replaces the modulo mapping that sent CUDA device 0 (RTX 3050)
  to MVGAL GPU 0 (Intel Arc).
- **No more out-of-bounds GPU indexing.** The `-1` sentinel is rejected by
  `>= 0` checks in `cuCtxCreate`, `cuMemAlloc`, `cuLaunchKernel`, and the
  runtime launch path; the old `mvgal_gpu < gpu_count` guard was true for
  `-1`.
- **Kernel launches are restricted to eligible GPUs.**
- **`MVGAL_CUDA_DEBUG=1` actually raises the log level**, so the
  `cuCtxCreate: CUDA device=N -> MVGAL GPU=M` attribution line is visible.

### Added

- **`test_cuda_multidevice`** — LD_PRELOAD integration harness asserting
  ordinal resolution, BDF set equality, and `cuCtxCreate` attribution.
  ctest is now 27/27 (4.73 s) on the bench.
- **Documentation:** Phase D addendum in `HARDWARE_VALIDATION_2026-10-25.md`;
  `POWER_MANAGEMENT.md`, `WINDOWS_COMPAT.md`, `STATUS.md`, and
  `SPEC_COMPLIANCE.md` gap closures (findings 4/5 resolved, 6 partially
  addressed).

## [0.7.27] - 2026-10-24

Fixes three hardware-detection and reporting defects that made valid hardware
look missing or report no stats.

### Fixed

- **AMD ICD detection now matches Fedora's `radeon_icd` manifest.** The
  Vulkan ICD filename check only matched `amd`/`radv`/`intel`/`mtt`
  substrings, but Fedora ships mesa's manifest as `radeon_icd.x86_64.json`,
  which contains none of them, so AMD GPUs were reported as having no Vulkan
  driver. The matcher now also accepts `radeon`/`radv` for AMD.
- **AMD shader-backend library list no longer probes lavapipe.** The list
  pointed at mesa's software rasterizer (`libvulkan_lvp.so`), not an AMD
  driver. It now probes the real RADV paths (`libvulkan_radeon.so` in the
  Fedora/RHEL/Arch and Debian layouts).
- **WoW64 layer detection accepts the `/usr/lib64` install path.** Multilib
  Fedora installs `libmvgal-wow64.so` under `/usr/lib64`, not `/usr/lib`, so
  the WoW64 check reported "not built" on a correctly installed package.
  Both paths are now checked.
- **`mvgal-info` reports NVIDIA temperature and utilization.** The
  proprietary NVIDIA driver exposes no hwmon `temp1_input` and no
  `gpu_busy_percent`, so those fields were left at their `-1` "unavailable"
  sentinel. `mvgal-info` now queries NVML (already linked in) for
  temperature and utilization by PCI bus id, filling only the fields sysfs
  left empty and leaving the sentinel when NVML is unavailable — never
  fabricating a value.

## [0.7.26] - 2026-10-24

### Fixed

- **Packaging:** Always include `mvgal-workload` in RPM files list (built when OpenCL is available).

## [0.7.25] - 2026-10-22

Fixes a packaging defect that made the modules unloadable, and a set of
reporting defects that made the system look healthy while it was not.

### Fixed

- **Signed modules could not be decompressed by the kernel.** Every module
  signed by the MVGAL key was compressed with `xz -9e`, which selects a
  CRC64-checked xz stream. The kernel's xz decoder rejects any check type
  above CRC32 (`lib/xz/xz_dec_stream.c`: `if (s->check_type >
  XZ_CHECK_CRC32) return XZ_OPTIONS_ERROR;`), and the kernel's decoder only
  carries an internal CRC32 implementation. The result was
  `insmod: ERROR: could not insert module ...: Invalid parameters` and
  `decompression failed with status 6` in dmesg -- at DECOMPRESSION time,
  before the Secure Boot signature was examined at all. **Enrolling the MOK
  could not fix it**, so the documented recovery path was broken end to end.
  CRC64 is xz's DEFAULT check at every compression level, so plain `xz -9`
  was just as broken as `xz -9e`. The signer now uses the kernel's own
  settings, copied from `scripts/Makefile.modinst`:
  `xz --check=crc32 --lzma2=dict=1MiB -f`. The output is byte-identical to
  what DKMS produces for the same module, and the signer verifies the
  container before installing it.
- **A module the signer had already signed with the MVGAL key was never
  repaired.** The "already signed" check looks at the DECOMPRESSED image, so
  a module signed by 0.7.21/0.7.22 was reported as correct and left in
  place -- with the CRC64 container intact. The upgrade therefore silently
  fixed nothing. The container is now checked first and overrides the
  shortcut.
- **Enrolling the MOK now also makes the modules loadable.**
  `mvgal-enroll-mok` re-signs the installed modules before queueing the
  certificate, and says so, instead of promising a fix that cannot work on
  its own.
- **`systemctl reload mvgald` failed permanently** with
  `status=233/RUNTIME_DIRECTORY`. The daemon chowned systemd's
  `RuntimeDirectory=/run/mvgal` to `root:mvgal`, and systemd requires such
  a directory to be owned by `root:root`, so every reload after the first
  start failed before the daemon was even signalled -- while `restart` kept
  working, and the daemon looked healthy. The daemon no longer touches the
  directory's ownership; the socket is still `0660 root:mvgal`, which is
  what provides access control.
- **A reload did nothing at all.** SIGHUP was installed but the handler had
  no case for it, so `systemctl reload mvgald` and `mvgal-config reload`
  signalled the daemon and nothing happened while both reported success.
  The daemon now re-reads the configuration and re-applies the strategy on
  SIGHUP, and `mvgal-config reload` reports the real outcome.
- **"Vulkan aggregated ICD: ACTIVE" was a false positive.** The probe
  treated the presence of the manifest in the opt-in staging directory as
  the ICD being registered, so the tool reported the aggregated ICD as
  active while the loader saw no manifest and `vulkaninfo` showed no MVGAL
  device. The ICD now reports REGISTERED (in a real search directory),
  AVAILABLE (staged only) or ABSENT, and never says ACTIVE for the
  staging copy. `mvgal-info` and `mvgal-compat` share one helper so they
  cannot drift apart again.
- **The OpenCL ICD registration was decided once, from a stale snapshot.**
  The `%post` parked the manifest if no other vendor ICD existed at that
  moment, so on a host where the vendor runtime was installed after MVGAL
  it stayed parked indefinitely: every OpenCL application ran against the
  vendor's own driver with MVGAL nowhere in the path, while the tools
  reported OpenCL results that had nothing to do with MVGAL. The decision
  now lives in `/usr/lib/mvgal/mvgal-opencl-icd.sh`, which can be re-run
  at any time, and the manifest is registered by default.
- **Module load failures were always blamed on Secure Boot.** The loader
  used `insmod` on a path that `modinfo` can legitimately return
  compressed (`.ko.xz`), which `insmod` cannot load -- and then printed the
  MOK remedy for a failure that enrollment could not fix. The loader now
  uses `modprobe` first, decompresses when it must use `insmod`, and
  classifies the failure: a signature rejection prints the enrollment
  steps, a decompression failure prints the re-signing steps, and a missing
  module says the module was not built.
- **The D-Bus API refused every non-root call.** The methods were
  registered without `SD_BUS_VTABLE_UNPRIVILEGED`, so sd-bus applied its
  own default policy and rejected them with `AccessDenied` regardless of
  the bus policy -- which explicitly allows the `mvgal` group. The two
  halves contradicted each other and the GUI and dashboard were dead for
  members of that group. The bus policy is now the deciding authority, and
  a `com.mvgal.daemon.control` polkit action documents the model.
- **`mvgal-config list-gpus` reported shared system RAM as dedicated
  VRAM.** It printed "VRAM: 7.43 GB" for an integrated GPU with no
  dedicated memory, without the caveat `mvgal-info` gave. It now says
  "no dedicated VRAM (shared system memory)" and says so that the number
  is not mistaken for a reservable pool.
- **A multi-GPU strategy was accepted on a single-GPU machine.** The
  shipped configuration says "Use afr/sfr/hybrid only after mvgal-compat
  reports COMPAT_SUPPORTED", but that was enforced nowhere: the daemon
  announced "Scheduler mode from config default_strategy='afr'" on a
  one-GPU host. The strategy is now checked against the detected GPU count
  in three places -- `mvgal-config set-strategy` (refuses unless
  `--force`), at daemon startup (falls back to `single` and says why) and
  in `mvgal-compat` (names the active strategy).
- **`mvgal-compat` exited 0 while reporting "Not operational".** It now
  distinguishes fully operational (0), not operational (1) and partially
  operational (2), like `mvgal-workload` and `mvgal-hw-validate` already
  did.
- **`mvgal-steam-setup --check` reported two false results.** "MVGAL
  runtime: found" only meant that `libmvgal.so` was on disk; it now
  reports the real state (ok / DEGRADED / missing). "MVGAL compat tool:
  not installed" looked for a per-game Steam compatdata directory rather
  than the `mvgal-compat` binary.
- **`mvgal-dashboard --check` printed "daemon not running" and then
  "OK"**, and exited 0. The two statements contradicted each other. It now
  reports DEGRADED and exits 2.
- **Every vendor shader backend was skipped, even for a present GPU.** The
  check looked only in the Debian layout
  (`/usr/lib/x86_64-linux-gnu/vulkan/vendors/`), so on Fedora every vendor
  -- including an Intel GPU with a working driver -- was reported as
  missing. It now checks the ICD directories the loader actually reads and
  the library paths used by the major distributions, and a skip says
  whether the GPU is absent or the driver is.
- **The DKMS build and the packaged modules used two different layouts and
  two different compression conventions**, so `rpm -V` and `dkms status`
  both reported them as mismatched. DKMS now installs into the DRM driver
  path, and the RPM ships the modules with the kernel's own compression,
  so the two agree.
- **`mvgal-config show-config` dumped the raw file**, not the effective
  configuration the daemon runs on. It now shows the parsed configuration
  with defaults applied, and `--raw` prints the literal file.
- **`/etc/OpenCL/layers` was missing**, so the OpenCL loader printed
  "Failed to open path /etc/OpenCL/layers" on every run.
- **The pkexec log was world-readable** and recorded command lines and
  configuration values. It is now 0640 root:mvgal.
- **`/var/log/mvgal` was created and never written to.** The daemon logs
  to journald and the only file log is `/var/log/mvgal-pkexec.log`, which
  lives directly in `/var/log`. The empty directory is not created any more.
- **The key directory was 0700 root**, so `/etc/mvgal/mvgal-signing.der` --
  the documented path to check with `mokutil --test-key` -- was unreadable
  by the very group it exists for. The directory is now 0750 root:mvgal and
  the public certificate is 0640 root:mvgal; the private key stays 0600.
- **Stale DKMS build trees accumulated for every kernel the machine had
  ever had.** They are now removed when the kernel is gone.
- **`[ai_scheduler] enabled = false` was never read**, so a default
  install -- where the model path is dangling by design -- produced a
  diagnostic on every start about a feature the user had switched off.
- **`mvgal-config --help` demonstrated destructive global mutations.**
  Copying `set-psu-config 750 20` out of the help text rewrote the system
  configuration. The examples are now read-only, and the mutating commands
  are listed as such.
- **`journalctl -u mvgald` returned nothing** while
  `journalctl -u mvgal-daemon.service` showed the whole log, because
  `journalctl` does not resolve unit aliases. The canonical unit name is
  now documented and the tools resolve it with `systemctl show -p Id`.

### Notes

- The kernel's own module compression is
  `xz --check=crc32 --lzma2=dict=1MiB`; matching it exactly is what makes
  the signed module byte-identical to the DKMS-built one.
- The 4-byte big-endian DER length in an appended module signature sits 32
  bytes before the end of the file, and the marker terminator is a
  NEWLINE, not a NUL.
- `sign-file` has no verify mode and re-signing APPENDS rather than
  replaces, so the signer strips any existing signature first and detects
  "already correct" by signing a scratch copy and comparing.

## [0.7.24] - 2026-10-18

Audit release: eleven defects found by exercising the installed package on a
three-GPU AMD/NVIDIA/Intel host, most of which had been silently disabling
parts of the system rather than failing visibly.

### Fixed
- Daemon: the systemd unit's `DeviceAllow=` used glob paths. systemd does not
  expand them, and their presence flipped the implicit `DevicePolicy` from
  `auto` to `closed`, so mvgald could open neither `/dev/mvgal0` nor any
  `/dev/dri/*` node. It ran permanently in userspace-only fallback while
  reporting only that the kernel device was unavailable. The allowlist is
  removed: the GPU node set depends on topology and udev render-node
  numbering, and GPUs hot-plug at runtime, so no static list can be correct.
- Daemon: surface `KernelDevice::lastError` when the kernel device cannot be
  opened. The errno was discarded, which is why the above went unnoticed --
  ENOENT and EPERM call for completely different investigations.
- Daemon: request the D-Bus name with `DO_NOT_QUEUE` and check the reply code.
  With flags=0 a taken name was queued and returned a positive value, so a
  takeover would have looked like success while every method call went to the
  other instance. Conflicts now name the owning pid instead of advising a
  dbus reload that could not help.
- Kernel: `pcie_gen`/`pcie_lanes` stored raw `enum pci_bus_speed` values, which
  are bus-speed codes rather than generations (`PCIE_SPEED_2_5GT` is 0x14). A
  Gen4 x16 GPU reported as "Gen 23 x16". Both are now decoded from the PCI
  Express capability register; the legacy wrappers also signal failure with
  `PCI_SPEED_UNKNOWN`, so the `>= 0` guard never fired.
- Kernel: `numa_node` used `dev_to_node()` on a PCI device, whose `dev` is never
  NUMA-aware, so it always read unknown. Now uses `pcibus_to_node()`, with a
  single-node fallback for hosts that have no ACPI/SRAT topology.
- Kernel: the `numa_node >= 0` guard was tautological on an unsigned field, so
  two GPUs with unknown nodes compared as same-node and P2P was admitted on
  the strength of a value carrying no information.
- Kernel: `class_code` was declared in the UABI and printed by mvgal-info, but
  no code ever assigned it. Every GPU reported `0x0000` instead of `0x030000`.
- Kernel: `mvgal_sysfs_init()` called `class_create("mvgal")` a second time
  when `mvgal_core.c` had already created it. The -EEXIST was swallowed, so the
  module reported a clean load while the documented per-GPU `capabilities`
  attributes did not exist -- and the stale class made every load after the
  first fail. sysfs_init now parents its per-GPU kobjects to the device kobject
  the core already registered instead of creating a competing class.
- Kernel: `mvgal_device_free()` cancelled the same delayed work twice, via
  `*_stop()` and again via `*_fini()`, tripping `WARN_ON` in `__flush_work` on
  every rmmod -- once per GPU. Both cancels are now guarded, which also makes
  `fini()` safe standalone. The DVFS work item had the same defect.
- Kernel: fix a use-after-free in PCI enumeration. `pci_get_device()` takes a
  reference on what it returns but not on the cursor it is handed, and the skip
  path released a reference on a cursor it did not own, so the next iteration
  walked freed memory. The cursor now owns one reference for the whole scan.
- Kernel: `*_init()` passed NULL as the delayed-work handler, so anything
  queuing the work before `*_start()` would have faulted.
- Tools: mvgal-info pooled an integrated GPU's shared system memory into
  "Aggregate VRAM", claiming a 66 GiB pool on a machine with 10 GiB of real
  VRAM. Dedicated VRAM and shared system RAM are now accumulated and reported
  separately.
- Daemon: `writeFrequency()` returned success without writing a clock, so the
  DVFS controller recorded clocks the GPU was never running at. It now reports
  clock control as unavailable and leaves last-known state intact.
- Daemon: the PSU headroom and power curve controllers both wrote
  `targetClockMhz`, which the DVFS controller rewrites from utilisation every
  tick, making both silently inert. Each now holds its own cap that the DVFS
  controller clamps against.
- Steam: shipped game profiles pinned `primary_gpu_mask = 0x3`, freezing them to
  a two-GPU machine regardless of hardware. Now `0`, which the scheduler already
  defines as "all GPUs".

### Added
- D1-D5 design/docs: narrow end-to-end userspace workload path (OpenCL ICD loader, host-staged, CPU reference validation)
- Tool: mvgal-workload (end-to-end OpenCL workload gate; validates >=2 distinct vendors)

### Changed
- Build: link mvgal-info with nvml_query.c and ${CMAKE_DL_LIBS} (standalone tool needs NVML helper)
- Kernel: PCIe link attributes are read from the capability register (maximum
  supported) rather than the status register, so a powered-down GPU reports its
  real capability instead of a negotiated width of zero.

- packaging: ship `/usr/bin/mvgal-workload`. The tool and its CMake install
  rule arrived in 0.7.23 but were never added to the RPM `%files`, so every
  COPR build since then has failed with "Installed (but unpackaged) file(s)
  found". It is built only when `find_package(OpenCL)` succeeds, so it is
  now listed under the existing `%bcond_without opencl`.

### Known issues
- The PCI enumeration use-after-free is source-verified only. On the host where
  it was found, earlier load/unload cycles had already driven a device refcount
  to zero, and such refcounts are not recoverable without a reboot. It needs a
  clean-boot check; `test_uapi_probe` fails on an affected machine because
  enumeration reports zero GPUs.

## [0.7.23] - 2026-10-18

### Fixed
- DKMS: ensure KERNELDIR is correctly resolved in kernel/Makefile and dkms.conf (fixes module build on kernel 7.2.11-200.fc44.x86_64)
- Userspace: fix NVIDIA VRAM reporting (0 GB) via NVML fallback by PCI BDF; aggregate VRAM correctly labels/excludes shared system memory
- Daemon: eliminate AMD frequency-set log spam by initializing C logger at INFO level (mvgal_log_init) so DEBUG messages are filtered
- Tools: mvgal-info shows full driver names (amdgpu/nvidia/i915); mvgal status displays VRAM with "(shared system memory)" for shared RAM

