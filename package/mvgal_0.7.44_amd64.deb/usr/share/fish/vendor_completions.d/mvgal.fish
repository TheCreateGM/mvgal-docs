# mvgal Fish Shell Completion
# Source: /usr/share/fish/vendor_completions.d/mvgal.fish

# Main mvgal command
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "start" -d "Start MVGAL daemon"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "stop" -d "Stop MVGAL daemon"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "status" -d "Show MVGAL status"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "restart" -d "Restart MVGAL daemon"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "list-gpus" -d "List detected GPUs"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "show-config" -d "Show configuration"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "show-stats" -d "Show statistics"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "set-strategy" -d "Set distribution strategy"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "enable-gpu" -d "Enable GPU"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "disable-gpu" -d "Disable GPU"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "reload" -d "Reload configuration"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "load-module" -d "Load kernel module"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "unload-module" -d "Unload kernel module"
complete -c mvgal -f -n "not __fish_seen_subcommand_from start stop status restart list-gpus show-config show-stats set-strategy enable-gpu disable-gpu set-priority reset-stats reload load-module unload-module benchmark bench-synthetic bench-realworld bench-stress" -a "benchmark" -d "Run benchmarks"

# Strategy completions for set-strategy
complete -c mvgal -f -n "__fish_seen_subcommand_from set-strategy" -a "round_robin" -d "Round-robin distribution"
complete -c mvgal -f -n "__fish_seen_subcommand_from set-strategy" -a "afr" -d "Alternate Frame Rendering"
complete -c mvgal -f -n "__fish_seen_subcommand_from set-strategy" -a "sfr" -d "Split Frame Rendering"
complete -c mvgal -f -n "__fish_seen_subcommand_from set-strategy" -a "single_gpu" -d "Single GPU only"
complete -c mvgal -f -n "__fish_seen_subcommand_from set-strategy" -a "hybrid" -d "Hybrid distribution"
complete -c mvgal -f -n "__fish_seen_subcommand_from set-strategy" -a "task" -d "Task-based distribution"
complete -c mvgal -f -n "__fish_seen_subcommand_from set-strategy" -a "compute_offload" -d "Compute offload"

# Global options
complete -c mvgal -l help -s h -d "Show help"
complete -c mvgal -l version -d "Show version"
complete -c mvgal -l config -s c -d "Config file" -r

# mvgal-info completions
complete -c mvgal-info -l json -s j -d "JSON output"
complete -c mvgal-info -l count -s c -d "GPU count only"
complete -c mvgal-info -l vulkan-groups -d "Vulkan device groups"
complete -c mvgal-info -l help -s h -d "Show help"

# mvgal-status completions
complete -c mvgal-status -l watch -s w -d "Continuous refresh"
complete -c mvgal-status -l interval -d "Refresh interval (ms)" -r
complete -c mvgal-status -l json -d "JSON output"
complete -c mvgal-status -l help -s h -d "Show help"

# mvgal-bench completions
complete -c mvgal-bench -f -a "all" -d "Run all benchmarks"
complete -c mvgal-bench -f -a "memory" -d "Memory bandwidth"
complete -c mvgal-bench -f -a "compute" -d "Compute FLOPS"
complete -c mvgal-bench -f -a "scheduler" -d "Scheduler latency"
complete -c mvgal-bench -f -a "sync" -d "Sync overhead"
complete -c mvgal-bench -l help -s h -d "Show help"

# mvgal-compat completions
complete -c mvgal-compat -l system -d "System check only"
complete -c mvgal-compat -l json -d "JSON output"
complete -c mvgal-compat -l help -s h -d "Show help"

# mvgal-config completions
complete -c mvgal-config -f -n "not __fish_seen_subcommand_from set-strategy get set" -a "set-strategy" -d "Set strategy"
complete -c mvgal-config -f -n "not __fish_seen_subcommand_from set-strategy get set" -a "get" -d "Get config"
complete -c mvgal-config -f -n "not __fish_seen_subcommand_from set-strategy get set" -a "set" -d "Set config"
complete -c mvgal-config -f -n "__fish_seen_subcommand_from set-strategy" -a "round_robin afr sfr task compute_offload hybrid single"
complete -c mvgal-config -l help -s h -d "Show help"

# mvgal-hw-validate
complete -c mvgal-hw-validate -l help -s h -d "Show help"

# mvgal-enum
complete -c mvgal-enum -l json -s j -d "JSON output"
complete -c mvgal-enum -l help -s h -d "Show help"

# mvgal-steam-setup
complete -c mvgal-steam-setup -l help -s h -d "Show help"

# mvgal-dmabuf-matrix
complete -c mvgal-dmabuf-matrix -l json -s j -d "JSON output"
complete -c mvgal-dmabuf-matrix -l help -s h -d "Show help"
