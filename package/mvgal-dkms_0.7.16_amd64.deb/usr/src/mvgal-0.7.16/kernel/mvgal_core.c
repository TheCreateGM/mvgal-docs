/**
 * MVGAL - Multi-Vendor GPU Aggregation Layer for Linux
 * 
 * Kernel Core Module - DRM registration and module entry point
 * 
 * SPDX-License-Identifier: GPL-2.0-only
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/pci.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/idr.h>
#include <linux/version.h>
#include <linux/ioctl.h>
#include <linux/notifier.h>
#include <drm/drm_drv.h>
#include <drm/drm_file.h>
#include <drm/drm_ioctl.h>
#include <drm/drm.h>
#include <drm/drm_print.h>

#include <mvgal/mvgal_uapi.h>
#include <mvgal/mvgal_version.h>
#include "mvgal_core.h"
#include "mvgal_device.h"
#include "mvgal_scheduler.h"
#include "mvgal_memory.h"
#include "mvgal_sync.h"
#include "mvgal_ntsync.h"
#include "mvgal_trace.h"

/* Use IOCTL definitions from header files */

#define DRIVER_NAME "mvgal"
#define DRIVER_DESC "Multi-Vendor GPU Aggregation Layer"
#define DRIVER_DATE "20260426"
#define DRIVER_MAJOR 0
#define DRIVER_MINOR 2
#define DRIVER_PATCHLEVEL 6

/* Module parameters */
static bool enable_debug = false;
module_param(enable_debug, bool, 0644);
MODULE_PARM_DESC(enable_debug, "Enable debug logging");

/* Character device */
static dev_t mvgal_devt;
static struct class *mvgal_class;
static struct cdev *mvgal_cdev;
static struct device *mvgal_class_dev;

/* DRM driver - actual definition below after ioctls */
/* MVGAL logical device */
struct mvgal_device *mvgal_logical_device;
EXPORT_SYMBOL_GPL(mvgal_logical_device);

/* Vendor registration — IDR-based dynamic table */
static DEFINE_IDR(vendor_idr);
static DEFINE_MUTEX(mvgal_vendor_lock);

/*
 * DRM operations
 */
static int mvgal_drm_open(struct drm_device *drm, struct drm_file *file)
{
	/* Allocate and initialize per-file private data */
	file->driver_priv = kzalloc(sizeof(struct mvgal_file), GFP_KERNEL);
	if (!file->driver_priv) {
		return -ENOMEM;
	}

	if (mvgal_logical_device)
		atomic64_inc(&mvgal_logical_device->stats.open_count);

	pr_debug("Open called\n");

	return 0;
}

static void mvgal_drm_postclose(struct drm_device *drm, struct drm_file *file)
{
	struct mvgal_file *mvgal_file = file->driver_priv;

	/* Cleanup per-file data */
	kfree(mvgal_file);
	file->driver_priv = NULL;

	if (mvgal_logical_device)
		atomic64_inc(&mvgal_logical_device->stats.release_count);

	pr_info("MVGAL: Postclose called\n");
}

#if IS_ENABLED(CONFIG_DRM)
static const struct drm_ioctl_desc mvgal_ioctls[] = {
	DRM_IOCTL_DEF_DRV(MVGAL_QUERY_DEVICES, mvgal_ioctl_query_devices, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_QUERY_CAPABILITIES, mvgal_ioctl_query_capabilities, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_SUBMIT_WORKLOAD, mvgal_ioctl_submit_workload, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_ALLOC_MEMORY, mvgal_ioctl_alloc_memory, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_FREE_MEMORY, mvgal_ioctl_free_memory, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_IMPORT_DMABUF, mvgal_ioctl_import_dmabuf, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_EXPORT_DMABUF, mvgal_ioctl_export_dmabuf, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_WAIT_FENCE, mvgal_ioctl_wait_fence, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_SIGNAL_FENCE, mvgal_ioctl_signal_fence, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(MVGAL_SET_GPU_AFFINITY, mvgal_ioctl_set_gpu_affinity, DRM_RENDER_ALLOW),
};

const struct drm_driver mvgal_drm_driver = {
	.driver_features = DRIVER_RENDER | DRIVER_HAVE_IRQ | DRIVER_GEM,
	.ioctls = mvgal_ioctls,
	.num_ioctls = ARRAY_SIZE(mvgal_ioctls),
	.open = mvgal_drm_open,
	.postclose = mvgal_drm_postclose,
	.name = DRIVER_NAME,
	.desc = DRIVER_DESC,
	.major = DRIVER_MAJOR,
	.minor = DRIVER_MINOR,
	.patchlevel = DRIVER_PATCHLEVEL,
};
EXPORT_SYMBOL_GPL(mvgal_drm_driver);
#endif /* CONFIG_DRM */

/*
 * GPU PCI identity table.
 *
 * MVGAL is an ABOVE-DRIVER coordinator.  It never claims a physical GPU
 * PCI function: doing so takes the device away from the native driver
 * (amdgpu, nvidia, i915/xe, mtgpu-drv) and breaks the display and compute
 * stack.  This table therefore exists only to identify display-class
 * functions during read-only discovery (mvgal_enumerate_gpus) and during
 * hotplug notification (mvgal_hotplug_callback).
 *
 * There is deliberately NO struct pci_driver and NO MODULE_DEVICE_TABLE
 * here.  Registering a PCI driver would put a competing probe on GPUs
 * that native drivers already own, and emitting a pci alias would let
 * udev autoload mvgal.ko onto real hardware.
 */
static const struct pci_device_id mvgal_gpu_pci_ids[] = {
	/* AMD GPUs */
	{ PCI_DEVICE(PCI_VENDOR_ID_ATI, 0x1638) }, /* AMD Radeon RX 6800 */
	{ PCI_DEVICE(PCI_VENDOR_ID_ATI, 0x73A0) }, /* AMD Radeon RX 6700 XT */

	/* NVIDIA GPUs */
	{ PCI_DEVICE(PCI_VENDOR_ID_NVIDIA, 0x2204) }, /* NVIDIA GA102 */
	{ PCI_DEVICE(PCI_VENDOR_ID_NVIDIA, 0x2206) }, /* NVIDIA GA104 */

	/* Intel GPUs */
	{ PCI_DEVICE(PCI_VENDOR_ID_INTEL, 0x4680) }, /* Intel DG2 */
	{ PCI_DEVICE(PCI_VENDOR_ID_INTEL, 0x4690) }, /* Intel DG2 */

	/* Moore Threads GPUs */
	{ PCI_DEVICE(0x1ED5, 0x4000) }, /* Moore Threads S2000 */

	{ 0, } /* Terminator */
};

/* Character device file operations */
static const struct file_operations mvgal_fops = {
	.owner = THIS_MODULE,
	.open = mvgal_char_open,
	.release = mvgal_char_release,
	.unlocked_ioctl = mvgal_char_ioctl,
	.compat_ioctl = compat_ptr_ioctl,
	.mmap = mvgal_char_mmap,
};

/* Module initialization */
int mvgal_init(void)
{
	int ret;

	pr_info("MVGAL: Multi-Vendor GPU Aggregation Layer initializing\n");

	/* Allocate device numbers */
	ret = alloc_chrdev_region(&mvgal_devt, 0, MVGAL_MAX_DEVICES, DRIVER_NAME);
	if (ret < 0) {
		pr_err("MVGAL: Failed to allocate device numbers\n");
		return ret;
	}

	/* Create device class */
/* RHEL_RELEASE_VERSION may be undefined on non-RHEL (Fedora, Amazon Linux).
 * Define fallback to prevent GCC 15+ preprocessor syntax errors. */
#ifndef RHEL_RELEASE_VERSION
#define RHEL_RELEASE_VERSION(a, b) 0
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0) || \
    (defined(RHEL_RELEASE_CODE) && RHEL_RELEASE_CODE >= RHEL_RELEASE_VERSION(9, 0))
	mvgal_class = class_create(DRIVER_NAME);
#else
	mvgal_class = class_create(THIS_MODULE, DRIVER_NAME);
#endif
	if (IS_ERR(mvgal_class)) {
		ret = PTR_ERR(mvgal_class);
		pr_err("MVGAL: Failed to create device class\n");
		goto err_unregister_chrdev;
	}

	/* Create character device */
	mvgal_cdev = cdev_alloc();
	if (!mvgal_cdev) {
		ret = -ENOMEM;
		pr_err("MVGAL: Failed to allocate cdev\n");
		goto err_class_destroy;
	}

	cdev_init(mvgal_cdev, &mvgal_fops);
	mvgal_cdev->owner = THIS_MODULE;

	ret = cdev_add(mvgal_cdev, mvgal_devt, MVGAL_MAX_DEVICES);
	if (ret < 0) {
		pr_err("MVGAL: Failed to add character device\n");
		goto err_cdev_del;
	}

	/* Create device node */
	{
		struct device *dev = device_create(mvgal_class, NULL, mvgal_devt, NULL, "%s0", DRIVER_NAME);
		if (IS_ERR(dev)) {
			ret = PTR_ERR(dev);
			pr_err("MVGAL: Failed to create device node\n");
			goto err_cdev_del;
		}
		mvgal_class_dev = dev;
	}

	/* Initialize logical device (includes DRM device allocation) */
	ret = mvgal_device_init(&mvgal_logical_device, mvgal_class_dev);
	if (ret < 0) {
		pr_err("MVGAL: Logical device initialization failed\n");
		goto err_drm_cleanup;
	}

	/* Register DRM device with kernel subsystem */
#if IS_ENABLED(CONFIG_DRM)
	ret = drm_dev_register(mvgal_logical_device->drm, 0);
	if (ret < 0) {
		pr_err("MVGAL: DRM device registration failed\n");
		goto err_device_fini;
	}
#endif

	/*
	 * No pci_register_driver() here on purpose.  Physical GPUs were
	 * already discovered read-only by mvgal_enumerate_gpus() from
	 * mvgal_device_init() above, and are observed for hotplug through
	 * the PCI bus notifier below.  MVGAL never binds a GPU, never
	 * calls pci_enable_device()/pci_set_master() on one, and never
	 * takes ownership of a native driver's device.
	 */

	/* Initialize trace provider */
	ret = mvgal_trace_init();
	if (ret < 0) {
		pr_warn("MVGAL: trace initialization failed: %d\n", ret);
		/* Non-fatal: continue without tracefs */
	}

	/* Initialize sysfs interface */
	ret = mvgal_sysfs_init(mvgal_logical_device);
	if (ret < 0) {
		pr_warn("MVGAL: sysfs initialization failed: %d\n", ret);
		/* Non-fatal: continue without sysfs */
	}

	/* Initialize PCI hotplug notifier */
	ret = mvgal_hotplug_init();
	if (ret < 0) {
		pr_warn("MVGAL: hotplug notifier initialization failed: %d\n", ret);
		/* Non-fatal: continue without hotplug */
	}

	pr_info("MVGAL: Initialization complete. Device node: /dev/mvgal0\n");

	return 0;

err_device_fini:
	mvgal_device_fini(mvgal_logical_device);
err_drm_cleanup:
	device_destroy(mvgal_class, mvgal_devt);
	cdev_del(mvgal_cdev);
err_cdev_del:
	kfree(mvgal_cdev);
err_class_destroy:
	class_destroy(mvgal_class);
err_unregister_chrdev:
	unregister_chrdev_region(mvgal_devt, MVGAL_MAX_DEVICES);

	return ret;
}

/* Module cleanup */
void mvgal_exit(void)
{
	pr_info("MVGAL: Cleanup starting\n");

	/* Cleanup hotplug notifier */
	mvgal_hotplug_exit();

	/* Cleanup trace provider */
	mvgal_trace_fini();

	/* Cleanup sysfs interface */
	mvgal_sysfs_exit(mvgal_logical_device);

	/* Nothing to unregister: MVGAL never registered a PCI driver.
	 * mvgal_device_fini() below releases the pci_dev references that
	 * mvgal_enumerate_gpus() holds for each discovered GPU. */

	/* Free IDR resources */
	idr_destroy(&vendor_idr);

	/* Unregister DRM device before dropping device ref */
#if IS_ENABLED(CONFIG_DRM)
	drm_dev_unregister(mvgal_logical_device->drm);
#endif

	/* Cleanup logical device (calls drm_dev_put) */
	mvgal_device_fini(mvgal_logical_device);

	/* Destroy character device */
	device_destroy(mvgal_class, mvgal_devt);
	cdev_del(mvgal_cdev);
	class_destroy(mvgal_class);
	unregister_chrdev_region(mvgal_devt, MVGAL_MAX_DEVICES);

	pr_info("MVGAL: Cleanup complete\n");
}

/*
 * Aggregation stack entry points — invoked when MVGAL_BUILD_FULL_STACK=1
 * is set in Kbuild (see kernel/Kbuild).
 *
 * NOTE: These do NOT register a char device.  mvgal_core.c already
 * handles that (alloc_chrdev_region, class_create, cdev_add,
 * device_create).  We only need the logical device; GPU discovery is
 * read-only PCI scanning, never a PCI driver binding.
 */
int mvgal_stack_init(struct device *parent)
{
	int ret;

	pr_info("MVGAL: Stack init (full-stack mode, chardev handled by mvgal_core)\n");

	/* Initialize power management */
	ret = mvgal_power_module_init();
	if (ret < 0) {
		pr_err("MVGAL: Power module init failed: %d\n", ret);
		return ret;
	}

	/* Init logical device */
	ret = mvgal_device_init(&mvgal_logical_device, parent);
	if (ret < 0) {
		pr_err("MVGAL: Logical device init failed: %d\n", ret);
		mvgal_power_module_exit();
		return ret;
	}

	/* GPUs were enumerated read-only by mvgal_device_init() above;
	 * MVGAL does not register a PCI driver and does not bind GPUs. */

	pr_info("MVGAL: Stack init complete\n");
	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_stack_init);

void mvgal_stack_exit(void)
{
	pr_info("MVGAL: Stack exit (full-stack mode)\n");

	/* No pci_unregister_driver(): no PCI driver was ever registered. */
#if IS_ENABLED(CONFIG_DRM)
	drm_dev_unregister(mvgal_logical_device->drm);
#endif
	mvgal_device_fini(mvgal_logical_device);

	idr_destroy(&vendor_idr);

	mvgal_power_module_exit();
}
EXPORT_SYMBOL_GPL(mvgal_stack_exit);

/*
 * Character device operations implementation
 */

int mvgal_char_open(struct inode *inode, struct file *filp)
{
	struct mvgal_file *file_priv;

	file_priv = kzalloc(sizeof(*file_priv), GFP_KERNEL);
	if (!file_priv)
		return -ENOMEM;

	INIT_LIST_HEAD(&file_priv->workloads);
	mutex_init(&file_priv->lock);
	file_priv->next_workload_id = 1;

	filp->private_data = file_priv;

	if (mvgal_logical_device)
		atomic64_inc(&mvgal_logical_device->stats.open_count);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_char_open);

int mvgal_char_release(struct inode *inode, struct file *filp)
{
	struct mvgal_file *file_priv = filp->private_data;

	if (file_priv) {
		struct mvgal_workload *workload, *tmp;
		
		mutex_lock(&file_priv->lock);
		list_for_each_entry_safe(workload, tmp, &file_priv->workloads, node) {
			list_del(&workload->node);
			/* Workload lifecycle is managed by scheduler/subsystem, we just unlink it from file */
		}
		mutex_unlock(&file_priv->lock);
		
		mutex_destroy(&file_priv->lock);
		kfree(file_priv);
		filp->private_data = NULL;
	}

	if (mvgal_logical_device)
		atomic64_inc(&mvgal_logical_device->stats.release_count);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_char_release);

int mvgal_char_mmap(struct file *filp, struct vm_area_struct *vma)
{
	unsigned long size = vma->vm_end - vma->vm_start;
	unsigned long pfn = vma->vm_pgoff;

	/* Basic implementation: map physical pages provided via vm_pgoff */
	/* In a real implementation, we would validate the PFN against our allocations */
	vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);

	if (remap_pfn_range(vma, vma->vm_start, pfn, size, vma->vm_page_prot))
		return -EAGAIN;

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_char_mmap);

long mvgal_char_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	void __user *uarg = (void __user *)arg;
	long ret = 0;
	struct drm_file mock_file;

	if (mvgal_logical_device)
		atomic64_inc(&mvgal_logical_device->stats.ioctl_count);

	/* Setup a mock drm_file so we can call the DRM-based ioctl handlers */
	memset(&mock_file, 0, sizeof(mock_file));
	mock_file.driver_priv = filp->private_data;

	/* Route standard MVGAL_IOC_... (magic 'M') ioctls */
	if (_IOC_TYPE(cmd) == MVGAL_IOC_MAGIC) {
		switch (cmd) {
		case MVGAL_IOC_QUERY_VERSION: {
			struct mvgal_uapi_version version = {
				.major = MVGAL_UAPI_VERSION_MAJOR,
				.minor = MVGAL_UAPI_VERSION_MINOR,
				.patch = MVGAL_UAPI_VERSION_PATCH,
				.feature_flags = MVGAL_UAPI_FEATURE_ENUMERATION |
						 MVGAL_UAPI_FEATURE_PCI_TOPOLOGY |
						 MVGAL_UAPI_FEATURE_HOTPLUG_MONITOR |
						 MVGAL_UAPI_FEATURE_RESCAN |
						 MVGAL_UAPI_FEATURE_FUTURE_DMABUF |
						 MVGAL_UAPI_FEATURE_FUTURE_SUBMISSION,
			};
			if (copy_to_user(uarg, &version, sizeof(version)))
				return -EFAULT;
			return 0;
		}
		case MVGAL_IOC_GET_GPU_COUNT: {
			struct mvgal_uapi_gpu_count count = {0};
			if (mvgal_logical_device)
				count.gpu_count = mvgal_logical_device->gpu_count;
			if (copy_to_user(uarg, &count, sizeof(count)))
				return -EFAULT;
			return 0;
		}
		case MVGAL_IOC_GET_GPU_INFO: {
			struct mvgal_uapi_gpu_query query;
			struct mvgal_gpu_device *gpu;
			uint32_t idx = 0;

			if (copy_from_user(&query, uarg, sizeof(query)))
				return -EFAULT;

			if (!mvgal_logical_device)
				return -ENODEV;

			mutex_lock(&mvgal_logical_device->gpu_lock);
			list_for_each_entry(gpu, &mvgal_logical_device->gpu_list, node) {
				if (idx == query.index) {
					memset(&query.info, 0, sizeof(query.info));
					query.info.index = gpu->gpu_index;
					query.info.vendor_id = gpu->pci_vendor_id;
					query.info.device_id = gpu->pci_device_id;
					query.info.numa_node = gpu->numa_node;
					query.info.pcie_link_gen = gpu->pcie_gen;
					query.info.pcie_link_width = gpu->pcie_lanes;
					strscpy(query.info.name, gpu->name, sizeof(query.info.name));
					if (gpu->pdev) {
						const char *drv = dev_driver_string(&gpu->pdev->dev);
						strscpy(query.info.driver, drv ? drv : "unknown", sizeof(query.info.driver));
						snprintf(query.info.bdf, sizeof(query.info.bdf), "%04x:%02x:%02x.%u",
							 pci_domain_nr(gpu->pdev->bus), gpu->pdev->bus->number,
							 PCI_SLOT(gpu->pdev->devfn), PCI_FUNC(gpu->pdev->devfn));
					}
					mutex_unlock(&mvgal_logical_device->gpu_lock);

					if (copy_to_user(uarg, &query, sizeof(query)))
						return -EFAULT;
					return 0;
				}
				idx++;
			}
			mutex_unlock(&mvgal_logical_device->gpu_lock);
			return -EINVAL;
		}
		case MVGAL_IOC_GET_CAPS: {
			struct mvgal_uapi_caps caps = {0};
			if (mvgal_logical_device) {
				caps.enabled = 1;
				caps.gpu_count = mvgal_logical_device->gpu_count;
				caps.topology_generation = 1;
				caps.max_pcie_link_gen = 4;
				caps.max_pcie_link_width = 16;
				caps.feature_flags = MVGAL_UAPI_FEATURE_ENUMERATION |
						     MVGAL_UAPI_FEATURE_PCI_TOPOLOGY |
						     MVGAL_UAPI_FEATURE_HOTPLUG_MONITOR |
						     MVGAL_UAPI_FEATURE_RESCAN |
						     MVGAL_UAPI_FEATURE_FUTURE_DMABUF |
						     MVGAL_UAPI_FEATURE_FUTURE_SUBMISSION;
				caps.largest_prefetchable_bar_bytes = 256 * 1024 * 1024;
				caps.largest_mmio_bar_bytes = 16 * 1024 * 1024;
			}
			if (copy_to_user(uarg, &caps, sizeof(caps)))
				return -EFAULT;
			return 0;
		}
		case MVGAL_IOC_RESCAN: {
			if (mvgal_logical_device) {
				/* Simply re-enumerate GPUs */
				mvgal_gpu_cleanup_all(mvgal_logical_device);
				mvgal_enumerate_gpus(mvgal_logical_device);
				atomic64_inc(&mvgal_logical_device->stats.rescans);
				mvgal_logical_device->topology_generation++;
			}
			return 0;
		}
		case MVGAL_IOC_GET_STATS: {
			struct mvgal_uapi_stats stats = {0};
			if (mvgal_logical_device) {
				stats.open_count = atomic64_read(&mvgal_logical_device->stats.open_count);
				stats.release_count = atomic64_read(&mvgal_logical_device->stats.release_count);
				stats.ioctl_count = atomic64_read(&mvgal_logical_device->stats.ioctl_count);
				stats.rescans = atomic64_read(&mvgal_logical_device->stats.rescans);
				stats.hotplug_events = atomic64_read(&mvgal_logical_device->stats.hotplug_events);
				stats.dma_buf_export_count = atomic64_read(&mvgal_logical_device->stats.dma_buf_export_count);
				stats.dma_buf_import_count = atomic64_read(&mvgal_logical_device->stats.dma_buf_import_count);
				stats.cross_vendor_alloc_count = atomic64_read(&mvgal_logical_device->stats.cross_vendor_alloc_count);
				stats.unsupported_dmabuf_exports = atomic64_read(&mvgal_logical_device->stats.unsupported_dmabuf_exports);
				stats.unsupported_dmabuf_imports = atomic64_read(&mvgal_logical_device->stats.unsupported_dmabuf_imports);
				stats.unsupported_cross_vendor_allocs = atomic64_read(&mvgal_logical_device->stats.unsupported_cross_vendor);
				stats.p2p_transfer_count = atomic64_read(&mvgal_logical_device->stats.p2p_transfer_count);
				stats.host_staging_transfer_count = atomic64_read(&mvgal_logical_device->stats.host_staging_transfer_count);
			}
			if (copy_to_user(uarg, &stats, sizeof(stats)))
				return -EFAULT;
			return 0;
		}
		case MVGAL_IOC_ENABLE:
		case MVGAL_IOC_DISABLE:
			return 0;
		case MVGAL_IOC_NTSYNC_QUERY: {
			struct mvgal_uapi_ntsync_info info = {0};
			int nret = mvgal_ntsync_query(&info);
			if (nret)
				return nret;
			if (copy_to_user(uarg, &info, sizeof(info)))
				return -EFAULT;
			return 0;
		}
		default:
			return -EINVAL;
		}
	}

	/* Route DRM-based aggregation ioctls */
	switch (cmd) {
	case DRM_IOCTL_MVGAL_QUERY_DEVICES: {
		struct drm_mvgal_generic args;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		ret = mvgal_ioctl_query_devices(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &args, &mock_file);
		if (ret == 0 && copy_to_user(uarg, &args, sizeof(args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_QUERY_CAPABILITIES: {
		struct drm_mvgal_generic args;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		ret = mvgal_ioctl_query_capabilities(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &args, &mock_file);
		if (ret == 0 && copy_to_user(uarg, &args, sizeof(args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_SUBMIT_WORKLOAD: {
		struct drm_mvgal_generic args;
		void __user *workload_user_ptr;
		struct mvgal_submit_workload_args w_args;
		
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		workload_user_ptr = (void __user *)(uintptr_t)args.data;
		if (!workload_user_ptr)
			return -EINVAL;
		if (copy_from_user(&w_args, workload_user_ptr, sizeof(w_args)))
			return -EFAULT;
		ret = mvgal_ioctl_submit_workload(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &w_args, &mock_file);
		if (ret == 0 && copy_to_user(workload_user_ptr, &w_args, sizeof(w_args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_ALLOC_MEMORY: {
		struct drm_mvgal_generic args;
		struct mvgal_alloc_memory_args mem_args;
		void __user *mem_user_ptr;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		mem_user_ptr = (void __user *)(uintptr_t)args.data;
		if (!mem_user_ptr)
			return -EINVAL;
		if (copy_from_user(&mem_args, mem_user_ptr, sizeof(mem_args)))
			return -EFAULT;
		ret = mvgal_ioctl_alloc_memory(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &mem_args, &mock_file);
		if (ret == 0 && copy_to_user(mem_user_ptr, &mem_args, sizeof(mem_args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_FREE_MEMORY: {
		struct drm_mvgal_generic args;
		struct mvgal_free_memory_args mem_args;
		void __user *mem_user_ptr;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		mem_user_ptr = (void __user *)(uintptr_t)args.data;
		if (!mem_user_ptr)
			return -EINVAL;
		if (copy_from_user(&mem_args, mem_user_ptr, sizeof(mem_args)))
			return -EFAULT;
		ret = mvgal_ioctl_free_memory(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &mem_args, &mock_file);
		if (ret == 0 && copy_to_user(mem_user_ptr, &mem_args, sizeof(mem_args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_IMPORT_DMABUF: {
		struct drm_mvgal_generic args;
		struct mvgal_import_dmabuf_args dmabuf_args;
		void __user *dmabuf_user_ptr;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		dmabuf_user_ptr = (void __user *)(uintptr_t)args.data;
		if (!dmabuf_user_ptr)
			return -EINVAL;
		if (copy_from_user(&dmabuf_args, dmabuf_user_ptr, sizeof(dmabuf_args)))
			return -EFAULT;
		ret = mvgal_ioctl_import_dmabuf(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &dmabuf_args, &mock_file);
		if (ret == 0 && copy_to_user(dmabuf_user_ptr, &dmabuf_args, sizeof(dmabuf_args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_EXPORT_DMABUF: {
		struct drm_mvgal_generic args;
		struct mvgal_export_dmabuf_args dmabuf_args;
		void __user *dmabuf_user_ptr;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		dmabuf_user_ptr = (void __user *)(uintptr_t)args.data;
		if (!dmabuf_user_ptr)
			return -EINVAL;
		if (copy_from_user(&dmabuf_args, dmabuf_user_ptr, sizeof(dmabuf_args)))
			return -EFAULT;
		ret = mvgal_ioctl_export_dmabuf(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &dmabuf_args, &mock_file);
		if (ret == 0 && copy_to_user(dmabuf_user_ptr, &dmabuf_args, sizeof(dmabuf_args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_WAIT_FENCE: {
		struct drm_mvgal_generic args;
		struct mvgal_wait_fence_args fence_args;
		void __user *fence_user_ptr;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		fence_user_ptr = (void __user *)(uintptr_t)args.data;
		if (!fence_user_ptr)
			return -EINVAL;
		if (copy_from_user(&fence_args, fence_user_ptr, sizeof(fence_args)))
			return -EFAULT;
		ret = mvgal_ioctl_wait_fence(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &fence_args, &mock_file);
		if (ret == 0 && copy_to_user(fence_user_ptr, &fence_args, sizeof(fence_args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_SIGNAL_FENCE: {
		struct drm_mvgal_generic args;
		struct mvgal_signal_fence_args fence_args;
		void __user *fence_user_ptr;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		fence_user_ptr = (void __user *)(uintptr_t)args.data;
		if (!fence_user_ptr)
			return -EINVAL;
		if (copy_from_user(&fence_args, fence_user_ptr, sizeof(fence_args)))
			return -EFAULT;
		ret = mvgal_ioctl_signal_fence(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &fence_args, &mock_file);
		if (ret == 0 && copy_to_user(fence_user_ptr, &fence_args, sizeof(fence_args)))
			return -EFAULT;
		return ret;
	}
	case DRM_IOCTL_MVGAL_SET_GPU_AFFINITY: {
		struct drm_mvgal_generic args;
		if (copy_from_user(&args, uarg, sizeof(args)))
			return -EFAULT;
		ret = mvgal_ioctl_set_gpu_affinity(mvgal_logical_device ? mvgal_logical_device->drm : NULL, &args, &mock_file);
		if (ret == 0 && copy_to_user(uarg, &args, sizeof(args)))
			return -EFAULT;
		return ret;
	}
	default:
		return -ENOTTY;
	}
}
EXPORT_SYMBOL_GPL(mvgal_char_ioctl);

/*
 * DRM ioctl handler definitions
 */

int mvgal_ioctl_query_devices(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct drm_mvgal_generic *args = data;
	struct mvgal_gpu_device *gpu;
	uint32_t count = 0;
	void __user *user_ptr = (void __user *)(uintptr_t)args->data;

	if (!user_ptr)
		return -EINVAL;

	if (!mvgal_logical_device)
		return -ENODEV;

	mutex_lock(&mvgal_logical_device->gpu_lock);
	list_for_each_entry(gpu, &mvgal_logical_device->gpu_list, node) {
		struct mvgal_gpu_info info;
		memset(&info, 0, sizeof(info));
		info.index = gpu->gpu_index;
		info.vendor_id = gpu->pci_vendor_id;
		info.device_id = gpu->pci_device_id;
		info.numa_node = gpu->numa_node;
		info.pcie_link_gen = gpu->pcie_gen;
		info.pcie_link_width = gpu->pcie_lanes;
		strscpy(info.name, gpu->name, sizeof(info.name));
		
		/* Copy to userspace */
		if (copy_to_user(user_ptr + count * sizeof(struct mvgal_gpu_info), &info, sizeof(info))) {
			mutex_unlock(&mvgal_logical_device->gpu_lock);
			return -EFAULT;
		}
		count++;
		if (count >= MVGAL_MAX_GPUS)
			break;
	}
	mutex_unlock(&mvgal_logical_device->gpu_lock);

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_ioctl_query_devices);

int mvgal_ioctl_query_capabilities(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct drm_mvgal_generic *args = data;
	void __user *user_ptr = (void __user *)(uintptr_t)args->data;
	struct mvgal_capability_profile profile;

	if (!user_ptr)
		return -EINVAL;

	if (!mvgal_logical_device)
		return -ENODEV;

	memset(&profile, 0, sizeof(profile));
	/* Copy capability profile from physical pool */
	profile = mvgal_logical_device->caps;

	if (copy_to_user(user_ptr, &profile, sizeof(profile)))
		return -EFAULT;

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_ioctl_query_capabilities);

int mvgal_ioctl_set_gpu_affinity(struct drm_device *drm, void *data, struct drm_file *file)
{
	struct mvgal_gpu_device *gpu;
	struct mvgal_uapi_set_affinity *args = data;
	uint32_t gpu_index;
	unsigned long affinity_mask;
	bool found = false;

	if (!mvgal_logical_device)
		return -ENODEV;

	/*
	 * The user passes a GPU index in args->gpu_index and a CPU affinity mask
	 * in args->affinity_mask.  We set the CPU affinity for the NUMA node of
	 * the target GPU so that memory allocations and thread scheduling bias
	 * toward the same NUMA node as the GPU.
	 */
	gpu_index = args->gpu_index;
	affinity_mask = (unsigned long)args->affinity_mask;

	mutex_lock(&mvgal_logical_device->gpu_lock);
	list_for_each_entry(gpu, &mvgal_logical_device->gpu_list, node) {
		if (gpu->gpu_index == gpu_index) {
			found = true;
			/*
			 * Store the user-requested affinity mask on the GPU device
			 * so that memory and scheduling subsystems can honor it.
			 */
			gpu->cpu_affinity_mask = affinity_mask;
			pr_info("MVGAL: GPU %u affinity set to 0x%lx (NUMA node %d)\n",
				gpu_index, affinity_mask, gpu->numa_node);
			break;
		}
	}
	mutex_unlock(&mvgal_logical_device->gpu_lock);

	if (!found)
		return -EINVAL;

	return 0;
}
EXPORT_SYMBOL_GPL(mvgal_ioctl_set_gpu_affinity);

/*
 * Vendor registration — IDR-based dynamic table.
 * Vendor modules call mvgal_core_register_vendor() at module_init time.
 */

int mvgal_core_register_vendor(enum mvgal_vendor_id id, const struct mvgal_vendor_ops *ops)
{
	int new_id;
	struct mvgal_gpu_device *gpu;
	int bound = 0;

	if (!ops)
		return -EINVAL;
	if (id == MVGAL_VENDOR_UNKNOWN)
		return -EINVAL;

	mutex_lock(&mvgal_vendor_lock);
	new_id = idr_alloc(&vendor_idr, (void *)ops, id, id + 1, GFP_KERNEL);
	mutex_unlock(&mvgal_vendor_lock);

	if (new_id < 0)
		return new_id;

	/*
	 * Vendor modules load after core enumeration. Bind ops onto already
	 * discovered GPUs of this vendor and run init so VRAM/API caps are real.
	 */
	if (mvgal_logical_device) {
		mutex_lock(&mvgal_logical_device->gpu_lock);
		list_for_each_entry(gpu, &mvgal_logical_device->gpu_list, node) {
			if (gpu->vendor != id)
				continue;
			gpu->ops = ops;
			if (ops->init && !gpu->vendor_priv) {
				int iret = ops->init(gpu);

				if (iret < 0) {
					pr_warn("MVGAL: vendor %d init failed for GPU %s: %d\n",
						id, gpu->name, iret);
					gpu->ops = NULL;
					continue;
				}
			}
			bound++;
			pr_info("MVGAL: Bound vendor %d to GPU '%s' (vram=%llu MB)\n",
				id, gpu->name,
				(unsigned long long)(gpu->vram_size >> 20));
		}
		mutex_unlock(&mvgal_logical_device->gpu_lock);

		if (bound)
			mvgal_compute_capability_profile(mvgal_logical_device);
	}

	pr_info("MVGAL: Vendor %d registered (via IDR, bound=%d)\n", new_id, bound);
	return new_id;
}
EXPORT_SYMBOL_GPL(mvgal_core_register_vendor);

void mvgal_core_unregister_vendor(enum mvgal_vendor_id id, const struct mvgal_vendor_ops *ops)
{
	struct mvgal_vendor_ops *found;

	mutex_lock(&mvgal_vendor_lock);
	found = idr_find(&vendor_idr, id);
	if (found == ops)
		idr_remove(&vendor_idr, id);
	mutex_unlock(&mvgal_vendor_lock);
}
EXPORT_SYMBOL_GPL(mvgal_core_unregister_vendor);

const struct mvgal_vendor_ops *mvgal_core_find_vendor_ops(enum mvgal_vendor_id id)
{
	const struct mvgal_vendor_ops *ops;

	mutex_lock(&mvgal_vendor_lock);
	ops = idr_find(&vendor_idr, id);
	mutex_unlock(&mvgal_vendor_lock);

	return ops;
}
EXPORT_SYMBOL_GPL(mvgal_core_find_vendor_ops);

/*
 * PCI hotplug bus notifier — detect GPU add/remove events at the PCI bus
 * level and trigger a topology rescan so the aggregation layer picks up
 * the change without requiring userspace to issue an explicit rescan IOCTL.
 */

static int mvgal_hotplug_callback(struct notifier_block *nb,
				  unsigned long action, void *data)
{
	struct device *dev = data;
	struct pci_dev *pdev;
	int i;

	/* Only process device add/remove events */
	if (action != BUS_NOTIFY_ADD_DEVICE &&
	    action != BUS_NOTIFY_DEL_DEVICE)
		return NOTIFY_DONE;

	if (!mvgal_logical_device)
		return NOTIFY_DONE;

	/* Verify the device is a PCI device we care about */
	if (!dev_is_pci(dev))
		return NOTIFY_DONE;

	pdev = to_pci_dev(dev);

	/* Match against our known GPU PCI ID table (identity only, no binding) */
	for (i = 0; mvgal_gpu_pci_ids[i].vendor != 0; i++) {
		if (pdev->vendor == mvgal_gpu_pci_ids[i].vendor &&
		    pdev->device == mvgal_gpu_pci_ids[i].device)
			break;
	}

	/* Not a GPU we track — ignore */
	if (mvgal_gpu_pci_ids[i].vendor == 0)
		return NOTIFY_DONE;

	if (action == BUS_NOTIFY_ADD_DEVICE) {
		pr_info("MVGAL: GPU hotplug add: %04x:%04x (%s)\n",
			pdev->vendor, pdev->device, pci_name(pdev));
	} else {
		pr_info("MVGAL: GPU hotplug remove: %04x:%04x (%s)\n",
			pdev->vendor, pdev->device, pci_name(pdev));
	}

	/* Rescan topology to pick up the change */
	mvgal_gpu_cleanup_all(mvgal_logical_device);
	mvgal_enumerate_gpus(mvgal_logical_device);
	mvgal_logical_device->topology_generation++;
	atomic64_inc(&mvgal_logical_device->stats.hotplug_events);

	return NOTIFY_DONE;
}

static struct notifier_block mvgal_hotplug_nb = {
	.notifier_call = mvgal_hotplug_callback,
};

int mvgal_hotplug_init(void)
{
	int ret;

	ret = bus_register_notifier(&pci_bus_type, &mvgal_hotplug_nb);
	if (ret) {
		pr_warn("MVGAL: Failed to register PCI bus notifier: %d\n",
			ret);
		return ret;
	}

	pr_info("MVGAL: PCI hotplug notifier registered\n");
	return 0;
}

void mvgal_hotplug_exit(void)
{
	bus_unregister_notifier(&pci_bus_type, &mvgal_hotplug_nb);
	pr_info("MVGAL: PCI hotplug notifier unregistered\n");
}

static int __init mvgal_core_module_init(void)
{
	return mvgal_init();
}

static void __exit mvgal_core_module_exit(void)
{
	mvgal_exit();
}

module_init(mvgal_core_module_init);
module_exit(mvgal_core_module_exit);

MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("AxoGM");
/* MODULE_VERSION() pastes its argument into a string literal rather than
 * expanding it, so it wants a token sequence, and the numbers have to be
 * pasted AFTER they have been expanded. A single stringify level would emit
 * the macro NAMES -- `modinfo mvgal` printed
 * "version: MVGAL_VERSION_MAJOR.MVGAL_VERSION_MINOR.MVGAL_VERSION_PATCH" --
 * so the outer level expands the three numbers and the inner level pastes
 * them. Doing it this way also means the version modinfo reports can no
 * longer fall behind the one the package is built from; it used to be a
 * hand-written literal that said 0.7.13 in a 0.7.14 build. */
#define MVGAL_MODULE_VERSION_TEXT_(major, minor, patch) \
    #major "." #minor "." #patch
#define MVGAL_MODULE_VERSION_TEXT(major, minor, patch) \
    MVGAL_MODULE_VERSION_TEXT_(major, minor, patch)
MODULE_VERSION(MVGAL_MODULE_VERSION_TEXT(MVGAL_VERSION_MAJOR, \
                                         MVGAL_VERSION_MINOR, \
                                         MVGAL_VERSION_PATCH));

/* Import DMA_BUF namespace for dma-buf driver-private symbol resolution.
 * Kernel < 5.14: no MODULE_IMPORT_NS support (RHEL 8, kernel 4.18).
 * Kernel 5.14-6.11: bare form MODULE_IMPORT_NS(DMA_BUF) — macro uses
 *   #ns stringification so passing a string literal would embed quotes.
 * Kernel 6.12+: string form MODULE_IMPORT_NS("DMA_BUF") — MODULE_INFO
 *   no longer stringifies its argument; bare form causes compile error.
 */
#ifdef MODULE_IMPORT_NS
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
MODULE_IMPORT_NS("DMA_BUF");
#else
MODULE_IMPORT_NS(DMA_BUF);
#endif
#endif
