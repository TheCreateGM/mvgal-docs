/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef MVGAL_VERSION_H
#define MVGAL_VERSION_H

#define MVGAL_VERSION "0.7.16"
#define MVGAL_KERNEL_VERSION ""

#endif /* MVGAL_VERSION_H */
